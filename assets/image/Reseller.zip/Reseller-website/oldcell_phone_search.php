<?
      $Type = "Cell_Phone";    //  `non_email_data`.`non_email_data`
      include("./includes/siteData.php");
	  include("./includes/cURL_other_functions.php");
	  include("./includes/dbConnect.php");
	  $_POST["AllPhones"] =  1;
	  $_POST['DoNotCall'] = 1;
 	  extract($_POST);
?><!DOCTYPE html>
  <html lang="en">
<head>
<? include("includes/metas.php"); ?>
 <title><?=$SiteName; ?>: Cell Phone &amp; Texting Numbers &amp; Other Data</title>
  <style type="text/css">
   </style>
     <script src="Scripts/query_scripts.js" type="text/javascript"></script>
  </head>
  <body>
   <? include("includes/header.php"); ?>
   <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" >
    <tr>
	 <td width="5">&nbsp;</td>
     <td  align="center">
	     <div id="divContent" style="">
            <h1>Cell Phone, Texting Numbers and Addresses Search</h1>
		  <div align="center"  class="contenttitlered">
	         SEARCH ANONYMOUSLY,   FREE SELECTS<br />
          "Build Your Database Your Way"
	       </div>
      <!--  content area  -->
	 	      <?
			   if($User_ID)
			   {
				  include("includes/recordCount.php");
			   }
		  ?>
  <!--   <hr /> BEGIN FORM  -->
		  <form method="post" action="<?=SELF; ?>#results"  id="frmSearch"  name="frmSearch"  onsubmit="return CheckForm();">
	<?
	    $submiturl = "$cURL_URL/Cell_Phone_Data_Insides.php";
		$_POST['AllPhones'] = 1;
        $data = GetDatacURL($submiturl, $_POST);
		echo $data;// this is the form contents with all the controls and query parameters
		 include("includes/query_buttons.php");
		?>
		</div><!--  end divContent  -->
	   </td>
	   <td width="5">&nbsp;</td>
	  </tr>
	</table>
	 <? include('includes/footer.php') ?>
 </body>
</html>