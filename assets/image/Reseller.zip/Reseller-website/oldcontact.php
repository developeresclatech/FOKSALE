<?
	    ////////////////////// OPEN DB  ////////////////////////////////////
      include_once("./includes/siteData.php");
      include_once("./includes/dbConnect.php");
     extract($_POST);
?><!DOCTYPE html>
  <html lang="en">
<head>
 <title><?=$SiteName; ?>: Contact Us</title>
<? include("includes/metas.php"); ?> 
<script type="text/javascript">
<!--
    /*  USE inside input element    onkeyup="NextBox(this.id, event);"   id="<?=$phIndex++; ?>_phone"  */
	   function NextBox(boxID, event)
	   {
        if(event.keyCode > 47)   // unprintable characters are all less than 47
		{
        Box = document.getElementsByTagName('input'); 
	    BoxL = Box.length;
		llen = document.getElementById(boxID).value.length;
		maxL = document.getElementById(boxID).maxLength;
		if(llen >= maxL)
		 { 
            for (x=0; x<BoxL; x++ )
            {
				if(boxID == Box[x].id )
				{
                    Box[++x].focus();
					//Box[x].select();
					break;
				}
            }
         }   
		}// key check 
       }
	   ////////////////////// END FUNCTION //////////////////////
//-->
</script>
  <style type="text/css" >
  	   .required
	   {
		  color: red;
		  font-size:19px;          
	   }
	   input[type=text], input[type=password], textarea
		{

			margin:1px;
			margin-right:2px;
			margin-top:2px;
			color:#000000;
		}
		h5
		{
             text-align: center;
			 font-style:italic;
			 font-size: 14pt;
			 color:#FF0011;
		}
		#fsLast label
		{
          font-size: 11pt;
		  font-weight: bold;
		}
		label
		{
			 font-size: 9pt;
			 color:#ffffff;
		}
		b
		{
			 font-size: 9pt;
			 color:#ffffff;
			 font-weight: 800;
	 }
	 #divStatus, #divStatus *
	 {
		 color: brown; 
		 font-size: 14pt; 
		 height: 30px;
	 }
   #divCenter .tail-middle1 #divContentALL #tblContents tr td #frmMail #div_mail #tbl_email tbody tr .contenttitlered h1 {
	color: #000;
}
  </style>
  </head>

<body>
 
<? include("includes/header.php"); ?>

 
 <!--  CONTENT AREA, INSERT GUTS HERE #CCFFCC   -->

   <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" style="background:none;">
	  <tr>
	   <td width="" align="center" ><!--   -->
      <!--   EMAIL  DIV BELOW
		<div class="wide" id="searchContent">  -->
		  	<? 
               extract($_POST);
			   if(isset($sendemail))
			   {
				    /*  require_once('includes/recaptchalib.php');
				  $privatekey = "6LdWlL0SAAAAAAVCWo8zoY24rw8SmueNF3nDjGmO";
				  $resp = recaptcha_check_answer($privatekey, $_SERVER["REMOTE_ADDR"], $_POST["recaptcha_challenge_field"], $_POST["recaptcha_response_field"]);
				  if ($resp->is_valid)   */
                  if(1) 
				  {
					// Your code here to handle a successful verification
					if(($lname != "" || $fname != "") && $comment != "")
					{
						 $headers = "From: \"$SiteName Contact Page\" <a@a.com>\r\nReply-To: ";
						 if($email != "")
							 $headers .= "\"$fname $lname\" <$email>";
						 else
							 $headers .= "\"No Reply\" <a@a.com>";
                         $headers .= "\r\nBCC: $WebmasterEmail"; 

		
						 $subject = "From $SiteName Contact Page:  $fname $lname ($areacode) $phoneExch-$phoneBody"; // placeholder f

						 $body = "E-Mail from $SiteName website ".date("m/d/Y h:i A").": \n\t Name: $fname $lname\n\t Phone: ($areacode) $phoneExch-$phoneBody \n\t Email: $email \n\tMessage: \n\t $comment"; 
						 $to = $SiteEmailFull;
						 if($aff_email)
						 {
							$to .=  "; ".$aff_email;
							$SS = $affiliate-> get_affiliate_company();
							$body .= "\r\n\tFrom Affiliate = $SS";
							//echo $body.$affiliate_id;
						 }
						 $body .= "\n\tFrom IP Address = ".$_SERVER['REMOTE_ADDR'];
						 if($_COOKIE['User_ID'] > 0)
                           $body .= "\nSite   ID = #". $_COOKIE['User_ID'];

						 if($debug)
							echo "<h3>$to</h3>";
						 $body= str_ireplace("\\r\\n", "\n\t", $body);
						// echo $body;
						 $mtest = mail($to, $subject, stripslashes($body), $headers);
						 //echo "<H4>mail($to, $subject, stripslashes($body), $headers)</h4>";
						 if($mtest) //, $headers
						 {
						   $NoReload = 1;
						   $states =  "";
						   $status =  "<span style=\"color: green;\">Mail Sent</span>";
						   if(filter_var($email, FILTER_VALIDATE_EMAIL))
						   {
								$headers  =  "From: $SiteEmailFull \r\nReply-To: $SiteEmailFull";
								$subject = "In Regards to Your  Inquiry to $SiteName";
								$body = "$fname $lname,\nThank you for your inquiry, we will get back to you as soon as possible. We value all our customers.\n-- $SiteName Management.";
								$mtest = mail($email, $subject, stripslashes($body), $headers);
						   }
						 }
						 else
						   $status = "<span style=\"color: red;\">Mail Failed</span>";	  
					}
					else// lacks name and comment
					   $status = "<span style=\"color: red;\">Your must enter your name and a comment</span>";  
			    }// end good recapcha part
			    else  //recaptcha good
			    {
					// What happens when the CAPTCHA was entered incorrectly
					  $status = "<span style=\"color: red;\">The reCAPTCHA wasn't entered correctly. Go back and try it again!</span>";   //<br /> reCAPTCHA said: " . $resp->error."
			    } 

			 }// end handler  
			   else
				 $status = "<span style=\"color: brown;\">&nbsp;</span>"; //default status message  	
	?>
<!--  BEGIN MAIL FORM  -->
<form method="post" action="<?=$_SERVER['PHP_SELF'] ; ?>#status" onsubmit="" name="frmMail" id="frmMail">
   <div  id="div_mail" >
       <h3 class="contenttitlered">Just provide us with your information &amp; we'll get back to you  ASAP</h3>
  <table id="tbl_email" style="" border="0" width="100%" cellpadding="2" cellspacing="2">
   <!--  <caption>Email Contact Form</caption>  -->
   <tbody>
       <tr>
         <td colspan="2" align="center" class="contenttitlered"><h1>&nbsp;</h1>
           <h1>Call Us Toll Free (888) 450-2659</h1>
           <p>&nbsp;</p></td>
         <td rowspan="9" align="center" valign="middle">
              <img  src="images/girl.jpg" alt="Pretty woman" border="0"  title=" We Have Over 200 Million Consumer &amp; Business Email &amp; Postal Addresses for all of US &amp; Canada. " height="220" width="150" />
		 </td>
       </tr>
       <tr>
         <td colspan="2" align="center" class="contenttitlered"> Email Contact Form<br /><span class="formcontent"><span class="required">*</span> These Are Required Fields.</span></td>
	   </tr>
       <tr><!--  width="150"  -->
		<td style="color: rgb(124, 128, 137);" align="right" >
		  Name:<span class="required">*</span></td>
		<td align="left" width="330">
		   <input size="13" name="fname" id="fname" type="text"   value="<?if(!$NoReload) echo $fname  ;?>"/> <input size="13" name="lname" id="lname" type="text"   value="<?if(!$NoReload) echo $lname  ;?>"/>	</td>
	 </tr>

  <tr>
	<td style="color: rgb(124, 128, 137);" align="right" >
	  Email: </td>
	<td align="left">
	    <input size="25" name="email" type="text"  value="<?if(!$NoReload) echo $email  ;?>" />	</td>
</tr>


 <tr>
	<td style="color: rgb(124, 128, 137);" align="right">
	 Phone:</td>
	<td align="left">
	   <span style="color:#ffffff; font-size: 15pt';"><input maxlength="3" size="1" name="areacode" id="areacode" type="text" onkeyup="NextBox(this.id, event);"  value="<?if(!$NoReload) echo $areacode  ;?>"  />-<input maxlength="3" size="1" id="phoneExch" name="phoneExch" type="text"  onkeyup="NextBox(this.id, event);"  value="<?if(!$NoReload) echo $phoneExch  ;?>" /> - <input maxlength="4" size="2" name="phoneBody" id="phoneBody" type="text" onkeyup="NextBox(this.id, event);"   value="<?if(!$NoReload) echo $phoneBody  ;?>" /></span>	</td>
</tr>

<tr>
	<td style="color: rgb(124, 128, 137);" align="right">
	  Message:<span class="required">*</span></td>
	<td align="left">
		 <textarea cols="45" rows="5" name="comment" id="comment"><?if(!$NoReload) echo $comment  ;?></textarea>	</td>
</tr>

<!--  <tr>
	<td colspan="2" align="center">
	 <span style="font-size: 12pt; color: #000000; font-weight: 800;">Recaptcha  Spam Stopper</span><br />
    <script type="text/javascript"  src="http://www.google.com/recaptcha/api/challenge?k=6LdWlL0SAAAAAPrU6yhUKI4Cn71uyoUfMfXX6s10"> </script>
  <noscript>
     <iframe src="http://www.google.com/recaptcha/api/noscript?k=6LdWlL0SAAAAAPrU6yhUKI4Cn71uyoUfMfXX6s10"
         height="300" width="500" frameborder="0"></iframe><br />
     <textarea name="recaptcha_challenge_field" rows="3" cols="40">
     </textarea>
     <input type="hidden" name="recaptcha_response_field"
         value="manual_challenge">
  </noscript>
	</td>
</tr>  -->


    <tr>
     <td colspan="2" align="center">
       <input value="Send" name="sendemail" title="send message" style="width: 63px; height: 26px; color: black; "  type="submit" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input value="Clear" title="clear form" style="width: 63px; height: 26px; color: black;"  type="reset" />    </td> 
   </tr>
  </tbody>
 </table>
 
  

    <div style="" align="center" id="divStatus">
       &nbsp;<?=$status; ?><a name="status"></a>
    </div>  
  </div>
 </form>
<!--</div> end search area -->
    
	  </td>
	  </tr>
	 
       </table><!-- end search table-->	
	 <? include("includes/footer.php"); ?>
	 </body>
</html>