<?
   include("./includes/siteData.php");
   include("./includes/dbConnect.php");
   include("./includes/cURL_other_functions.php");
   include("./includes/customer_profile_inc.php");
   $SiteName ='Get Trusted Advice';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
   <title>
    <?=$SiteName.": "; if($User_ID) echo "Manage"; else echo "Create"; ?> Your Profile</title>
    <? include("includes/metas.php"); include("includes/links.php"); ?>
    <script>
    <!--
        var xmlHttp
        function CheckUsername(username)
        {
         span = document.getElementById("spanCheckUsername") ;
         box = document.getElementById("Username")
        if (username.length==0)
        {
          span.innerHTML="Enter a Username";
          box.select();
          return;
        }
        xmlHttp=GetXmlHttpObject();
        if (xmlHttp==null)
          {
          alert ("Your browser does not support AJAX!");
          return;
          }
        var url="<?=$SiteURL; ?>/AJAX/CheckUsername.php";
        url=url+"?UN="+username;
        url=url+"&sid="+Math.random();
        xmlHttp.onreadystatechange=stateChanged;
        xmlHttp.open("GET",url,true);
        xmlHttp.send(null);
        }

        function GetXmlHttpObject()
        {
         var xmlHttp=null;
         try
         {
          // Firefox, Opera 8.0+, Safari
          xmlHttp=new XMLHttpRequest();
         }
         catch (e)
         {
          // Internet Explorer
          try
            {
            xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
            }
          catch (e)
            {
            xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
          }
         return xmlHttp;
        }

        function stateChanged()
        {
         if (xmlHttp.readyState==4)
         {
            span.innerHTML=xmlHttp.responseText;
            span.style.color ='red';
            if(xmlHttp.responseText !='')
                 box.select();

         }
        }
        var button = '';  // for onsubmit event
            //-->
    </script>
  <script src="./Scripts/customer_profile.js"></script>
  <style>
        h3
        {
             font-size: 14pt;
             color: Olive;
        }
        h5
        {
             text-align: center;
             font-style:italic;
             font-size: 14pt;
        }
        #fsLast label
        {
          font-size: 11pt;
          font-weight: bold;
        }
        .narrowNew   /*  lhs column height  */
        {
            height:6250px;
        }
        b
        {
             font: bold 11pt Tahoma,Arial;
             color:#FFF;
       }
      caption
       {
         font-weight:700;
         font-size: 16pt;
       }
       .cue
       {
         font-weight:700;
         font-size: 8pt;
       }
       .required
       {
          color: red;
          font-size:19px;
       }
       #order
       {
          padding:7px;
       }
       .tdLHS{
        width: 50% !important;
       }
       .tdLHS label{
        color: #000 !important;
        font-size: 18px;
        margin: 6px;
       }
       #tblContents{
         background: #fff !important;
       }
       #tblContents td{
        border-radius: 30px;
       
        padding: 8px;
        border-radius: 30px;
       }
       .reg-form{
        margin: 20px !important;
       }
  </style>
 </head>

<body>
   <? include("includes/newhome_header.php"); ?>



<section class="section section-xs content newcheckbusiness recodesoft">
<div class="container">
<div class="row">
            
<?
    if(!$User_ID)
    {
        echo    "<form method=\"post\" action=\"$_SERVER[PHP_SELF]\" name=\"frmLogin\" id=\"frmLogin\">\n";
      
        include("includes/login.php");
        echo "<hr>\n</form>\n";
    }
?>


<table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" class="style7 border mt-4 mb-4" >
    
    <tr class="reg-form">
      <td  align="center">

        <table width="100%" cellpadding="1" cellspacing="1">
            <tr>
                <td colspan="2" align="center" nowrap="nowrap">
                     <? if($CompMessage!='Ready'){?>
                         <span style="color:<?=$fontColor ;?>; font-size:14pt; background-color: #CCFFCC;">&nbsp;&nbsp;Status: <?=$CompMessage ;?>&nbsp;&nbsp;</span>
                       <? } ?>
                <br>
              </td>
            </tr>
            <tr>
                <td colspan="2"> 
                    <span class="formcontent"><span class="required">*</span> These Are Required Fields.</span>
                  <span class="formcontent">( DO NOT USE  &#39; or Apostrophe. It will be filtered out. )</span>
                </td>
            </tr>
        </table>




    <?  if($User_ID) {       ?>
    
  <form name="frmPassword" id="frmPassword" onsubmit="return changePasswords();" action="<?= $_SERVER['PHP_SELF']; ?>"
    method="post">
    <table width="100%" cellpadding="6" cellspacing="3">
        <tr>
            <td colspan="2">
                <?
                echo "<a href=\"$_SERVER[PHP_SELF]?LO=TRUE\"   style=\"font-size: 12pt; font-weight: 700; \">If not $CompFName $CompLName, you can logout here</a><br>";
                include("includes/recordCount.php");
                echo "<h3>You Can Update Your Profile or Change your Password Below</h3>";
                ?>
            </td>
        </tr>
        <tr>
            <td class="tdLHS" width="40%">
                <label for="username">Username:<span class="required">*</span></label><br>
                <span class="cue">(Can not be changed)</span>
                <input type="hidden" name="User_ID" id="User_ID" value="<?= $User_ID; ?>">
                <input type="hidden" name="CompanyName" id="CompanyName" value="<?= $SiteName; ?>">
                <input type="hidden" name="Username" id="Username" value="<?= $Username ?>">
            </td>
            <td class="tdRHS"> &nbsp;&nbsp; <span style=\"font-size: 12pt;\"><?= $Username ?></span>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <hr>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <h3>Change Your Password Here:</h3>
                <hr>
            </td>
        </tr>
        <tr>
            <td class="tdLHS"><label for="CPassword">New Password Here:<span class="required">*</span></label><br><span
                    class="cue">(6 -16 letters and numbers)</span></td>
            <td class="tdRHS"><input type="password" class="form-input" name="CPassword" id="CPassword" maxlength="16"
                    size="12" value="" autocomplete="off"></td>
        </tr>
        <tr>
            <td class="tdLHS"><label for="XCPassword">Confirm NEW Password:<span class="required">*</span></label></td>
            <td class="tdRHS"><input type="password" class="form-input" name="XCPassword" id="XCPassword" maxlength="16"
                    size="12" value="" autocomplete="off"></td>
        </tr>
        <tr>
            <td class="tdLHS"><label for="CCheckPassword">Confirm OLD Password: <span class="required">*</span></label>
            </td>
            <td class="tdRHS"><input type="password" class="form-input" name="CCheckPassword" id="CCheckPassword"
                    maxlength="16" size="12" value="" autocomplete="off"></td>
        </tr>

        <tr>
            <td class="tdLHS"><label for="subChangePW" class="">Change Password Here:</label></td>
            <td class="tdRHS"><input type="submit" class="form-input" name="subChangePW" id="subChangePW" maxlength="16"
                    size="12" value="Change Password" onclick="button = 'changePW';" autocomplete="off"></td>
        </tr>

        <tr>
            <td colspan="2">
                <hr>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <h3>Edit Your Profile Here:</h3>
                <hr>
            </td>
        </tr>
    </table>
</form>



<form name="frmCompData" id="frmCompData"  onsubmit="return checkData();" action="<?=$_SERVER['PHP_SELF']; ?>"  method="post">
    <input type="hidden" name="User_ID" id="User_ID"  value="<?=$User_ID ;?>">
    <input type="hidden" name="CompanyName" id="CompanyName"  value="<?=$SiteName ;?>">
    <input type="hidden" name="Username" id="Username"  value="<?=$Username ?>">
<?       
} else {     //returning user above, new one below ?>
    <form name="frmCompData" id="frmCompData"  onsubmit="return checkData();" action="<?=$_SERVER['PHP_SELF']; ?>"  method="post">


    <table width="100%" cellpadding="6" cellspacing="3" class="mt-4">
    <tr>
        <td colspan="2">
            <h1 class='redbig'>Create A Profile</h1>
            <input type="hidden" name="User_ID" id="User_ID"  value="<?=$User_ID ;?>">
            <input type="hidden" name="CompanyName" id="CompanyName"  value="<?=$SiteName ;?>">
        </td>
    </tr>

    <tr>
        <td class="tdLHS" width="40%"><label for="username">Username:<span class="required">*</span></label><br><span class="cue">(7 -16 letters, "_",  and numbers ONLY. Must be unique)</span></td>
        <td class="tdRHS"><input type="text" name="Username" id="Username" class="form-control" maxlength="16" size="14" onblur="CheckUsername(this.value);"></td>
    </tr>
    <tr>
        <td colspan="2"><span id="spanCheckUsername"></span></td>
    </tr>
    <tr>
        <td class="tdLHS"><label for="CPassword"><? if(!$User_ID) echo 'Please Create Password:' ; else echo 'New Password Here:'; ?><span class="required">*</span></label><br>
            <span class="cue">(6 -16 letters and numbers)</span>
        </td>

        <td class="tdRHS"><input  type="password"  name="CPassword" id="CPassword" maxlength="16" size="12" value=""  class="form-control" autocomplete="off"></td>
    </tr>
    <tr>
        <td class="tdLHS"><label for="XCPassword">Confirm NEW Password:<span class="required">*</span></label></td>
        <td class="tdRHS"><input type="password"  name="XCPassword" id="XCPassword"  maxlength= "16" size="12" value="" class="form-control"  autocomplete="off"></td>
    </tr>
</table>
<?   }  ?>


    <table width="100%" cellpadding="6" cellspacing="4">
       <tr>
            <td class="tdLHS"><label for="CompName" class="optional">Company Name:</label></td>
            <td class="tdRHS"><input type="text"  class="longtext form-control" name="CompName" id="CompName" maxlength="60" size="35" value="<?=$CompName; ?>"></td>
       </tr>

       <tr>
            <td class="tdLHS"><label for="CompFName">First &amp Last Name: <span class="required">*</span></label></td>
            <td class="tdRHS"><input type="text"  name="CompFName" id="CompFName" class="form-control"  maxlength="30" size="12" value="<?=$CompFName; ?>">&nbsp;&nbsp;
           <input  type="text" name="CompLName" id="CompLName"   maxlength="30" size="15" value="<?=$CompLName; ?>" class="form-control"></td>
       </tr>

       <tr>
            <td class="tdLHS"><label for="CompAddress1">Address:</label></td>
            <td class="tdRHS"><input  type="text" class="longtext form-control"   class="form-control" name="CompAddress1" id="CompAddress1" maxlength="60" size="25" value="<?=$CompAddress1; ?>"></td>
       </tr>

       <tr>
            <td class="tdLHS"><label for="CompCity">City:</label></td>
            <td class="tdRHS"><input  type="text" class="longtext form-control" class="form-control"  name="CompCity" id="CompCity" maxlength="60" size="25" value="<?=$CompCity; ?>"></td>
       </tr>

       <tr>
            <td class="tdLHS"><label for="states">State or Province:</label><br><small>(USA &amp; Canada)</small></td>
            <td class="tdRHS"><? include("includes/US_states_CA_provs.php"); ?></td>
       </tr>

        <tr id="tblProvince" style="visibility: hidden;">
            <td class="tdLHS"><label for="CompProvince">Province:</label><br><small>(Outside USA &amp; Canada)</small></td>
            <td class="tdRHS"><input class="form-control" type="text" name="CompProvince" id="CompProvince" maxlength="48" size="25" value="<?=$CompProvince; ?>"></td>
        </tr>

        <script>
        <!--
           function showProvince(country)
           {
             if(country != "US" && country != "CA")
                 document.getElementById('tblProvince').style.visibility='visible';
             else
                 document.getElementById('tblProvince').style.visibility='hidden';
           }
        //-->
        </script>

        <tr>
            <td class="tdLHS"><label for="CompCountry">Country:</label></td>
            <td class="tdRHS"><? include("includes/country.php"); ?></td>
        </tr>
        <script>
        <!--
            showProvince(document.frmCompData.CompCountry.value);
        //-->
        </script>
        <tr>
            <td class="tdLHS"><label for="CompZip">Zip or Postal Code:</label></td>
            <td class="tdRHS"><input class="form-control" type="text" name="CompZip"  id="CompZip" maxlength="7" size="5" value="<?=$CompZip; ?>" onkeyup="NextBox(this.id, event);">
            <input type="text"  name="CompPlus4"  class="form-control" id="CompPlus4"  maxlength="4" size="4" value="<?=$CompPlus4; ?>" onkeyup="NextBox(this.id, event);"></td>
        </tr>

        <tr>
            <td class="tdLHS"><label for="CompEmail">Email Address:<span class="required">*</span></label></td>
            <td class="tdRHS"><input class="form-control" type="text" class="longtext" name="CompEmail" id="CompEmail" maxlength="50" size="30" value="<?=$CompEmail; ?>"></td>
        </tr>
        <tr>
            <td class="tdLHS"><label for="XCompEmail">Re-enter Email Address: <span class="required">*</span></label></td>
            <td class="tdRHS"><input class="form-control" type="text"  class="longtext" name="XCompEmail" id="XCompEmail" maxlength="50" size="30" value="<?=$XCompEmail; ?>"></td>
        </tr>
        <tr>
        <td class="tdLHS">
            <?
            if($User_ID)
            {
                $CompExc = substr($CompPhone,0,3);
                $CompBody = substr($CompPhone,3,4);
                }
            ?>
            <label for="CompPhone">Telephone Number: <span class="required">*</span></label>
        </td>
        <td class="tdRHS"> 
            <table width="" cellpadding="3" cellspacing="3">
                <tr>
                    <td style="font-size:15pt;">(</td>
                    <td style="width: 20%;">
                        <input class="form-control" type="text" name="CompAreaCode"  id="CompAreaCode" maxlength="3" size="2" value="<?=$CompAreaCode; ?>" onkeyup="NextBox(this.id, event);"></td>
                    <td style="font-size:15pt;">)</td>
                    <td style="width: 20%;">
                        <input class="form-control" type="text" name="CompExc" id="CompExc"   maxlength="3" size="2" value="<?=$CompExc; ?>" onkeyup="NextBox(this.id, event);"></td>
                    <td style="width: 5%; font-size:15pt;">-</td>
                    <td style="width: 20%;">
                        <input class="form-control" type="text" name="CompBody" id="CompBody"   maxlength="4" size="3" value="<?=$CompBody; ?>" onkeyup="NextBox(this.id, event);"></td>
                    <td style="width: 5%; font-size:15pt;">xx&nbsp;</td>
                    <td style="width: 20%;">
                        <input class="form-control" type="text" name="CompExt" id="CompExt" size="1"   maxlength="6" value="<?=$CompExt;?>"></td>
                </tr>
            </table>
        </td>
       </tr>

        <tr>
            <td class="tdLHS"><label for="CompURL" class="optional">Company Web Site:</label></td>
            <td class="tdRHS"><input class="form-control" type="text" class="longtext"  name="CompURL" id="CompURL" maxlength="60" size="40" value="<?=$CompURL; ?>"></td>
        </tr>


 <? if($User_ID)  { ?>
        <tr>
            <td class="tdLHS"><label for="CheckPassword">Enter Current Password: <span class="required">*</span></label></td>
            <td class="tdRHS"><input class="form-control" type="password"  name="CheckPassword" id="CheckPassword"  maxlength= "24" size="12"  autocomplete="off" value="<?=$CheckPassword; ?>"></td>
        </tr>
 <? } else {   ?>
        <tr>
            <td class="tdLHS"><label for="txtSpam">Anti Robot Prompt <?=$antiSpamQuestion ;?> <span class="required">*</span></label></td>
            <td class="tdRHS"><input class="form-control" type="text"  name="txtSpam" id="txtSpam"  maxlength= "24" size="40" value="<?=$txtSpam; ?>" required placeholder="<?=$antiSpamQuestion ;?>"></td>
        </tr>
 <? } ?>
        <tr>
            <td class="tdLHS"><label for="cmdCompData"><? if($User_ID) echo "Edit Profile Here:"; else echo 'Press "Create Profile" Button:'; ?><span class="required">*</span></label></td>
            <td class="tdRHS">
                <input  type="submit" class="formbutton"   name="cmdCompData" id="cmdCompData" accesskey="c" title="or alt-c"  style="    padding: 14px 65px;
                    font-size: 17px;
                    border: 1px solid #fff;
                    color: #fff;
                    background-color: #000;
                    border-radius: 35px;
                    font-weight: 600;
                    margin: 55px;
                    "  value="<? if($User_ID) echo "Edit Profile"; else echo "Create Profile"; ?>"></td>
        </tr>
  <?
      if($User_ID)
      {   //  when customer is active disabled="disabled"
        $RecordsAvailable = checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID);
        $RecordsCredit =  checkUserPOSCredits($Reseller_UN, $Reseller_ID, $User_ID);
        $ActualRecordsDebit = $RecordsCredit -  $Balance;
     ?>
        <tr>
            <td colspan="2"><hr><h3>Your Account Records &amp; Status:</h3><hr></td></tr>
        <tr>
            <td class="tdLHS"><label> Records Purchased:</label></td>
            <td class="tdRHS"><?=number_format(intval($RecordsCredit)); ?></td>
       </tr>

        <tr>
            <td class="tdLHS"><label> Records Downloaded:</label></td>
            <td class="tdRHS"><?=number_format(intval($ActualRecordsDebit)); ?></td>
        </tr>
        <tr>
            <td class="tdLHS"><label> Records Available:</label></td>
            <td class="tdRHS"><?=number_format(intval($RecordsAvailable)); ?></td>
        </tr>

        <tr>
            <td class="tdLHS"><label for="cmdHistory"> Your Export File History:</label></td>
            <td class="tdRHS"><input class="form-control" type="button"  name="cmdHistory" id="cmdHistory"  value="View Your Export File History" onclick="location='your_export_file_history.php';" title="takes you to another page with a list and description of all files you have ordered so far on this account"></td>
        </tr>
      <? } else {  ?>
       <tr>
            <td align="text-center" colspan="2">You will receive a very important email from us at  <?=$SiteEmailFull ;?> within 2 minutes from when you  create a data account  with us so therefore  please add our email address,  <?=$SiteEmailFull ;?>,  to your permit email address list if you have an email spam blocker in place.
            </td>
        </tr>
       <? } ?>
        <tr>
            <td  align="center" colspan="2"><div align="center"> <b class="violet">Get an Online Data Count Query</b> <br>
                <a href="your_export_file_history.php" class="cblink">Your Export File History</a> |
                <a href="consumer_records_search.php" class="cblink">Consumer Data</a> | <a href="business_records_search.php" class="cblink"  >Business Data</a><br>
                &nbsp;&nbsp; </div>
            </td>
        </tr>
        </table>

     </form>
    <!--   </div>end contents div -->
</td>

     </tr>
    </table><!--  end contents table-->
    </div><!--  end content  -->
    </div>

</form>



</div></div>



     <? include('includes/newFooter.php') ?>
    </div>
  </body>
</html>