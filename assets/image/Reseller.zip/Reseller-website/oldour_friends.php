<?
	    ////////////////////// OPEN DB  ////////////////////////////////////
      include_once("./includes/siteData.php");
      include_once("./includes/dbConnect.php");
     extract($_POST);
?><!DOCTYPE html>
  <html lang="en">
<head>
 <title><?=$SiteName; ?>: Our Friends</title>
<? include("includes/metas.php"); ?> 

  <style type="text/css" >
  	   .required
	   {
		  color: red;
		  font-size:19px;          
	   }
	   input[type=text], input[type=password], textarea
		{

			margin:1px;
			margin-right:2px;
			margin-top:2px;
			color:#000000;
		}
		h5
		{
             text-align: center;
			 font-style:italic;
			 font-size: 14pt;
			 color:#FF0011;
		}
		#fsLast label
		{
          font-size: 11pt;
		  font-weight: bold;
		}
		label
		{
			 font-size: 9pt;
			 color:#ffffff;
		}
		b
		{
			 font-size: 9pt;
			 color:#ffffff;
			 font-weight: 800;
	 }
	 #divStatus, #divStatus *
	 {
		 color: brown; 
		 font-size: 14pt; 
		 height: 30px;
	 }
   </style>
  </head>

<body>
 
<? include("includes/header.php"); ?>

 
 <!--  CONTENT AREA, INSERT GUTS HERE #CCFFCC   -->

   <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" style="background:none;">
	  <tr>
	   <td width="" align="left" ><!--   -->
    <fieldset style="width: 85%;">
     <legend style="font-size:14pt; font-weight:800;">Local Businesses</legend>
      <ul>
  <?
	 function GetDatacURL($submiturl, &$arrData)
	{
		if(is_array($arrData))
           //$postdata = jdf_build_query( $arrData);//for fucking godaddy bs
	       $postdata = http_build_query( $arrData); //for fucking PHP 5
		$ch = curl_init(); /// initialize a cURL session
		curl_setopt ($ch, CURLOPT_URL,$submiturl);  //live server
		curl_setopt ($ch, CURLOPT_HEADER, 0);
		curl_setopt ($ch, CURLOPT_POST, 1);
		curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);

		//Un comment the next line to write the response to the rates and services request to a file.
		//curl_setopt ($ch, CURLOPT_FILE, $fp);
		$data = curl_exec ($ch);
		if (curl_errno($ch))
		{
			  return curl_error($ch);
		}
		else
			return $data;
  	  curl_close ($ch);
	}// END function GetDatacURL($submiturl)

	$Array = ARRAY("Type"=>"marketing", "URL" => str_replace("www.", "", $_SERVER['SERVER_NAME']));
     echo GetDatacURL("http://highpeaksbyway.com/nyroutesSharedFiles/linksServer.php", $Array);
?>

    </ul>
  </fieldset>
    
	  </td>
	  </tr>
    </table><!-- end search table-->	
	 <? include("includes/footer.php"); ?>
	 </body>
</html>