<?
      $Type = "Non_Email_Consumer";    //  `non_email_data`.`non_email_data`
      include("./includes/siteData.php");
	  include("./includes/cURL_other_functions.php");
	  include("./includes/dbConnect.php");
 	  extract($_POST);
	    ////////////////////// OPEN DB  ////////////////////////////////////
?><!DOCTYPE html>
  <html lang="en">
<head>
 <title><?=$SiteName; ?>: Mail Out Data with 380 Fields</title>
<? include("includes/metas.php"); ?>
  <style>

   </style>
	 <script type="text/javascript">
	 <!--
	    var button = "jack";
	 function CheckFormX(subCounties)
	 {
	  x = document.forms[0];
	  var errMessage;
	  GoStates = false;
	   if(  x.optUS.checked ==  true)
			  GoStates = true;
	  //if(document.getElementById('US_CAN_ALL').value != '')// added 12/17/2009 for new select box for US/Can
      else
	  {
	      chkBoxes  = x.elements;   //the checkboxes for states and provinces
		  for(u = 2; u < 54; u++)// go through all the radios for US/Can and checkboxes for states and provinces
		  {
			  if(chkBoxes[u].checked == true)
			  {
				  GoStates = true;
				  break;
			  }
		  }
	  }
	  if(GoStates == false)
	  {
		 alert('You Must Select a State or check the All US radio button!');
		 x.states1.focus(); // puts focus on Alabama checkbox
		 return false;
	  }
	 }
	//Disables state boxes when a country search is selected
	 function DisableStatesX()
	 {
	  x = document.frmSearch;
	  chkBoxes  = x.elements;
	  for(u = 2; u < 54; u++)// go through  checkboxes for states and provinces
	  {
		  chkBoxes[u].disabled = true;
		  chkBoxes[u].style.backgroundColor = "#FF4444";
		  //chkBoxes[u].style.color = "#FF4444";

	   }
	 }

	//Enables state boxes when a country search is selected
	 function EnableStatesX()
	 {
	  x = document.frmSearch;
	  chkBoxes  = x.elements;
	  for(u = 4; u < 54; u++)// go through  checkboxes for states and provinces  5 & 68 for the radio buttons
	  {
		  chkBoxes[u].disabled = false;
		  chkBoxes[u].style.backgroundColor = "#FFFFFF";
	   }
	 }

   function onloaderX()
   {
	   if(document.getElementById('optNone').checked == false)
	      DisableStatesX();
	  else
          EnableStatesX();
    }
	 //-->
	 </script>
      <script src="Scripts/query_scripts.js" type="text/javascript"></script>
  </head>
  <body style="">
   <? include("includes/header.php"); ?>
  <div align="center" style=";">
    <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" >
    <tr>
	 <td width="5">&nbsp;</td>
     <td  align="center">
	     <div id="divContent" style="">
		  <div align="center"  class="contenttitlered">
	         SEARCH ANONYMOUSLY,   FREE SELECTS<br />
          "Build Your Database Your Way"
	       </div>
      <!--  content area  -->
	 	      <?
			   if($User_ID)
			   {
				  include("includes/recordCount.php");
			   }
		  ?>
  <!--   <hr /> BEGIN FORM  -->
		  <form method="post" action="<?=SELF; ?>#results"  id="frmSearch"  name="frmSearch"  onsubmit="return CheckFormX();">
		  <h4>Mail Out Data With Over 380 Demographic Fields And Valid Phone Numbers</h4>
	<?
	    $submiturl = "$cURL_URL/nonemailconsumerdata_content.php";
		$_POST["CompID"] = $Reseller_ID;
		$_POST["User_ID"] = $User_ID;
		$_POST["Username"] = $Reseller_UN;
        $data = GetDatacURL($submiturl, $_POST);
		echo $data;// this is the form contents with all the controls and query parameters
		 include("includes/query_buttons.php");
			    /*  if(!$User_ID)
					 include("includes/loginExp.php");   */
		?>
		</div><!--  end divContent  -->
	   </td>
	   <td width="5">&nbsp;</td>
	  </tr>
	</table>
  </div>
	 <? include('includes/footer.php') ?>
 </body>
</html>