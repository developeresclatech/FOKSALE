<?    include("./includes/siteData.php"); $SiteName = 'Get Trusted Advice';?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <title><?=$SiteName; ?>; Consumer and Business Email Address: Terms and Conditions</title>
   <? include("includes/metas.php");  include("includes/links.php"); ?>
	<style type="text/css" title="">
		#collapse_checklink002, #collapse_checklink003 p{
            text-align: left !important;
        }
	</style>
  </head>
 <body>
   <? include("includes/newhome_header.php"); ?>


 <section class="newcheckbusiness" class="text-center">

      <div id="divContent"  align="center"  id="tblContents" >
        <div class="row">
            <div class="col-md-12 text-center">
                <h1>Terms & Conditons</h1>

               
            </div>
        </div>
        <div class="row d-flex flex-sm-column-reverse flex-md-row justify-content-center flex-xs-column-reverse w-100">
            <div
                class="col-md-6 col-lg-8 col-xl-7 offset-lg-0 d-lg-flex justify-content-lg-center align-items-lg-center">
                <ul class="list-group">
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                              
                            </svg>
                            <p class="mx-2 list-text"><?=$SiteName; ?></p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                              
                            </svg>
                            <p class="mx-2 list-text"><?=$SitePhone; ?></p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                              
                            </svg>
                            <p class="mx-2 list-text"><?=$SiteURL; ?></p>
                        </div>
                    </li>
                  
                </ul>
            </div>
            <div class="col-md-6 col-lg-4 d-sm-flex justify-content-sm-center"><img src="/images/search-db-1080.png"
                    width="320px"></div>
        </div>
      </div>




       <div class="container d-flex flex-column justify-content-center align-items-center">
          <div class="wide" id="searchContent">
             <p>Welcome to the <?=$SiteName; ?> (hereinafter "<?=$SiteNameShort; ?>") web site, and Thank You for considering our products. <?=$SiteNameShort; ?> will provide their goods and services to You subject to the following terms and conditions. Please read this information carefully before placing any orders. By placing an order with <?=$SiteNameShort; ?>, You agree to be bound by the following Terms of Sales and Service (Agreement):
            </p>


            <div align="center" id="divButtons">
              <div style="border:2px solid #CCC;   padding-top:5px; padding-bottom:0; font-size:12px">
                  <h3>PRODUCT DESCRIPTIONS:</h3>
              </div>
          </div>



<fieldset id="f2">
    <button class="btn btn-primary mb-3 collapsed" type="button" data-toggle="collapse"
        data-target="#collapse_checklink002" aria-expanded="false" aria-controls="collapse_checklink002">
        <legend>a. Data Products:</legend>
    </button>
    <div class="collapse" id="collapse_checklink002" style="">
        <div class="card card-body">
           <p>Data Products:</p>
          </b><p>i. All data delivered through the <?=$SiteNameShort; ?> network contains complete subscriber information including, but not limited to, subscriber's name, company name, email address, postal address, phone number, fax number, opt-in date and registration plus free selects.<br />
          ii. In the unlikely event that a complaint or complaints are sent to the ISP of an advertiser, <?=$SiteNameShort; ?> will provide, upon request, the complete details to the ISP verifying that the complaint was from a legitimate subscriber or from public information.<br />
          iii. Further, if <?=$SiteNameShort; ?> has purchased data from a Web Property Owner ("Publisher"), or broker, <?=$SiteNameShort; ?> enters into a signed Agreement whereby the Publisher or broker represents that the data was collected in such a manner as to be in full compliance with "Campaign Specifics" and with all applicable state and federal laws including the CAN-SPAM Act of 2003, and with all applicable privacy policies. Such compliance includes, but is not limited to: (1) not having collected this data by e-mail address Harvesting or Dictionary Attacks; and (2) not including the e-mail addresses of recipients who have opted-out of receiving e-mail messages in this data. <br />
          iv. <?=$SiteNameShort; ?> has procedures in place and <?=$SiteNameShort; ?> uses its best efforts to remove any hard bounces from our data. <?=$SiteNameShort; ?> routinely tests the data to ensure deliverability of approximately 75%. However, results may vary regarding bounces and deliverability based on Your own and outsource broadcast methods. <?=$SiteNameShort; ?> accepts no responsibility for the deliverability of Your own and outsource methods data once it is purchased.</p>


        </div>
    </div>
</fieldset>

<fieldset id="f2">
    <button class="btn btn-primary mb-3 collapsed" type="button" data-toggle="collapse"
        data-target="#collapse_checklink003" aria-expanded="false" aria-controls="collapse_checklink003">
        <legend>b. Email Campaign and Delivery Services:</legend>
    </button>
    <div class="collapse" id="collapse_checklink003" style="">
        <div class="card card-body">

            <p>i. <?= $SiteNameShort; ?> will provide clients professional solutions for all of their email marketing
                needs.<br />
                ii. <?= $SiteNameShort; ?> will provide clients with statistics and clicker "prospect" after the campaign
                has been completed.<br />
                iii. <?= $SiteNameShort; ?> will provide tracking reports with full statistics for each email marketing
                campaign including emails delivered, opened, and clicked. <br />
                iv. Client provides mailer and landing web site.<br />
                v. "Unsubscribes" will be processed by <?= $SiteNameShort; ?>.</p>




            <b>
                <p>2. FEES FOR SERVICES:
            </b> For each of the Products described above, the fee will be provided by <?= $SiteNameShort; ?> and paid by
            client at the time the service is ordered.</p>




            <b>
                <p>3. REFUND POLICY AND REPLACEMENT:
            </b> Due to the nature of our product, You agree and acknowledge that <?= $SiteNameShort; ?> maintains a no
            refund policy on all products and services offered. <?= $SiteNameShort; ?> will replace all hard bounces of
            emails that exceeds 75% when using <?= $SiteNameShort; ?>'s deployment services. <?= $SiteNameShort; ?> does
            not guarantee its data if deployed by your own service or an outsource deployment service. If You are
            dissatisfied with any product or service offered by <?= $SiteNameShort; ?> Your exclusive remedy is to
            discontinue use of the service without refund of any kind whatsoever.</p>

            <b>
                <p>4. WARRANTIESdelivered
                <p>6. INDEMNIFICATION:
            </b> You agree to indemnify, defend, and hold harmless <?= $SiteNameShort; ?>, its parents, subsidiaries,
            affiliates, officers, directors, employees, agents, and suppliers, and their respective affiliates,
            officers, directors, employees, and agents, from any claim, action, demand, or damage, including reasonable
            attorney's fees, made by any third party or governmental agency arising out of or related to Your use of any
            service offered by <?= $SiteNameShort; ?> or Your violation of this Agreement, including without limitation,
            claims or suits for libel, violation of rights of privacy or publicity, interference with property rights,
            trespass, violations of Federal or State Law including but not limited to Can-Spam violations, copyright
            infringement, trademark infringement, patent infringement or plagiarism. <?= $SiteNameShort; ?> may, at its
            sole discretion, assume the exclusive defense and control of any matter subject to indemnification by You.
            The assumption of such defense or control by <?= $SiteNameShort; ?>, however, shall not excuse any of Your
            indemnity obligations.</p>
            <b>
                <p>7. FORCE MAJEURE:
            </b> Neither party shall be liable for delays or nonperformance of this Agreement caused by strike, fire or
            accidents, nor shall either party be liable for delay or nonperformance caused by lack of availability of
            materials, fuel or utilities or for any other cause beyond its control.</p>
            <b>
                <p>8. ASSIGNMENT:
            </b> Neither party may assign its rights or obligations under this Agreement without the prior written
            consent of the other party.</p>
            <b>
                <p>9. RELATIONSHIP OF THE PARTIES:
            </b> The parties are independent contracting entities, and there is no partnership or agency relationship
            between them. Further, You may not use the <?= $SiteNameShort; ?> name in Your advertising or marketing as
            the source of Your data without express written permission from <?= $SiteNameShort; ?>.</p>

            <b>
                <p>10. INTENDED FOR USERS OVER 18:
            </b> <?= $SiteNameShort; ?> web site is intended for use by individuals 18 years of age or older only. </p>
            <b>
                <p>11. ENTIRE AGREEMENT:
            </b> Except as modified or supplemented by a writing executed by both parties, the Terms and Conditions
            described herein are the only representations, warranties, and understandings between the parties with
            respect to the products and/or services described herein.</p>
            <b>
                <p>12. DISPUTES:
            </b> In the event of a dispute, You agree to attempt to resolve the dispute by contacting <?= $SiteEmail; ?>
            prior to taking any other action. Failure to contact <?= $SiteNameShort; ?> to attempt a dispute resolution
            prior to taking any other action will result in a breach of this Agreement by You. You hereby waive any
            right to a trial by jury in the event of any controversy or claim relating to this Agreement. This Agreement
            and Your use of the <?= $SiteNameShort; ?> web site are governed by the laws of the State of Pennsylvania,
            and the courts of general jurisdiction located within Allegheny County, Pennsylvania, will have exclusive
            jurisdiction over any and all disputes arising out of, relating to, or concerning Agreement and
            <?= $SiteNameShort; ?>. In addition to the foregoing, in the event of any breach or violation of this
            Agreement, <?= $SiteNameShort; ?> shall be entitled to enforce all of its legal remedies for the breach or
            wrongful activity including, but not limited to, seeking actual damages, the maximum amount of statutory
            damages under applicable statutes and Acts, profits, treble damages, and attorneys' fees and costs. These
            remedies and damages are in addition to the monetary payments described above and/or any amounts otherwise
            due under Agreement.</p>
            <b>
                <p>13. SEVERABILITY:
            </b> If any provision, or portion thereof, of Agreement is held by a court of competent jurisdiction to be
            invalid under any applicable statute or rule of law, the parties agree that such invalidity shall not affect
            the validity of the remaining portions of Agreement and further agree to substitute for the invalid
            provision a valid provision which most closely approximates the intent and economic effect of the invalid
            provisions.</p>
            <b>
                <p>14. HEADINGS:
            </b>The headings of this Agreement are for convenience only and shall not be used to construe the meaning of
            this Agreement.</p>

            <b>
                <p>15. DATABASE PURCHASES AND LEGAL COMPLIANCE:
            </b>You agree that any use of this data will be in compliance with all applicable state and federal laws,
            including, but not limited to, the CAN-SPAM Act of 2003, The Gramm-Leach Bliley Act, FTC Telephone Sales
            Rules, and Your own privacy policies. If using this data to send e-mail messages, such compliance includes,
            but is not limited to: (1) not using forged, false or misleading header information; (2) not using false or
            misleading subject lines; (3) including the sender's physical address (not a P.O. box); (4) clearly
            identifying the e-mail message as an advertisement; (5) providing an opt-out notice with a functioning
            opt-out mechanism via e-mail or the Internet which is operational for at least 30 days after sending the
            message; (6) honoring opt-out notices within 10 business days of receipt of each opt-out request; and (7)
            for e-mail messages with sexually explicit material, including a warning in the subject line and requiring
            an additional step to view the material after opening the message. If the use of this data includes making
            telephone sales calls, such compliance includes, but is not limited to, scrubbing the list against
            government Do Not Call lists. If reselling, sharing, renting or transferring this data, such compliance
            includes, but is not limited to, not reselling, sharing, renting or transferring the e-mail addresses of
            recipients who have opt-ed out of receiving e-mail messages. You agree not to sell, share, rent or transfer
            this data to or with any person or entity which does not agree to use this data in compliance with all
            applicable state and federal laws including, but not limited to, the CAN-SPAM Act of 2003, The Gramm-Leach
            Bliley Act, FTC Telephone Sales Rules, and Your own privacy policies. You agree to indemnify Route 72, its
            clients, owners, officers, partners, members, managers, employees, agents, subsidiaries, and their
            respective successors and assigns, against any and all claims, damages, liabilities, costs and expenses
            (including reasonable attorney's fees) arising from or related to Your breach or alleged breach, or the
            breach or alleged breach of any person or entity to whom You may have sold the data, of the promises and
            obligations herein.</p>
            <b>
                <p>16. PROTECTION OF DATA:
            </b> You agree to follow all applicable state and federal laws concerning the protection and use of personal
            record data including but not limited to The Gramm-Leach Bliley Act and the FTC Telephone Sales Rules and
            Your own data protection policies.</p>
            <p>This Agreement was last revised on February 1, 2011.</p>



        </div>
    </div>
  </div></div>
</fieldset>
</section>

    <? include("includes/newFooter.php"); ?>
 </body>
</html>