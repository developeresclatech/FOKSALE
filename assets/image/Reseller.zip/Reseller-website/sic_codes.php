<?
     include("./includes/siteData.php");
	 include("./includes/dbConnect.php");
	 extract($_POST);
?><html>
<head>
 <title><?=$SiteName; ?>:: List of SICS Codes </title>
  <? include("includes/metas.php"); ?> 
  <style>
	   input[type=text], input[type=password], textarea
		{

			margin:1px;
			margin-right:2px;
			margin-top:2px;
			border:2px solid #7f7f7f;
			background-color: #F2f2f2;
		}
		select
		{
			background-color: #CCCCDD;
		}
		h5
		{
             text-align: center;
			 font-style:italic;
			 font-size: 14pt;
			 color:#FF0011;
		}
		#fsLast label
		{
          font-size: 11pt;
		  font-weight: bold;
		}
		.narrowNew   /*  lhs column height  */
		{
			height:6250px;
        }
		label, *
		{
			 font-size: 9pt;
			 color:#330066;
		}
		b
		{
			 font-size: 9pt;
			 color:#330066;
			 font-weight: 800;
	 }
	 html
	 {
		  background-color: #282828;
     }
   </style>
<!--    <script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
  <script src="Scripts/checkconsumer.js" type="text/javascript"></script>
  <script language="javascript" type="text/javascript" src="Scripts/fadescript.js"></script>  -->
</head>
<body>
   <? include("includes/header.php"); ?>

 	 <table  id="tblContents">
	  <caption style="color: #FFFF66; font-size: 14pt;">List of SICS Codes </caption>
	  <tr>
	   <td width="100">&nbsp;</td>
	   <td width="8000" align="center">
 <!--  CONTENT AREA, INSERT GUTS HERE  -->
         <?php include("includes/sic_codes_table.php"); ?>
<!-- end Content area -->	
	  </td>
	  <td width="100">&nbsp; </td>
	 </tr>
	</table>
</table>
	 <table width="100%" bgcolor="white">
	    <? include('includes/footer.php') ?>
     </table>
</body>
</html>