<?
		$tableName = $tableNameCon;
		$Type = "Consumer";
		include("./includes/siteData.php");
		include("./includes/cURL_other_functions.php");
		include("./includes/dbConnect.php");
		extract($_POST);
		$SiteName = 'Get Trusted Advice';
?>
<!DOCTYPE html>
	<html lang="en">
	<head>
	<title>
		<?=$SiteName; ?>: Search for Consumer Residential Addresses 
	</title>
  <? include("includes/metas.php"); 
     include("includes/links.php"); 
  ?>
  <style type="text/css">
		input[type=text], input[type=password], textarea
		{
			margin:1px;
			margin-right:2px;
			margin-top:2px;
			border:2px solid #7f7f7f;
			background-color: #F2f2f2;
			color:#000000;
		}
		select
		{
		  color:#000000;
		}
		h5
		{
			color: #111111;
			font-family: Arial,Helvetica,sans-serif;
			font-size: 14pt;
			font-style:italic;
		}
		h3 ,h4
		{
			color: #E7A856;
			font-family: Arial,Helvetica,sans-serif;
			font-size: 20px;
			font-weight: bold;
			line-height: normal;
			text-decoration: none;
/*			text-shadow: 1px 1px 1px black;*/
		}
		#fsLast label
		{
			font-size: 11pt;
			font-weight: bold;
		}
		.narrowNew   /*  lhs column height  */
		{
	   	height:6250px;
		}
		caption
		{
		 font-size: 12pt;
		 color:#E7A856;
		}
		b
		{
		 font-size: 9pt;
		 font-weight: 800;
		}
   </style>
   <script src="Scripts/query_scripts.js" type="text/javascript"></script>
  </head>
  <body>
   <? include("includes/newhome_header.php"); ?>

    <section class="newcheckbusiness" class="text-center">
			<div id="divContent"  align="center"  id="tblContents" >
         <div class="container d-flex flex-column justify-content-center align-items-center">
           <div class="row">
              <div class="col-md-12 text-center">
                  <h1>Consumer Optin Email Data Search</h1>
              </div>
           </div>
           <div class="row d-flex flex-sm-column-reverse flex-md-row justify-content-center flex-xs-column-reverse w-100">
              <div class="col-md-6 col-lg-8 col-xl-7 offset-lg-0 d-lg-flex justify-content-lg-center align-items-lg-center">
                 <ul class="list-group">
                      <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                          <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                  width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                  <path
                                      d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                  </path>
                              </svg>
                              <p class="mx-2 list-text">Data Credits don't expire!</p>
                          </div>
                      </li>
                      <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                          <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                  width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                  <path
                                      d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                  </path>
                              </svg>
                              <p class="mx-2 list-text">One credit for one full record!</p>
                          </div>
                      </li>
                      <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                          <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                  width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                  <path
                                      d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                  </path>
                              </svg>
                              <p class="mx-2 list-text">No extra cost to select many criteria!</p>
                          </div>
                      </li>
                      <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                          <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                  width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                  <path
                                      d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                  </path>
                              </svg>
                              <p class="mx-2 list-text">You can require your search results include executives emails.</p>
                          </div>
                      </li>
                      <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                          <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                  width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                  <path
                                      d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                  </path>
                              </svg>
                              <p class="mx-2 list-text">We'll give you extra records to more than cover any bounces!</p>
                          </div>
                      </li>
                 </ul>
              </div>
              <div class="col-md-6 col-lg-4 d-sm-flex justify-content-sm-center">
              	<img src="/images/search-db-1080.png" width="320px">
              </div>
           </div>
       </div>
      
					<?
					 if($User_ID)
					 {
					  include("includes/recordCount.php");
					 }
					?>

					<div class="container d-flex flex-column justify-content-center align-items-center">
			      <div class="wide" id="searchContent">

							<form method="post" action="<?=$_SERVER['PHP_SELF']; ?>#results"  id="frmSearch"  name="frmSearch"  onsubmit="if(button == 'check') return CheckForm(subCounties); else if(button == 'county') return CheckCounties();">
									<div id="divCENTER">
										<?
										$submiturl = "$cURL_URL/newcheckconsumer_Insides.php";
										$data = GetDatacURL($submiturl, $_POST);
										echo $data;
										include("includes/newquery_buttons.php");
										?>
									</div>
							</form>
					  </div>
          </div>
    </section>

   <? include('includes/newFooter.php') ?>
 </body>
</html>