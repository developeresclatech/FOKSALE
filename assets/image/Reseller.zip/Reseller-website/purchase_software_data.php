<?
function GetItemOE($dbhi, $Quantity)
{
    $query = "SELECT * FROM `tblItems` WHERE `Item_Licenses` >= $Quantity AND `Active` > 0  AND `Item_Type` = 'OE'  ORDER BY `Item_Licenses` ASC LIMIT 1  ;  ";
    $results = mysqli_query($dbhi, $query);
    if ($results) {
        //echo $query. mysqli_error($dbhi);
        // echo "NOR = ". mysql_num_rows();
        $data = mysqli_fetch_assoc($results);
        return $data;
    } else
        echo $query . mysqli_error($dbhi);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function GetDatacURL(&$arrData)
{
    $submiturl = "https://www.paypal.com/cgi-bin/webscr";
    if (is_array($arrData))
        //$postdata = jdf_build_query( $arrData);//for fucking godaddy bs
        $postdata = http_build_query($arrData); //for fucking PHP 5
    $ch = curl_init(); /// initialize a cURL session
    curl_setopt($ch, CURLOPT_URL, $submiturl);  //live server
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    //Un comment the next line to write the response to the rates and services request to a file.
    //curl_setopt ($ch, CURLOPT_FILE, $fp);

    //Check to see if this code is on a windows machine or a unix
    $filename = "c:\\windows\\system32\\ca-bundle.crt";
    if (file_exists($filename)) {
        curl_setopt($ch, CURLOPT_CAINFO, "c:\windows\system32\ca-bundle.crt");
        curl_setopt($ch, CURLOPT_CAPATH, "c:\windows\system32\ca-bundle.crt");
        //curl_setopt ($ch, CURL_CA_BUNDLE, "c:\windows\system32\ca-bundle.crt");
    }
    $data = curl_exec($ch);
    if (curl_errno($ch)) {
        return curl_error($ch);
    } else
        return $data;
    curl_close($ch);
}//
////////////////////////////////////////  END function GetDatacURL($submiturl)  //////////////////////////////////////////////////////
include("./includes/siteData.php");
include("./includes/dbConnect.php");
session_start();
extract($_POST);
/*
  CREATE TABLE tblSales (
  SalesID bigint(20) unsigned NOT NULL auto_increment,
  Order_No varchar(128) NOT NULL COMMENT 'The order id forwarded to cc handler, unique',
  Price decimal(12,2) unsigned NOT NULL COMMENT 'Price ',
  ReferenceNo int(11) NOT NULL,
  Description varchar(128) NOT NULL,
  User_ID bigint(20) unsigned NOT NULL COMMENT 'who bought it',
  Completed tinyint(4) NOT NULL COMMENT 'was it paid',
  Error varchar(64) default NULL COMMENT 'Why payment was rejected',
  SalesDate timestamp NOT NULL default CURRENT_TIMESTAMP,
  IPAddress varchar(64) NOT NULL,
  Item_ID bigint(20) unsigned NOT NULL,
  authcode varchar(32) NOT NULL,
  response_reason varchar(64) NOT NULL,
  txn_id varchar(64) NOT NULL,
  CCPayment decimal(12,2) unsigned default NULL COMMENT 'actual payment',
  PRIMARY KEY  (SalesID)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COMMENT='new sales table for software'
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////
function GetItem($Item_ID)
{
    $query = "SELECT * FROM `tblItems` WHERE `Item_ID` = $Item_ID  ;  ";
    $results = mysqli_query($dbhi, $query);
    if ($results) {
        $data = mysqli_fetch_assoc($results);
        return $data;
    } else
        echo $query . mysqli_error($dbhi);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
function GetPayPalID($Item_ID)
{
    $query = "SELECT `hosted_button_id` AS HBID  FROM `tblItems` WHERE `Item_ID` = $Item_ID  ;  ";
    $results = mysqli_query($dbhi, $query);
    if ($results) {
        $data = mysqli_fetch_assoc($results);
        extract($data);
        if ($HBID != "")
            return $HBID;
        else
            return 0;
    } else
        echo $query . mysqli_error($dbhi);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
if (isset($SubCompleteOrder) && $User_ID)//processing loop
{
    if (ctype_digit($CCNumber) && ctype_digit($CCMonth) && ctype_digit($CCYear) && ctype_digit($User_ID)) {
        include("includes/graypay.php");
        extract(GetItem($_SESSION['Item_ID']));
        $Invoice = $User_ID . "_" . date('YmdHis');
        $gw = new gwapi;
        $gw->setLogin($CC_UN, $CC_PW); // LIVE LOGIN
        //$gw->setLogin("demo", "password"); // TEST LOGIN
        $gw->setBilling($CCFName, $CCLName, $CompName, $CCAddress1, $CompAddress2, $CCCity, $states, $CCZip, $CCCountry, $CompAreaCode . $CompPhone, "", $CompEmail, $CompURL);
        $gw->setOrder($Invoice, $Item_Description, $_SERVER['REMOTE_ADDR']);
        $r = $gw->doSale($Item_Price, $CCNumber, $CCMonth . $CCYear, $CCCcv);
        extract($gw->responses);
        if ($response == 1) {
            $Completed = 1;
            $SalesMessage = "Sale Successful: Authorization Code = $authcode";
        } else {
            $Completed = 0;
            $SalesMessage = "Sale Failed: $responsetext";
        }

        $queryI = "INSERT INTO `tblSales`  SET  `Order_No` = '$Invoice', `IPAddress`= '" . $_SERVER['REMOTE_ADDR'] . "',  `Price` = '$Item_Price',  `User_ID` = '$User_ID' , `Item_ID` = '$Item_ID' ,  `Description` = '$Item_Description' , Completed = '$Completed' , ReferenceNo = '$transactionid' , Error = '$responsetext' , authcode = '$authcode ' ;  ";
        $resultsI = mysqli_query($dbhi, $queryI);
        if ($resultsI) {
            $SalesID = mysqli_insert_id($dbhi);
        } else {
            //echo $queryI.mysqli_error($dbhi);
            $SalesMessage .= "<br />Good Sale but local DB error";
        }  //Town News <townnews@optonline.net>
        /*  echo      */
        $gw->sendReceipt($Completed, $responsetext, $MainEmail);  //,  jakefree@verizon.net
    }// end if(ctype_digit($CCNumber) && ctype_digit($CCMonth) && ctype_digit($CCYear) && ctype_digit($User_ID) )
    else
        $SalesMessage = "You have Bad CC Information, check your numbers and  expiration date";

}
$SiteName = 'Get Trusted Advice';

?><!DOCTYPE html>
<html>

<head>
    <title><?= $SiteName; ?>: Purchase Data and Licenses</title>
    <? include("includes/metas.php"); 
    include("includes/links.php");?>
    <style>
        p {}

        label {
            padding-left: 15px;
            padding-bottom: 5px;
            font-size: 11pt;
        }

        #ulOE li,
        .ulOE {
            font-size: 11pt;
        }

        .my_li,
        li {
            padding-left: 30px;
            margin-bottom: 6px;
            list-style-type: none;
        }

        #tdItems strong {
            font-size: 14pt;
        }

        .productName {
            font-size: 13pt;
        }

        .description {
            font-size: 11pt;
        }

        .notes {
            font-size: 9pt;
            font-style: italic;
        }

        .PP {
            color: #928E87;
            font-size: 11pt;
        }
    </style>
    <script type="text/javascript">
        <!--
          //////////////////////////////// BOX JUMPER FUNCTION ////////////////////////////////////////////
          /*  USE inside input element    onkeyup="NextBox(this.id);"   id="phone"  */
        function NextBox(boxID, event) {
            if (event.keyCode > 47) {
                Box = document.getElementsByTagName('input');
                BoxL = Box.length;
                llen = document.getElementById(boxID).value.length;
                maxL = document.getElementById(boxID).maxLength;
                if (llen >= maxL) {
                    for (x = 0; x < BoxL; x++) {
                        if (boxID == Box[x].id) {
                            Box[++x].focus();
                            break;
                        }
                    }
                }
            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        function enable() {
            w = document.frmPayment;
            w.subSelectItem.disabled = false;
            /*  w.subSelectItem2.disabled = false;
          w.subSelectItem3.disabled = false;
          w.subSelectItem4.disabled = false;
          w.subSelectItem5.disabled = false;
          w.subSelectItem6.disabled = false;
          w.subSelectItem7.disabled = false;
          w.subSelectItem8.disabled = false;
          //w.subSelectItem9.disabled = false;
          w.subSelectItem10.disabled = false;  */
        }
        //-->
    </script>
</head>

<body>
    <? include("includes/newhome_header.php"); ?>

    <section class="section section-xs content newcheckbusiness recodesoft">
      <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1>Purchase Your Targeted Opt-In Email, Phone or Other Data, Software Licenses and Reseller Site Plans
                    Here</h1>
                <p>You will be forwarded to PayPal's site, so you may have to over-ride your pop-up blocker. Use the
                    Ctrl key when clicking on the final prompt.</p>
            </div>
        </div>
        <div class="row d-flex flex-sm-column-reverse flex-md-row justify-content-center flex-xs-column-reverse w-100">
            <div
                class="col-md-6 col-lg-8 col-xl-7 offset-lg-0 d-lg-flex justify-content-lg-center align-items-lg-center">
                <ul class="list-group">
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">Data Credits don't expire!</p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">One credit for one full record!</p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">No extra cost to select many criteria!</p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">You can require your search results include executives emails.</p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">We'll give you extra records to more than cover any bounces!</p>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-md-6 col-lg-4 d-sm-flex justify-content-sm-center"><img src="/images/search-db-1080.png"
                    width="320px"></div>
        </div>
      </div>

    <div class="container d-flex flex-column justify-content-center align-items-center">
       <div class="wide" id="searchContent">

        <div class="row1">
            <div class="main">
                <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>#start"
                    id="frmPayment">
                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents">
                        <tr>
                            <td align="center" valign="top" class="p2">
                                <table width="100%" border="0" cellspacing="0" cellpadding="5" style="color:white;">
                                    <tr>
                                        <td align="center" valign="top">
                                            <table width="97%" border="0" cellspacing="0" cellpadding="5"
                                                style="margin:10px;">
                                                <tr>
                                                    <td align="left" valign="top">
                                                        <h3><center>Purchase Plans for our Software and Data Packages</center></h3>
                                                        <p class="productName">( We accept PayPal payments only )</p>

                                                        <p>250 Million US Opt-in Email records; 100% Bounced Data
                                                        Replacement</p>



                                                      <fieldset id="fs2">
																											    <button class="btn btn-primary mb-3 collapsed" type="button" data-toggle="collapse"
																											        data-target="#collapse_checklink01" aria-expanded="false" aria-controls="collapse_checklink01">
																											        <legend>TECH SUPPORT & TRAINING:</legend>
																											    </button>
																											    <div class="collapse" id="collapse_checklink01" style="">
																											        <div class="card card-body">
																											            <p>
																											                Let our techies help you set up your software and give you
																											                one on one personal training; only $25 per hour*. ( *subject
																											                to change without notice). <br />
																											                We will schedule the appointment between you and our
																											                Technical Support Staff after we deliver your software
																											                license
																											            </p>

																											        </div>
																											    </div>
																											</fieldset>


                                                      <fieldset id="fs12">
																											    <button class="btn btn-primary mb-3 collapsed" type="button" data-toggle="collapse"
																											        data-target="#collapse_checklink0001" aria-expanded="false" aria-controls="collapse_checklink0001">
																											        <legend><center>All One Time License Fees Include Updates</center></legend>
																											    </button>
																											    <div class="collapse" id="collapse_checklink0001" style="">
																											        <div class="card card-body">
																											            <?
																											            if (!$User_ID) {
																											                echo "<h3>You must be logged into make a purchase</h3>";
																											                include("includes/loginNew.php");
																											                echo "<hr /><br />\n";
																											            }
																											            ?>

																											        </div>
																											    </div>
																											</fieldset>



                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td align="left" id="tdItems">
                                                        <?
                                                        $queryCL = "SELECT  *  FROM tblCategories   WHERE Cat_Active !=0  ORDER BY ORDERBY, Cat_Name ASC; ";
                                                        $resultsCL = mysqli_query($dbhi, $queryCL);
                                                        if ($resultsCL) {
                                                            while ($dataCI = mysqli_fetch_assoc($resultsCL)) {
                                                                extract($dataCI);
                                                                $d = 0;
                                                                $query = "SELECT * FROM `tblItems` WHERE `Active` = 1 AND  Cat_ID = '$Cat_Type'  AND  ! subscription  ORDER BY `Item_Price`, `Item_Records` ASC  ; ";
                                                                $results = mysqli_query($dbhi, $query);
                                                                if ($results && mysqli_num_rows($results)) {
                                                                    echo "<p class='productName'>$Cat_Name ($Cat_Type)</p><a name='$Cat_Type'></a>
								   <p class='description'>" . stripslashes($Description) . "</p><br />
								  <p class='PP'>Purchase Plans:</p>
								<ul>\n";
                                                                    while ($data = mysqli_fetch_assoc($results)) {
                                                                        extract($data);             //
                                                                        echo "<li><label for=\"Data_" . $Item_ID . "\"><input type=\"radio\" name=\"Items\" id=\"Data_" . $Item_ID . "\" value=\"$Item_ID\"";
                                                                        echo "   onclick='enable();' />" . stripslashes($Item_Description) . " $Item_Price";
                                                                        echo "</label></li>\n";
                                                                    }// end while
                                                                    //echo "<li><input type=\"radio\" name=\"UMamount\" id=\"1\" value=\".5\"  checked='checked' />  50 Cents for 1 Record TEST ONLY </li>\n";
                                                                    echo "\n</ul>\n<br /><hr /><br />"; //end of data only section
                                                                } elseif (mysqli_errno($dbhi))
                                                                    echo "$query  " . mysqli_error($dbhi);
                                                            }
                                                        } elseif (mysqli_errno($dbhi))
                                                            echo "$queryCL  " . mysqli_error($dbhi);
                                                        /////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        
                                                        $d = 0;
                                                        $query = "SELECT * FROM `tblItems` WHERE `Active` = 1 AND  subscription = 1  ORDER BY `Item_Price`, `Item_Records` ASC  ; ";
                                                        $results = mysqli_query($dbhi, $query);
                                                       if ($results && mysqli_num_rows($results)) {
                                                            echo '
                                                            <fieldset id="fs211">
                                                                <button class="btn btn-primary mb-3 collapsed" type="button" data-toggle="collapse"
                                                                    data-target="#collapse_checklink041" aria-expanded="false" aria-controls="collapse_checklink041">
                                                                    <legend>Monthly Subscriptions Plans</legend>
                                                                    <p class="description">Get monthly allotments of records through a subscription plan with Pay Pal</p>
                                                                </button>';

                                                            echo "
                                                            <div class='collapse' id='collapse_checklink041'>
                                                                <div class='card card-body'>";

                                                            while ($data = mysqli_fetch_assoc($results)) {
                                                                extract($data);

                                                                echo "
                                                                <li><label for='AllPack_" . $Item_ID . "'>
                                                                    <input type='radio' name='Items' id='AllPack_" . $Item_ID . "' value='" . $Item_ID . "' onclick='enable();' />
                                                                    $Item_Description
                                                                </label></li>
                                                                <li>&nbsp;</li>\n";
                                                            } // end while

                                                            echo "
                                                                </div>
                                                            </div>"; // end of collapse and card-body divs

                                                        } // end if statement
                                                        elseif (mysqli_errno($dbhi))
                                                            echo "$query  " . mysqli_error($dbhi);
                                                        ?><br />
                                                        <hr /><br />
                                                        <div align="center" id="divButtons">
                                                            <?
                                                            if ($User_ID) {
                                                                echo '
                                                                <div class="collapse" id="collapse_checklink041">
                                                                    <div class="card card-body">
                                                                        <p style="width:168px; border: 2px solid #369; padding: 10px;" title="Purchase selected package or alt p, You must select a package first!">
                                                                            <input type="submit" name="subSelectItem" id="subSelectItem" style="font-size:14pt; font-weight:bold; color:#30F; margin:2px;" value="Purchase Item" accesskey="P" disabled="disabled" />
                                                                        </p>
                                                                    </div>
                                                                </div>';
                                                            }

                                                            else {
                                                                echo "<div style='border:2px solid #CCC;   padding-top:5px; padding-bottom:0; font-size:12px'>
                                                                <h3>You must be logged into make a purchase</h3></div>";
                                                                // include("includes/login.php");
                                                            }
                                                            ?>
                                                        </div>
                                                        <hr /><br />

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td align="left" valign="top">
																										<div style="border:2px solid #CCC;   padding-top:5px; padding-bottom:0; font-size:12px">
																										<h3><center>All One Time License Fees Include Updates</center></h3>
																										</div>
                                                      <fieldset id="f2">
																											    <button class="btn btn-primary mb-3 collapsed" type="button" data-toggle="collapse"
																											        data-target="#collapse_checklink002" aria-expanded="false" aria-controls="collapse_checklink002">
																											        <legend>Use of Stolen Card Security Warning:</legend>
																											    </button>
																											    <div class="collapse" id="collapse_checklink002" style="">
																											        <div class="card card-body">
																											        When purchasing the Internet Protocol (IP)
																											        address of your computer will be seen and if the IP address
																											        is not one
																											        that matches the postal mailing location provided on the
																											        credit card being used, no license or software download
																											        will be issued. Additionally all orders need a phone number
																											        in the geographic area that corresponds to the mailing
																											        address being used on the credit card as security will
																											        contact you to verify that you are placing the order.
																											        Users of stolen credit cards should also understand that the
																											        software unlock codes can be remotely disabled by us.
																											        Additionally if there is an attempt to purchase with a
																											        stolen credit card the IP address of the computer used will
																											        be turned over to authorities
																											        </div>
																											    </div>
                                                      </fieldset>



                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </form>
                <?
                if ($User_ID) {
                    if (isset($subSelectItem)) // 1st click
                    {
                        $_SESSION['Item_ID'] = "";
                        if (ctype_digit($Items)) {
                            if ($Items)
                                extract(GetItem($Items));
                            // echo "<h1>$hosted_button_id</h1>";
                            if ($Item_Price > 0) {
                                $_SESSION['Item_ID'] = $Items;
                                $GoAhead = 1;
                                $querySales = "INSERT INTO `tblSales` SET `Price` = $Item_Price, User_ID = $User_ID, `Item_ID` = $Item_ID, `IPAddress` = '$_SERVER[REMOTE_ADDR]' , `Description` = '$Item_Description'  ;         ";
                                $resutlsSales = mysqli_query($dbhi, $querySales);
                                if (!$resutlsSales)
                                    echo $querySales . mysqli_error($dbhi);
                                else {
                                    $SalesID = mysqli_insert_id($dbhi);
                                    $_SESSION['SalesID'] = $SalesID;
                                    //echo "<h1>id = $SalesID | ".$_SESSION['SalesID']."</h1>";
                                }
                            }
                        }
                    } elseif (isset($subOutlookEnhanced)) // 1st click
                    {
                        $selQuantity = (intval($selQuantity));
                        $_SESSION['Item_ID'] = "";
                        if ($selQuantity > 0) {
                            extract(GetItemOE($selQuantity));
                            //  print_r(GetItemOE($selQuantity));
                            if ($Item_Price > 0) {
                                $GoAhead = 1;
                                $Price = $Item_Price * $selQuantity;
                                $querySales = "INSERT INTO `tblSales` SET `Price` = $Price, `Quantity` = $selQuantity,  User_ID = $User_ID, `Item_ID` = $Item_ID, `IPAddress` = '$_SERVER[REMOTE_ADDR]' , `Description` = '$Item_Description'  ;         ";
                                $resutlsSales = mysqli_query($dbhi, $querySales);
                                $Item_Description = "$selQuantity Outlook Enhanced Licenses at \$$Item_Price a piece";
                                if (!$resutlsSales)
                                    echo $querySales . mysqli_error($dbhi);
                                else {
                                    $SalesID = mysqli_insert_id($dbhi);
                                    $_SESSION['SalesID'] = $SalesID;
                                    //echo "<h1>id = $SalesID | ".$_SESSION['SalesID']."</h1>";
                                    $Item_Price = $Price;
                                }
                            }
                        }
                    } //elseif(isset($subOutlookEnhanced)) // 1st click
                }// if userid
                ?>
                <div style="" id="divPayPal">
                    <form action="https://www.paypal.com/cgi-bin/webscr" method="post" id="frmPayPal" name="frmPayPal">
                        <input type="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif"
                            border="0" name="submit" id="subPayPal" alt="PayPal - The safer, easier way to pay online!"
                            style="display:none;" />
                        <input type="hidden" name="business"
                            value="<?= $PayPalEmail; ?>" /><!--  seller_1315543827_biz@verizon.net  -->
                        <input type="hidden" name="return"
                            value="http://<?= $_SERVER['SERVER_NAME']; ?>/order_status.php?SalesID=<?= $SalesID; ?>" />
                        <input type="hidden" name="cancel_return"
                            value="http://<?= $_SERVER['SERVER_NAME']; ?>/order_status.php" />
                        <input type="hidden" name="cbt" value="Return to <?= $SiteName; ?>" />
                        <input type="hidden" name="invoice" value="Order_<?= $SalesID; ?>" />
                        <input type="hidden" name="item_name" value="<?= $Item_Description; ?>" />
                        <input type="hidden" name="item_number" value="<?= $Item_ID; ?>" />
                        <? if ($subscription) { ?>
                            <input type="hidden" name="cmd" value="_xclick-subscriptions" />
                            <input type="hidden" name="rm" value="2" />
                            <input type="hidden" name="a3" value="<?= $Item_Price; ?>" />
                            <? if (!$Item_Days)
                                $Item_Days = 30; ?>
                            <input type="hidden" name="p3" value="<?= $Item_Days; ?>" />
                            <input type="hidden" name="t3" value="D" />
                            <input type="hidden" name="src" value="1" />
                            <input type="hidden" name="sra" value="1" />
                            <input type="hidden" name="srt" value="26" />
                            <input type="hidden" name="no_note" value="0" />
                        <? } else {  //recurring payments for weekly subscription ?>
                            <input type="hidden" name="cmd" value="_xclick" />
                            <input type="hidden" name="amount" value="<?= $Item_Price; ?>" />
                        <? } ?>
                    </form>
                    <? if ($GoAhead) { ?>
                        <script type="text/javascript">
          <!--
              answer = confirm('Do you want to go ahead to PayPal with this sale, <?= $Item_Description; ?>, for a total of $<?= $Item_Price; ?> ? ');
               if (answer)
                                document.frmPayPal.subPayPal.click();
                            //-->
                        </script>
                    <? } ?>

                </div>
            </div>
        </div>
    </div>
</div>
        </div>
    </div>
  </section>
    <? include("includes/newFooter.php"); ?>
</body>

</html>