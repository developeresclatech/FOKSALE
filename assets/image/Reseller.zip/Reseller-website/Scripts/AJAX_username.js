// part of the AJAX function for the check username feature on store/compdata_Include.php, along with store/CheckUsername.php
var xmlHttp

function CheckUsername(username)
{
if (username.length==0)
{ 
  document.getElementById("spanCheckUsername").innerHTML="";
  return;
}
xmlHttp=GetXmlHttpObject();
if (xmlHttp==null)
  {
  alert ("Your browser does not support AJAX!");
  return;
  } 
var url="includes/CheckUsername.php";
url=url+"?UN="+username;
url=url+"&sid="+Math.random();
xmlHttp.onreadystatechange=stateChanged;
xmlHttp.open("GET",url,true);
xmlHttp.send(null);
} 

function GetXmlHttpObject()
{
 var xmlHttp=null;
 try
 {
  // Firefox, Opera 8.0+, Safari
  xmlHttp=new XMLHttpRequest();
 }
 catch (e)
 {
  // Internet Explorer
  try
    {
    xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
 return xmlHttp;
}

function stateChanged() 
{ 
 if (xmlHttp.readyState==4)
 { 
   document.getElementById("spanCheckUsername").innerHTML=xmlHttp.responseText;
   //document.frmShit.txt1.value= document.frmShit.txt1.value + xmlHttp.responseText;
   //document.frmShit.txt1.select();
 }
}