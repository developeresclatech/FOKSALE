// part of the AJAX function for the check Make feature on store/compdata_Include.php, along with store/CheckModel.php
var xmlHttp
var selID;
function getModels(Make)
{
  if(Make.length==0)
  { 
    return;
  }
  xmlHttp=GetXmlHttpObject();
  if(xmlHttp==null)
  {
  alert ("Your browser does not support AJAX!");
  return;
  } 
	Year = document.getElementById('selYear').value
	var url="AJAX/CheckModel.php";
	url=url+"?Year="+Year;
	url=url+"&Make="+Make;
	url=url+"&sid="+Math.random();
	xmlHttp.onreadystatechange=stateChanged;
	xmlHttp.open("GET",url,true);
	xmlHttp.send(null);
	selID = "Model";
} 
 ////////////////////////////////// END FUNCTION ///////////////////////////////////////
function getMakes(Year)
{
  if(!Year)
  { 
    return;
  }
  xmlHttp=GetXmlHttpObject();
  if(xmlHttp==null)
  {
    alert ("Your browser does not support AJAX!");
    return;
  } 
	var url="AJAX/CheckModel.php";
	url=url+"?Year="+Year;
	url=url+"&GetMakes=1";
	url=url+"&sid="+Math.random();
	xmlHttp.onreadystatechange=stateChanged;
	xmlHttp.open("GET",url,true);
	xmlHttp.send(null);
	selID = "Make";
//	alert(url);
} 
/////////////////////////// END FUNCTION //////////////////////////////////////////////// 
function GetXmlHttpObject()
{
 var xmlHttp=null;
 try
 {
  // Firefox, Opera 8.0+, Safari
  xmlHttp=new XMLHttpRequest();
 }
 catch (e)
 {
  // Internet Explorer
  try
    {
    xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
 return xmlHttp;
}
/////////////////////////// END FUNCTION ////////////////////////////////////////////////
function stateChanged() 
{ 
 if (xmlHttp.readyState==4)
 { 
  if(selID == "Model")
     var S =  document.forms.frmSearch.selModel;
  else
	 var S =  document.forms.frmSearch.selMake;

   cleanout(selID);
   //alert(S.id +' ||\n '+ xmlHttp.responseText);
   eval(xmlHttp.responseText);
 }
}
 ////////////////////////////////// END FUNCTION ///////////////////////////////////////
 function cleanout(box)
 {
  if(box == "Make")
  {
    var selModel =   document.getElementById('selMake');
    while (selModel.length > 1)
    {
      selModel.options[1] = null;
    }//end while
  }
   var selModel =   document.getElementById('selModel');
   while (selModel.length > 1)
   {
      selModel.options[1] = null;
   }//end while
 }