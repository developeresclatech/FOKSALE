//   javascript for Chock's quick pick menu, urh corner of index
//   version 8.11, Netscape compatible, 2/23/2004, eliminated the options.add() method which is incompatible
//   with Netscape
//   modified 12/5/2004, Wood Category added
//   modified 1/13/2005, RR and Wood Fixed so if Size is selected, it will go to appropriate page, and not throw a 404
//   modified 7/19/2005, revised for new style list pages
//   modified 12/18/2009, revised for new website and schema
 ///$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$      
      function fillsel2()//triggered when a material is selected in sel1
      {  
		   d1 = document.forms.frm1.sel1;
		   d2 = document.forms.frm1.sel2;
		   d3 = document.forms.frm1.sel3;   /*  select shortcuts  */
          cleanout();//calls function to empty sel2 of previous entries
		//              error trap if no material selected
        if(d1.selectedIndex == 0)
	     {
			 return;
		 }
//************************************aluminum construction options*****************************************
       else       if(d1.selectedIndex == 1)
        {
           var opt0 = new Option( "All Constructions",  "");
           var opt1 = new Option( "Extruded", "1");
           var opt2 = new Option( "Molded", "2");
           var opt3 = new Option( "Specialty", "3");

           d2.options[0] = opt0;
           d2.options[1] = opt1;
           d2.options[2] = opt2;
           d2.options[3] = opt3;
         }
//***********************************rubber construction options******************************************
     else if(d1.selectedIndex == 2)
      {
            var opt0 = new Option( "All Constructions",  "");
            var opt1 = new Option( "Contour", "1");
            var opt2 = new Option( "Pyramid", "2");
            var opt3 = new Option( "Wedge", "3");
            var opt4 = new Option( "Dblock", "4");

           d2.options[0] = opt0;
           d2.options[1] = opt1;
           d2.options[2] = opt2;
           d2.options[3] = opt3;
           d2.options[4] = opt4;
		   
     }

//**************************************aircraft construction options*************************************
        else   if(d1.selectedIndex == '3')
        {
                 var opt0 = new Option( "All Constructions",  "");   
                 var opt1 = new Option( "Extruded Rubber", "4");
				 var opt2 = new Option( "Molded Rubber", "5");
                /*     var opt3 = new Option( "Specialty", "3");
                 var opt4 = new Option( "Triangular Wood", "4");
                 var opt5 = new Option( "Polygonal Wood", "5");        */  

           d2.options[0] = opt0;
           d2.options[1] = opt1;
           d2.options[2] = opt2;
		    /* d2.options[3] = opt3;
		   d2.options[4] = opt4;
		   d2.options[5] = opt5;  */

         } 

		 	

		

//************************************urethane/wood/plastic construction options****************************************
    else if(d1.selectedIndex == 6) // STEEL CHOCKS
    {
               var opt0 = new Option( "All Constructions",  "0");
               var opt1 = new Option( "Molded   ",  "2");
			   var opt2 = new Option( "Fabricated   ",  "3");
			   var opt3 = new Option( "Railroad   ",  "4");
                d2.options[0] = opt0;
                d2.options[1] = opt1;
                d2.options[2] = opt2;
                d2.options[3] = opt3;
   }
	    

    else if(d1.selectedIndex == 4 )  /////////  urethane
    {
               var opt0 = new Option( "All Constructions",  "0");
               var opt1 = new Option( "Contour   ",  "1");      
			   var opt2 = new Option( "Molded Aircraft", "4");
               d2.options[0] = opt0;
               d2.options[1] = opt1;
               d2.options[2] = opt2;
   }
// railroad chock
    else if(d1.selectedIndex == 5)  /////////  urethane
    {
             var opt0 = new Option( "All RR Constructions",  "4");
            d2.options[0] = opt0;
   }

//****************************************plastic construction options***************************
       else    if(d1.selectedIndex == 8)
        {
           var opt0 = new Option( "All Constructions",  "0");
           var opt1 = new Option( "Contour   ",  "1");      
           d2.options[0] = opt0;
           d2.options[1] = opt1;
        }
// --------------------  WOOD -----------------
       else    if(d1.selectedIndex == 7)
        {
           var opt0 = new Option( "All Constructions",  "0");
           var opt1 = new Option( "Wedge   ",  "1");      
           var opt2 = new Option( "Triangular Aircraft   ",  "3");    
           var opt3 = new Option( "Polygonal Aircraft   ",  "4");    
           d2.options[0] = opt0;
           d2.options[1] = opt1;
           d2.options[2] = opt2;
           d2.options[3] = opt3;
        }
//---------------------------end if-else-------------------------------------------------         
   return; 
 }  
   //*************************************************end function******************************
   //function below body onload event handler---------------------------------------------------
      function dropdownmenu()
	  {
		 cleanout();
         var opt0 = new Option( "Construction",  "0");  
		 d1.selectedIndex = 0;
         d2.options[0] = opt0;
	  }
  //**************************************end function*****************************
  //cleans out sel2 selectbox before it's repopulated 
 function cleanout()
 {
   var d2 = document.forms.frm1.sel2;;  
   var c = 0;
  while ( d2.length > 0 )
  {
      d2.options[0] = null;
 }//end while

  //sets sel3 back to first entry
      document.forms.frm1.sel3.selectedIndex = 0;
      return;
 }   //end function
 //   takes you to chock selection------------------------------------------------------------------

    function navvy(dirlevel)
   {  //all the initial, index = 0, options are invalid choices, so if the index > 0, then a selection has been made
       //drop down box variables
       var dd1 = document.forms.frm1.sel1;        
       var dd2 = document.forms.frm1.sel2;  
       var dd3 = document.forms.frm1.sel3;  
       var strList = '/grandlist.php?';    //jer this may be wrong
	//if button pressed but no material, sel1, is selected, returns with alert   
    if(dd1.selectedIndex == 0)
     {
       alert("You Must Select at least a Material");
	   dd1.focus();
	   return;
     }
   
	strList = '/grandlist.php?Type=1&'; 
    strList = strList + 'Mat=' + dd1.value;

	if(dd2.value !='')
      strList = strList +"&Const="+ dd2.value;
	if(dd3.value !='')
      strList = strList +"&Size="+ dd3.value;	
	
	location = strList ;
}
 //-----------------------------------------------------------------------------------------------------------------