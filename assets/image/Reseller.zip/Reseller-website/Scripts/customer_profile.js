function highLightBox(ID)
{
     v = document.getElementById(ID);
	 v.style.backgroundColor = '#FFCCCC';
	 v.style.borderColor = '#3300FF';
	 return 0;
}
/////////// END FUNCTION /////////////////////////
function checkData()
{
   a = document.frmCompData;
   var errMessage = "You must correct these issues to create or edit your profile:\n";
   var kill = false;
   var t = 0;
   if(!a.User_ID.value)
	     t =  checkPasswords();
   else	if(a.CheckPassword.value.length < 6 || a.CheckPassword.value.length > 16)
	{
        kill = true;
        errMessage += "The Current Password must be between 6 & 16 characters long\n";
        highLightBox('CheckPassword');
	}
   if(t)
        kill = true;
   if(a.Username.value.length < 6 || a.Username.value.length > 16)
	{
        kill = true;
        errMessage += "Username must be between 6 & 16 characters long\n";
        highLightBox('Username');
	}
   var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
  // return emailPattern.test(elementValue);  
   if(!emailPattern.test(a.CompEmail.value))
	{
        kill = true;
        errMessage += "Email Is not in Valid Format\n";
        highLightBox('CompEmail');
	}
   if(a.CompEmail.value != a.XCompEmail.value)
	{
        kill = true;
        errMessage += "Emails Must Match\n";
        highLightBox('XCompEmail');
	}
   if(a.CompFName.value == "" || a.CompLName.value == "")
	{
        kill = true;
        errMessage += "Enter your first and last names\n";
        highLightBox('CompFName');
        highLightBox('CompLName');
	}
    if(kill)
	{
		alert(errMessage);
		return false;
	}
	else
		return true;

}
/////////// END FUNCTION /////////////////////////

function checkPasswords()
{
   a = document.frmCompData;
   var errMessage = "You must correct these issues to register:\n";
   var kill = false;
	if(a.CPassword.value.length < 6 || a.CPassword.value.length > 16)
	{
        kill = true;
        errMessage += "Password must be between 6 & 16 characters long\n";
        highLightBox('CPassword');
	}
   if(a.CPassword.value != a.XCPassword.value)
	{
        kill = true;
        errMessage += "Passwords Must Match\n";
        highLightBox('XCPassword');
	}
    if(kill)
	{
		alert(errMessage);
		return 1;
	}
	else
		return 0;
}
function changePasswords()
{
   a = document.frmPassword;
   var errMessage = "You must correct these issues to change your password:\n";
   var kill = false;
	if(a.CPassword.value.length < 6 || a.CPassword.value.length > 16)
	{
        kill = true;
        errMessage += "New Password must be between 6 & 16 characters long\n";
        highLightBox('CPassword');
	}
   if(a.CPassword.value != a.XCPassword.value)
	{
        kill = true;
        errMessage += "New Passwords Must Match\n";
        highLightBox('XCPassword');
	}
	if(a.CCheckPassword.value.length < 6 || a.CCheckPassword.value.length > 16)
	{
        kill = true;
        errMessage += "Old Password must be between 6 & 16 characters long\n";
        highLightBox('CCheckPassword');
	}
    if(kill)
	{
		alert(errMessage);
		return false;
	}
	else
		return 1;
}
    //////////////////////////////// BOX JUMPER FUNCTION ////////////////////////////////////////////
    /*  USE inside input element    onkeyup="NextBox(this.id, event);"   id="<?=$phIndex++; ?>_phone"  */
       function NextBox(boxID, event)
       {
           //alert(event.keyCode);
        if(event.keyCode > 47)   // unprintable characters are all less than 47
        {
        Box = document.getElementsByTagName('input');
        BoxL = Box.length;
        llen = document.getElementById(boxID).value.length;
        maxL = document.getElementById(boxID).maxLength;
        if(llen >= maxL)
         {
            for (x=0; x<BoxL; x++ )
            {
                if(boxID == Box[x].id )
                {
                    Box[++x].focus();
                    //Box[x].select();
                    break;
                }
            }
         }
        }// key check
       }