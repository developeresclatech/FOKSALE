<?php
  extract($_POST);
  include("./includes/cURL_other_functions.php");
  include("./includes/siteData.php");
  include("./includes/dbConnect.php");
?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
     <title><?=$SiteName; ?>: Saved Queries For <?=$CompName; ?></title>
     <? include("includes/metas.php"); ?>
    <style type="text/css">
    	  /*  *, h1,h2,h3,h4, td{ color:#111111; }  */
		  #divStep{ color:#111111; } 
		  #tblSearch th
		  {
			  color:black;
		  }
    </style>
		 <script type="text/javascript">
		 <!--
			 function checkDownload()
			 {
					  a = document.frmGetOutfile;   
					  xx = a.custNumOfRecords.value;
					  yy = a.txtStep.value;
				      NumOfRecords =   a.hidNumOfRecords.value;
					  xx = parseInt(xx);
					  if(xx < 1 || xx > NumOfRecords || isNaN(xx))
					  {
						  alert('The number of records you entered is not correct, it is either too high, too low or is not a number');
						  a.custNumOfRecords.select();
						  return false;
					  }
					 a.custNumOfRecords.value = xx;

					  if(yy != '')
					  {
						yy = parseInt(yy);
						a.txtStep.value= yy;
						// checks the record offset value
							  if(yy < 1 ||  isNaN(yy) )
							  {
								  alert('The record offset value is not correct, it is too high or low or is not a number');
								  a.select();
								  return false;
							  }
							  else if( (xx + yy) > NumOfRecords)
							  {
								  alert('The sum of the record offset value and records requested value '+ (xx + yy) + ' is greater than the total records available '+ NumOfRecords + ', make one or the other lower.');
								  a.select();
								  return false;
							  }
					  }
					  else
						  yy = "1";
					 return    confirm('Do You Want to Download These '+ xx + ' Records Starting from Record '+  yy   +'? If OK, then your account here will be charged for all the records that you requested.');
			 }
			 ////////////////////////////////////////////////////////////////////////////////////// END FUNCTION //////////////////////////////////////////////////////////////////
			 function EnableSubmit(qid)
			 {
				a = document.frmGetOutfile;
				a.subGetOutFile.disabled = false;
			    a.hidNumOfRecords.value =  document.getElementById(qid).value;
			    a.custNumOfRecords.value =  document.getElementById(qid).value;
			 }
		//-->
		</script>	
  </head>

  <body>	
   <div align="center" style="" id="divMain">  	  
     <?   include("includes/header.php");    ?>
	  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" class="textareacolor" style="border-left:1px solid #a1a1a1; border-right:1px solid #a1a1a1; background-color:#FFF" >
	   <tr>
          <!--  	   <td width="50">&nbsp;</td>  -->
	   <td width="100%" align="center" valign="top">
      <? 
	      include("includes/recordCount.php"); 
        if($User_ID)  
		{ 
		  if(isset($subDeleteRepeat))
		 {
							$submiturl = "$cURL_URL/api/repeat_queries.php";
							$_POST["User_ID"] = $User_ID;
							$_POST["Repeat_ID"] = $Repeat_ID;
							$_POST["subDeleteRepeat"] =  1;
							$deleteStatus =  GetDatacURL($submiturl, $_POST);		
							echo $deleteStatus;
		 }						
		 
		 ?>

			  <div align="center" width="" style="padding:20px;" id="divRepeatQueries">
				<h3>Your Saved Repeat Queries</h3>
			    <h3><?=$deleteStatus  ;?></h3>
			  These are the queries that will be repeated at 2 week intervals and the results will be emailed to you automatically<br />You are allowed three of these at any one time.
			    <form method="post" action="<?=$_SERVER['PHP_SELF'] ; ?>#repeat"  onsubmit="return " name="frmRepeat" id="frmRepeat"><a name='repeat'></a>
				<table width="100%"   id="tblRepeatQueries">
				   <caption></caption>
				   <tr style="font-size:13pt;" valign="top">
					<td>Date Created</td>
					<td>Query</td>
					<td>Original Count</td>
					<td>Delete</td>
				   </tr>
					<? 
							$submiturl = "$cURL_URL/api/repeat_queries.php";
							$_POST["User_ID"] = $User_ID;
							$_POST["GetRepeatStatus"] = 1;
							echo GetDatacURL($submiturl, $_POST);
							//echo $data;
					?>
			  </table>
			   <input type="submit" name="subDeleteRepeat" id="subDeleteRepeat"  style=";" value="Delete Selected Repeat Query"   title="Delete Selected Saved Repeat Query" disabled="disabled" />
			</form>
		  </div>
     <hr />
 	   <table  id="tblContents">
	  <tr>
<!--  	   <td width="50">&nbsp;</td>  -->
	   <td width="100%" align="center" valign="top">
 <!--  CONTENT AREA, INSERT GUTS HERE  -->
 <?   ?>
<form method="post" action=""   name="frmGetOutfile" id="frmGetOutfile" style="background-color: #EEEEEE; color: #111111;"    onsubmit="return checkDownload();">
		<?php
		 		$submiturl = "$cURL_URL/api/customer_queries_api.php";
                $OUT_ARRAY = array("CompID" => $Reseller_ID, "User_ID" => $User_ID, "Username" =>$Reseller_UN );
                $data = GetDatacURL($submiturl, $OUT_ARRAY);
                echo $data;
			   if($Balance >0) {
         ?>
 	                Specify a name for your data export file(letters, numbers, or '_'s only): (opt) <input type="text" name="export_name"  size="20"/><br />
					Change this to a lower value if you don't want all the records in the search: (opt) <input onBlur="document.getElementById('divStep').style.display='block';  document.frmGetOutfile.txtStep.focus();" onChange="document.getElementById('divStep').style.display='block';  document.frmGetOutfile.txtStep.focus();" type="text" name="custNumOfRecords" id="custNumOfRecords"   size="12" value="<?=$NumOfRecords;?>" /><br />
					<div align="center" id="divStep" style="display:none; padding: 2px 20px;">
					  if selecting less than the whole record count, start from this record: (opt) <input type="text" name="txtStep" style=";" id="txtStep"  maxlength=" " size="12"  value="<?=$txtStep ;?>"  /><br />
                      Otherwise you will get the records sorted A to Z by email address from the top of the list.<br />
					  Example you want only 10K records of a 101K count, but starting from the 20,000th record since you already downloaded the first two sets of 10K., you'd enter 10000 in the first box then 20000 in the one above.
					</div>
				  <input type="hidden" name="hidNumOfRecords" id="hidNumOfRecords" />
				 <input type="submit"  value="Download Results"  id="subGetOutFile"  name="subGetOutFile" disabled="disabled" accesskey="g" title="Get the Outfile, or alt-g" /><br />
                 <small>(First, Select one of the Queries Above)</small><!--  <br />
				<input type="button" name="testB" id="testB"  style=";" value="Test Function"  onclick="checkDownload();" />  -->
				<?
				   if(isset($subGetOutFile))
				   {
					   echo "<br /><a href='retrieve_data_files.php' style='color:white;'>Go Here to Download Your File(s)</a><br /><b>It may take a while depending on traffic and size</b>";
						$submiturl = "$cURL_URL/api/outfiles/remote_api_file_interface.php";
						$_POST["CompID"] = $Reseller_ID;
						$_POST["User_ID"] = $User_ID;
						$_POST["Username"] = $Reseller_UN;
						$data = GetDatacURL($submiturl, $_POST);
						echo "<div style='color:black;'>$data <h3>DONE</h3></div>";
				   }
           }// END DISPLAY ONLY IF THEY HAVE A BALANCE
	?>
	       </form>
<!-- end Content area -->
	    </td>
	  </tr>
	</table>
        <a href="your_export_file_history.php"  style="font-size:11pt;">Your Download File History</a>
    </td>
    </tr>
    </table>
    
	 <? include('includes/footer.php') ;?>
 	 </div>
   <?
	      } // end if user id
	      else
		  {
			  echo "\n<div style=\"background-color: white;\">\n<br />&nbsp;&nbsp;<h3>Your must be logged in to use this page</h3>";
			   echo "<form  method=\"post\"  action=\"customers_queries.php\">\n";
			  include('includes/login.php');
			   echo "</form >\n";
			  echo "\n</div>\n";
	     include('includes/footer.php');
		  }
   ?>
  
 </body>
</html>