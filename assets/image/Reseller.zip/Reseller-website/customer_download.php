 <?
 // page for management to see downloads by a chosen user
    include("../includes/dbConnect.php");
   extract($_POST);
   $User_ID = $_GET['User_ID'];
   $Name = $_GET['Name'];

 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title>Customer Download History for #<?=$User_ID.', '.$Name  ;?>: Private</title>
  <meta http-equiv="content-type" content="text/html; charset=windows-1251">
  <link rel="stylesheet" href="css/cssMain.css" type="text/css" />
  <style type="text/css" title="">
  	   body
	   {
		   padding-left:30px;
		   font-family: arial, tahoma, helvetica;
		   font-size:10pt;
	   }
  </style>

 </head>
 
 <body bgcolor="#FFFFFF" leftmargin="30" topmargin="20" >
<!-- imageready slices (0005_red.psd - slices: 03, 04, 05) -->

     <h2>Customer Download History</h2>
       <!--  BEGIN FORM  -->
 <form method="post" action="" name="" id="" onsubmit="">
<?
  
     $query = "SELECT * FROM `tblCustomerDebits` WHERE `User_ID` = '$User_ID' ORDER BY `DatePulled` DESC  ;   ";
     $results = mysql_query($query);
	 if($results)
	 {
        echo "<h2>Customer $Name  #$User_ID Downloads</h2><hr />";
		echo '<table><tr><th width="100">When</th><th width="100">How Many</th><th width="800">Description</th><th>File Name</th></tr>';
		echo "<caption><b>".mysql_num_rows($results)." Downloads</b></caption>";
		while($dataX = mysql_fetch_assoc($results))
		 {	
			extract($dataX);
			echo "<tr valign=\"top\"><td>$DatePulled</td><td>$RecordsDownloaded</td><td><a href=\"SQL_Readout.php?Debit_ID=$Debit_ID\" target=\"_blank\"> $query_description SQL</a></td><th align='left'>$Filename</th></tr>";
			echo '<tr><td colspan="4"><hr /></td></tr>';
            $Total += $RecordsDownloaded;
		 }
		 echo "<tr><td><b>Total Records Downloaded</b></td><td><b>$Total</b></td><td>&nbsp;</td></tr>";
        echo "</table>";
	 }
	 else
	   echo $query.mysql_error().'<br />';     

	  mysql_free_result($results);
      mysql_close($dbh); 
     //   phpinfo();			
  ?>
   </form>	
 </body>
</html>