<?
include("./includes/siteData.php");
include("./includes/dbConnect.php");
?><!DOCTYPE html>
<html lang="en">

<head>
    <title><?= $SiteName; ?>; Consumer and Business Email Addresses: About Us</title>
    <? include("includes/metas.php");
    include("includes/links.php"); ?>
    <style type="text/css">
a.button.button-sm.button-default-outline.button-winona {
    top: 6px !important;
}
.content {
    margin-top: 40px;
}
.imglist img {
    width: 100%;
}
#footer {
    height: 135px;
}
.contenttitlered {
    font-size: 16px;
    font-weight: bold;
    line-height: normal;
    text-decoration: none;
    text-shadow: unset;
}
    </style>
</head>

<body>
    <? include("includes/newhome_header.php"); ?>

    <section class="newcheckbusiness" class="text-center">
        <div id="divContent" align="center" id="tblContents">
            <div class="container d-flex flex-column justify-content-center align-items-center">
                <div class="col-md-12 text-center">
                    <h1 class="content">About us </h1>
                    <p class="content">
                        <?= $SiteName; ?> has been in business over 13 years helping
                        the business owner make money.&nbsp; During that time we learned the more
                        open you are with your customer and by giving them full and complete access
                        to managing their own marketing campaigns the more they trust you.&nbsp; At
                        <?= $SiteNameShort; ?> you have full control of your budget and campaign by
                        building you campaign &ldquo;your way&rdquo; in searching our database <span
                            class="contenttitlered">"Anonymously"</span> and being rewarded with
                        unlimited <span class="contenttitlered">"FREE SELECTS".</span>&nbsp; Yes you
                        save time and money!
                    </p>
                    <p class="content">It&rsquo;s a known fact while most of our competitors keep
                        paying high priced IT people to run <strong class="contenttitlered">Business
                            Data Searches</strong> and <strong class="contenttitlered">Consumer Data
                            Searches</strong> to obtain record counts for their prospective
                        customers, our website allows for the ability to select dozens of socio,
                        economic, and demographics right from this website and get the counts
                        immediately with <span class="contenttitlered">"FREE"</span> selects.&nbsp;
                        No more running around on the phone waiting for counts and prices when you
                        have a change to your database demographics.&nbsp; At <?= $SiteNameShort; ?>
                        you control your time and budget by having access to our 300 Million
                        Consumer and 30 Million Business master database. It&rsquo;s all in your
                        hands.</p>
                </div>


                <div class="row d-flex flex-sm-column-reverse flex-md-row justify-content-center flex-xs-column-reverse w-100">
                     <h1 class="content">Own Your Own Targeted Data versus Renting It!</h1>
                    <p align="left" class="mt-3">
                        <?= $SiteName; ?> allows you to own your opt-in email data, which is better quality than our
                        competitors and is
                    </p>

                    <div
                        class="col-md-6 col-lg-8 col-xl-7 offset-lg-0 d-lg-flex justify-content-lg-center align-items-lg-center">




                        <ul class="list-group">
                            <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                                <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="-32 0 512 512" width="1em" height="1em" fill="currentColor"
                                        style="font-size: 26px;">
                                        <path
                                            d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                        </path>
                                    </svg>
                                    <p class="mx-2 list-text">Highly targeted with 20+ demographics per record</p>
                                </div>
                            </li>
                            <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                                <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="-32 0 512 512" width="1em" height="1em" fill="currentColor"
                                        style="font-size: 26px;">
                                        <path
                                            d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                        </path>
                                    </svg>
                                    <p class="mx-2 list-text">You can use the database as many times as you want</p>
                                </div>
                            </li>
                            <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                                <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="-32 0 512 512" width="1em" height="1em" fill="currentColor"
                                        style="font-size: 26px;">
                                        <path
                                            d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                        </path>
                                    </svg>
                                    <p class="mx-2 list-text">We provide a 100% bounce back replacement guarantee!</p>
                                </div>
                            </li>
                            <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                                <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="-32 0 512 512" width="1em" height="1em" fill="currentColor"
                                        style="font-size: 26px;">
                                        <path
                                            d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                        </path>
                                    </svg>
                                    <p class="mx-2 list-text">We offer full email deployment for a small fee.</p>
                                </div>
                            </li>
                            <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                                <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="-32 0 512 512" width="1em" height="1em" fill="currentColor"
                                        style="font-size: 26px;">
                                        <path
                                            d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                        </path>
                                    </svg>
                                    <p class="mx-2 list-text">We offer full email flyer design for a small fee</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-lg-4 d-sm-flex justify-content-sm-center">
                        <img src="/images/search-db-1080.png" width="320px">
                    </div>
                </div>
            </div>

        <div class="container imglist">
            <h1 align="center" class="content">Opt In Email Marketing means now in real
                    time for the future.</h1>
                    <div class="row mt-5">
                        <div class="col-md-4"><img src="images/about1.jpg"></div>
                        <div class="col-md-4"><img src="images/about2.jpg"></div>
                        <div class="col-md-4"><img src="images/about3.jpg"></div>
                    </div>
                    </div>
            
    </section>

    <? include("./includes/newFooter.php");
    ; ?>
</body>

</html>