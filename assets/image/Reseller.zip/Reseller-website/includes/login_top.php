     <form method="post" action="<?=$_SERVER['PHP_SELF'] ; ?>"   name="frmLoginSmall" id="frmLoginSmall">
	      <table id="tblLoginSmall"  width="162">
		   <!--  <caption style="color:white; font-size:9pt;">Login Here</caption>  -->
		    <tr  valign="middle">
			  <td align="left" height="20">
			    <input type="text" style="height:17px;"  name="frmUsername"  id="frmUsername1" size="12" maxlength = "16">
			  </td>
			  <td align="left">
			    <input type="password"  style="height:17px;"   name="frmCPassword"  id="frmCPassword1" size="12" maxlength = "16">
			  </td>
			  <td>
			      <input type="submit"  name="cmdLogin" id="cmdLogin" value="Login"  accesskey="l"   title="Login to your account" style="height:22px; padding:4px; font-size:12px;">
		<!--   	      <input type="submit"   style="height:20px; width:40px; vertical-align: middle;" name="cmdLogin" id="cmdLogin" value="Login"  accesskey="l"   title="Login to your account" />  -->
             </td>
		  </tr>
		   <tr>
			  <td align="left"> Username</td>
			  <td align="left">Password</td>
			  <td>Login</td>
		  </tr>
		    <tr  valign="middle"> <td colspan="3"><h4><?=$_SESSION['login']   ;?></h4></td></tr>
      </table>
	</form>