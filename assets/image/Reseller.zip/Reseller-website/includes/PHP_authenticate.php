<?
 //$_SESSION['LoggedIn'] = 1;
 if($_SESSION['LoggedIn'] == 1)
 {
	  $welcomeMessage = "<h3>Hello $CompName, welcome to the Customer Management Suite</h3>" ;
	  $_SESSION['LoggedIn'] = 1;
 }
 elseif( $_POST['PHP_AUTH_USER'] != "" && ($_POST['PHP_AUTH_USER'] != PHP_AUTH_USER || $_POST['PHP_AUTH_PW'] != PHP_AUTH_PW))
 {
		 echo "FADDDDDD";
		 $q = "SELECT User_ID, concat(CompFName, ' ',CompLName) AS NAME FROM tblResellerCustomers WHERE Username= '".$Username."' AND User_ID = $User_ID AND Admin > 0 ; ";
		 $r = mysqli_query($dbhi, $q);
		 if($r)
		  @$d = mysqli_fetch_row($r);
		 if($d[0])
		 {
		  $welcomeMessage = "<h3>Hello $d[1], welcome to the Customer Management Suite</h3>" ;
		  $_SESSION['LoggedIn'] = 1;
		 }
		else
		{
		 echo "You need to login with proper username and password to gain access to this page.";
		}
 }
 elseif(($_POST['PHP_AUTH_USER'] == PHP_AUTH_USER && $_POST['PHP_AUTH_PW'] == PHP_AUTH_PW))
 {
     $welcomeMessage = "<h3>Hello $SiteContact, welcome to the Customer Management Suite</h3>" ;
	 $_SESSION['LoggedIn'] = 1;
 }
 //echo "SLIID = ".$_SESSION['LoggedIn'];
 if($_SESSION['LoggedIn'] != 1)  { ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Login to your Site Control Panel</title>
</head>

<body style="width:600px; margin:auto;">
   <form method="post">
       <h2>Login Here</h2>
       <input type="text" name="PHP_AUTH_USER" style=";" id="PHP_AUTH_USER" maxlength="" size="12" value="<?=$_POST['PHP_AUTH_USER'] ;?>" placeholder="Username" /> <input type="password" name="PHP_AUTH_PW" id="PHP_AUTH_PW" value="<?=$_POST['PHP_AUTH_PW'] ;?>" placeholder="password"  /> <input type="submit" name="subLogin" id="subLogin" value="Login" accesskey="L" title="or alt L" />
   </form>
</body>
</html>
<?  exit ; }?>