<? include_once("includes/resetPassword.php"); ?><br />
<style>
    .tabcls {
        border: 1px solid #CCC;
        border-bottom: 3px solid #CCC;
        border-right: 2px solid #CCC;
    }

    .tabcls td {
        padding: 3px;
    }
    .formdes{
/*      border-radius: 28px;*/
      background: #fff !important;
/*      margin: 54px;*/
    }


</style>
<div class="row">
    <div class="col-md-5  border p-4 formdes">
        <h3><strong>If Previously Registered, Login Here </strong></h3>
        <div class="col-md-12">

            <div class="col-md-12">
                <label for="frmUsername">Username<span class="required">*</span>:</label>
            </div>
            <div class="col-md-12">
                <input type="text" name="frmUsername" class="form-control" id="frmUsername" size="15" maxlength="16"
                    tabindex="1" />
            </div>
            <div class="col-md-12">
                <label for="CPassword">Enter Password<span class="required">*</span>:</label>
            </div>
            <div class="col-md-12">
                <input type="password" name="frmCPassword" id="frmCPassword" class="form-control" size="15"
                    maxlength="16" tabindex="2" />
            </div>
            <div class="col-md-12">
                &nbsp;
            </div>
            <div class="col-md-12">
                <input type="submit" class="form-control" value="Login" name="cmdLogin" id="cmdLogin"
                    style="width:100px ;color:#fff; background:#000;" title="Login Here if previously registered" accesskey="p"
                    tabindex="3" />
            </div>
        </div>
    </div>
    <div class="col-md-5  border p-4 offset-md-2 formdes">
        <h3><strong>Lost Your Password? Reset it Here. </strong></h3>

        <div class="col-md-12">
            <div class="col-md-12">
                <label for="frmEmail">Email on File<span class="required">*</span>:</label>
            </div>
            <div class="col-md-12">
                <input type="text" name="frmEmail" id="frmEmail" class="form-control" size="15" maxlength=""
                    tabindex="4" />
            </div>
            <div class="col-md-12">
                <label for="frmUsername2">Or Username<span class="required">*</span>:</label>
            </div>

            <div class="col-md-12">
                <input type="text" name="frmUsername2" id="frmUsername2" class="form-control" size="15" maxlength="16"
                    tabindex="5" />
            </div>

            <div class="col-md-12 mt-4">
                <input type="submit" value="Reset Your Password" name="resetPW" id="resetPW" class="form-control"
                    style="width:180px ;color:#fff; background:#000; border-radius:20px;padding-top:-10px; padding:8px;" title="Reset your password, or alt-z"
                    accesskey="z" tabindex="5" />
            </div>



        </div>
    </div>


</div>

<!-- Modified design on 22-oct-2024 -->
<!-- 
<table width="100%" align="center">
    <tr>
        <td width="55%">
            <table width="304" align="center" class="tabcls">
                <tr>
                    <td align="center" colspan="2">
                        <p><strong>If Previously Registered, Login Here </strong></p>
                    </td>
                </tr>
                <tr>
                    <td width="55%" align="right">
                        <label for="frmUsername">Username<span class="required">*</span>:</label>
                    </td>
                    <td width="45%" align="left">
                        <input type="text" name="frmUsername" class="form-control" id="frmUsername" size="15" maxlength="16" tabindex="1" />
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <label for="CPassword">Enter Password<span class="required">*</span>:</label>
                    </td>
                    <td align="left">
                        <input type="password" name="frmCPassword" id="frmCPassword" class="form-control" size="15" maxlength="16"
                            tabindex="2" />
                    </td>
                </tr>
                <tr>
                    <td align="center" width="26%" height="50">&nbsp;</td>
                    <td align="left">
                      <input type="submit" class="form-control" value="Login" name="cmdLogin" id="cmdLogin"
                            style="width:100px ;color:#000066;" title="Login Here if previously registered"
                            accesskey="p" tabindex="3" />
                    </td>
                </tr>
            </table>
        </td>

        <td width="45%">
            <table width="289" align="center" class="tabcls">
                <tr>
                    <td colspan="2" align="center">
                        <p><strong>Lost Your Password? Reset it Here. </strong></p>
                    </td>
                </tr>
                <tr>
                    <td align="right" width="29%">
                        <label for="frmEmail">Email on File<span class="required">*</span>:</label>
                    </td>
                    <td align="left" width="24%">
                        <input type="text" name="frmEmail" id="frmEmail" class="form-control" size="15" maxlength="" tabindex="4" />
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <label for="frmUsername2">Or Username<span class="required">*</span>:</label>
                    </td>
                    <td align="left">
                        <input type="text" name="frmUsername2" id="frmUsername2" class="form-control" size="15" maxlength="16"
                            tabindex="5" />
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center" height="50">
                        <input type="submit" value="Reset Your Password" name="resetPW" id="resetPW" class="form-control"
                            style="width:180px ;color:#000066; padding-top:-10px" title="Reset your password, or alt-z"
                            accesskey="z" tabindex="5" />
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table> -->

<?= $_SESSION['login']; ?>
</h2>