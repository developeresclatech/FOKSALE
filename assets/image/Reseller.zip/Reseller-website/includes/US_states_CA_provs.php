<select name="states" id="states" class="form-control"> tabindex = "<?=$sti; ?>" style="width:180px; color:black" class="" onchange="CheckCounty(this.value);"> 
 <option value="">Select Your State</option>
 <optgroup label="------- US States: -------" >
 <option value="AL" <? if($states == "AL") echo "selected=\"selected\""; ?> >Alabama(AL)</option>
 <option value="AK" <? if($states == "AK") echo "selected=\"selected\""; ?> >Alaska(AK)</option>
<!--   <option value="AS" <? if($states == "AS") echo "selected=\"selected\""; ?> >American Samoa(AS)</option>  -->
 <option value="AZ" <? if($states == "AZ") echo "selected=\"selected\""; ?> >Arizona(AZ)</option>
 <option value="AR" <? if($states == "AR") echo "selected=\"selected\""; ?> >Arkansas(AR)</option>
 <option value="CA" <? if($states == "CA") echo "selected=\"selected\""; ?> >California(CA)</option>
 <option value="CO" <? if($states == "CO") echo "selected=\"selected\""; ?> >Colorado(CO)</option>
 <option value="CT" <? if($states == "CT") echo "selected=\"selected\""; ?> >Connecticut(CT)</option>
 <option value="DE" <? if($states == "DE") echo "selected=\"selected\""; ?> >Delaware(DE)</option>
 <option value="DC" <? if($states == "DC") echo "selected=\"selected\""; ?> >District of Columbia(DC)</option>
 <option value="FL" <? if($states == "FL") echo "selected=\"selected\""; ?> >Florida(FL)</option>
 <option value="GA" <? if($states == "GA") echo "selected=\"selected\""; ?> >Georgia(GA)</option>
 <!--  <option value="GU" <? if($states == "GU") echo "selected=\"selected\""; ?> >Guam(GU)</option>  -->
 <option value="HI" <? if($states == "HI") echo "selected=\"selected\""; ?> >Hawaii(HI)</option>
 <option value="ID" <? if($states == "ID") echo "selected=\"selected\""; ?> >Idaho(ID)</option>
 <option value="IL" <? if($states == "IL") echo "selected=\"selected\""; ?> >Illinois(IL)</option>
 <option value="IN" <? if($states == "IN") echo "selected=\"selected\""; ?> >Indiana(IN)</option>
 <option value="IA" <? if($states == "IA") echo "selected=\"selected\""; ?> >Iowa(IA)</option>
 <option value="KS" <? if($states == "KS") echo "selected=\"selected\""; ?> >Kansas(KS)</option>
 <option value="KY" <? if($states == "KY") echo "selected=\"selected\""; ?> >Kentucky(KY)</option>
 <option value="LA" <? if($states == "LA") echo "selected=\"selected\""; ?> >Louisiana(LA)</option>
 <option value="ME" <? if($states == "ME") echo "selected=\"selected\""; ?> >Maine(ME)</option>
 <!--  <option value="MH" <? if($states == "MH") echo "selected=\"selected\""; ?> >Marshall Islands(MH)</option>  -->
 <option value="MD" <? if($states == "MD") echo "selected=\"selected\""; ?> >Maryland(MD)</option>
 <option value="MA" <? if($states == "MA") echo "selected=\"selected\""; ?> >Massachusetts(MA)</option>
 <option value="MI" <? if($states == "MI") echo "selected=\"selected\""; ?> >Michigan(MI)</option>
 <option value="MN" <? if($states == "MN") echo "selected=\"selected\""; ?> >Minnesota(MN)</option>
 <option value="MS" <? if($states == "MS") echo "selected=\"selected\""; ?> >Mississippi(MS)</option>
 <option value="MO" <? if($states == "MO") echo "selected=\"selected\""; ?> >Missouri(MO)</option>
 <option value="MT" <? if($states == "MT") echo "selected=\"selected\""; ?> >Montana(MT)</option>
 <option value="NE" <? if($states == "NE") echo "selected=\"selected\""; ?> >Nebraska(NE)</option>
 <option value="NV" <? if($states == "NV") echo "selected=\"selected\""; ?> >Nevada(NV)</option>
 <option value="NH" <? if($states == "NH") echo "selected=\"selected\""; ?> >New Hampshire(NH)</option>
 <option value="NJ" <? if($states == "NJ") echo "selected=\"selected\""; ?> >New Jersey(NJ)</option>
 <option value="NM" <? if($states == "NM") echo "selected=\"selected\""; ?> >New Mexico(NM)</option>
 <option value="NY" <? if($states == "NY") echo "selected=\"selected\""; ?> >New York(NY)</option>
 <option value="NC" <? if($states == "NC") echo "selected=\"selected\""; ?> >North Carolina(NC)</option>
 <option value="ND" <? if($states == "ND") echo "selected=\"selected\""; ?> >North Dakota(ND)</option>
 <option value="OH" <? if($states == "OH") echo "selected=\"selected\""; ?> >Ohio(OH)</option>
 <option value="OK" <? if($states == "OK") echo "selected=\"selected\""; ?> >Oklahoma(OK)</option>
 <option value="OR" <? if($states == "OR") echo "selected=\"selected\""; ?> >Oregon(OR)</option>
 <option value="PA" <? if($states == "PA") echo "selected=\"selected\""; ?> >Pennsylvania(PA)</option>
<option value="PR" <? if($states == "PR") echo "selected=\"selected\""; ?> >Puerto Rico(PR)</option> 
 <option value="RI" <? if($states == "RI") echo "selected=\"selected\""; ?> >Rhode Island(RI)</option>
 <option value="SC" <? if($states == "SC") echo "selected=\"selected\""; ?> >South Carolina(SC)</option>
 <option value="SD" <? if($states == "SD") echo "selected=\"selected\""; ?> >South Dakota(SD)</option>
 <option value="TN" <? if($states == "TN") echo "selected=\"selected\""; ?> >Tennessee(TN)</option>
 <option value="TX" <? if($states == "TX") echo "selected=\"selected\""; ?> >Texas(TX)</option>
 <option value="UT" <? if($states == "UT") echo "selected=\"selected\""; ?> >Utah(UT)</option>
 <option value="VT" <? if($states == "VT") echo "selected=\"selected\""; ?> >Vermont(VT)</option>
 <option value="VA" <? if($states == "VA") echo "selected=\"selected\""; ?> >Virginia(VA)</option>
 <option value="WA" <? if($states == "WA") echo "selected=\"selected\""; ?> >Washington(WA)</option>
 <option value="WV" <? if($states == "WV") echo "selected=\"selected\""; ?> >West Virginia(WV)</option>
 <option value="WI" <? if($states == "WI") echo "selected=\"selected\""; ?> >Wisconsin(WI)</option>
 <option value="WY" <? if($states == "WY") echo "selected=\"selected\""; ?> >Wyoming(WY)</option>
</optgroup>
<optgroup label="------- CA Provinces: -------" >
 <option value="AB" <? if($states == "AB") echo "selected"; ?>>Alberta(AB)</option>
 <option value="BC" <? if($states == "BC") echo "selected"; ?> >British Columbia(BC)</option>
 <option value="MB" <? if($states == "MB") echo "selected"; ?> >Manitoba(MB)</option>
 <option value="NB" <? if($states == "NB") echo "selected"; ?> >New Brunswick(NB)</option>
 <option value="NL" <? if($states == "NL") echo "selected"; ?> >Newfoundland(NL)</option>
 <option value="NT" <? if($states == "NT") echo "selected"; ?> >Northwest Territories(NT)</option>
 <option value="NS" <? if($states == "NS") echo "selected"; ?> >Nova Scotia(NS)</option>
 <option value="NU" <? if($states == "NU") echo "selected"; ?> >Nunavit(NU)</option>
 <option value="ON" <? if($states == "ON") echo "selected"; ?> >Ontario(ON)</option>
 <option value="PE" <? if($states == "PE") echo "selected"; ?> >Prince Edward Island(PE)</option>
 <option value="QC" <? if($states == "QC") echo "selected"; ?> >Quebec(QC)</option>
 <option value="SK" <? if($states == "SK") echo "selected"; ?> >Saskatchewan(SK)</option>
 <option value="YT" <? if($states == "YT") echo "selected"; ?> >Yukon(YT)</option>
</optgroup>
<optgroup label="---- Outside US &amp; Canada: ---" >
 <option value="NO" <? if($states == "NO") echo "selected=\"selected\""; ?> >Not in the USA or Canada</option>
</optgroup>
</select>