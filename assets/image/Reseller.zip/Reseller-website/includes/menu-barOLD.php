         <div class="fleft">
            <ul>
            <li <? if(SELF=="/index.php" || SELF=="/") { echo 'style="display:none;"'; } ?>><a href="index.php" >Home</a></li>
            <li <? if(SELF=="/Aboutus.php") { echo 'style="display:none;"'; } ?>><a href="Aboutus.php" >About</a></li>
            <li <? if(SELF=="/consumer_records_search.php") { echo 'style="display:none;"'; } ?>><a href="consumer_records_search.php"  >Consumer Data</a></li>
			<li <? if(SELF=="/mail_out_records_search.php") { echo 'style="display:none;"'; } ?>><a href="mail_out_records_search.php"  title="with over 380 demographic fields and valid phone numbers" >Telemarketing</a></li>
            <li <? if(SELF=="/business_records_search.php") { echo 'style="display:none;"'; } ?>><a href="business_records_search.php" >Business Data</a></li>
            <li <? if(SELF=="/contact.php") { echo 'style="display:none;"'; } ?>><a href="contact.php">Contact</a></li>
            <li <? if(SELF=="/software.php") { echo 'style="display:none;"'; } ?>><a href="software.php" >Software</a></li>
            <li <? if(SELF=="/purchase_data.php") { echo 'style="display:none;"'; } ?>><a href="purchase_data.php" >Purchase</a></li>
            <li <? if(SELF=="/listen-to-webinar.php") { echo 'style="display:none;"'; } ?>><a href="listen-to-webinar.php">Webinar</a></li>
            <? if($User_ID) { ?>
            <li <? if(SELF=="/customer_profile.php") { echo 'style="display:none;"'; } ?>><a href="customer_profile.php">Manage Profile</a></li>
            <li <? if(SELF=="/retrieve_data_files.php") { echo 'style="display:none;"'; } ?>><a href="retrieve_data_files.php">Download Data</a></li>
            <li  <? if(SELF=="/customers_queries.php") { echo 'style="display:none;"'; } ?>><a href="/customers_queries.php">Saved Queries</a></li>
            <? } else { ?>
             <li <? if(SELF=="/customer_profile.php") { echo 'style="display:none;"'; } ?>><a href="customer_profile.php">Create Account</a></li>
           <? } ?>

		     <!--  <li><a href="<?=$_SERVER['REQUEST_URI']; ?>#bottom">End of Page</a></li>  -->
          </ul><br />

         </div>