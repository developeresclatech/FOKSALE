<?
  function checkLogin()
  {
  		 $queryS = "SELECT * FROM  `tblCustomers` WHERE `Username` = '".$_POST['frmUsername']."' AND `CPassword` = PASSWORD('".$_POST['frmCPassword']."')  LIMIT 1  ;";		  
	     $resultsS = mysql_query($queryS);
		 if(mysql_num_rows( $resultsS))
		 {
			 $data = mysql_fetch_assoc($resultsS);
			 extract($data);
 			 include("includes/cookie.php");
			 return $data;
	     } 
  }
?>