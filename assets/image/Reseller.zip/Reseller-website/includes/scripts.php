<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
<script language="javascript" type="text/javascript"  src="js/swfobject_modified.js"></script>
<!--[if lt IE 7]>
<script defer type="text/javascript" src="js/pngfix.js"></script>
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="css/ie_style.css"/>
<![endif]-->