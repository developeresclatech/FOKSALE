   <!--  button and download form section  --><a name="results"></a>
   <?
      if(isset($_POST['cmdSearch']))//if submit
  	  {
		 echo "<span id='spWait' style=\" font-size:12pt;\">Search in Progress, please wait.......<br /></span>";
		$submiturl = "$cURL_URL/api/remote_api_search.php";
		$_POST["CompID"] = $Reseller_ID;
		$_POST["Username"] = $Reseller_UN;
		$_POST["TableType"] = $Type;
		$_POST["User_ID"] = $User_ID;
		$_POST["Repeat"] = $chkRepeat;
        $data = GetDatacURL($submiturl, $_POST);
		echo "\n<script type=\"text/javascript\">\n\tdocument.getElementById('spWait').style.display='none'; \n</script>\n";
		if($_COOKIE['PullData'])
			echo $data;
		$arrReturns = decomposeQueryString($data);
		  /*  echo "<br />ARRAY IS<br />";
		print_r($arrReturns);
		echo "<br />ARRAY WAS<hr />";  */
		if(is_array($arrReturns))
		{
		    extract($arrReturns);
	        include_once("./includes/query_results_email.php");
		}
	 } // END  if(isset($_POST['cmdSearch']))//if submit
    if($display != "")
{ ?>
   <fieldset style="font-size: 12pt; font-weight: 600;" id="fsResults">

             <legend >Results:</legend>
        		<?
			          echo "<span style='font-size:12pt;'>$display</span>" ;
					   if($RepeatQuery == 1)
			             echo "<br /><span style='font-size:12pt;'>The Repeat Query Was Added to Our System</span>" ;
					  elseif($RepeatQuery == -1)
			             echo "<br /><span style='font-size:12pt;'>The Repeat Query Was NOT Added to Our System, you have more than three</span>" ; // done in check inc now
				  	  if($GroupBy)
				      {
 					   echo  "<div style='border:2px blue solid;'>\n<table border=\"0\" width=\"100%\">\n";
					   echo "<caption  style=\"font-size:13pt; font-weight:bold; color:#3300FF;\"><b>Results By Zip Codes</b></caption>\n<tr valign='top'><td>\n";
						   ksort($arrGroupByResults);
						   echo  "<table border=\"0\" width=\"210\" style=\"font-size:11pt; font-weight:bold; color:#000000;\">\n";
						   echo "<caption  style=\"font-size:12pt; font-weight:bold; color:#3300FF;\"><b>Sorted By Zip Codes</b></caption>\n";
						   foreach($arrGroupByResults AS $ZZ=>$CC)
								  echo  "<tr><td cellpadding='10' cellspacing='4' align=\"right\">$ZZ: </td><td cellpadding='10' cellspacing='4' align=\"right\">".number_format($CC,0)."</td></tr>\n";;
						   echo "</table>\n";
                      echo "</td><td>\n";
					       $arrGroupByResultsCounts = array_flip($arrGroupByResults);
						   ksort($arrGroupByResultsCounts);
						   echo  "<table border=\"0\" width=\"210\" style=\"font-size:11pt; font-weight:bold; color:#000000;\">\n";
						   echo "<caption  style=\"font-size:12pt; font-weight:bold; color:#3300FF;\"><b>Sorted By Counts</b></caption>\n";
						   foreach($arrGroupByResultsCounts AS $CC=>$ZZ)
								  echo  "<tr><td cellpadding='10' cellspacing='4' align=\"right\">$ZZ: </td><td cellpadding='10' cellspacing='4' align=\"right\">".number_format($CC,0)."</td></tr>\n";;
						   echo "</table>\n";
 					   echo "</td></tr>\n</table>\n</div>\n";

				     }
				?>
        </fieldset>
          <? } ?>
        <fieldset>
		 <legend >Buttons:</legend>
		   		<div align="center" style=";" id="divButtons">
				<div align="left" style="padding-left:20px" >Before you press the button below to get your query results, you also have the option to
be emailed the results. Depending upon the time of day, the quantity of selects, the query wait time can range from 10 seconds to 12 minutes.
</div><br/>
<div align="left" style="padding-left:20px" ><b>Option 1:</b> If you don't want to wait to see your query results, we'll  email them to you at this address: <input type="text" value="" size="25" maxlength="128" id="QueryEmail" name="QueryEmail" title="enter the email address here that you want the results sent to" /></div><br/>
   <? if($User_ID) { ?>
       <div align="left" style="padding-left:20px" ><b>Option 2: </b>Go to this <a href="customers_queries.php" >Page to See Your Query Results<!--   then Download Them Anytime  --></a></div><br />
     <div align="left" style="padding-left:20px" >
       <b>Option 3: </b>Make this a Repeat Query Search, which will automatically rerun every 2 weeks then the results will be emailed to you: <input type="checkbox"  accesskey="q"  name="chkRepeat" id="chkRepeat"  style=";" value="1"   /><br />
	   <span style="font-size:8pt;">(Limit of 3 Active Repeat Searches, you can manage your existing ones on the  <a href="customers_queries.php#repeat" target="_blank"  style="font-size:8pt;">saved queries page</a>)</span>
     </div><br />
<?
		}
			if($dbhi)
				 echo '<input type="submit"  value="Check Record Count!" name="cmdSearch" id="cmdSearch" onclick="subCounties = false; button = \'check\';" accesskey="s" title="Search for number of records matching your selections, or alt-s"  />';
                else
			      Echo '<h1 style="color:red;">Sorry, but the search feature is suspended temporarily for technical reasons, try back soon!';
?>
     | <input type="button" value="Clear Form"   accesskey="x" title="Clear Form, or alt-x"  onclick="location='<?=$_SERVER['PHP_SELF'];?>';" /> | <input type="button"  onclick="window.open('purchase_software_data.php#data');" value="Purchase Records"  title="Buy data Records" />
         </div>
      </fieldset>
	  </form><!--  closes search form at top of td  --><br />
<script type="text/javascript">
<!--
     function checkDownload()
	 {
		      xx = document.getElementById('custNumOfRecords').value;
			  yy = document.getElementById('txtStep').value;
			  NumOfRecords = document.getElementById('NumOfRecords').value;
			  xx = parseInt(xx);
	         document.getElementById('custNumOfRecords').value = xx;
			 // checks customer adjusted number of records
			  if(xx < 1 || xx > NumOfRecords || isNaN(xx))
		      {
				  alert('The number of records requested is not correct, it is too high, too low or is not a number');
                  document.getElementById('custNumOfRecords').select();
 				  return false;
              }

			  if(yy != '')
		      {
			    yy = parseInt(yy);
			    document.getElementById('txtStep').value = yy;
				// checks the record offset value
					  if(yy < 1 ||  isNaN(yy) )
					  {
						  alert('The record offset value is not correct, it is too high or low or is not a number');
						  document.getElementById('txtStep').select();
						  return false;
					  }
					  else if( (xx + yy) > NumOfRecords)
					  {
						  alert('The sum of the record offset value and records requested value '+ (xx + yy) + ' is greater than the total records available '+ NumOfRecords + ', make one or the other lower.');
						  document.getElementById('txtStep').select();
						  return false;
					  }
			  }
			  else
				  yy = "1";

             return    confirm('Do You Want to Download These '+ xx + ' Records Starting from Record '+  yy   +'? If OK, then your account here will be charged for all the records that you requested.\nRemember that some downloads may take a long time, like an hours or so, so DO NOT repeat the download. Just go to the downloads page and eventually the file(s) will show up.');
	 }
//-->
</script>
          <?
		     if($User_ID && $Balance >0  && $NumOfRecords > 0)
			 {
					$_SESSION['NoReload'] = 0;?>
        <fieldset>
		 <legend >Download:</legend>
				<form method="post" action="" id="frmGetOutfile" name="frmGetOutfile"  onsubmit="return  checkDownload();">
				 <input type="hidden" name="NumOfRecords" id="NumOfRecords"  value="<?=$NumOfRecords;?>" />
				 <input type="hidden" name="query_description" id="query_description"  value="<?=$display;?>" />
				 <input type="hidden" name="QueryID" id="QueryID"  value="<?=$QueryID;?>" />
                <input type="hidden" name="Pull_Type" id="Pull_Type"  value="<?=$Type; ?>" />
                <?
					if($NumOfRecords >0) {
			               echo "<span style='font-size:12pt;'>You have ".number_format(intval($Balance))." credits left.</span><br /><hr />" ;
				        if($Balance < $NumOfRecords)
							$Records = $Balance;
						else
							$Records = $NumOfRecords;
				?>
                	Specify a name for your data export file(letters, numbers, or '_'s only): (opt) <input type="text" name="export_name"  size="20"  value="<?=$export_name;?>"/><br />
					Change this to a lower value if you don't want all the records in the search: (opt) <input onchange="document.getElementById('divStep').style.display='block';  document.frmGetOutfile.txtStep.focus();" type="text" name="custNumOfRecords" id="custNumOfRecords"   size="12" value="<?=$Records;?>" /><br />
					<div align="center" id="divStep" style="display:none;">
					  if selecting less than the whole record count, start from this record: (opt) <input type="text" name="txtStep" style=";" id="txtStep"  maxlength=" " size="12"  value="<?=$txtStep ;?>"  /><br />
                      Otherwise you will get the records sorted A to Z by email address from the top of the list.<br />
					  Example you want only 10K records of a 101K count, but starting from the 20,000th record since you already downloaded the first two sets of 10K., you'd enter 10000 in the first box then 20000 in the one above.
					</div>

                <? }
				   if(isset($subGetOutFile))
				   {  //<h3>START</h3>
					    echo "<div style='' id='divFileResults'>\n";
						$submiturl = "$cURL_URL/api/outfiles/remote_api_file_interface.php";
						$_POST["CompID"] = $Reseller_ID;
						$_POST["User_ID"] = $User_ID;
						$_POST["Username"] = $Reseller_UN;
						$data = GetDatacURL($submiturl, $_POST);
						echo $data;
						$_SESSION['NoReload'] = 1;
						echo "</div>\n";
				   }
				   if(!$_SESSION['NoReload']) {
				?>
				 <input type="submit"  name="subGetOutFile"  value="Download Results" accesskey="g" title="Get the Outfile, or alt-g" />
				 <br /><span style="font-size:11pt; font-weight: 600; color: #DD2222;">NOTE: Please be patient, some downloads may take more than an hour depending on its complexity, size and/or the server's load. DO NOT RELOAD the page or REPEAT the download after you hit the button!. You can go later at any time to the <a href="/retrieve_data_files.php" target="_blank"  style="font-size:11pt; font-weight: 600; color: #DD2222;">download page</a> to get the file later so you don't have to wait here.</span>
			    <? } ?>
			   </form>
			 <noscript> Enable JavaScript</noscript>
           </fieldset>
        <? } // ECHO "$User_ID  | $Balance  |  $NumOfRecords";    ?>
   	</div>