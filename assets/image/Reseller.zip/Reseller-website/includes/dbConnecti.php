<?
	  //contains db connection script
	 $dbhi = mysqli_connect($dbHost, $dbUserName, $dbPW, $dbName);
     if(!$dbhi)
	   echo mysqli_connect_error();// . " ($dbHost || $dbUserName || $dbPW || $dbName)";
	 if($_POST['cmdLogin'] != "") //handler for user login from login form
	 {
        //echo "<h2>cmdLogin</h2>";
        $cc = checkLogin($dbhi, 0);
		if(is_array($cc))
           extract($cc);
	 }
	 //echo "mysqli_connect($dbHost, $dbUserName, $dbPW, $dbName);";
 ?>