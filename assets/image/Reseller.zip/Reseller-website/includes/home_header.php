<!-- HEADER -->
<div>
 <div id="header" align="center">
   <div class="container" >
      <div class="row-1">
      <div class="fleft"><a href="/"><img src="images/logo.png" alt="logo"></a></div>
      <div class="fleft"></div>
      <div class="fright">
<?
	if($User_ID)
	{
	   echo "<div id='divGreeting'><a href='customer_profile.php'>Welcome Back, $CompName</a> <a href='".SELF."?LO=1' style='display: inline;'>Log Out</a></div>\n";
	 }
	 else{
	  include("includes/login_top.php");
	 }
?>
         </div>
      </div>
      <div class="row-2">
        <? include("includes/menu-bar.php"); ?>       
      </div>
   </div>
</div>
