  <!--  begin footer  -->
  </div>
  </div>
<div id="footer">
  <div class="container" style="text-align:center; ">
     <p><?=$SiteName; ?>&reg;  &copy;<?=DATE("Y");?> All Rights Reserved  |  <a href="terms.php">Terms &amp; Conditions</a></p>
 </div>
         <div id="footerLink">
            <span <? if(SELF=="/index.php" || SELF=="/") { echo 'style="display:none;"'; } ?>><a href="index.php" >Home</a> | </span>
            <span <? if(SELF=="/Aboutus.php") { echo 'style="display:none;"'; } ?>><a href="Aboutus.php" >About</a> | </span>
            <span <? if(SELF=="/consumer_records_search.php") { echo 'style="display:none;"'; } ?>><a href="consumer_records_search.php"  >Consumer</a> | </span>
            <span <? if(SELF=="/business_records_search.php") { echo 'style="display:none;"'; } ?>><a href="business_records_search.php" >Business</a> | </span>
			<!--  <span <? if(SELF=="/vehicle.php") { echo 'style="display:none;"'; } ?>><a href="vehicle.php"  title="search for vehicles by make model and year" >Vehicle  Data</a> | </span>
			<span <? if(SELF=="/mail_out_records_search.php") { echo 'style="display:none;"'; } ?>><a href="mail_out_records_search.php"  title="with over 380 demographic fields and valid phone numbers" >Telemarketing &amp; Mail Data</a> | </span>  -->
            <span <? if(SELF=="/contact.php") { echo 'style="display:none;"'; } ?>><a href="contact.php">Contact</a> | </span>
            <span <? if(SELF=="/software.php") { echo 'style="display:none;"'; } ?>><a href="software.php" >Software</a> | </span>
            <span <? if(SELF=="/purchase_software_data.php") { echo 'style="display:none;"'; } ?>><a href="purchase_software_data.php" >Purchase</a> | </span>
            <span <? if(SELF=="/listen-to-webinar.php") { echo 'style="display:none;"'; } ?>><a href="listen-to-webinar.php">Webinar</a> | </span>
            <? if($User_ID) { ?>
            <span <? if(SELF=="/customer_profile.php") { echo 'style="display:none;"'; } ?>><a href="customer_profile.php">Manage Profile</a> | </span>
            <span <? if(SELF=="/retrieve_data_files.php") { echo 'style="display:none;"'; } ?>><a href="retrieve_data_files.php">Download Data</a> | </span>
            <span  <? if(SELF=="/customers_queries.php") { echo 'style="display:none;"'; } ?>><a href="/customers_queries.php">Saved Queries</a> | </span> 
            <? } else { ?>
             <span <? if(SELF=="/customer_profile.php") { echo 'style="display:none;"'; } ?>><a href="customer_profile.php">Create Account</a> | </span>
           <? } ?>
             <span><a href="<?=$_SERVER['REQUEST_URI']; ?>#top">Top</a>  | </span>
			  <span <? if(SELF=="/our_friends.php") { echo 'style="display:none;"'; } ?>><a href="our_friends.php">Other Links</a></span>
         </div>
  </div><a name="bottom"></a>
</div>

<div align="center" style=";"  id="divFooterKeywords">
  <table width="976" id="footerKeywords">

  <tr valign="top">
   <td width="33%">
        free optin emails, free opt-in emails, fresh feed data, data cleaning services, email list hygiene, free emailing, free email list, buy email list, purchase opt-in email addresses, low cost email address, rent email addresses, targeted email list, opt-in mailing lists, email software, email metrics, insurance leads, business email lists, emailings, free email software, email addresses for sale, foreign email data, foreign email lists, emailer ,bulk email, cheap email addresses, cheap email list, email data suppliers, email advertising, Opt In Email Marketing, Targeted Opt In Email, Bulk Email Software, Opt In Leads, Opt In Email, business lists, auto data, cell phone data, text data, email software, free business emails,B2B email data, low cost smtp's, free smtp's, CPA emailing, CPM emailing, email deployment services, email landing page, email newsletters, list, double opt-in emails, double optin lists, emailing, lists, email advertising, email targeted marketing, optin, opt-in, e-mail, marketing, email lists, email list, optin email, auto responder services, double opt-in email lists, buy email addresses,
   </td>
   <td width="34%">
       optin email lists,  consumer email lists, mortgage leads,loan leads, business email list, email marketing agencies, email marketing services, internet marketing, emails, auto responder services, e-mail marketing, ezine advertising, payday loan data, advertising, opt-in email lists, optin e-mail lists, email marketing, newsletter hosting & Mailing, free email advertising, bulk email advertising, opt-in email advertising, optin email advertising, targeted email advertising, opt in email advertising, telemarketing data, email marketing, mass emailing, bulk email marketing, direct email marketing, email marketing program, opt-in emailing, email marketing service, opt in email marketing, targeted email marketing, permission email marketing, email marketing software, marketing email, optin  email marketing, opt-in email marketing, email marketing tool, online email marketing, email marketing list, email bulk mlm business marketing opportunity, network marketing, educational data, multi-level-marketing emails, email direct marketing,
   </td>
   <td width="33%">
		 email marketing service, business leads,email marketing campaign, email marketing company, bulk email  marketing service, opt in email marketing, email marketing solution,email marketing services, email marketing consultant, target bulk email marketing, email marketing strategy, opt in email  marketing service, direct email marketing firm, email list marketing, email  marketing consulting, permission based email marketing, bulk email marketing software, marketing email list, optin email marketing research, business to business email marketing, permission based emailing, mass email marketing, newsletter advertising, free e-newsletters, email marketing technology, email permission  marketing, internet marketing online marketing email marketing interactive marketing, targeted bulk email marketing, mass email marketing, yellow pages software, contact page submitter software, maps.google software, google maps software, b2b lead generator, white pages software, website ranking booster software, seo, free opt-in email lists
    </td>

   </tr>
  </table><!--  close  divCenter  in head -->
<!--  end footer  -->