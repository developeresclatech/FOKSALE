<?
   $CompMessage = "Ready";
  // Print_r($_POST);
   function SendEmail($Name, $ID, $to, $SiteName)
   {
       extract($_POST);
       $body = "Customer $Name, #$ID just created a user profile on $SiteName on ".Date("m/d/y H:i")." \r\n";
       $body .= "Name: $CompFName $CompLName \n";
       $body .= "Address: $CompAddress1 \n";
       $body .= "$CompCity, $states $CompZip  $CompCountry \n";
       $body .= "Phone: ($CompAreaCode) $CompExc-$CompBody \n";
       $body .= "Email: $CompEmail\n";
       //$body .= "Referered from a $RefererType, $RefererSource\n";
       //$body .= "Data Requested: $DataNeeded\n";
       $subject = "New Customer Profile on $SiteName";
       $header = "From: \"$SiteName Customer Accounts Page\"<$to>\r\nReply-To: No Reply<a@a.com>";
       $results =  mail($to, $subject , $body); //, $header
       return $results;
   }

   function SendConfirmEmail($FROM, $SiteName)
   {
       extract($_POST);
       $body = "You have just created a user profile on $SiteName at ".Date("m/d/y H:i")." \r\n";
       $body .= "Dear $CompFName $CompLName of $CompName,\r\n    Thank you for creating a data download account on our website.\r\n";
       $body .= "Your Username is \"$Username\" and your Password is \"$CPassword\". \r\n";
       $body .= "Thank you,\r\n$SiteName Management";
       $subject = "Thank You for Creating a Customer Profile on our $SiteName Website";
       $header = "From: $FROM\r\nReply-To: $FROM";  // added his other address, 3/17/2012, used to be $FROM
       $results =  mail($CompEmail, $subject , $body); //, $header
      // echo $CompEmail.$subject.$body.$header;
       return $results;
   }
 // SendConfirmEmail(); //test only
   ///////////////////// END NOTIFICATION EMAIL FUNCTION Saturday, November 14, 2009 ///////////////////////////////////
  // echo  SendConfirmEmail()." EMAIL STATS";jakefree@verizon.net
  // SendEmail("Jake", "410", $SiteEmailFull);
   $CLEAN = array();
  // SendEmail("JAKE", "10", "Jeremy Freedman <jakefree@verizon.net>");
  if(count($_POST ))
  {
    foreach($_POST AS $K => $V)
    {
         $V = stripslashes($V);
         $V = trim($V);
         $V = str_replace(chr(39), "",$V);
         $CLEAN[$K] = mysqli_real_escape_string($dbhi, $V);
         //echo $K.' ='.$V." &nbsp;&nbsp;";
    }
    extract($CLEAN);
  }
 //  var_dump($CLEAN);
   if(!$User_ID)
      $User_ID = $_REQUEST['User_ID'];

    if(!$Username)
        $Username = $_REQUEST['Username'];
     $Username  = str_replace("'", "", $Username);
     if(CheckUserStatus($User_ID))
     {
       // BEGIN HANDLER
    if($subChangePW) // changes pw for customers, Thursday, September 03, 2009
    {
        if(strlen($CPassword)  >  5 && strlen($CPassword) < 17  &&  $CPassword == $XCPassword)
        {
         $queryS = "UPDATE  `tblResellerCustomers` SET CPassword = PASSWORD('$CPassword') WHERE `Username` = '$Username'  AND  User_ID=$User_ID AND CPassword = PASSWORD('$CCheckPassword') LIMIT 1;";
         $resultsS = mysqli_query($dbhi,$queryS);
         if($resultsS && mysqli_affected_rows($dbhi))
         {
             $CompMessage = "Password Updated";
             $fontColor = "green";
         }
         elseif($resultsS)
         {
            // $CompMessage =  mysqli_error($dbhi). $queryS;
             $CompMessage  = "Password not Changed";
             $fontColor = "red";
         }
		 else
         {
             $CompMessage =  mysqli_error($dbhi). $queryS;
             $fontColor = "red";
         }
        }
       else
       {
             $CompMessage = "Password Length Wrong it's ".strlen($CPassword) . ' characters long  or the 2 don\'t match ';
             $fontColor = "red";
       }
    }
///////////////////////////////////////////////////////////
    elseif (isset($cmdCompData))
    {
        if(is_numeric($CompExc) &&  is_numeric($CompBody))
           $CompPhone = $CompExc . $CompBody;
		$CompAreaCode = intval($CompAreaCode);
        if($CompName == "")
        {
            $CompName = $CompFName . " " . $CompLName;
        }

   if($XCompEmail == $CompEmail && filter_var($CompEmail, FILTER_VALIDATE_EMAIL))//Tuesday, October 06, 2009, added filter
   {
     $CLEAN['Reseller_ID'] = $Reseller_ID;
     $CLEAN["CompID"] = $Reseller_ID;
     $CLEAN["Reseller_UN"] = $Reseller_UN;
     $GotID = true;
     $SET =  " SET  `CompName` = '$CompName',  CompAddress1 = '$CompAddress1',  CompCity = '$CompCity', CompSt = '$states', CompCountry = '$CompCountry',  CompZip = '$CompZip', CompPlus4 = '$CompPlus4', CompAreaCode = '$CompAreaCode', CompPhone = '$CompPhone', CompExt = '$CompExt',  CompEmail = '$CompEmail', CompURL = '$CompURL', CompFName = '$CompFName', CompLName = '$CompLName', `RefererType` = '$RefererType', `RefererSource` = '$RefererSource' ,`DataNeeded` = '$DataNeeded' , `CompProvince` = '$CompProvince', `Reseller_ID` =  $Reseller_ID, `IPAddress` = '".$_SERVER['REMOTE_ADDR']."'";
     if(!$User_ID)
     {
       if(stristr($txtSpam, $antiSpamAnswer))
	   {
        $Username =  preg_replace('/[^0-9a-zA-Z_]/', "", $Username);
       if(strlen($Username) < 17  AND strlen($Username) > 7 AND ctype_alnum($Username) == 1)
       {
        if(strlen($CPassword) < 17  AND strlen($CPassword) > 7 AND trim($CompName) != ""  AND $CPassword == $XCPassword)
        {
          $queryI = "INSERT INTO tblResellerCustomers  $SET ";
          // send to remote server, dbe for insertion first
           {
               $submiturl = "$cURL_URL/api/remote_interface_insert_new.php";
               $queryI .= "  , `Username` = '$Username', `CPassword` = PASSWORD('$CPassword') "  ;  //need to add username for use on this page
               $data = GetDatacURL($submiturl, $CLEAN);
              if(is_numeric($data))
              {
                   $User_ID = $data;
                   $InsertGood = 1;
                   $queryI .=", `User_ID` = $User_ID";
              }
              else
               {
                  echo $data;
                  echo  "<h2>Username $Username has been already taken, choose another one</h2>";
                  //exit;
                  $NoGo = 1;
               }
         }// END REMOTE ACCESS
        //error messages for insert
     if($InsertGood)
     {
        $resultsI = mysqli_query($dbhi,$queryI);
        if(mysqli_affected_rows($dbhi) > 0)
        {
             include("includes/cookie.php");
             $update = 100;  //flag var for successful updates and inserts
             $CompMessage = "$CompName, Your Profile Has Been Successfully Created. Welcome To $SiteName";
			 $fontColor = "blue";
             SendEmail($CompName, $User_ID, $SiteEmail, $SiteName);
             SendConfirmEmail($SiteEmailFull, $SiteName);
         }
		 elseif(Mysqli_errno($dbhi)>0)
         { //
            $CompMessage ="ERROR: ". Mysqli_error($dbhi). $queryI;
            $fontColor = "red";
            $User_ID = 0;
         }
        else//username taken, so no User_ID returned, insert failed, User_ID is primary key, table logic
         { //
            $CompMessage = "Username is taken, $Username. Please choose another one!";
            $fontColor = "red";
            $User_ID = 0;
         }
      }
      else
      { //
          $CompMessage = "There Is Missing Information In Your Profile, Please Try Again. Also make sure your username and password are at least 8 characters, letters &amp; digits long.";
          $fontColor = "red";
       }
       }
      }
       else
       { //
          $CompMessage = "Your username either has non letters or numbers or it is too short. or long.";
          $fontColor = "red";
        }
	  }//spam if
	  else
      { //
          $CompMessage = "Your anti spam response \"$txtSpam\" didn't match $ASPAM_ANS";
          $fontColor = "red";
       }
    }//insert new user when User_ID is null

///////////////////////////////////   UPDATE QUERY
      else //update query
     {
        $queryUp = "UPDATE tblResellerCustomers  $SET  WHERE `Username` = '$Username'  AND `CPassword` = PASSWORD('$CheckPassword') AND  User_ID = '$User_ID'  LIMIT 1  ;";
        //$queryUpRemote = "UPDATE tblResellerCustomers  $SET  WHERE `Username` = '".$Username."_".$Reseller_ID."'  AND  `User_ID` = '$User_ID'  LIMIT 1  ;";
        $submiturl = "$cURL_URL/api/remote_interface_update_new.php";
             $data = GetDatacURL($submiturl, $CLEAN);
              if(is_numeric($data))
              {
                   $UpdateGood = 1;
              }
              else
               {
                  echo $data;
                  $errorMessage = "Update Failed";
                  exit;
               }

        $resultsUp = mysqli_query($dbhi,$queryUp);
         $update = 100;   //flag var for successful updates and inserts
        //error messages for chock edit
        if(mysqli_affected_rows($dbhi)>0)
        {
          $CompMessage = "Your Profile Has Been Updated";//$CompName Data Entered!";
          $fontColor = "green";
          include("includes/cookie.php");
        }
        elseif(mysqli_errno($dbhi))
        {
           $CompMessage = "Company Data Entry Failed!" ; //. mysqli_error($dbhi).", " . mysqli_errno($dbhi) . " : <br />". $queryUp;
           $fontColor = "red";
        }
        else
        {
          $CompMessage = "Check your confirmation password!";
          $fontColor = "orange";
        }
      }//END else //update query
     }// end check emails
     else //passwords don't match or are not long enough
     { //
          $CompMessage = "Your emails don't match or it is an invalid format, Please Try Again.";
          $fontColor = "red";
     }

    }// END  if (isset($_POST['cmdCompData']))  /// DATA ENTRY EDIT HANDLERS
 }//end check on status
 else//bad account warning
 {
       $CompMessage = "Your Account Has Been Disabled! Please Contact the Site Administrator";
       $fontColor = "red";
 }
    if($User_ID >0  && !$GotID && !$_GET['LO']) //JUST GET DATA IF good User_ID
    {
         $queryS = "SELECT * FROM  `tblResellerCustomers` WHERE  User_ID = '$User_ID'   LIMIT 1  ; ";
         $resultsS = mysqli_query($dbhi,$queryS);
         if(mysqli_num_rows( $resultsS))
         {
             $data = mysqli_fetch_assoc($resultsS);
             extract($data);
             $states = $CompSt;
             $XCompEmail = $CompEmail;
         }
         else
             echo mysqli_error($dbhi). $queryS;
    }