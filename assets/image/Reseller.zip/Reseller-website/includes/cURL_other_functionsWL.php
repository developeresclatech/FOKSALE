<?
    function jdf_build_query($arrData) //for fucking godaddy bs
	{
		 $qstr = "";
		 foreach($arrData AS $K=> $V)
		 {
            if(!is_array($V) && $V != "")
                $qstr .= "$K=$V&";
			elseif(is_array($V))
		      foreach($V AS $K1=> $V1)
		      {
				 if( $V1 != "")
	                $qstr .= $K."[".$K1."]=$V1&";
			  }// end 2nd foreach
		  }// end first foreach
        $str = (substr($qstr,0,-1));
		//echo $str;
		return $str;
	 /*	return "US_CAN_ALL=ALL&cmdSearch=1"; */
	 }
/////////////////////////////////////////
    function GetDatacURL($submiturl, &$arrData)
	{
		if(is_array($arrData))
           //$postdata = jdf_build_query( $arrData);//for fucking godaddy bs
	       $postdata = http_build_query( $arrData); //for fucking PHP 5
		$ch = curl_init(); /// initialize a cURL session
		curl_setopt ($ch, CURLOPT_URL,$submiturl);  //live server
		curl_setopt ($ch, CURLOPT_HEADER, 0);
		curl_setopt ($ch, CURLOPT_POST, 1);
		curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);

		//Un comment the next line to write the response to the rates and services request to a file.
		//curl_setopt ($ch, CURLOPT_FILE, $fp);

		//Check to see if this code is on a windows machine or a unix
		$filename = "c:\\windows\\system32\\ca-bundle.crt";
		if (file_exists($filename))
		{
			curl_setopt ($ch, CURLOPT_CAINFO, "c:\windows\system32\ca-bundle.crt");
			curl_setopt ($ch, CURLOPT_CAPATH, "c:\windows\system32\ca-bundle.crt");
			//curl_setopt ($ch, CURL_CA_BUNDLE, "c:\windows\system32\ca-bundle.crt");
		}
		$data = curl_exec ($ch);
		if(curl_errno($ch))
		{
			  return"XOXOXOXO" ;//curl_error($ch);
		}
		else
			return $data;
  	  curl_close ($ch);
	}// END function GetDatacURL($submiturl)
	function checkResellerCredits($UN, $ID, $Type="")
	{
           $arrData= ARRAY("Reseller_UN"=>"$UN", "Reseller_ID"=>"$ID", "GetResellerBalance"=>"1", "CreditType"=> "$Type") ;
           $count = GetDatacURL(cURL_URL."/api/reseller_remote_create_usersWL.php", $arrData);
		   return $count;
	}
	function checkUserCredits($UN, $ID, $User_ID, $Type="") //available credits
	{
           $arrData= ARRAY("Reseller_UN"=>"$UN", "Reseller_ID"=>"$ID", "checkUserCredits"=>"1", "User_ID"=>"$User_ID", "CreditType"=> "$Type") ;
           $count = GetDatacURL(cURL_URL."/api/reseller_remote_create_usersWL.php", $arrData);
		   return $count;
	}
	function checkUserPOSCredits($UN, $ID, $User_ID, $Type="") //available credits
	{
           $arrData= ARRAY("Reseller_UN"=>"$UN", "Reseller_ID"=>"$ID", "checkUserPOSCredits"=>"1", "User_ID"=>"$User_ID", "CreditType"=> "$Type") ;
           $count = GetDatacURL(cURL_URL."/api/reseller_remote_create_usersWL.php", $arrData);
		   return $count;
	}
	function getUserTransactions($UN, $ID, $User_ID, $Type="") //available credits
	{
           $arrData= ARRAY("Reseller_UN"=>"$UN", "Reseller_ID"=>"$ID", "getUserTransactions"=>"1", "User_ID"=>"$User_ID", "CreditType"=> "$Type") ;
           $list = GetDatacURL(cURL_URL."/api/reseller_remote_create_usersWL.php", $arrData);
		   return $list;
	}
	function AddUserCredits($UN, $ID, $User_ID, $Credits, $Notes, $Type="")
	{
           $arrData= ARRAY("Reseller_UN"=>"$UN", "Reseller_ID"=>"$ID", "CreditUserAccount"=>"1", "User_ID"=>"$User_ID" , "UserCredits"=>"$Credits", "Notes"=>"$Notes", "CreditType"=> "$Type" ) ;
           $status = GetDatacURL(cURL_URL."/api/reseller_remote_create_usersWL.php", $arrData);
		   return $status;
	}
	function CheckUserStatus($User_ID)
	{
        $dbhi = mysqli_connect(dbHost, dbUserName, dbPW, dbName);
		if($User_ID > 0)
		{
		 $QueryCheck = "SELECT Stopped FROM `tblResellerCustomers` WHERE User_ID = $User_ID  LIMIT 1; ";
		 $ResultsCheck = mysqli_query($dbhi,$QueryCheck);
		 $DR = mysqli_fetch_row($ResultsCheck);
         if($DR[0] != "Y" && $DR[0] != "y")
           return 1;
		 else
		   return 0;
		}
		else
		  return 1;
	}
	//////////////////////////////////              ////////////////////////////////////////////
	function decomposeQueryString($strIn)
	{
		$outArray1 = explode("&", $strIn);
		$outArrayF = Array();
		foreach($outArray1 AS $K => $V)
		{
			list($A, $B) = explode("=", $V);
            $outArrayF[trim($A)] = trim($B);
		}
		return $outArrayF;
    }
	/////////////////////////////////////////////////////////////////////
    function checkUserLicenses($User_ID, $CompID) //available credits
	{
           $arrData= ARRAY(  "CheckUserLicenses"=>"1", "User_ID"=>"$User_ID", "CompID" => "$CompID") ;
           $table = GetDatacURL(cURL_URL."/api/reseller_software_licenses_interface.php", $arrData);
		   return $table;
	}
	function AssignLicenses($User_ID, $CompID) //available credits
	{
           $arrData= ARRAY(  "AssignLicenses"=>"1", "User_ID"=>"$User_ID", "CompID" => "$CompID") ;
           $table = GetDatacURL(cURL_URL."/api/reseller_software_licenses_interface.php", $arrData);
		   return $table;
	}
	function setLicense($User_ID, $CompID, $KeyID) //available credits
	{
           $arrData= ARRAY(  "setLicense"=>"1", "User_ID"=>"$User_ID", "CompID" => "$CompID", "KeyID" => "$KeyID") ;
           $table = GetDatacURL(cURL_URL."/api/reseller_software_licenses_interface.php", $arrData);
		   return $table;
	}
	function CheckAllLicenses($CompID) //available credits
	{
           $arrData= ARRAY(  "CheckAllLicenses"=>"1", "CompID" => "$CompID") ;
           $table = GetDatacURL(cURL_URL."/api/reseller_software_licenses_interface.php", $arrData);
		   return $table;
	}
	function checkUserDownloadedCredits($UN, $ID, $User_ID, $Type="") //available credits
	{
           $arrData= ARRAY("Reseller_UN"=>"$UN", "Reseller_ID"=>"$ID", "checkUserDownloadedCredits"=>"1", "User_ID"=>"$User_ID", "CreditType"=> "$Type") ;
           $count = GetDatacURL(cURL_URL."/api/reseller_remote_create_usersWL.php", $arrData);
		   return $count;
	}
	function deleteUser($UN, $ID, $User_ID) //available credits
	{
           $arrData= ARRAY("Reseller_UN"=>"$UN", "Reseller_ID"=>"$ID", "deleteUser"=>"1", "User_ID"=>"$User_ID") ;
           $count = GetDatacURL(cURL_URL."/api/reseller_remote_create_usersWL.php", $arrData);
		   return $count;
	}
	function getNoPurchaseCustomers($UN, $ID) //available credits
	{
           $arrData= ARRAY("Reseller_UN"=>"$UN", "Reseller_ID"=>"$ID", "getNoPurchaseCustomers"=>"1") ;
           $count = GetDatacURL(cURL_URL."/api/reseller_remote_create_usersWL.php", $arrData);
		   return $count;
	} // echo getNoPurchaseCustomers($Reseller_UN, $Reseller_ID);

///////////// START FILE DOWNLOAD FUNCTION ///////////////////////////////////////
function DownloadFile($file)
{

 if(file_exists($file))
 {
	//$finfo = finfo_open(FILEINFO_MIME);
    header('Content-Description: File Transfer');
    header('Content-Type: text/plain');  //.finfo_file($finfo, $file)header('Content-Type: text/plain'); basename
    header('Content-Disposition: attachment; filename='.($file));
    header('Content-Transfer-Encoding: ascii');  //header('Content-Transfer-Encoding: ascii'); //
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    $download_done = readfile($file);
	if($download_done > 0)
	{
	   $dlMessage = "File " .  $file . " Downloaded";
	   //unlink($file);
	   exit;
	}
  }
  else
  {
		return "File not found, $file";
  }
}
///////////// END  FILE DOWNLOAD FUNCTION ///////////////////////////////////////
///////////// BEGIN MAILING LIST FUNCTION //////////////////////////////////////////
   function makeCustomerList($dbhi)
   {
  	  $query = "SELECT Username,User_ID, DateEntered, CompName, CompAddress1, CompCity, CompSt, CompZip, CompPlus4, CompCountry, CompAreaCode, CompPhone, CompExt, CompURL, CompEmail, CompFName, CompLName, Stopped,IPAddress,Admin FROM  tblResellerCustomers WHERE 1 ORDER BY `User_ID`    ";
	  $results = mysqli_query($dbhi,$query);
	//  echo $query;
	  if($results ) // && mysqli_num_rows($results)
	  {   //emailLists/
		  $fileName = "CustomerData_".date('mdY_His').".csv";
		 $fh= fopen($fileName, "w");              //"customerEmails".time().".csv"
         if($fh)
		 {
       while ($property = mysqli_fetch_field($results))
       {
		  $fieldname = $property->name;
		  //$fieldname = ucwords(str_replace("_", " ", $fieldname));
          $strFieldname .=  "$fieldname,";
	   }
         $strFieldname = substr($strFieldname,0,-1);
		  fputs($fh, $strFieldname);

		  while($data = mysqli_fetch_assoc($results))
	      {
             fputcsv($fh, $data);
	      }
		  fclose($fh);
          return DownloadFile($fileName);
		 }
		 else//file open problems
		 {
			 echo "Can't open the file,  $fileName for writing";
             return 0;
		 }
	   }
	  elseif($results)
      {
         echo  "<h2>No Emails In This Set</h2>";
		 return 0;
      }
	  else///if(mysqli_error($dbhi))// db problems
      {
         echo  "$query<br />  ". mysqli_error($dbhi) .',  '. mysqli_errno($dbhi);
		 return 0;
      }
   }

///////////// BEGIN MAILING LIST FUNCTION //////////////////////////////////////////
   function makeEmailList($dbhi, $cond)
   {
	   if(!file_exists($_SERVER['DOCUMENT_ROOT']."/emailLists"))
          mkdir($_SERVER['DOCUMENT_ROOT']."/emailLists");
      $cond = stripslashes($cond);     // ORDER BY `CompEmail`
  	  $query = "SELECT `CompEmail` FROM  tblResellerCustomers WHERE  `CompEmail` != ''  $cond  ORDER BY `User_ID`    ";
	  $results = mysqli_query($dbhi,$query);
	//  echo $query;
	  if($results  && mysqli_num_rows($results))
	  {   //emailLists/
	   if($cond)
		  $fileName = $_SERVER['DOCUMENT_ROOT']."/emailLists/DBEMUpdatesEmails_".date('mdY').".txt";
	   else
		  $fileName = $_SERVER['DOCUMENT_ROOT']."/emailLists/CustomerEmails_".date('mdY').".txt";

		 $fh= fopen($fileName, "w");              //"customerEmails".time().".csv"
         if($fh)
		 {
		  while($data = mysqli_fetch_assoc($results))
	      {
			 extract($data);
             $str .=  "$CompEmail;\r\n";
	      }
		  fputs($fh, $str);
		  fclose($fh);
          return DownloadFile($fileName);
		 }
		 else//file open problems
		 {
			 echo "Can't open the email file,  $fileName for writing";
             return 0;
		 }
	   }
	  elseif(mysqli_error($dbhi))// db problems
      {
         echo  "$query<br />  ". mysqli_error($dbhi) .',  '. mysqli_errno($dbhi);
		 return 0;
      }
	  else
      {
         echo  "<h2>No Emails In This Set</h2>";
		 return 0;
      }
   }
   ///////////// END  MAILING LIST FUNCTION //////////////////////////////////////////
   ?>