   
   <select  name="CompCountry" id="CompCountry"  class="form-control"> tabindex = "<?=$cti; ?>" class="selinc" onchange="showProvince(this.value);" onblur="" >
     <!--  <option value=""  >SELECT</option>  -->
	 <option value="US" <? if($CompCountry == "US") echo 'selected="selected" '; ?> >USA</option>
	<option value="CA"<? if($CompCountry == "CA") echo 'selected="selected" '; ?> >Canada</option>
    <option value="AF"<? if($CompCountry == "AF") echo 'selected="selected" '; ?> >Afghanistan</option>
    <option value="AL"<? if($CompCountry == "AL") echo 'selected="selected" '; ?> >Albania</option>
    <option value="DZ"<? if($CompCountry == "DZ") echo 'selected="selected" '; ?> >Algeria</option>
    <option value="AD"<? if($CompCountry == "AD") echo 'selected="selected" '; ?> >Andorra</option>
    <option value="AO"<? if($CompCountry == "AO") echo 'selected="selected" '; ?> >Angola</option>
    <option value="AI"<? if($CompCountry == "AI") echo 'selected="selected" '; ?> >Anguilla</option>
    <option value="AG"<? if($CompCountry == "AG") echo 'selected="selected" '; ?> >Antigua &amp; Barduba</option>
    <option value="AR"<? if($CompCountry == "AR") echo 'selected="selected" '; ?> >Argentina</option>
    <option value="AM"<? if($CompCountry == "AM") echo 'selected="selected" '; ?> >Armenia</option>
    <option value="AW"<? if($CompCountry == "AW") echo 'selected="selected" '; ?> >Aruba</option>
    <option value="AU"<? if($CompCountry == "AU") echo 'selected="selected" '; ?> >Australia</option>
    <option value="AT"<? if($CompCountry == "AT") echo 'selected="selected" '; ?> >Austria</option>
    <option value="AZ"<? if($CompCountry == "AZ") echo 'selected="selected" '; ?> >Azerbaijan</option>
    <option value="BS"<? if($CompCountry == "BS") echo 'selected="selected" '; ?> >Bahamas</option>
    <option value="BH"<? if($CompCountry == "BH") echo 'selected="selected" '; ?> >Bahrain</option>
    <option value="BD"<? if($CompCountry == "BD") echo 'selected="selected" '; ?> >Bangladesh</option>
    <option value="BB"<? if($CompCountry == "BB") echo 'selected="selected" '; ?> >Barbados</option>
    <option value="BY"<? if($CompCountry == "BY") echo 'selected="selected" '; ?> >Belarus</option>
    <option value="BE"<? if($CompCountry == "BE") echo 'selected="selected" '; ?> >Belgium</option>
    <option value="BZ"<? if($CompCountry == "BZ") echo 'selected="selected" '; ?> >Belize</option>
    <option value="BJ"<? if($CompCountry == "BJ") echo 'selected="selected" '; ?> >Benin</option>
    <option value="BM"<? if($CompCountry == "BM") echo 'selected="selected" '; ?> >Bermuda</option>
    <option value="BT"<? if($CompCountry == "BT") echo 'selected="selected" '; ?> >Bhutan</option>
    <option value="BO"<? if($CompCountry == "BO") echo 'selected="selected" '; ?> >Bolivia</option>
    <option value="BA"<? if($CompCountry == "BA") echo 'selected="selected" '; ?> >Bosnia-Herzegovina</option>
    <option value="BW"<? if($CompCountry == "BW") echo 'selected="selected" '; ?> >Botswana</option>
    <option value="BR"<? if($CompCountry == "BR") echo 'selected="selected" '; ?> >Brazil</option>
    <option value="IO"<? if($CompCountry == "IO") echo 'selected="selected" '; ?> >British Indian Ocean Territory</option>
    <option value="VG"<? if($CompCountry == "VG") echo 'selected="selected" '; ?> >British Virgin Islands</option>
    <option value="BN"<? if($CompCountry == "BN") echo 'selected="selected" '; ?> >Brunei Darussalam</option>
    <option value="BG"<? if($CompCountry == "BG") echo 'selected="selected" '; ?> >Bulgaria</option>
    <option value="BF"<? if($CompCountry == "BF") echo 'selected="selected" '; ?> >Burkina Faso</option>
    <option value="BI"<? if($CompCountry == "BI") echo 'selected="selected" '; ?> >Burundi</option>
    <option value="KH"<? if($CompCountry == "KH") echo 'selected="selected" '; ?> >Cambodia</option>
    <option value="CM"<? if($CompCountry == "CM") echo 'selected="selected" '; ?> >Cameroon</option>
    <option value="CV"<? if($CompCountry == "CV") echo 'selected="selected" '; ?> >Cape Verde</option>
    <option value="KY"<? if($CompCountry == "KY") echo 'selected="selected" '; ?> >Cayman Islands</option>
    <option value="CF"<? if($CompCountry == "CF") echo 'selected="selected" '; ?> >Central African Republic</option>
    <option value="TD"<? if($CompCountry == "TD") echo 'selected="selected" '; ?> >Chad</option>
    <option value="CL"<? if($CompCountry == "CL") echo 'selected="selected" '; ?> >Chile</option>
    <option value="CN"<? if($CompCountry == "CN") echo 'selected="selected" '; ?> >China</option>
    <option value="CX"<? if($CompCountry == "CX") echo 'selected="selected" '; ?> >Christmas Islands</option>
    <option value="CC"<? if($CompCountry == "CC") echo 'selected="selected" '; ?> >Cocos Island</option>
    <option value="CO"<? if($CompCountry == "CO") echo 'selected="selected" '; ?> >Colombia</option>
    <option value="KM"<? if($CompCountry == "KM") echo 'selected="selected" '; ?> >Comoros</option>
    <option value="CG"<? if($CompCountry == "CG") echo 'selected="selected" '; ?> >Congo (Brazzaville)</option>
    <option value="CD"<? if($CompCountry == "CD") echo 'selected="selected" '; ?> >Congo, Dem. Republic Of</option>
    <option value="CK"<? if($CompCountry == "CK") echo 'selected="selected" '; ?> >Cook Islands</option>
    <option value="CR"<? if($CompCountry == "CR") echo 'selected="selected" '; ?> >Costa Rica</option>
    <option value="HR"<? if($CompCountry == "HR") echo 'selected="selected" '; ?> >Croatia</option>
    <option value="CY"<? if($CompCountry == "CY") echo 'selected="selected" '; ?> >Cyprus</option>
    <option value="CZ"<? if($CompCountry == "CZ") echo 'selected="selected" '; ?> >Czech Republic, The</option>
    <option value="DK"<? if($CompCountry == "DK") echo 'selected="selected" '; ?> >Denmark</option>
    <option value="DJ"<? if($CompCountry == "DJ") echo 'selected="selected" '; ?> >Djibouti</option>
    <option value="DM"<? if($CompCountry == "DM") echo 'selected="selected" '; ?> >Dominica</option>
    <option value="DO"<? if($CompCountry == "DO") echo 'selected="selected" '; ?> >Dominican Republic</option>
    <option value="TP"<? if($CompCountry == "TP") echo 'selected="selected" '; ?> >East Timor</option>
    <option value="EC"<? if($CompCountry == "EC") echo 'selected="selected" '; ?> >Ecuador</option>
    <option value="EG"<? if($CompCountry == "EG") echo 'selected="selected" '; ?> >Egypt</option>
    <option value="SV"<? if($CompCountry == "SV") echo 'selected="selected" '; ?> >El Salvador</option>
    <option value="GQ"<? if($CompCountry == "GQ") echo 'selected="selected" '; ?> >Equatorial Guinea</option>
    <option value="ER"<? if($CompCountry == "ER") echo 'selected="selected" '; ?> >Eritrea</option>
    <option value="EE"<? if($CompCountry == "EE") echo 'selected="selected" '; ?> >Estonia</option>
    <option value="ET"<? if($CompCountry == "ET") echo 'selected="selected" '; ?> >Ethiopia</option>
    <option value="FK"<? if($CompCountry == "FK") echo 'selected="selected" '; ?> >Falkland Islands</option>
    <option value="FO"<? if($CompCountry == "FO") echo 'selected="selected" '; ?> >Faroe Islands</option>
    <option value="FJ"<? if($CompCountry == "FJ") echo 'selected="selected" '; ?> >Fiji</option>
    <option value="FI"<? if($CompCountry == "FI") echo 'selected="selected" '; ?> >Finland</option>
    <option value="FR"<? if($CompCountry == "FR") echo 'selected="selected" '; ?> >France</option>
    <option value="GF"<? if($CompCountry == "GF") echo 'selected="selected" '; ?> >French Guiana</option>
    <option value="PF"<? if($CompCountry == "PF") echo 'selected="selected" '; ?> >French Polynesia</option>
    <option value="TF"<? if($CompCountry == "TF") echo 'selected="selected" '; ?> >French Sthrn Territories</option>
    <option value="GA"<? if($CompCountry == "GA") echo 'selected="selected" '; ?> >Gabon</option>
    <option value="GM"<? if($CompCountry == "GM") echo 'selected="selected" '; ?> >Gambia</option>
    <option value="GZ"<? if($CompCountry == "GZ") echo 'selected="selected" '; ?> >Gaza Strip</option>
    <option value="GE"<? if($CompCountry == "GE") echo 'selected="selected" '; ?> >Georgia</option>
    <option value="DE"<? if($CompCountry == "DE") echo 'selected="selected" '; ?> >Germany</option>
    <option value="GH"<? if($CompCountry == "GH") echo 'selected="selected" '; ?> >Ghana</option>
    <option value="GI"<? if($CompCountry == "GI") echo 'selected="selected" '; ?> >Gibraltar</option>
    <option value="GR"<? if($CompCountry == "GR") echo 'selected="selected" '; ?> >Greece</option>
    <option value="GL"<? if($CompCountry == "GL") echo 'selected="selected" '; ?> >Greenland</option>
    <option value="GD"<? if($CompCountry == "GD") echo 'selected="selected" '; ?> >Grenada</option>
    <option value="GP"<? if($CompCountry == "GP") echo 'selected="selected" '; ?> >Guadeloupe</option>
    <option value="GT"<? if($CompCountry == "GT") echo 'selected="selected" '; ?> >Guatemala</option>
    <option value="GN"<? if($CompCountry == "GN") echo 'selected="selected" '; ?> >Guinea</option>
    <option value="GW"<? if($CompCountry == "GW") echo 'selected="selected" '; ?> >Guinea-Bissau</option>
    <option value="GY"<? if($CompCountry == "GY") echo 'selected="selected" '; ?> >Guyana</option>
    <option value="HT"<? if($CompCountry == "HT") echo 'selected="selected" '; ?> >Haiti</option>
    <option value="HM"<? if($CompCountry == "HM") echo 'selected="selected" '; ?> >Heard &amp; McDonald Islands</option>
    <option value="HN"<? if($CompCountry == "HN") echo 'selected="selected" '; ?> >Honduras</option>
    <option value="HK"<? if($CompCountry == "HK") echo 'selected="selected" '; ?> >Hong Kong</option>
    <option value="HU"<? if($CompCountry == "HU") echo 'selected="selected" '; ?> >Hungary</option>
    <option value="IS"<? if($CompCountry == "IS") echo 'selected="selected" '; ?> >Iceland</option>
    <option value="IN"<? if($CompCountry == "IN") echo 'selected="selected" '; ?> >India</option>
    <option value="ID"<? if($CompCountry == "ID") echo 'selected="selected" '; ?> >Indonesia</option>
    <option value="IE"<? if($CompCountry == "IE") echo 'selected="selected" '; ?> >Ireland</option>
    <option value="IL"<? if($CompCountry == "IL") echo 'selected="selected" '; ?> >Israel</option>
    <option value="IT"<? if($CompCountry == "IT") echo 'selected="selected" '; ?> >Italy</option>
    <option value="CI"<? if($CompCountry == "CI") echo 'selected="selected" '; ?> >Ivory Coast</option>
    <option value="JM"<? if($CompCountry == "JM") echo 'selected="selected" '; ?> >Jamaica</option>
    <option value="JP"<? if($CompCountry == "JP") echo 'selected="selected" '; ?> >Japan</option>
    <option value="JO"<? if($CompCountry == "JO") echo 'selected="selected" '; ?> >Jordan</option>
    <option value="KZ"<? if($CompCountry == "KZ") echo 'selected="selected" '; ?> >Kazakhstan</option>
    <option value="KE"<? if($CompCountry == "KE") echo 'selected="selected" '; ?> >Kenya</option>
    <option value="KI"<? if($CompCountry == "KI") echo 'selected="selected" '; ?> >Kiribati</option>
    <option value="KW"<? if($CompCountry == "KW") echo 'selected="selected" '; ?> >Kuwait</option>
    <option value="KG"<? if($CompCountry == "KG") echo 'selected="selected" '; ?> >Kyrgyzstan</option>
    <option value="LA"<? if($CompCountry == "LA") echo 'selected="selected" '; ?> >Laos</option>
    <option value="LV"<? if($CompCountry == "LV") echo 'selected="selected" '; ?> >Latvia</option>
    <option value="LB"<? if($CompCountry == "LB") echo 'selected="selected" '; ?> >Lebanon</option>
    <option value="LS"<? if($CompCountry == "LS") echo 'selected="selected" '; ?> >Lesotho</option>
    <option value="LR"<? if($CompCountry == "LR") echo 'selected="selected" '; ?> >Liberia</option>
    <option value="LI"<? if($CompCountry == "LI") echo 'selected="selected" '; ?> >Liechtenstein</option>
    <option value="LT"<? if($CompCountry == "LT") echo 'selected="selected" '; ?> >Lithuania</option>
    <option value="LU"<? if($CompCountry == "LU") echo 'selected="selected" '; ?> >Luxembourg</option>
    <option value="MO"<? if($CompCountry == "MO") echo 'selected="selected" '; ?> >Macau</option>
    <option value="MK"<? if($CompCountry == "MK") echo 'selected="selected" '; ?> >Macedonia</option>
    <option value="MG"<? if($CompCountry == "MG") echo 'selected="selected" '; ?> >Madagascar</option>
    <option value="MW"<? if($CompCountry == "MW") echo 'selected="selected" '; ?> >Malawi</option>
    <option value="MY"<? if($CompCountry == "MY") echo 'selected="selected" '; ?> >Malaysia</option>
    <option value="MV"<? if($CompCountry == "MV") echo 'selected="selected" '; ?> >Maldives</option>
    <option value="ML"<? if($CompCountry == "ML") echo 'selected="selected" '; ?> >Mali</option>
    <option value="MT"<? if($CompCountry == "MT") echo 'selected="selected" '; ?> >Malta</option>
    <option value="MQ"<? if($CompCountry == "MQ") echo 'selected="selected" '; ?> >Martinique</option>
    <option value="MR"<? if($CompCountry == "MR") echo 'selected="selected" '; ?> >Mauritania</option>
    <option value="MU"<? if($CompCountry == "MU") echo 'selected="selected" '; ?> >Mauritius</option>
    <option value="YT"<? if($CompCountry == "YT") echo 'selected="selected" '; ?> >Mayotte</option>
    <option value="ME"<? if($CompCountry == "ME") echo 'selected="selected" '; ?> >Mexico</option>
    <option value="MD"<? if($CompCountry == "MD") echo 'selected="selected" '; ?> >Moldova</option>
    <option value="MC"<? if($CompCountry == "MC") echo 'selected="selected" '; ?> >Monaco</option>
    <option value="MN"<? if($CompCountry == "MN") echo 'selected="selected" '; ?> >Mongolia</option>
    <option value="MS"<? if($CompCountry == "MS") echo 'selected="selected" '; ?> >Montserrat</option>
    <option value="MA"<? if($CompCountry == "MA") echo 'selected="selected" '; ?> >Morocco</option>
    <option value="MZ"<? if($CompCountry == "MZ") echo 'selected="selected" '; ?> >Mozambique</option>
    <option value="MM"<? if($CompCountry == "MM") echo 'selected="selected" '; ?> >Myanmar</option>
    <option value="NA"<? if($CompCountry == "NA") echo 'selected="selected" '; ?> >Namibia</option>
    <option value="NR"<? if($CompCountry == "NR") echo 'selected="selected" '; ?> >Nauru</option>
    <option value="NP"<? if($CompCountry == "NP") echo 'selected="selected" '; ?> >Nepal</option>
    <option value="NL"<? if($CompCountry == "NL") echo 'selected="selected" '; ?> >Netherlands</option>
    <option value="AN"<? if($CompCountry == "AN") echo 'selected="selected" '; ?> >Netherlands Antilles</option>
    <option value="NC"<? if($CompCountry == "NC") echo 'selected="selected" '; ?> >New Caledonia</option>
    <option value="NZ"<? if($CompCountry == "NZ") echo 'selected="selected" '; ?> >New Zealand</option>
    <option value="NI"<? if($CompCountry == "NI") echo 'selected="selected" '; ?> >Nicaragua</option>
    <option value="NE"<? if($CompCountry == "NE") echo 'selected="selected" '; ?> >Niger</option>
    <option value="NG"<? if($CompCountry == "NG") echo 'selected="selected" '; ?> >Nigeria</option>
    <option value="NU"<? if($CompCountry == "NU") echo 'selected="selected" '; ?> >Niue</option>
    <option value="NF"<? if($CompCountry == "NF") echo 'selected="selected" '; ?> >Norfolk Island</option>
    <option value="NO"<? if($CompCountry == "NO") echo 'selected="selected" '; ?> >Norway</option>
    <option value="OM"<? if($CompCountry == "OM") echo 'selected="selected" '; ?> >Oman</option>
    <option value="PK"<? if($CompCountry == "PK") echo 'selected="selected" '; ?> >Pakistan</option>
    <option value="PA"<? if($CompCountry == "PA") echo 'selected="selected" '; ?> >Panama</option>
    <option value="PG"<? if($CompCountry == "PG") echo 'selected="selected" '; ?> >Papua New Guinea</option>
    <option value="PY"<? if($CompCountry == "PY") echo 'selected="selected" '; ?> >Paraguay</option>
    <option value="PE"<? if($CompCountry == "PE") echo 'selected="selected" '; ?> >Peru</option>
    <option value="PH"<? if($CompCountry == "PH") echo 'selected="selected" '; ?> >Philippines</option>
    <option value="PN"<? if($CompCountry == "PN") echo 'selected="selected" '; ?> >Pitcairn Island</option>
    <option value="PL"<? if($CompCountry == "PL") echo 'selected="selected" '; ?> >Poland</option>
    <option value="PT"<? if($CompCountry == "PT") echo 'selected="selected" '; ?> >Portugal</option>
    <option value="QA"<? if($CompCountry == "QA") echo 'selected="selected" '; ?> >Qatar</option>
    <option value="RE"<? if($CompCountry == "RE") echo 'selected="selected" '; ?> >Reunion</option>
    <option value="RO"<? if($CompCountry == "RO") echo 'selected="selected" '; ?> >Romania</option>
    <option value="RU"<? if($CompCountry == "RU") echo 'selected="selected" '; ?> >Russia</option>
    <option value="LC"<? if($CompCountry == "LC") echo 'selected="selected" '; ?> >Saint Lucia</option>
    <option value="WS"<? if($CompCountry == "WS") echo 'selected="selected" '; ?> >Samoa</option>
    <option value="SM"<? if($CompCountry == "SM") echo 'selected="selected" '; ?> >San Marino</option>
    <option value="ST"<? if($CompCountry == "ST") echo 'selected="selected" '; ?> >Sao Tome &amp; Principe</option>
    <option value="SA"<? if($CompCountry == "SA") echo 'selected="selected" '; ?> >Saudi Arabia</option>
    <option value="SN"<? if($CompCountry == "SN") echo 'selected="selected" '; ?> >Senegal</option>
    <option value="YU"<? if($CompCountry == "YU") echo 'selected="selected" '; ?> >Serbia &amp; Montenegro</option>
    <option value="SC"<? if($CompCountry == "SC") echo 'selected="selected" '; ?> >Seychelles</option>
    <option value="SL"<? if($CompCountry == "SL") echo 'selected="selected" '; ?> >Sierra Leone</option>
    <option value="SG"<? if($CompCountry == "SG") echo 'selected="selected" '; ?> >Singapore</option>
    <option value="SK"<? if($CompCountry == "SK") echo 'selected="selected" '; ?> >Slovakia</option>
    <option value="SI"<? if($CompCountry == "SI") echo 'selected="selected" '; ?> >Slovenia</option>
    <option value="SB"<? if($CompCountry == "SB") echo 'selected="selected" '; ?> >Soloman Islands</option>
    <option value="SO"<? if($CompCountry == "SO") echo 'selected="selected" '; ?> >Somalia</option>
    <option value="ZA"<? if($CompCountry == "ZA") echo 'selected="selected" '; ?> >South Africa</option>
    <option value="KR"<? if($CompCountry == "KR") echo 'selected="selected" '; ?> >South Korea</option>
    <option value="ES"<? if($CompCountry == "ES") echo 'selected="selected" '; ?> >Spain/Canary Islands</option>
    <option value="LK"<? if($CompCountry == "LK") echo 'selected="selected" '; ?> >Sri Lanka</option>
    <option value="VC"<? if($CompCountry == "VC") echo 'selected="selected" '; ?> >St Vincent And Grenadines</option>
    <option value="SH"<? if($CompCountry == "SH") echo 'selected="selected" '; ?> >St. Helena</option>
    <option value="KN"<? if($CompCountry == "KN") echo 'selected="selected" '; ?> >St. Kitts &amp; Nevis</option>
    <option value="PM"<? if($CompCountry == "PM") echo 'selected="selected" '; ?> >St. Pierre And Miquelon</option>
    <option value="SR"<? if($CompCountry == "SR") echo 'selected="selected" '; ?> >Suriname</option>
    <option value="SJ"<? if($CompCountry == "SJ") echo 'selected="selected" '; ?> >Svalbard Jan Mayen Island</option>
    <option value="SZ"<? if($CompCountry == "SZ") echo 'selected="selected" '; ?> >Swaziland</option>
    <option value="SE"<? if($CompCountry == "SE") echo 'selected="selected" '; ?> >Sweden</option>
    <option value="CH"<? if($CompCountry == "CH") echo 'selected="selected" '; ?> >Switzerland</option>
    <option value="TW"<? if($CompCountry == "TW") echo 'selected="selected" '; ?> >Taiwan</option>
    <option value="TJ"<? if($CompCountry == "TJ") echo 'selected="selected" '; ?> >Tajikistan</option>
    <option value="TZ"<? if($CompCountry == "TZ") echo 'selected="selected" '; ?> >Tanzania</option>
    <option value="TH"<? if($CompCountry == "TH") echo 'selected="selected" '; ?> >Thailand</option>
    <option value="TG"<? if($CompCountry == "TG") echo 'selected="selected" '; ?> >Togo</option>
    <option value="TK"<? if($CompCountry == "TK") echo 'selected="selected" '; ?> >Tokelau</option>
    <option value="TO"<? if($CompCountry == "TO") echo 'selected="selected" '; ?> >Tonga</option>
    <option value="TT"<? if($CompCountry == "TT") echo 'selected="selected" '; ?> >Trinidad And Tobago</option>
    <option value="TN"<? if($CompCountry == "TN") echo 'selected="selected" '; ?> >Tunisia</option>
    <option value="TR"<? if($CompCountry == "TR") echo 'selected="selected" '; ?> >Turkey</option>
    <option value="TM"<? if($CompCountry == "TM") echo 'selected="selected" '; ?> >Turkmenistan</option>
    <option value="TC"<? if($CompCountry == "TC") echo 'selected="selected" '; ?> >Turks And Caicos Islands</option>
    <option value="TV"<? if($CompCountry == "TV") echo 'selected="selected" '; ?> >Tuvalu</option>
    <option value="UM"<? if($CompCountry == "UM") echo 'selected="selected" '; ?> >U.S. Minor Outlying Islands</option>
    <option value="UG"<? if($CompCountry == "UG") echo 'selected="selected" '; ?> >Uganda</option>
    <option value="UA"<? if($CompCountry == "UA") echo 'selected="selected" '; ?> >Ukraine</option>
    <option value="AE"<? if($CompCountry == "AE") echo 'selected="selected" '; ?> >United Arab Emirates</option>
    <option value="UK"<? if($CompCountry == "UK") echo 'selected="selected" '; ?> >United Kingdom</option>
    <option value="UY"<? if($CompCountry == "UY") echo 'selected="selected" '; ?> >Uruguay</option>
    <option value="UZ"<? if($CompCountry == "UZ") echo 'selected="selected" '; ?> >Uzbekistan</option>
    <option value="VU"<? if($CompCountry == "VU") echo 'selected="selected" '; ?> >Vanuatu</option>
    <option value="VA"<? if($CompCountry == "VA") echo 'selected="selected" '; ?> >Vatican City</option>
    <option value="VE"<? if($CompCountry == "VE") echo 'selected="selected" '; ?> >Venezuela</option>
    <option value="VN"<? if($CompCountry == "VN") echo 'selected="selected" '; ?> >Vietnam</option>
    <option value="WF"<? if($CompCountry == "WF") echo 'selected="selected" '; ?> >Wallis &amp; Futunu Islands</option>
    <option value="WE"<? if($CompCountry == "WE") echo 'selected="selected" '; ?> >West Bank</option>
    <option value="EH"<? if($CompCountry == "EH") echo 'selected="selected" '; ?> >Western Sahara</option>
    <option value="YE"<? if($CompCountry == "YE") echo 'selected="selected" '; ?> >Yemen, Republic Of</option>
    <option value="ZM"<? if($CompCountry == "ZM") echo 'selected="selected" '; ?> >Zambia</option>
    <option value="ZW"<? if($CompCountry == "ZW") echo 'selected="selected" '; ?> >Zimbabwe</option>
   </select>