<?
	   if(isset($_POST['subResetPW']))
	   {
	        extract($_POST);
		    $frmEmail = trim($frmEmail);
		    $frmUsername2 = trim($frmUsername2);
			if (filter_var($frmEmail, FILTER_VALIDATE_EMAIL) || $frmUsername2 != "")
			{
              if($frmUsername2 != "")
			  {
			      $query = "SELECT * FROM `tblResellerCustomers` WHERE `Username` = '$frmUsername2'  ;  ";
				  $what = "username ";
			  }
			  else
			  {
			      $query = "SELECT * FROM `tblResellerCustomers` WHERE `CompEmail` = '$frmEmail'  ORDER BY `User_ID`  ;  ";
				  $what = "email ";
			  }
		    @$results = mysqli_query($dbhi, $query);
	         if(@mysqli_num_rows($results) == 1)
		     {
				// echo mysqli_num_rows($results) ." = number of rows<br />";
               $data = mysqli_fetch_assoc($results);
			   {
                  $NewPW = substr(md5(uniqid(rand(),1)),3,10);
                  $queryRPW = "UPDATE `tblResellerCustomers` SET `ResetCode` = '$NewPW'  WHERE `User_ID` = '$data[User_ID]';";
		          @$resultsRPW = mysqli_query($dbhi, $queryRPW);
				  if($resultsRPW)
				  {
					 $headers = "FROM: \"$SiteNameSh Password Reset\"<$SiteEmail>\r\nReply-To: \"No Reply\"<a@a.com>";
					 $EM = $data['CompEmail'];
                     $subject = "From $SiteNameSh PW Reset";
				     $body  = "Hello $data[CompFName]  $data[CompLName], \r\n\tto reset your password  go to this page. ".$SiteURL."/reset_your_password.php?em=$data[CompEmail]&rc=$NewPW&un=$data[Username]\r\n";
                     $body .= "Your username is $data[Username] and and this reset code is $NewPW\r\n\r\n";
                    $body .= "If you didn't request or do not need your password changed, then ignore this email and nothing will happen.\r\n";
                     $body .= "Thank You\r\n The Systems Management Crew";
                     //$headers = "From: $SiteName <$SiteEmail>\r\nReply-To: \"No Reply\"<a@a.com>";
					 //print_r($data);
					//echo $data['CompEmail'] .'  = COMPEMAIL<br />';
				     $mc = mail($EM, $subject, $body, $headers);
					 if($mc)
                        $_SESSION['login']  = "Your password reset instructions have been sent to your email address,  $EM";
					 else
                        $_SESSION['login']  = "Email Failed";
                   }
				  else
				  {
                   if(mysqli_errno($dbhi) == 0)
                      $_SESSION['login']  = "Password reset failed";
				   else
					  echo  $queryRPW.'<br>'.mysqli_error($dbhi);
                  }
               }
			 }
		    elseif(mysqli_num_rows($results) > 1)
		   {
			  $_SESSION['login']  = "There is more than one account associated with that email address, go to  <a href='/reset_your_password.php?em=$frmEmail&mult=1'>this page</a> to select which one..";
		    }
			else
			{
                  if(mysqli_errno($dbhi) == 0)
                     $_SESSION['login']  = "The $what entered does not match any active users ";
				  else
					  echo  $query.'<br>'.mysqli_error($dbhi);
             }
			}//filter validation test
			else
			{
                     $_SESSION['login']  = "Email entered, $frmEmail,  has an invalid format";
            }
	 }// end reset password
?>