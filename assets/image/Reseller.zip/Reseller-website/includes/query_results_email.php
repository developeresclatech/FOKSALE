<? 	  
    if(filter_var($QueryEmail, FILTER_VALIDATE_EMAIL))
	   {
          $to = $QueryEmail;
		  $header = "From: $CompanyEmail Search Results<$SiteEmail>\r\nReply-To: No Reply<a@a>";
          $body = "Hi search page user,\r\nThe results of your query at $SiteName on ".date("m/d/y H:i")." is:\n$display";
          if($Type == "Consumer")
			$url = "http://".$_SERVER['SERVER_NAME']."/consumer_records_search.php";
		  else
			$url = "http://".$_SERVER['SERVER_NAME']."/business_records_search.php";
          $body .= "\r\nYou can go to $url to start the process again.\r\n$Addendum\r\n Thank You ,\n-- $SiteName Customer Service.";
		  $subject = "Your $SiteNamer Query Results";
		  $cust_email =  mail($to, $subject , $body, $header);
		    /*  if($cust_email)
			   echo "<h3>Email Sent</h3>";
		  else
			   echo "<h3>Email Failed | mail($to, $subject , $body, $header)</h3>";  */
	   }
		    /*  else
			   echo "<h3>Bad Email |  $QueryEmail</h3>";  */
?>