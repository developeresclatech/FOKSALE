<div id="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <p>Opt In Email Marketing® © <? echo date('Y'); ?> All Rights Reserved | <a href="terms.php">Terms &amp;
                        Conditions</a></p>
            </div>

            <div class="col-md-12 text-center">
                <div id="footerLink">
                    <span><a href="index.php">Home</a> | </span>
                    <span><a href="Aboutus.php">About</a> | </span>
                    <span><a href="contact.php">Contact</a> | </span>

                    <span style="display:none;"><a href="consumer_records_search.php">Consumer</a> | </span>
                    <span><a href="business_records_search.php">Business</a> | </span>

                    <span><a href="non_email_consumer_records_search.php">Phone & Postal</a> | </span>
                    <span><a href="cell_phone_search.php">Cell Phones</a> | </span>
                    <span><a href="purchase_software_data.php">Purchase</a> | </span>

                    <span><a href="vehicle.php">Vehicle</a> | </span>
                    <span><a href="software.php">Software</a> | </span>
                    <span><a href="listen-to-webinar.php">Webinar</a> | </span>

                    <span><a href="customer_profile.php">Create Account</a> | </span>
                    <span><a href="consumer_records_search.php#top">Top</a> | </span>
                    <span><a href="our_friends.php">Other Links</a></span>
                </div>
            </div>
        </div>
    </div>
</div>