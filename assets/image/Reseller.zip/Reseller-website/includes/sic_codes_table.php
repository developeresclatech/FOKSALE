<h3>SIC Code</h3><hr />
<table width="100%" cellspacing="5" style="font-size:9pt;">
<caption> Sorted Alphabetically by Description</caption>
 <tr>
  <td>3291</td>
  <td>Abrasive Products (except steel wool with or without soap)</td>
 </tr>

 <tr>
  <td>3291</td>
  <td>Abrasive Products (steel wool with or without soap)</td>

 </tr>
 <tr>
  <td>6321</td>
  <td>Accident and Health Insurance (disability insurers-direct)</td>

 </tr>
 <tr>
  <td>6321</td>
  <td>Accident and Health Insurance (health and medical insurers-direct)</td>

 </tr>
 <tr>
  <td>6321</td>
  <td>Accident and Health Insurance (reinsurers)</td>

 </tr>
 <tr>
  <td>6321</td>
  <td>Accident and Health Insurance (self insurers)</td>

 </tr>
 <tr>
  <td>8721</td>
  <td>AccountingAuditing  and Bookkeeping Services (auditing  accountants)</td>

 </tr>
 <tr>
  <td>8721</td>
  <td>AccountingAuditing  and Bookkeeping Services (other accounting
  services)</td>

 </tr>
 <tr>
  <td>8721</td>
  <td>AccountingAuditing  and Bookkeeping Services (payroll
  services)</td>

 </tr>
 <tr>
  <td>2891</td>
  <td>Adhesives and Sealants</td>

 </tr>
 <tr>
  <td>7322</td>
  <td>Adjustment and Collection Services</td>

 </tr>
 <tr>
  <td>9411</td>
  <td>Administration of Educational Programs</td>

 </tr>
 <tr>
  <td>9611</td>
  <td>Administration of General Economic Programs</td>

 </tr>
 <tr>
  <td>9531</td>
  <td>Administration of Housing Programs</td>

 </tr>
 <tr>
  <td>9431</td>
  <td>Administration of Public Health Programs</td>

 </tr>
 <tr>
  <td>9441</td>
  <td>Administration of SocialHuman
  Resource and Income Maintenance Programs</td>

 </tr>
 <tr>
  <td>9532</td>
  <td>Administration of Urban Planning and Community and Rural Development</td>

 </tr>
 <tr>
  <td>9451</td>
  <td>Administration of Veterans Affairs,  Except Health and Insurance</td>

 </tr>
 <tr>
  <td>7319</td>
  <td>Advertising NEC (advertising
  materials distributor)</td>

 </tr>
 <tr>
  <td>7319</td>
  <td>Advertising NEC (display
  advertisingaerial advertising using
  special purpose aircraftsuch as
  blimps)</td>

 </tr>
 <tr>
  <td>7319</td>
  <td>Advertising NEC (except media
  buyingdisplay advertising  except outdoor and advertising material
  distributors)</td>

 </tr>
 <tr>
  <td>7319</td>
  <td>Advertising NEC (media buying
  services)</td>

 </tr>
 <tr>
  <td>7319</td>
  <td>Advertising NEC (using general
  purpose aircraft for aerial advertising and a variety of other services)</td>

 </tr>
 <tr>
  <td>7311</td>
  <td>Advertising Agencies</td>

 </tr>
 <tr>
  <td>3563</td>
  <td>Air and Gas Compressors</td>

 </tr>
 <tr>
  <td>9511</td>
  <td>Air and Water Resource and Solid Waste Management</td>

 </tr>
 <tr>
  <td>4513</td>
  <td>Air Courier Services</td>

 </tr>
 <tr>
  <td>4522</td>
  <td>Air TransportationNonscheduled
  (air ambulance)</td>

 </tr>
 <tr>
  <td>4522</td>
  <td>Air TransportationNonscheduled
  (freight)</td>

 </tr>
 <tr>
  <td>4522</td>
  <td>Air TransportationNonscheduled
  (passenger)</td>

 </tr>
 <tr>
  <td>4522</td>
  <td>Air TransportationNonscheduled
  (sightseeing planes)</td>

 </tr>
 <tr>
  <td>4522</td>
  <td>Air Transportation Nonscheduled
  (using general purpose aircraft for a variety of passenger,  freight  courier and other uses)</td>

 </tr>
 <tr>
  <td>4512</td>
  <td>Air TransportationScheduled
  (freight)</td>

 </tr>
 <tr>
  <td>4512</td>
  <td>Air TransportationScheduled
  (passenger)</td>

 </tr>
 <tr>
  <td>3585</td>
  <td>Air-Conditioning and Warm Air Heating Equipment and Commercial and
  Industrial Refrigeration Equipment (except motor vehicle air-conditioning)</td>

 </tr>
 <tr>
  <td>3585</td>
  <td>Air-Conditioning and Warm Air Heating Equipment and Commercial and
  Industrial Refrigeration Equipment (motor vehicle air-conditioning)</td>

 </tr>
 <tr>
  <td>3721</td>
  <td>Aircraft (except research and development not producing prototypes)</td>

 </tr>
 <tr>
  <td>3721</td>
  <td>Aircraft (research and development not producing prototypes)</td>

 </tr>
 <tr>
  <td>3724</td>
  <td>Aircraft Engines and Engine Parts (except research and development not
  producing prototypes)</td>

 </tr>
 <tr>
  <td>3724</td>
  <td>Aircraft Engines and Engine Parts (research and development not producing
  prototypes)</td>

 </tr>
 <tr>
  <td>3728</td>
  <td>Aircraft Parts and Auxiliary Equipment �
    NEC (except fluid power aircraft subassemblies  target drones  and research and development not producing prototypes)</td>

 </tr>
 <tr>
  <td>3728</td>
  <td>Aircraft Parts and Auxiliary Equipment � NEC (fluid power aircraft subassemblies)</td>

 </tr>
 <tr>
  <td>3728</td>
  <td>Aircraft Parts and Auxiliary Equipment � NEC (research and development not producing prototypes)</td>

 </tr>
 <tr>
  <td>3728</td>
  <td>Aircraft Parts and Auxiliary Equipment � NEC (target drones)</td>

 </tr>
 <tr>
  <td>4581</td>
  <td>AirportsFlying Fields  and Airport Terminal Services (air freight
  handling at airportshangar
  operationsairport terminal
  servicesaircraft storage  airports �
   and flying fields)</td>

 </tr>
 <tr>
  <td>4581</td>
  <td>AirportsFlying Fields  and Airport Terminal Services (aircraft
  servicing and repairing)</td>

 </tr>
 <tr>
  <td>4581</td>
  <td>AirportsFlying Fields  and Airport Terminal Services (aircraft
  upholstery repair)</td>

 </tr>
 <tr>
  <td>4581</td>
  <td>AirportsFlying Fields  and Airport Terminal Services (airplane
  cleaning and janitorial services)</td>

 </tr>
 <tr>
  <td>4581</td>
  <td>AirportsFlying Fields  and Airport Terminal Services (private air
  traffic control)</td>

 </tr>
 <tr>
  <td>2812</td>
  <td>Alkalies and Chlorine</td>

 </tr>
 <tr>
  <td>3363</td>
  <td>Aluminum Die-Castings</td>

 </tr>
 <tr>
  <td>3354</td>
  <td>Aluminum Extruded Products</td>

 </tr>
 <tr>
  <td>3365</td>
  <td>Aluminum Foundries</td>

 </tr>
 <tr>
  <td>3355</td>
  <td>Aluminum Rolling and Drawing NEC</td>

 </tr>
 <tr>
  <td>3353</td>
  <td>Aluminum SheetPlate  and Foil</td>

 </tr>
 <tr>
  <td>3483</td>
  <td>AmmunitionExcept for Small Arms</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (aerial tramways, scenic
  and amusement)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (baseball, basketball  bowling �
   gymnasticjudo  karate �
   parachutescuba and skin
  divingskating  ski �
   swimmingtennis  and other sports instruction</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (bridge instructionyoga
  instructionand similar nonathletic
  instruction)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (canoepleasure boats  bicycles �
   motorcyclesmoped  go carts �
   etc. rental)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (casinosexcept hotel
  casinos)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (caverns and miscellaneous commercial parks)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (charter fishing)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services   NEC (circus companies and traveling carnival shows)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation
  Services NEC (except circuses  traveling carnivals  professional athletes  caverns and other commercial parks  skiing facilities  casinos and other gambling operations  nonmembership fitness and recreational
  sports centerssports
  instructionsports equipment
  rentalticket agencies  charter fishing  state fairsagriculture
  fairscounty fairs  operation of fishing lakes  phrenologists services  and amusement or scenic transport
  operations)</td>
 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (lotterybingo  bookie �
   and other gambling operations)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (nonmembership fitness and recreational sports centers)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (phrenologists services)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (professional athletes)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (scenic transport operations �
   land)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (skiing facilities)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (state fairsagriculture
  fairs and county fairs with facilities)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (state fairsagriculture
  fairs and county fairs without facilities)</td>

 </tr>
 <tr>
  <td>7999</td>
  <td>Amusement and Recreation Services � NEC (ticket agencies)</td>

 </tr>
 <tr>
  <td>7996</td>
  <td>Amusement Parks</td>

 </tr>
 <tr>
  <td>2077</td>
  <td>Animal and Marine Fats and Oils (animal fats and oils)</td>

 </tr>
 <tr>
  <td>2077</td>
  <td>Animal and Marine Fats and Oils (canned marine fats and oils)</td>

 </tr>
 <tr>
  <td>2077</td>
  <td>Animal and Marine Fats and Oils (fresh and frozen marine fats and oils)</td>

 </tr>
 <tr>
  <td>273</td>
  <td>Animal Aquaculture (except finfish and shellfish farms)</td>

 </tr>
 <tr>
  <td>273</td>
  <td>Animal Aquaculture (finfish farms)</td>

 </tr>
 <tr>
  <td>273</td>
  <td>Animal Aquaculture (shellfish farms)</td>

 </tr>
 <tr>
  <td>279</td>
  <td>Animal Specialties NEC
  (apiculture)</td>

 </tr>
 <tr>
  <td>279</td>
  <td>Animal Specialties NEC (except
  apiculturefrog and alligator farms)</td>

 </tr>
 <tr>
  <td>279</td>
  <td>Animal Specialties NEC (frog and
  alligator farms)</td>

 </tr>
 <tr>
  <td>752</td>
  <td>Animal Specialty ServicesExcept
  Veterinary (boarding and training horses (except race horses)  animal semen banks  and artificial insemination services for
  pets)</td>

 </tr>
 <tr>
  <td>752</td>
  <td>Animal Specialty ServicesExcept
  Veterinary (pet care servicesexcept
  veterinary)</td>

 </tr>
 <tr>
  <td>1231</td>
  <td>Anthracite Mining</td>

 </tr>
 <tr>
  <td>2389</td>
  <td>Apparel and Accessories NEC
  (accessories such as handkerchiefs, arm bands  cummerbunds suspenders, etc.  except contractors)</td>

 </tr>
 <tr>
  <td>2389</td>
  <td>Apparel and Accessories NEC
  (apparelsuch as academic gowns  clerical outerwear  and band uniforms  except contractors)</td>

 </tr>
 <tr>
  <td>2389</td>
  <td>Apparel and Accessories NEC
  (garters and garter belts except contractors)</td>

 </tr>
 <tr>
  <td>2389</td>
  <td>Apparel and Accessories NEC
  (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>2389</td>
  <td>Apparel and Accessories NEC
  (women'sGirl's  and infants' contractors)</td>

 </tr>
 <tr>
  <td>2387</td>
  <td>Apparel Belts (except contractors)</td>

 </tr>
 <tr>
  <td>2387</td>
  <td>Apparel Belts (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>2387</td>
  <td>Apparel Belts (women's �
   Girl'sand infants'
  contractors)</td>

 </tr>
 <tr>
  <td>8422</td>
  <td>Arboreta and Botanical or Zoological Gardens (except nature parks and
  reserves)</td>

 </tr>
 <tr>
  <td>8422</td>
  <td>Arboreta and Botanical or Zoological Gardens (nature parks and reserves)</td>

 </tr>
 <tr>
  <td>3446</td>
  <td>Architectural and Ornamental Metal Work</td>

 </tr>
 <tr>
  <td>8712</td>
  <td>Architectural Services</td>

 </tr>
 <tr>
  <td>7694</td>
  <td>Armature Rewinding Shops (remanufacturing)</td>

 </tr>
 <tr>
  <td>7694</td>
  <td>Armature Rewinding Shops (repair)</td>

 </tr>
 <tr>
  <td>4729</td>
  <td>Arrangement of Passenger Transportation � NEC (arrangement of carpools and vanpools)</td>

 </tr>
 <tr>
  <td>4729</td>
  <td>Arrangement of Passenger Transportation � NEC (except arrangement of vanpools and carpools)</td>

 </tr>
 <tr>
  <td>4731</td>
  <td>Arrangement of Transportation of Freight and Cargo (except freight rate
  auditorsprivate mail centers  and tariff consultants)</td>

 </tr>
 <tr>
  <td>4731</td>
  <td>Arrangement of Transportation of Freight and Cargo (freight rate-auditors
  and tariff consulting)</td>

 </tr>
 <tr>
  <td>3292</td>
  <td>Asbestos Products (asbestos brake linings and pads)</td>

 </tr>
 <tr>
  <td>3292</td>
  <td>Asbestos Products (asbestos clutch facings  motor vehicle)</td>

 </tr>
 <tr>
  <td>3292</td>
  <td>Asbestos Products (except brake pads and linings)</td>

 </tr>
 <tr>
  <td>2952</td>
  <td>Asphalt Felts and Coatings</td>

 </tr>
 <tr>
  <td>2951</td>
  <td>Asphalt Paving Mixtures and Blocks</td>

 </tr>
 <tr>
  <td>5531</td>
  <td>Auto and Home Supply Stores (auto supply stores)</td>

 </tr>
 <tr>
  <td>5531</td>
  <td>Auto and Home Supply Stores (other auto and home supply stores)</td>

 </tr>
 <tr>
  <td>5531</td>
  <td>Auto and Home Supply Stores (tires and tubes)</td>

 </tr>
 <tr>
  <td>3822</td>
  <td>Automatic Controls for Regulating Residential and Commercial Environments
  and Appliances</td>

 </tr>
 <tr>
  <td>5962</td>
  <td>Automatic Merchandise Machine Operators</td>

 </tr>
 <tr>
  <td>3581</td>
  <td>Automatic Vending Machines</td>

 </tr>
 <tr>
  <td>7521</td>
  <td>Automobile Parking</td>

 </tr>
 <tr>
  <td>5012</td>
  <td>Automobiles and Other Motor Vehicles (agents and brokers)</td>

 </tr>
 <tr>
  <td>5012</td>
  <td>Automobiles and Other Motor Vehicles (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5012</td>
  <td>Automobiles and Other Motor Vehicles (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>5599</td>
  <td>Automotive Dealers NEC</td>

 </tr>
 <tr>
  <td>7533</td>
  <td>Automotive Exhaust System Repair Shops</td>

 </tr>
 <tr>
  <td>7536</td>
  <td>Automotive Glass Replacement Shops</td>

 </tr>
 <tr>
  <td>7539</td>
  <td>Automotive Repair Shops NEC
  (automotive air-conditioning repair)</td>

 </tr>
 <tr>
  <td>7539</td>
  <td>Automotive Repair Shops NEC
  (except automotive air-conditioning repair)</td>

 </tr>
 <tr>
  <td>7549</td>
  <td>Automotive ServicesExcept Repair
  and Carwashes (automotive window tinting)</td>

 </tr>
 <tr>
  <td>7549</td>
  <td>Automotive ServicesExcept Repair
  and Carwashes (except automotive lubricating �
   automotive window tintingand
  towing services)</td>

 </tr>
 <tr>
  <td>7549</td>
  <td>Automotive ServicesExcept Repair
  and Carwashes (lubricating service �
   automotive)</td>

 </tr>
 <tr>
  <td>7549</td>
  <td>Automotive ServicesExcept Repair
  and Carwashes (towing)</td>

 </tr>
 <tr>
  <td>3465</td>
  <td>Automotive Stampings</td>

 </tr>
 <tr>
  <td>7537</td>
  <td>Automotive Transmission Repair Shops</td>

 </tr>
 <tr>
  <td>2396</td>
  <td>Automotive TrimmingsApparel
  Findingsand Related Products
  (apparel findings and trimmings �
   except contractors)</td>

 </tr>
 <tr>
  <td>2396</td>
  <td>Automotive TrimmingsApparel
  Findingsand Related Products (men's
  and boys' contractors)</td>

 </tr>
 <tr>
  <td>2396</td>
  <td>Automotive TrimmingsApparel
  Findingsand Related Products
  (printing and embossing on fabric articles)</td>

 </tr>
 <tr>
  <td>2396</td>
  <td>Automotive TrimmingsApparel
  Findingsand Related Products
  (textile motor vehicle trimming except contractors)</td>

 </tr>
 <tr>
  <td>2396</td>
  <td>Automotive TrimmingsApparel
  Findingsand Related Products
  (textile products except automotive and apparel trimmings and findings  printing or embossing on apparel  and contractors)</td>

 </tr>
 <tr>
  <td>2396</td>
  <td>Automotive TrimmingsApparel
  Findingsand Related Products
  (women'sGirl's  and infants' contractors)</td>

 </tr>
 <tr>
  <td>3562</td>
  <td>Ball and Roller Bearings</td>

 </tr>
 <tr>
  <td>7929</td>
  <td>BandsOrchestras  Actors �
   and Entertainment Groups �
   (except musical groupsmusical
  artistsorchestras  actors �
   and actresses)</td>

 </tr>
 <tr>
  <td>7929</td>
  <td>BandsOrchestras  Actors �
   and Other Entertainers and Entertainment Groups (actors and actresses)</td>

 </tr>
 <tr>
  <td>7929</td>
  <td>BandsOrchestras  Actors �
   and Other Entertainers Entertainment Groups (musical groups  musical artists and orchestras)</td>

 </tr>
 <tr>
  <td>7241</td>
  <td>Barber Shops (barber colleges)</td>

 </tr>
 <tr>
  <td>7241</td>
  <td>Barber Shops (except barber colleges)</td>

 </tr>
 <tr>
  <td>7231</td>
  <td>Beauty Shops (beauty and cosmetology schools)</td>

 </tr>
 <tr>
  <td>7231</td>
  <td>Beauty Shops (except beauty and cosmetology schools and manicure and
  pedicure salons)</td>

 </tr>
 <tr>
  <td>7231</td>
  <td>Beauty Shops (manicure and pedicure salons)</td>

 </tr>
 <tr>
  <td>212</td>
  <td>Beef CattleExcept Feedlots</td>

 </tr>
 <tr>
  <td>211</td>
  <td>Beef Cattle Feedlots</td>

 </tr>
 <tr>
  <td>5181</td>
  <td>Beer and Ale (agents and brokers)</td>

 </tr>
 <tr>
  <td>5181</td>
  <td>Beer and Ale (beer and ale sold via retail method)</td>

 </tr>
 <tr>
  <td>5181</td>
  <td>Beer and Ale (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5181</td>
  <td>Beer and Ale (merchant wholesalers except those selling beer and ale via
  retail method)</td>

 </tr>
 <tr>
  <td>2063</td>
  <td>Beet Sugar</td>

 </tr>
 <tr>
  <td>171</td>
  <td>Berry Crops ( except strawberry farms)</td>

 </tr>
 <tr>
  <td>171</td>
  <td>Berry Crops (strawberry farms)</td>

 </tr>
 <tr>
  <td>2836</td>
  <td>Biological ProductsExcept
  Diagnostic Substances</td>

 </tr>
 <tr>
  <td>1221</td>
  <td>Bituminous Coal and Lignite Surface Mining</td>

 </tr>
 <tr>
  <td>1222</td>
  <td>Bituminous Coal Underground Mining</td>

 </tr>
 <tr>
  <td>2782</td>
  <td>BlankbooksLooseleaf Binders and
  Devices (checkbooks)</td>

 </tr>
 <tr>
  <td>2782</td>
  <td>BlankbooksLooseleaf Binders and
  Devices (except checkbooks)</td>

 </tr>
 <tr>
  <td>3732</td>
  <td>Boat Building and Repairing (boat building)</td>

 </tr>
 <tr>
  <td>3732</td>
  <td>Boat Building and Repairing (pleasure boat repair)</td>

 </tr>
 <tr>
  <td>5551</td>
  <td>Boat Dealers </td>

 </tr>
 <tr>
  <td>3452</td>
  <td>Bolts,Nuts, Screws,  Rivetsand Washers</td>

 </tr>
 <tr>
  <td>2732</td>
  <td>Book Printing</td>

 </tr>
 <tr>
  <td>5942</td>
  <td>Book Stores</td>

 </tr>
 <tr>
  <td>2789</td>
  <td>Bookbinding and Related Work</td>

 </tr>
 <tr>
  <td>5192</td>
  <td>BooksPeriodicals  and Newspapers (agents and brokers)</td>

 </tr>
 <tr>
  <td>5192</td>
  <td>BooksPeriodicals  and Newspapers (business to business
  electronic markets)</td>

 </tr>
 <tr>
  <td>5192</td>
  <td>BooksPeriodicals  and Newspapers (merchant wholesalers
  except those selling publications via retail method)</td>

 </tr>
 <tr>
  <td>5192</td>
  <td>BooksPeriodicals  and Newspapers (sold via retail method)</td>

 </tr>
 <tr>
  <td>2731</td>
  <td>Books: Publishingor Publishing
  and Printing (except music books and Internet book publishing)</td>

 </tr>
 <tr>
  <td>2731</td>
  <td>Books: Publishingor Publishing
  and Printing (Internet book publishing)</td>

 </tr>
 <tr>
  <td>2731</td>
  <td>Books: Publishingor Publishing
  and Printing (music books)</td>

 </tr>
 <tr>
  <td>3131</td>
  <td>Boot and Shoe Cut Stock and Findings (except wood heels and metal
  buckles)</td>

 </tr>
 <tr>
  <td>3131</td>
  <td>Boot and Shoe Cut Stock and Findings (metal buckles)</td>

 </tr>
 <tr>
  <td>3131</td>
  <td>Boot and Shoe Cut Stock and Findings (wood heels)</td>

 </tr>
 <tr>
  <td>2086</td>
  <td>Bottled and Canned Soft Drinks and Carbonated Water (bottled water)</td>

 </tr>
 <tr>
  <td>2086</td>
  <td>Bottled and Canned Soft Drinks and Carbonated Water (except bottled
  water)</td>

 </tr>
 <tr>
  <td>7933</td>
  <td>Bowling Centers</td>

 </tr>
 <tr>
  <td>6081</td>
  <td>Branches and Agencies of Foreign Banks (agencies  except international trade financing)</td>

 </tr>
 <tr>
  <td>6081</td>
  <td>Branches and Agencies of Foreign Banks (branches)</td>

 </tr>
 <tr>
  <td>6081</td>
  <td>Branches and Agencies of Foreign Banks (international trade financing)</td>

 </tr>
 <tr>
  <td>2342</td>
  <td>BrassieresGirdles  and Allied Garments (contractors)</td>

 </tr>
 <tr>
  <td>2342</td>
  <td>BrassieresGirdles  and Allied Garments (except contractors)</td>

 </tr>
 <tr>
  <td>2051</td>
  <td>Bread and Other Bakery Products �
   Except Cookies and Crackers</td>

 </tr>
 <tr>
  <td>5032</td>
  <td>Brick, Stone  and Related Construction Materials  (agents and brokers)</td>

 </tr>
 <tr>
  <td>5032</td>
  <td>Brick, Stone  and Related Construction Materials  (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5032</td>
  <td>Brick, Stone  and Related Construction Materials  (merchant wholesalers except construction
  materials sold via retail method)</td>

 </tr>
 <tr>
  <td>5032</td>
  <td>Brick, Stone  and Related Construction Materials
  (Brick, Stone  and related construction materials sold
  via retail method)</td>

 </tr>
 <tr>
  <td>3251</td>
  <td>Brick and Structural Clay Tile (except slumped brick)</td>

 </tr>
 <tr>
  <td>3251</td>
  <td>Brick and Structural Clay Tile (slumped brick)</td>

 </tr>
 <tr>
  <td>1622</td>
  <td>Bridge  Tunnel �
   and Elevated Highway Construction (bridge and elevated highway
  construction) </td>

 </tr>
 <tr>
  <td>1622</td>
  <td>BridgeTunnel  and Elevated Highway Construction (tunnel
  construction)</td>

 </tr>
 <tr>
  <td>2211</td>
  <td>Broadwoven Fabric MillsCotton</td>

 </tr>
 <tr>
  <td>2221</td>
  <td>Broadwoven Fabric MillsManmade
  Fiber and Silk</td>

 </tr>
 <tr>
  <td>2231</td>
  <td>Broadwoven Fabric MillsWool
  (Including Dyeing and Finishing) (except finishing wool fabric without
  weaving wool fabric)</td>

 </tr>
 <tr>
  <td>2231</td>
  <td>Broadwoven Fabric MillsWool
  (wool broadwoven fabric finishing without weaving fabric)</td>

 </tr>
 <tr>
  <td>2231</td>
  <td>Broadwoven Fabric MillsWool
  (wool fabricexcept broadwoven  finishing without weaving fabric)</td>

 </tr>
 <tr>
  <td>251</td>
  <td>BroilerFryer  and Roaster Chickens</td>

 </tr>
 <tr>
  <td>3991</td>
  <td>Brooms and Brushes</td>

 </tr>
 <tr>
  <td>7349</td>
  <td>Building Cleaning and Maintenance Services    NEC (janitorial services)</td>

 </tr>
 <tr>
  <td>7349</td>
  <td>Building Cleaning and Maintenance Services    NEC (services to buildings and dwellings  except janitorial services)</td>

 </tr>
 <tr>
  <td>3995</td>
  <td>Burial Caskets</td>

 </tr>
 <tr>
  <td>4142</td>
  <td>Bus Charter ServiceExcept Local</td>

 </tr>
 <tr>
  <td>8244</td>
  <td>Business and Secretarial Schools</td>

 </tr>
 <tr>
  <td>8611</td>
  <td>Business Associations</td>

 </tr>
 <tr>
  <td>8748</td>
  <td>Business Consulting Services NEC
  (educational test development and evaluation services  educational testing services  and educational consultants)</td>

 </tr>
 <tr>
  <td>8748</td>
  <td>Business Consulting Services   NEC (except educational testing and
  consultingeconomic consulting  safety and security  agriculture consulting  environmental consulting firms  urban planning and industrial development
  organizations)</td>
 </tr>

 <tr>
  <td>8748</td>
  <td>Business Consulting Services NEC
  (safetysecurity  agriculture   and economic consultants)</td>

 </tr>
 <tr>
  <td>8748</td>
  <td>Business Consulting Services NEC
  (traffic consultants)</td>

 </tr>
 <tr>
  <td>8748</td>
  <td>Business Consulting Services NEC
  (urban planners and industrial development organizations)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (aerosol
  packagingsolvent recovery
  service-contract)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (agents and
  brokers for authors and artists and speaker bureaus)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (apparel
  pressing service for the trade)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (audio
  taping services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (business
  support services except telephone answering �
   telemarketing bureausprivate
  mail centers and repossession services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (convention
  and trade show services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (convention
  and visitors bureaustourist
  information bureaus)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (credit
  card and check validation service)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC
  (distribution of telephone directories on a fee or contract basis)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services   NEC (drafting service) </td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (driving
  servicese.g.  auto or truck delivery and pilot car
  services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (embroidery
  of advertising on shirts and rug binding for the trade)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC
  (fashionfurniture  and other design services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (home and
  building inspection services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (industrial
  design)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (interior
  design)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (map making
  services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (microfilm
  services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (other
  business service centersexcept
  private mail centers and mailbox rental)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (other
  support services except packaging and labeling   convention and trade shows services   convention and visitor bureaus �
   tourist information bureaus)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (packaging
  and labeling services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (post
  office contract stations)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (press
  clipping services and stock photo agencies)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (private
  mail centers and mailbox rental)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (process
  servicespatent agents  notaries public   paralegal services )</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (promoters
  of air showsheritage festivals  and ethnic festivals with facilities)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (promoters
  of air showsheritage festivals  and ethnic festivals without facilities)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (radio
  transcription services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (recording
  studios)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (recovery
  and repossession services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC
  (reservation systems for hotels �
   restaurantsand time-share
  condominium exchanges)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (sign
  painting and letteringshowcard
  paintingmannequin decorating service
  and other advertising related business services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC
  (spongingshrinking  etc. fabric for tailors and dress
  makersbatik work)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (swimming
  pool cleaning and maintenance)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (tax
  collection for federalstate  or local agencies)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC
  (telemarketing bureaus and telephone soliciting)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (telephone
  answering services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (tobacco
  sheeting service)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC
  (translation and interpretation services)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services NEC (yacht
  brokers)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Business Services (appraisers except insurance and real estate  outplacement services  and miscellaneous professional  scientific   and technical services)</td>

 </tr>
 <tr>
  <td>4841</td>
  <td>Cable and Other Pay Television Services (cable networks)</td>

 </tr>
 <tr>
  <td>4841</td>
  <td>Cable and Other Pay Television Services (except cable and other
  subscription programming)</td>

 </tr>
 <tr>
  <td>3578</td>
  <td>Calculating and Accounting Machinery �
   Except Electronic Computers (change making machines)</td>

 </tr>
 <tr>
  <td>3578</td>
  <td>Calculating and Accounting Machinery �
   Except Electronic Computers (except point of sales terminals  change making machines and funds transfer
  devices)</td>

 </tr>
 <tr>
  <td>3578</td>
  <td>Calculating and Accounting Machines �
   Except Electronic Computers (point of sale terminals and fund transfer
  devices)</td>

 </tr>
 <tr>
  <td>5946</td>
  <td>Camera and Photographic Supply Stores</td>

 </tr>
 <tr>
  <td>5441</td>
  <td>CandyNut  and Confectionery Stores (chocolate candy
  storespreparing on premises)</td>

 </tr>
 <tr>
  <td>5441</td>
  <td>CandyNut  and Confectionery Stores (except stores
  preparing candy on premises)</td>

 </tr>
 <tr>
  <td>5441</td>
  <td>CandyNut  and Confectionery Stores (nonchocolate
  candy storespreparing on premises)</td>

 </tr>
 <tr>
  <td>2064</td>
  <td>Candy and Other Confectionery Products (chocolate confectionery)</td>

 </tr>
 <tr>
  <td>2064</td>
  <td>Candy and Other Confectionery Products (nonchocolate confectionery )</td>

 </tr>
 <tr>
  <td>2061</td>
  <td>Cane SugarExcept Refining</td>

 </tr>
 <tr>
  <td>2062</td>
  <td>Cane Sugar Refining</td>

 </tr>
 <tr>
  <td>2091</td>
  <td>Canned and Cured Fish and Seafoods</td>

 </tr>
 <tr>
  <td>2033</td>
  <td>Canned FruitsVegetables  Preserves �
   Jamsand Jellies</td>

 </tr>
 <tr>
  <td>2032</td>
  <td>Canned Specialties (canned puddings)</td>

 </tr>
 <tr>
  <td>2032</td>
  <td>Canned Specialties (except canned puddings)</td>

 </tr>
 <tr>
  <td>2394</td>
  <td>Canvas and Related Products</td>

 </tr>
 <tr>
  <td>3624</td>
  <td>Carbon and Graphite Products </td>

 </tr>
 <tr>
  <td>2895</td>
  <td>Carbon Black</td>

 </tr>
 <tr>
  <td>3955</td>
  <td>Carbon Paper and Inked Ribbons</td>

 </tr>
 <tr>
  <td>3592</td>
  <td>CarburetorsPistons  Piston Rings   and Valves</td>

 </tr>
 <tr>
  <td>1751</td>
  <td>Carpentry Work (finish carpentry)</td>

 </tr>
 <tr>
  <td>1751</td>
  <td>Carpentry Work (framing carpentry)</td>

 </tr>
 <tr>
  <td>7217</td>
  <td>Carpet and Upholstery Cleaning</td>

 </tr>
 <tr>
  <td>2273</td>
  <td>Carpets and Rugs</td>

 </tr>
 <tr>
  <td>7542</td>
  <td>Carwashes</td>

 </tr>
 <tr>
  <td>119</td>
  <td>Cash Grains NEC (dry pea and bean
  farms)</td>

 </tr>
 <tr>
  <td>119</td>
  <td>Cash Grains NEC (except
  popcorndry pea and bean  oilseed (except soybean)  and oilseed and grain combination farms)</td>

 </tr>
 <tr>
  <td>119</td>
  <td>Cash Grains NEC (oilseed and
  grain combination farms)</td>

 </tr>
 <tr>
  <td>119</td>
  <td>Cash Grains NEC (oilseed
  farmingexcept soybeans)</td>

 </tr>
 <tr>
  <td>119</td>
  <td>Cash Grains NEC (popcorn farming)</td>

 </tr>
 <tr>
  <td>5961</td>
  <td>Catalog and Mail-Order Houses (electronic auctions)</td>

 </tr>
 <tr>
  <td>5961</td>
  <td>Catalog and Mail-Order Houses (electronic shopping web sites)</td>

 </tr>
 <tr>
  <td>5961</td>
  <td>Catalog and Mail-Order Houses (mail-order houses)</td>

 </tr>
 <tr>
  <td>2823</td>
  <td>Cellulosic Manmade Fibers</td>

 </tr>
 <tr>
  <td>3241</td>
  <td>CementHydraulic</td>

 </tr>
 <tr>
  <td>6553</td>
  <td>Cemetery Subdividers and Developers</td>

 </tr>
 <tr>
  <td>6019</td>
  <td>Central Reserve Depository Institutions � NEC</td>

 </tr>
 <tr>
  <td>3253</td>
  <td>Ceramic Wall and Floor Tile</td>

 </tr>
 <tr>
  <td>2043</td>
  <td>Cereal Breakfast Foods (cereal breakfast foods and related preparations
  except grain based coffee substitutes)</td>

 </tr>
 <tr>
  <td>2043</td>
  <td>Cereal Breakfast Foods (grain based coffee substitutes)</td>

 </tr>
 <tr>
  <td>1479</td>
  <td>Chemical and Fertilizer Mineral Mining � NEC</td>

 </tr>
 <tr>
  <td>5169</td>
  <td>Chemicals and Allied Products NEC
  (agents and brokers)</td>

 </tr>
 <tr>
  <td>5169</td>
  <td>Chemicals and Allied Products NEC
  (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5169</td>
  <td>Chemicals and Allied Products NEC
  (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>2899</td>
  <td>Chemicals and Chemical Preparations � NEC (except fritfatty
  acidsplastic wood fillers  and table salt)</td>

 </tr>
 <tr>
  <td>2899</td>
  <td>Chemicals and Chemical Preparations � NEC (fatty acids)</td>

 </tr>
 <tr>
  <td>2899</td>
  <td>Chemicals and Chemical Preparations � NEC (frit and plastic wood fillers)</td>

 </tr>
 <tr>
  <td>2899</td>
  <td>Chemicals and Chemical Preparations � NEC (table salt)</td>

 </tr>
 <tr>
  <td>2131</td>
  <td>Chewing and Smoking Tobacco and Snuff</td>

 </tr>
 <tr>
  <td>2067</td>
  <td>Chewing Gum</td>

 </tr>
 <tr>
  <td>252</td>
  <td>Chicken Eggs</td>

 </tr>
 <tr>
  <td>8351</td>
  <td>Child Day Care Services</td>

 </tr>
 <tr>
  <td>5641</td>
  <td>Children's and Infants' Wear Stores</td>

 </tr>
 <tr>
  <td>2066</td>
  <td>Chocolate and Cocoa Products (chocolate products made from purchased
  chocolate)</td>

 </tr>
 <tr>
  <td>2066</td>
  <td>Chocolate and Cocoa Products (except chocolate products  made from purchased chocolate)</td>

 </tr>
 <tr>
  <td>2111</td>
  <td>Cigarettes</td>

 </tr>
 <tr>
  <td>2121</td>
  <td>Cigars</td>

 </tr>
 <tr>
  <td>174</td>
  <td>Citrus Fruits (except orange groves and farms)</td>

 </tr>
 <tr>
  <td>174</td>
  <td>Citrus Fruits (orange groves and farms)</td>

 </tr>
 <tr>
  <td>8641</td>
  <td>CivicSocial  and Fraternal Associations (condominium
  and homeowner associations)</td>

 </tr>
 <tr>
  <td>8641</td>
  <td>Civic   Socialand Fraternal
  Associations (except condominium and homeowner associations  taxpayers associations  tenants advocacy associations  temperance organizations  and Indian and Alaska Native Tribal
  Councils)</td>

 </tr>
 <tr>
  <td>8641</td>
  <td>CivicSocial  and Fraternal Associations (Indian and
  Alaska Native Tribal Councils)</td>

 </tr>
 <tr>
  <td>8641</td>
  <td>CivicSocial  and Fraternal Associations (taxpayers'
  associationstenants' advocacy
  associationstemperance
  organizations)</td>

 </tr>
 <tr>
  <td>1459</td>
  <td>ClayCeramic  and Refractory Minerals   NEC</td>

 </tr>
 <tr>
  <td>3255</td>
  <td>Clay Refractories</td>

 </tr>
 <tr>
  <td>5052</td>
  <td>Coal and Other Minerals and Ores (agents and brokers)</td>

 </tr>
 <tr>
  <td>5052</td>
  <td>Coal and Other Minerals and Ores (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5052</td>
  <td>Coal and Other Minerals and Ores (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>1241</td>
  <td>Coal Mining Services (except site preparation and related construction
  activities on a contract basis)</td>

 </tr>
 <tr>
  <td>1241</td>
  <td>Coal Mining Services (site preparation and related construction
  activities on a contract basis)</td>

 </tr>
 <tr>
  <td>2672</td>
  <td>Coated and Laminated Paper NEC</td>

 </tr>
 <tr>
  <td>2295</td>
  <td>Coated FabricsNot Rubberized</td>

 </tr>
 <tr>
  <td>3479</td>
  <td>CoatingEngraving  and Allied Services   NEC (costume jewelry engraving and
  etching)</td>

 </tr>
 <tr>
  <td>3479</td>
  <td>CoatingEngraving  and Allied Services   NEC (except jewelry  silverware   and flatware engraving and etching)</td>

 </tr>
 <tr>
  <td>3479</td>
  <td>CoatingEngraving  and Allied Services   NEC (precious metal jewelry engraving and
  etching)</td>

 </tr>
 <tr>
  <td>3479</td>
  <td>CoatingEngraving  and Allied Services   NEC (silver and plated ware engraving and
  etching)</td>

 </tr>
 <tr>
  <td>7993</td>
  <td>Coin-Operated Amusement Devices (amusement arcades)</td>

 </tr>
 <tr>
  <td>7993</td>
  <td>Coin-Operated Amusement Devices (except amusement arcades and slot
  machine operators)</td>

 </tr>
 <tr>
  <td>7993</td>
  <td>Coin-Operated Amusement Devices (slot machine operators)</td>

 </tr>
 <tr>
  <td>7215</td>
  <td>Coin-Operated Laundry and
  Drycleaning </td>

 </tr>
 <tr>
  <td>3316</td>
  <td>Cold-Rolled Steel Sheet �
   Stripand Bars</td>

 </tr>
 <tr>
  <td>8221</td>
  <td>CollegesUniversities  and Professional Schools</td>

 </tr>
 <tr>
  <td>4939</td>
  <td>Combination Utilities NEC
  (electric power distribution)</td>

 </tr>
 <tr>
  <td>4939</td>
  <td>Combination
  Utilities NEC (electric power
  transmission and control) </td>

 </tr>
 <tr>
  <td>4939</td>
  <td>Combination Utilities NEC (fossil
  fuel power generation)</td>

 </tr>
 <tr>
  <td>4939</td>
  <td>Combination Utilities NEC
  (hydroelectric power generation)</td>

 </tr>
 <tr>
  <td>4939</td>
  <td>Combination Utilities NEC
  (natural gas distribution)</td>

 </tr>
 <tr>
  <td>4939</td>
  <td>Combination Utilities NEC
  (nuclear power generation)</td>

 </tr>
 <tr>
  <td>4939</td>
  <td>Combination Utilities NEC (other
  electric power generation)</td>

 </tr>
 <tr>
  <td>3646</td>
  <td>CommercialIndustrial  and Institutional Electric Lighting
  Fixtures</td>

 </tr>
 <tr>
  <td>7336</td>
  <td>Commercial Art and Graphic Design</td>

 </tr>
 <tr>
  <td>6029</td>
  <td>Commercial Banks    NEC </td>

 </tr>
 <tr>
  <td>8732</td>
  <td>Commercial Economic �
   Sociologicaland Educational
  Research (market research and opinion research)</td>

 </tr>
 <tr>
  <td>8732</td>
  <td>Commercial Economic �
   Sociologicaland Educational
  Research (social sciences and humanities)</td>

 </tr>
 <tr>
  <td>5046</td>
  <td>Commercial Equipment NEC (agents
  and brokers)</td>

 </tr>
 <tr>
  <td>5046</td>
  <td>Commercial Equipment NEC
  (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5046</td>
  <td>Commercial Equipment NEC
  (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>3582</td>
  <td>Commercial Laundry �
   Drycleaningand Pressing
  Machines</td>

 </tr>
 <tr>
  <td>7335</td>
  <td>Commercial Photography (except using general purpose aircraft for aerial
  photography and a variety of other services)</td>

 </tr>
 <tr>
  <td>7335</td>
  <td>Commercial Photography (using general purpose aircraft for aerial
  photography and a variety of other services)</td>

 </tr>
 <tr>
  <td>8731</td>
  <td>Commercial Physical and Biological Research</td>

 </tr>
 <tr>
  <td>2754</td>
  <td>Commercial PrintingGravure</td>

 </tr>
 <tr>
  <td>2752</td>
  <td>Commercial PrintingLithographic
  (except quick printing)</td>

 </tr>
 <tr>
  <td>2752</td>
  <td>Commercial PrintingLithographic
  (quick printing)</td>

 </tr>
 <tr>
  <td>2759</td>
  <td>Commercial Printing NEC (digital
  printingexcept quick printing)</td>

 </tr>
 <tr>
  <td>2759</td>
  <td>Commercial Printing NEC
  (flexographic printing)</td>

 </tr>
 <tr>
  <td>2759</td>
  <td>Commercial Printing NEC (other
  commercial printing except flexographic �
   screendigital  and quick printing)</td>

 </tr>
 <tr>
  <td>2759</td>
  <td>Commercial Printing NEC (quick
  printing)</td>

 </tr>
 <tr>
  <td>2759</td>
  <td>Commercial Printing NEC (screen
  printing)</td>

 </tr>
 <tr>
  <td>6221</td>
  <td>Commodity Contracts Brokers and Dealers (commodity brokers)</td>

 </tr>
 <tr>
  <td>6221</td>
  <td>Commodity Contracts Brokers and Dealers (commodity dealers)</td>

 </tr>
 <tr>
  <td>3669</td>
  <td>Communications Equipment NEC</td>

 </tr>
 <tr>
  <td>4899</td>
  <td>Communications Services NEC
  (except ship to shore broadcasting �
   satellite communicationspay
  telephone concession operators)</td>

 </tr>
 <tr>
  <td>4899</td>
  <td>Communications Services NEC (pay
  telephone concession operators)</td>

 </tr>
 <tr>
  <td>4899</td>
  <td>Communications Services NEC
  (radio broadcasting operated by cab companies)</td>

 </tr>
 <tr>
  <td>4899</td>
  <td>Communications Services NEC
  (satellite communications)</td>

 </tr>
 <tr>
  <td>4899</td>
  <td>Communications Services NEC (ship
  to shore broadcasting carriers)</td>

 </tr>
 <tr>
  <td>5734</td>
  <td>Computer and Computer Software Stores</td>

 </tr>
 <tr>
  <td>7376</td>
  <td>Computer Facilities Management Services</td>

 </tr>
 <tr>
  <td>7373</td>
  <td>Computer Integrated Systems Design</td>

 </tr>
 <tr>
  <td>7378</td>
  <td>Computer Maintenance and Repair (except sales locations providing
  supporting repair services as major source of revenue)</td>

 </tr>
 <tr>
  <td>7378</td>
  <td>Computer Maintenance and Repair (sales locations providing supporting
  repair services as major source of receipts)</td>

 </tr>
 <tr>
  <td>3577</td>
  <td>Computer Peripheral Equipment NEC
  (except plotter controllers and magnetic tape head cleaners)</td>

 </tr>
 <tr>
  <td>3577</td>
  <td>Computer Peripheral Equipment NEC
  (magnetic tape head cleaners)</td>

 </tr>
 <tr>
  <td>3577</td>
  <td>Computer Peripheral Equipment NEC
  (plotter controllers)</td>

 </tr>
 <tr>
  <td>7374</td>
  <td>Computer Processing and Data Preparation and Processing Services</td>

 </tr>
 <tr>
  <td>7371</td>
  <td>Computer Programming Services</td>

 </tr>
 <tr>
  <td>7379</td>
  <td>Computer Related Services NEC
  (computer systems consultants)</td>

 </tr>
 <tr>
  <td>7379</td>
  <td>Computer Related Services NEC
  (disk conversion services)</td>

 </tr>
 <tr>
  <td>7379</td>
  <td>Computer Related Services NEC
  (except computer systems consultants and disk conversion services)</td>

 </tr>
 <tr>
  <td>7377</td>
  <td>Computer Rental and Leasing</td>

 </tr>
 <tr>
  <td>3572</td>
  <td>Computer Storage Devices</td>

 </tr>
 <tr>
  <td>3575</td>
  <td>Computer Terminals</td>

 </tr>
 <tr>
  <td>5045</td>
  <td>Computers and Computer Peripheral Equipment and Software (agents and
  brokers)</td>

 </tr>
 <tr>
  <td>5045</td>
  <td>Computers and Computer Peripheral Equipment and Software (business to
  business electronic markets)</td>

 </tr>
 <tr>
  <td>5045</td>
  <td>Computers and Computer Peripheral Equipment and Software (computers  peripherals   and software sold via retail method)</td>

 </tr>
 <tr>
  <td>5045</td>
  <td>Computers and Computer Peripheral Equipment and Software (merchant
  wholesalers except those selling computers �
   equipmentand software via
  retail method)</td>

 </tr>
 <tr>
  <td>3271</td>
  <td>Concrete Block and Brick</td>

 </tr>
 <tr>
  <td>3272</td>
  <td>Concrete ProductsExcept Block
  and Brick (concrete pipe)</td>

 </tr>
 <tr>
  <td>3272</td>
  <td>Concrete ProductsExcept Block
  and Brick (concrete productsexcept
  dry mix concrete and pipe)</td>

 </tr>
 <tr>
  <td>3272</td>
  <td>Concrete ProductsExcept Block
  and Brick (dry mixture concrete)</td>

 </tr>
 <tr>
  <td>1771</td>
  <td>Concrete Work (asphaltbrick  and concrete paving)</td>

 </tr>
 <tr>
  <td>1771</td>
  <td>Concrete Work (concrete work except stucco work and asphalt  brick �
   and paving)</td>

 </tr>
 <tr>
  <td>1771</td>
  <td>Concrete Work (stucco work)</td>

 </tr>
 <tr>
  <td>5145</td>
  <td>Confectionery (agents and brokers)</td>

 </tr>
 <tr>
  <td>5145</td>
  <td>Confectionery (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5145</td>
  <td>Confectionery (confectionery sold via retail method)</td>

 </tr>
 <tr>
  <td>5145</td>
  <td>Confectionery (merchant wholesalers except those selling confectionery
  via retail method)</td>

 </tr>
 <tr>
  <td>5082</td>
  <td>Construction and Mining (Except Petroleum) Machinery and Equipment
  (agents and brokers)</td>

 </tr>
 <tr>
  <td>5082</td>
  <td>Construction and Mining (Except Petroleum) Machinery and Equipment
  (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5082</td>
  <td>Construction and Mining (Except Petroleum) Machinery and Equipment
  (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>3531</td>
  <td>Construction Machinery and Equipment (railway track maintenance
  equipment)</td>

 </tr>
 <tr>
  <td>3531</td>
  <td>Construction Machinery and Equipment (winches   aerial work platforms �
   automobile wrecker hoists �
   locomotive cranesand ship
  cranes)</td>

 </tr>
 <tr>
  <td>5039</td>
  <td>Construction Materials NEC
  (agents and brokers)</td>

 </tr>
 <tr>
  <td>5039</td>
  <td>Construction Materials NEC
  (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5039</td>
  <td>Construction Materials NEC (glass
  sold via retail method)</td>

 </tr>
 <tr>
  <td>5039</td>
  <td>Construction Materials NEC
  (merchant wholesalers of construction materials    NEC except wood prefabricated buildings and structural
  assemblies and merchant wholesalers selling via retail method)</td>

 </tr>
 <tr>
  <td>5039</td>
  <td>Construction Materials NEC
  (merchant wholesalers of prefabricated buildings and structural
  assemblieswood)</td>

 </tr>
 <tr>
  <td>1442</td>
  <td>Construction Sand and Gravel</td>

 </tr>
 <tr>
  <td>2679</td>
  <td>Converted Paper and Paperboard Products � NEC ( except corrugated paper �
   wall papergift wrap
  paperpaper supplies for business
  machinesand other paper office
  supplies)</td>

 </tr>
 <tr>
  <td>2679</td>
  <td>Converted Paper and Paperboard Products � NEC (corrugated paper)</td>

 </tr>
 <tr>
  <td>2679</td>
  <td>Converted Paper and Paperboard Products � NEC (paper supplies for business machines   such as adding machine tape �
   and other paper office supplies)</td>

 </tr>
 <tr>
  <td>2679</td>
  <td>Converted Paper and Paperboard Products � NEC (wallpaper and gift wrap paper)</td>

 </tr>
 <tr>
  <td>3535</td>
  <td>Conveyors and Conveying Equipment</td>

 </tr>
 <tr>
  <td>2052</td>
  <td>Cookies and Crackers (except unleavened bread and pretzels)</td>

 </tr>
 <tr>
  <td>2052</td>
  <td>Cookies and Crackers (hard pretzels and snack pretzels  except soft)</td>

 </tr>
 <tr>
  <td>2052</td>
  <td>Cookies and Crackers (unleavened bread and soft pretzels)</td>

 </tr>
 <tr>
  <td>3366</td>
  <td>Copper Foundries</td>

 </tr>
 <tr>
  <td>1021</td>
  <td>Copper Ores</td>

 </tr>
 <tr>
  <td>2298</td>
  <td>Cordage and Twine (except hemp rope made in spinning mills)</td>

 </tr>
 <tr>
  <td>2298</td>
  <td>Cordage and Twine (hemp rope made in spinning mills)</td>

 </tr>
 <tr>
  <td>115</td>
  <td>Corn</td>

 </tr>
 <tr>
  <td>9223</td>
  <td>Correctional Institutions</td>

 </tr>
 <tr>
  <td>2653</td>
  <td>Corrugated and Solid Fiber Boxes</td>

 </tr>
 <tr>
  <td>3961</td>
  <td>Costume Jewelry and Costume Novelties �
   Except Precious Metal (except cuff links)</td>

 </tr>
 <tr>
  <td>3961</td>
  <td>Costume Jewelry and Costume Novelties �
   Except Precious Metal (nonprecious cuff links)</td>

 </tr>
 <tr>
  <td>131</td>
  <td>Cotton</td>

 </tr>
 <tr>
  <td>724</td>
  <td>Cotton Ginning</td>

 </tr>
 <tr>
  <td>2074</td>
  <td>Cottonseed Oil Mills (cottonseed processing)</td>

 </tr>
 <tr>
  <td>2074</td>
  <td>Cottonseed Oil Mills (processing purchased cottonseed oil)</td>

 </tr>
 <tr>
  <td>4215</td>
  <td>Courier ServicesExcept by Air
  (hub and spoke intercity delivery)</td>

 </tr>
 <tr>
  <td>4215</td>
  <td>Courier ServicesExcept by Air
  (local delivery)</td>

 </tr>
 <tr>
  <td>9211</td>
  <td>Courts</td>

 </tr>
 <tr>
  <td>2021</td>
  <td>Creamery Butter</td>

 </tr>
 <tr>
  <td>7323</td>
  <td>Credit Reporting Services</td>

 </tr>
 <tr>
  <td>6061</td>
  <td>Credit UnionsFederally Chartered</td>

 </tr>
 <tr>
  <td>6062</td>
  <td>Credit UnionsNot Federally
  Chartered</td>

 </tr>
 <tr>
  <td>722</td>
  <td>Crop HarvestingPrimarily by
  Machine</td>

 </tr>
 <tr>
  <td>721</td>
  <td>Crop PlantingCultivating  and Protecting</td>

 </tr>
 <tr>
  <td>723</td>
  <td>Crop Preparation Services for Market �
   Except Cotton Ginning (custom grain grinding)</td>

 </tr>
 <tr>
  <td>723</td>
  <td>Crop Preparation Services for Market �
   Except Cotton Ginning (except custom grain grinding)</td>

 </tr>
 <tr>
  <td>3466</td>
  <td>Crowns and Closures</td>

 </tr>
 <tr>
  <td>1311</td>
  <td>Crude Petroleum and Natural Gas</td>

 </tr>
 <tr>
  <td>4612</td>
  <td>Crude Petroleum Pipelines</td>

 </tr>
 <tr>
  <td>1423</td>
  <td>Crushed and Broken Granite</td>

 </tr>
 <tr>
  <td>1422</td>
  <td>Crushed and Broken Limestone</td>

 </tr>
 <tr>
  <td>1429</td>
  <td>Crushed and Broken Stone NEC</td>

 </tr>
 <tr>
  <td>3643</td>
  <td>Current-Carrying Wiring Devices</td>

 </tr>
 <tr>
  <td>2391</td>
  <td>Curtains and Draperies</td>

 </tr>
 <tr>
  <td>3087</td>
  <td>Custom Compounding of Purchased Plastics Resins</td>

 </tr>
 <tr>
  <td>3281</td>
  <td>Cut Stone and Stone Products</td>

 </tr>
 <tr>
  <td>3421</td>
  <td>Cutlery (except hedge shears and trimmers   tinners' snipsand
  similar nonelectric hand tools)</td>

 </tr>
 <tr>
  <td>3421</td>
  <td>Cutlery (hedge shears and trimmers �
   tinners snipsand similar
  nonelectric hand tools)</td>

 </tr>
 <tr>
  <td>3545</td>
  <td>Cutting ToolsMachine Tool
  Accessoriesand Machinist Precision
  Measuring Devices (precision measuring devices)</td>

 </tr>
 <tr>
  <td>3545</td>
  <td>Cutting ToolsMachine Tool
  Accessoriesand Machinists' Precision
  Measuring Devices (except precision measuring devices)</td>

 </tr>
 <tr>
  <td>2865</td>
  <td>Cyclic Organic Crudes and Intermediates �
   and Organic Dyes and Pigments (aromatics)</td>

 </tr>
 <tr>
  <td>2865</td>
  <td>Cyclic Organic Crudes and Intermediates �
   and Organic Dyes and Pigments (organic dyes and pigments)</td>

 </tr>
 <tr>
  <td>2865</td>
  <td>Cyclic Organic Crudes and Intermediates and Organic Dyes and Pigments
  (except aromatics and organic dyes and pigments)</td>

 </tr>
 <tr>
  <td>241</td>
  <td>Dairy Farms (dairy heifer replacement farms)</td>

 </tr>
 <tr>
  <td>241</td>
  <td>Dairy Farms
  (except dairy heifer replacement farms) </td>

 </tr>
 <tr>
  <td>5143</td>
  <td>Dairy ProductsExcept Dried or
  Canned (agents and brokers)</td>

 </tr>
 <tr>
  <td>5143</td>
  <td>Dairy ProductsExcept Dried or
  Canned (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5143</td>
  <td>Dairy ProductsExcept Dried or
  Canned (dairy products sold via retail method)</td>

 </tr>
 <tr>
  <td>5143</td>
  <td>Dairy ProductsExcept Dried or
  Canned (merchant wholesalers except those selling dairy products via retail
  method)</td>

 </tr>
 <tr>
  <td>5451</td>
  <td>Dairy Products Stores</td>

 </tr>
 <tr>
  <td>7911</td>
  <td>Dance StudiosSchools  and Halls (dance instructors  and professional and other dance schools)</td>

 </tr>
 <tr>
  <td>7911</td>
  <td>Dance StudiosSchools  and Halls (except instruction)</td>

 </tr>
 <tr>
  <td>8243</td>
  <td>Data Processing Schools (computer repair training)</td>

 </tr>
 <tr>
  <td>8243</td>
  <td>Data Processing Schools (except computer repair training)</td>

 </tr>
 <tr>
  <td>175</td>
  <td>Deciduous Tree Fruits (apple orchards and farms)</td>

 </tr>
 <tr>
  <td>175</td>
  <td>Deciduous Tree Fruits (except apple orchards and farms)</td>

 </tr>
 <tr>
  <td>4424</td>
  <td>Deep Sea Domestic Transportation of Freight</td>

 </tr>
 <tr>
  <td>4412</td>
  <td>Deep Sea Foreign Transportation of Freight</td>

 </tr>
 <tr>
  <td>4481</td>
  <td>Deep Sea Transportation of Passengers �
   Except by Ferry (coastal activities)</td>

 </tr>
 <tr>
  <td>4481</td>
  <td>Deep Sea Transportation of Passengers �
   Except by Ferry (deep sea activities)</td>

 </tr>
 <tr>
  <td>3843</td>
  <td>Dental Equipment and Supplies</td>

 </tr>
 <tr>
  <td>8072</td>
  <td>Dental Laboratories</td>

 </tr>
 <tr>
  <td>5311</td>
  <td>Department Stores (discount department stores)</td>

 </tr>
 <tr>
  <td>5311</td>
  <td>Department Stores (except discount department stores and
  supercenters-general merchandise and groceries)</td>

 </tr>
 <tr>
  <td>7381</td>
  <td>DetectiveGuard  and Armored Car Services (armored car
  services)</td>

 </tr>
 <tr>
  <td>7381</td>
  <td>DetectiveGuard  and Armored Car Services (detective
  services)</td>

 </tr>
 <tr>
  <td>7381</td>
  <td>DetectiveGuard  and Armored Car Services (guard services)</td>

 </tr>
 <tr>
  <td>2675</td>
  <td>Die-Cut Paper and Paperboard and Cardboard (die-cut paper and paperboard
  office suppliessuch as file
  folderstabulating cards  and report covers)</td>

 </tr>
 <tr>
  <td>2675</td>
  <td>Die-Cut Paper and Paperboard and Cardboard (except pasted  lined �
   laminatedor surface coated
  paperboard and die-cut paper and paperboard office supplies)</td>

 </tr>
 <tr>
  <td>2675</td>
  <td>Die-Cut Paper and Paperboard and Cardboard (pasted  lined �
   laminatedor surface-coated
  paperboard)</td>

 </tr>
 <tr>
  <td>1411</td>
  <td>Dimension Stone</td>

 </tr>
 <tr>
  <td>7331</td>
  <td>Direct Mail Advertising Services (except mailing list compilers)</td>

 </tr>
 <tr>
  <td>7331</td>
  <td>Direct Mail Advertising Services (mailing list compilers)</td>

 </tr>
 <tr>
  <td>5963</td>
  <td>Direct Selling Establishments (except mobile food services and food
  wagons)</td>

 </tr>
 <tr>
  <td>5963</td>
  <td>Direct Selling Establishments (mobile food services and food wagons)</td>

 </tr>
 <tr>
  <td>7342</td>
  <td>Disinfecting and Pest Control Services (except exterminating and pest
  control)</td>

 </tr>
 <tr>
  <td>7342</td>
  <td>Disinfecting and Pest Control Services (exterminating and pest control)</td>

 </tr>
 <tr>
  <td>2085</td>
  <td>Distilled and Blended Liquors (apple jack)</td>

 </tr>
 <tr>
  <td>2085</td>
  <td>Distilled and Blended Liquors (except apple jack)</td>

 </tr>
 <tr>
  <td>2047</td>
  <td>Dog and Cat Food</td>

 </tr>
 <tr>
  <td>3942</td>
  <td>Dolls and Stuffed Toys</td>

 </tr>
 <tr>
  <td>5714</td>
  <td>DraperyCurtain  and Upholstery Stores (custom drapes)</td>

 </tr>
 <tr>
  <td>5714</td>
  <td>DraperyCurtain  and Upholstery Stores (custom slipcovers)</td>

 </tr>
 <tr>
  <td>5714</td>
  <td>DraperyCurtain  and Upholstery Stores (drapery and curtain
  stores except primarily custom)</td>

 </tr>
 <tr>
  <td>5714</td>
  <td>DraperyCurtain  and Upholstery Stores (upholstery
  materials)</td>

 </tr>
 <tr>
  <td>2591</td>
  <td>Drapery Hardware and Window Blinds and Shades</td>

 </tr>
 <tr>
  <td>3357</td>
  <td>Drawing and Insulating of Nonferrous Wire (aluminum wire drawing)</td>

 </tr>
 <tr>
  <td>3357</td>
  <td>Drawing and Insulating of Nonferrous Wire (communication and energy
  wireexcept fiber optic-insulating
  only)</td>

 </tr>
 <tr>
  <td>3357</td>
  <td>Drawing and Insulating of Nonferrous Wire (copper wire drawing)</td>

 </tr>
 <tr>
  <td>3357</td>
  <td>Drawing and Insulating of Nonferrous Wire (fiber optic cable-insulating
  only)</td>

 </tr>
 <tr>
  <td>3357</td>
  <td>Drawing and Insulating of Nonferrous Wire (wire drawing except copper or
  aluminum)</td>

 </tr>
 <tr>
  <td>2381</td>
  <td>Dress and Work GlovesExcept Knit
  and All-Leather (except contractors)</td>

 </tr>
 <tr>
  <td>2381</td>
  <td>Dress and Work GlovesExcept Knit
  and All-Leather (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>2381</td>
  <td>Dress and Work GlovesExcept Knit
  and All-Leather (women'sGirl's  and infants' contractors)</td>

 </tr>
 <tr>
  <td>2034</td>
  <td>Dried and Dehydrated Fruits �
   Vegetablesand Soup Mixes
  (soup mixes made from purchased dehydrated ingredients)</td>

 </tr>
 <tr>
  <td>2034</td>
  <td>Dried and Dehydrated Fruits �
   Vegetables and Soup Mixes (except vegetable flour and soup mixes made
  from purchased dried and dehydrated ingredients)</td>

 </tr>
 <tr>
  <td>2034</td>
  <td>Dried and Dehydrated Fruits �
   Vegetables and Soup Mixes (vegetable flour)</td>

 </tr>
 <tr>
  <td>1381</td>
  <td>Drilling Oil and Gas Wells</td>

 </tr>
 <tr>
  <td>5813</td>
  <td>Drinking Places (Alcoholic Beverages)</td>

 </tr>
 <tr>
  <td>7833</td>
  <td>Drive-In Motion Picture Theaters</td>

 </tr>
 <tr>
  <td>5912</td>
  <td>Drug Stores and Proprietary Stores</td>

 </tr>
 <tr>
  <td>5122</td>
  <td>DrugsDrug Proprietaries  and Druggists' Sundries (vitamins sold via
  retail method)</td>

 </tr>
 <tr>
  <td>5122</td>
  <td>DrugsDrug Proprietaries  and Druggists' Sundries (agents and
  brokers)</td>

 </tr>
 <tr>
  <td>5122</td>
  <td>DrugsDrug Proprietaries  and Druggists' Sundries (business to
  business electronic markets)</td>

 </tr>
 <tr>
  <td>5122</td>
  <td>DrugsDrug Proprietaries  and Druggists' Sundries (cosmetics sold
  via retail method)</td>

 </tr>
 <tr>
  <td>5122</td>
  <td>DrugsDrug Proprietaries  and Druggists' Sundries (drugs and
  sundries sold via retail method)</td>

 </tr>
 <tr>
  <td>5122</td>
  <td>DrugsDrug Proprietaries  and Druggists' Sundries (merchant
  wholesalers except those selling drugs and sundries via retail method)</td>

 </tr>
 <tr>
  <td>2023</td>
  <td>DryCondensed and Evaporated
  Dairy Products (except liquid non-dairy creamer)</td>

 </tr>
 <tr>
  <td>2023</td>
  <td>DryCondensed and Evaporated
  Dairy Products (liquid non-dairy creamer)</td>

 </tr>
 <tr>
  <td>7216</td>
  <td>Drycleaning PlantsExcept Rug
  Cleaning</td>

 </tr>
 <tr>
  <td>5099</td>
  <td>Durable Goods NEC (agents and
  brokers)</td>

 </tr>
 <tr>
  <td>5099</td>
  <td>Durable Goods NEC (ammunition and
  firearms sold via retail method)</td>

 </tr>
 <tr>
  <td>5099</td>
  <td>Durable Goods NEC (business to
  business electronic markets)</td>

 </tr>
 <tr>
  <td>5099</td>
  <td>Durable Goods NEC (coin-operated
  game machines sold via retail method)</td>

 </tr>
 <tr>
  <td>5099</td>
  <td>Durable Goods NEC (gas lighting
  fixturesrough timbers  and other wood or construction materials
  sold via retail method)</td>

 </tr>
 <tr>
  <td>5099</td>
  <td>Durable Goods NEC (merchant
  wholesalers except those selling miscellaneous durable goods via retail
  method)</td>

 </tr>
 <tr>
  <td>5099</td>
  <td>Durable Goods NEC (prerecorded
  audio and video tapes and discs sold via retail method)</td>

 </tr>
 <tr>
  <td>5812</td>
  <td>Eating Places (cafeterias)</td>

 </tr>
 <tr>
  <td>5812</td>
  <td>Eating Places (caterers)</td>

 </tr>
 <tr>
  <td>5812</td>
  <td>Eating Places (dinner theaters)</td>

 </tr>
 <tr>
  <td>5812</td>
  <td>Eating Places (food service contractors)</td>

 </tr>
 <tr>
  <td>5812</td>
  <td>Eating Places (full-service restaurants)</td>

 </tr>
 <tr>
  <td>5812</td>
  <td>Eating Places (limited-service restaurants)</td>

 </tr>
 <tr>
  <td>5812</td>
  <td>Eating Places (snack and nonalcoholic beverage bars)</td>

 </tr>
 <tr>
  <td>6732</td>
  <td>EducationalReligious  and Charitable Trusts</td>

 </tr>
 <tr>
  <td>3548</td>
  <td>Electric and Gas Welding and Soldering Equipment (except transformers for
  arc-welding)</td>

 </tr>
 <tr>
  <td>3548</td>
  <td>Electric and Gas Welding and Soldering Equipment (transformers for
  arc-welders)</td>

 </tr>
 <tr>
  <td>4931</td>
  <td>Electric and Other Services Combined (electric power distribution)</td>

 </tr>
 <tr>
  <td>4931</td>
  <td>Electric and Other Services Combined (electric power transmission and
  control)</td>

 </tr>
 <tr>
  <td>4931</td>
  <td>Electric and Other Services Combined (fossil fuel power generation)</td>

 </tr>
 <tr>
  <td>4931</td>
  <td>Electric
  and Other Services Combined (hydroelectric power generation) </td>

 </tr>
 <tr>
  <td>4931</td>
  <td>Electric and Other Services Combined (natural gas distribution)</td>

 </tr>
 <tr>
  <td>4931</td>
  <td>Electric and Other Services Combined (nuclear power generation)</td>

 </tr>
 <tr>
  <td>4931</td>
  <td>Electric and Other Services Combined (other electric power generation)</td>

 </tr>
 <tr>
  <td>3634</td>
  <td>Electric Housewares and Fans (electronic cigarette lighters)</td>

 </tr>
 <tr>
  <td>3634</td>
  <td>Electric Housewares and Fans (except wall and baseboard heating units for
  permanent installationelectronic
  cigarette lightersand wall mount
  restroom hand dryers)</td>

 </tr>
 <tr>
  <td>3634</td>
  <td>Electric Housewares and Fans (wall and baseboard heating units for
  permanent installation)</td>

 </tr>
 <tr>
  <td>3641</td>
  <td>Electric Lamp Bulbs and Tubes</td>

 </tr>
 <tr>
  <td>4911</td>
  <td>Electric Services (electric power distribution)</td>

 </tr>
 <tr>
  <td>4911</td>
  <td>Electric Services (electric power transmission and control)</td>

 </tr>
 <tr>
  <td>4911</td>
  <td>Electric Services (fossil fuel power generation)</td>

 </tr>
 <tr>
  <td>4911</td>
  <td>Electric Services (hydroelectric power generation)</td>

 </tr>
 <tr>
  <td>4911</td>
  <td>Electric Services (nuclear electric power generation)</td>

 </tr>
 <tr>
  <td>4911</td>
  <td>Electric Services (other electric power generation)</td>

 </tr>
 <tr>
  <td>7629</td>
  <td>Electrical
  and Electronic Repair Shops NEC
  (business and office machine repair �
   electrical) </td>

 </tr>
 <tr>
  <td>7629</td>
  <td>Electrical and Electronic Repair Shops � NEC (electrical appliance repair �
   washing machine repair �
   electric razor repair)</td>

 </tr>
 <tr>
  <td>7629</td>
  <td>Electrical and Electronic Repair Shops � NEC (electrical measuring instrument repair and calibration  medical electrical equipment repair)</td>

 </tr>
 <tr>
  <td>7629</td>
  <td>Electrical and Electronic Repair Shops � NEC (new retail sales combined with repair-repair services as major
  source of receipts)</td>

 </tr>
 <tr>
  <td>7629</td>
  <td>Electrical and Electronic Repair Shops � NEC (other consumer electronic equipment   except business and office machines   telephonesand
  appliances-repair and maintenance)</td>

 </tr>
 <tr>
  <td>7629</td>
  <td>Electrical and Electronic Repair Shops � NEC (telephone set repair)</td>

 </tr>
 <tr>
  <td>5063</td>
  <td>Electrical Apparatus and Equipment �
   Wiring Suppliesand
  Construction Materials (electrical supplies �
   equipmentand apparatus sold
  via retail method)</td>

 </tr>
 <tr>
  <td>5063</td>
  <td>Electrical Apparatus and Equipment �
   Wiring Supplies and Construction Materials (agents and brokers)</td>

 </tr>
 <tr>
  <td>5063</td>
  <td>Electrical Apparatus and Equipment �
   Wiring Supplies and Construction Materials (business to business
  electronic markets)</td>

 </tr>
 <tr>
  <td>5063</td>
  <td>Electrical Apparatus and Equipment �
   Wiring Supplies and Construction Materials (merchant wholesalers
  except those selling electrical supplies �
   equipmentand apparatus via
  retail method)</td>

 </tr>
 <tr>
  <td>5064</td>
  <td>Electrical AppliancesTelevision
  and Radio Sets (agents and brokers)</td>

 </tr>
 <tr>
  <td>5064</td>
  <td>Electrical AppliancesTelevision
  and Radio Sets (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5064</td>
  <td>Electrical AppliancesTelevision
  and Radio Sets (ceiling fans sold via retail method)</td>

 </tr>
 <tr>
  <td>5064</td>
  <td>Electrical AppliancesTelevision
  and Radio Sets (household appliances sold via retail method)</td>

 </tr>
 <tr>
  <td>5064</td>
  <td>Electrical AppliancesTelevision
  and Radio Sets (merchant wholesalers except those selling appliances  TVs �
   and radios via retail method)</td>

 </tr>
 <tr>
  <td>5064</td>
  <td>Electrical AppliancesTelevision
  and Radio Sets (television and radio sets sold via retail method)</td>

 </tr>
 <tr>
  <td>3694</td>
  <td>Electrical Equipment for Internal Combustion Engines</td>

 </tr>
 <tr>
  <td>3629</td>
  <td>Electrical Industrial Apparatus � NEC</td>

 </tr>
 <tr>
  <td>3699</td>
  <td>Electrical Machinery �
   Equipmentand Supplies   NEC (Christmas tree lighting sets  electric insect lamps  electric fireplace logs  and trouble lights)</td>

 </tr>
 <tr>
  <td>3699</td>
  <td>Electrical Machinery �
   Equipmentand Supplies   NEC (electronic teaching machines and
  flight simulators)</td>

 </tr>
 <tr>
  <td>3699</td>
  <td>Electrical Machinery �
   Equipmentand Supplies   NEC (other electrical industrial
  apparatus)</td>

 </tr>
 <tr>
  <td>3699</td>
  <td>Electrical Machinery �
   Equipmentand Supplies   NEC (outboard electric motors)</td>

 </tr>
 <tr>
  <td>3699</td>
  <td>Electrical Machinery Equipment �
   and Supplies NEC (laser
  welding and soldering equipment)</td>

 </tr>
 <tr>
  <td>1731</td>
  <td>Electrical Work (electrical work except burglar and fire alarm
  installation)</td>

 </tr>
 <tr>
  <td>3845</td>
  <td>Electromedical and Electrotherapeutic Apparatus (CT and CAT Scanners)</td>

 </tr>
 <tr>
  <td>3845</td>
  <td>Electromedical and Electrotherapeutic Apparatus (except CT and CAT
  scanners)</td>

 </tr>
 <tr>
  <td>3313</td>
  <td>Electrometallurgical Products �
   Except Steel</td>

 </tr>
 <tr>
  <td>3671</td>
  <td>Electron Tubes</td>

 </tr>
 <tr>
  <td>3675</td>
  <td>Electronic Capacitors</td>

 </tr>
 <tr>
  <td>3677</td>
  <td>Electronic Coils �
   Transformersand Other
  Inductors</td>

 </tr>
 <tr>
  <td>3679</td>
  <td>Electronic Components NEC
  (antennas)</td>

 </tr>
 <tr>
  <td>3679</td>
  <td>Electronic Components NEC (other
  electronic components)</td>

 </tr>
 <tr>
  <td>3679</td>
  <td>Electronic Components NEC
  (printed circuit/electronic assembly manufacturing)</td>

 </tr>
 <tr>
  <td>3679</td>
  <td>Electronic Components NEC (radio
  headphones)</td>

 </tr>
 <tr>
  <td>3571</td>
  <td>Electronic Computers</td>

 </tr>
 <tr>
  <td>3678</td>
  <td>Electronic Con NECtors</td>

 </tr>
 <tr>
  <td>5065</td>
  <td>Electronic Parts and Equipment � NEC (agents and brokers)</td>

 </tr>
 <tr>
  <td>5065</td>
  <td>Electronic Parts and Equipment � NEC (amateur radiosCB's  intercommunications equipment  public address equipment  and similar communications equipment sold
  via retail method)</td>

 </tr>
 <tr>
  <td>5065</td>
  <td>Electronic Parts and Equipment � NEC (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5065</td>
  <td>Electronic Parts and Equipment � NEC (merchant wholesalers except those selling electronic parts and
  equipment via retail method)</td>

 </tr>
 <tr>
  <td>5065</td>
  <td>Electronic Parts and Equipment � NEC (modems and other computer components sold via retail method)</td>

 </tr>
 <tr>
  <td>3676</td>
  <td>Electronic Resistors</td>

 </tr>
 <tr>
  <td>3471</td>
  <td>ElectroplatingPlating  Polishing �
   Anodizingand Coloring</td>

 </tr>
 <tr>
  <td>8211</td>
  <td>Elementary and Secondary Schools</td>

 </tr>
 <tr>
  <td>3534</td>
  <td>Elevators and Moving Stairways</td>

 </tr>
 <tr>
  <td>7361</td>
  <td>Employment Agencies (except executive placement services)</td>

 </tr>
 <tr>
  <td>7361</td>
  <td>Employment Agencies (executive placement services)</td>

 </tr>
 <tr>
  <td>3431</td>
  <td>Enameled Iron and Metal Sanitary Ware</td>

 </tr>
 <tr>
  <td>8711</td>
  <td>Engineering Services</td>

 </tr>
 <tr>
  <td>2677</td>
  <td>Envelopes</td>

 </tr>
 <tr>
  <td>7359</td>
  <td>Equipment Rental and Leasing NEC
  (aircraft rental and leasing)</td>

 </tr>
 <tr>
  <td>7359</td>
  <td>Equipment Rental and Leasing NEC
  (appliancesTVs  VCRs �
   and other consumer electronic equipment rental)</td>

 </tr>
 <tr>
  <td>7359</td>
  <td>Equipment Rental and Leasing NEC
  (except aircraft</td>

 </tr>
 <tr>
  <td>7359</td>
  <td>Equipment Rental and Leasing NEC
  (general rental centers and home and garden equipment rental centers)</td>

 </tr>
 <tr>
  <td>7359</td>
  <td>Equipment Rental and Leasing NEC
  (industrial truck and equipment rental and leasing)</td>

 </tr>
 <tr>
  <td>7359</td>
  <td>Equipment Rental and Leasing NEC
  (office machine rental and leasing)</td>

 </tr>
 <tr>
  <td>7359</td>
  <td>Equipment Rental and Leasing NEC
  (oil field and well drilling equipment)</td>

 </tr>
 <tr>
  <td>7359</td>
  <td>Equipment Rental and Leasing NEC
  (portable toilet rental)</td>

 </tr>
 <tr>
  <td>1794</td>
  <td>Excavation Work</td>

 </tr>
 <tr>
  <td>9131</td>
  <td>Executive and
  Legislative Office Combined </td>

 </tr>
 <tr>
  <td>9111</td>
  <td>Executive Offices</td>

 </tr>
 <tr>
  <td>2892</td>
  <td>Explosives</td>

 </tr>
 <tr>
  <td>3499</td>
  <td>Fabricated Metal Products NEC
  (metal aerosol valves)</td>

 </tr>
 <tr>
  <td>3499</td>
  <td>Fabricated Metal Products NEC
  (metal automobile seat frames)</td>

 </tr>
 <tr>
  <td>3499</td>
  <td>Fabricated Metal Products NEC
  (metal boxes)</td>

 </tr>
 <tr>
  <td>3499</td>
  <td>Fabricated Metal Products NEC
  (metal furniture frames)</td>

 </tr>
 <tr>
  <td>3499</td>
  <td>Fabricated Metal Products NEC
  (other metal products)</td>

 </tr>
 <tr>
  <td>3499</td>
  <td>Fabricated Metal Products NEC
  (powder metallurgy)</td>

 </tr>
 <tr>
  <td>3499</td>
  <td>Fabricated Metal Products NEC
  (safe and vault locks)</td>

 </tr>
 <tr>
  <td>3498</td>
  <td>Fabricated Pipe and Pipe Fittings</td>

 </tr>
 <tr>
  <td>3443</td>
  <td>Fabricated Plate Work (Boiler Shops) (fabricated plate work and metal
  weldments)</td>

 </tr>
 <tr>
  <td>3443</td>
  <td>Fabricated Plate Work (Boiler Shops) (heavy gauge tanks)</td>

 </tr>
 <tr>
  <td>3443</td>
  <td>Fabricated Plate Work (Boiler Shops) (metal cooling towers)</td>

 </tr>
 <tr>
  <td>3443</td>
  <td>Fabricated Plate Work (Boiler Shops) (power boilers and heat exchangers)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products NEC
  (bags made from rubberized fabric)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products NEC
  (bibsbathing caps  related rubber accessories)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products   NEC (except rubberized fabric and
  garmentsgloves  life vests   wet suits �
   accessoriessuch as bibs and
  bathing capsrubber toys  bags made from rubberized fabric  rubber diaper covers  and rubber resilient floor coverings)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products NEC
  (rubber cut and sew outerwear)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products NEC
  (rubber glovesinflatable rubber
  lifejackets)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products NEC
  (rubber resilient floor coverings)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products NEC
  (rubber toysexcept dolls)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products NEC
  (rubberizing fabric or purchased textile products)</td>

 </tr>
 <tr>
  <td>3069</td>
  <td>Fabricated Rubber Products NEC
  (wet suits)</td>

 </tr>
 <tr>
  <td>3441</td>
  <td>Fabricated Structural Metal</td>

 </tr>
 <tr>
  <td>2399</td>
  <td>Fabricated Textile Products NEC
  (apparel and apparel accessories �
   except contractors)</td>

 </tr>
 <tr>
  <td>2399</td>
  <td>Fabricated Textile Products NEC
  (except apparel and accessories �
   automotive seat beltsseat and
  tire coversand contractors)</td>

 </tr>
 <tr>
  <td>2399</td>
  <td>Fabricated Textile Products NEC
  (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>2399</td>
  <td>Fabricated Textile Products NEC
  (seat beltsand seat and tire covers)</td>

 </tr>
 <tr>
  <td>2399</td>
  <td>Fabricated Textile Products NEC
  (women'sGirl's  and infants' contractors)</td>

 </tr>
 <tr>
  <td>8744</td>
  <td>Facilities Support Management Services</td>

 </tr>
 <tr>
  <td>5651</td>
  <td>Family Clothing Stores</td>

 </tr>
 <tr>
  <td>5083</td>
  <td>Farm and Garden Machinery and Equipment (agents and brokers)</td>

 </tr>
 <tr>
  <td>5083</td>
  <td>Farm and Garden Machinery and Equipment (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5083</td>
  <td>Farm and Garden Machinery and Equipment (lawn and garden equipment sold
  via retail method)</td>

 </tr>
 <tr>
  <td>5083</td>
  <td>Farm and Garden Machinery and Equipment (merchant wholesalers except
  those selling lawn and garden equipment via retail method)</td>

 </tr>
 <tr>
  <td>761</td>
  <td>Farm Labor Contractors and Crew Leaders</td>

 </tr>
 <tr>
  <td>3523</td>
  <td>Farm Machinery and Equipment (corrals �
   stallsand holding gates)</td>

 </tr>
 <tr>
  <td>3523</td>
  <td>Farm Machinery and Equipment (except corrals   stallsholding
  gateshand clippers for animals  and farm conveyors/elevators)</td>

 </tr>
 <tr>
  <td>3523</td>
  <td>Farm Machinery and Equipment (farm conveyors and elevators)</td>

 </tr>
 <tr>
  <td>3523</td>
  <td>Farm Machinery and Equipment (hand hair clippers for animals)</td>

 </tr>
 <tr>
  <td>762</td>
  <td>Farm Management Services</td>

 </tr>
 <tr>
  <td>4221</td>
  <td>Farm Product Warehousing and Storage</td>

 </tr>
 <tr>
  <td>5191</td>
  <td>Farm Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5191</td>
  <td>Farm Supplies (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5191</td>
  <td>Farm Supplies (lawn and garden supplies sold via retail method)</td>

 </tr>
 <tr>
  <td>5191</td>
  <td>Farm Supplies (merchant wholesalers except those selling lawn and garden
  supplies via retail method)</td>

 </tr>
 <tr>
  <td>5159</td>
  <td>Farm-Product Raw Materials NEC
  (agents and brokers)</td>

 </tr>
 <tr>
  <td>5159</td>
  <td>Farm-Product Raw Materials NEC
  (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5159</td>
  <td>Farm-Product Raw Materials NEC
  (farm-product raw materials sold via retail method)</td>

 </tr>
 <tr>
  <td>5159</td>
  <td>Farm-Product Raw Materials NEC
  (merchant wholesalers except those selling farm product raw materials   NEC via retail method)</td>

 </tr>
 <tr>
  <td>3965</td>
  <td>FastenersButtons  Needles �
   and Pins</td>

 </tr>
 <tr>
  <td>6111</td>
  <td>Federal and Federally Sponsored Credit Agencies (secondary market
  financing)</td>

 </tr>
 <tr>
  <td>6111</td>
  <td>Federal and Federally-Sponsored Credit Agencies (except trade banks  secondary market financing and Federal
  Land Banks)</td>

 </tr>
 <tr>
  <td>6111</td>
  <td>Federal and Federally-Sponsored Credit Agencies (trade banks)</td>

 </tr>
 <tr>
  <td>6111</td>
  <td>Federal and Federally-Sponsored Credit Agencies (trade banks)</td>

 </tr>
 <tr>
  <td>6011</td>
  <td>Federal Reserve Banks</td>

 </tr>
 <tr>
  <td>4482</td>
  <td>Ferries (coastal and Great Lakes)</td>

 </tr>
 <tr>
  <td>4482</td>
  <td>Ferries (inland)</td>

 </tr>
 <tr>
  <td>1061</td>
  <td>Ferroalloy OresExcept Vanadium
  (nickel)</td>

 </tr>
 <tr>
  <td>1061</td>
  <td>Ferroalloy OresExcept Vanadium
  (other ferroalloys except nickel)</td>

 </tr>
 <tr>
  <td>2875</td>
  <td>FertilizersMixing Only</td>

 </tr>
 <tr>
  <td>2655</td>
  <td>Fiber CansTubes  Drums �
   and Similar Products</td>

 </tr>
 <tr>
  <td>139</td>
  <td>Field CropsExcept Cash
  Grains NEC (broom corn farming)</td>

 </tr>
 <tr>
  <td>139</td>
  <td>Field CropsExcept Cash
  Grains NEC (except peanut  sweet potato   broom cornyam and hay
  farms)</td>

 </tr>
 <tr>
  <td>139</td>
  <td>Field CropsExcept Cash
  Grains NEC (hay farms)</td>

 </tr>
 <tr>
  <td>139</td>
  <td>Field CropsExcept Cash
  Grains NEC (peanut farms)</td>

 </tr>
 <tr>
  <td>139</td>
  <td>Field Crops Except Cash Grains (sweet potatoes and yams)   NEC</td>

 </tr>
 <tr>
  <td>3263</td>
  <td>Fine Earthenware (Whiteware) Table and Kitchen Articles</td>

 </tr>
 <tr>
  <td>912</td>
  <td>Finfish</td>

 </tr>
 <tr>
  <td>2261</td>
  <td>Finishers of Broadwoven Fabrics of Cotton</td>

 </tr>
 <tr>
  <td>2262</td>
  <td>Finishers of Broadwoven Fabrics of Manmade Fiber and Silk</td>

 </tr>
 <tr>
  <td>2269</td>
  <td>Finishers of Textiles NEC (except
  linen fabric finishing)</td>

 </tr>
 <tr>
  <td>2269</td>
  <td>Finishers of Textiles NEC (linen
  fabric finishing)</td>

 </tr>
 <tr>
  <td>6331</td>
  <td>FireMarine  and Casualty Insurance (contact lens
  insurance)</td>

 </tr>
 <tr>
  <td>6331</td>
  <td>FireMarine  and Casualty Insurance (fire  marine �
   and casualty insurers-direct �
   except contact lens insurance)</td>

 </tr>
 <tr>
  <td>6331</td>
  <td>FireMarine  and Casualty Insurance (reinsurers)</td>

 </tr>
 <tr>
  <td>6331</td>
  <td>FireMarine  and Casualty Insurance (self insurers)</td>

 </tr>
 <tr>
  <td>9224</td>
  <td>Fire Protection</td>

 </tr>
 <tr>
  <td>5146</td>
  <td>Fish and Seafoods (agents and brokers)</td>

 </tr>
 <tr>
  <td>5146</td>
  <td>Fish and Seafoods (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5146</td>
  <td>Fish and Seafoods (fish and seafoods sold via retail method)</td>

 </tr>
 <tr>
  <td>5146</td>
  <td>Fish and Seafoods (merchant wholesalers except those selling fish and
  seafoods via retail method)</td>

 </tr>
 <tr>
  <td>921</td>
  <td>Fish Hatcheries and Preserves (finfish hatcheries)</td>

 </tr>
 <tr>
  <td>921</td>
  <td>Fish Hatcheries and Preserves (shellfish hatcheries)</td>

 </tr>
 <tr>
  <td>4785</td>
  <td>Fixed Facilities and Inspection and Weighing Services for Motor Vehicle
  Transportation (except marine cargo checkers)</td>

 </tr>
 <tr>
  <td>4785</td>
  <td>Fixed Facilities and Inspection and Weighing Services for Motor Vehicle
  Transportation (marine cargo checkers)</td>

 </tr>
 <tr>
  <td>3211</td>
  <td>Flat Glass</td>

 </tr>
 <tr>
  <td>2087</td>
  <td>Flavoring Extracts and Flavoring Syrups � NEC(flavoring syrups and
  concentrates except coffee)</td>

 </tr>
 <tr>
  <td>2087</td>
  <td>Flavoring Extracts and Flavoring Syrups � NEC (coffee flavoring and syrups)</td>

 </tr>
 <tr>
  <td>2087</td>
  <td>Flavoring Extracts and Flavoring Syrups � NEC (flavoring extracts and natural food colorings)</td>

 </tr>
 <tr>
  <td>2087</td>
  <td>Flavoring Extracts and Flavoring Syrups � NEC (powered drink mix)</td>

 </tr>
 <tr>
  <td>5713</td>
  <td>Floor Coverings Stores</td>

 </tr>
 <tr>
  <td>1752</td>
  <td>Floor Laying and Other
  Floor Work NEC </td>

 </tr>
 <tr>
  <td>5992</td>
  <td>Florists</td>

 </tr>
 <tr>
  <td>2041</td>
  <td>Flour and Other Grain Mill Products</td>

 </tr>
 <tr>
  <td>5193</td>
  <td>FlowersNursery Stock  and Florists' Supplies (agents and
  brokers)</td>

 </tr>
 <tr>
  <td>5193</td>
  <td>FlowersNursery Stock  and Florists' Supplies (business to
  business electronic markets)</td>

 </tr>
 <tr>
  <td>5193</td>
  <td>FlowersNursery Stock  and Florists' Supplies (merchant
  wholesalers except those selling nursery stock via retail method)</td>

 </tr>
 <tr>
  <td>5193</td>
  <td>FlowersNursery Stock  and Florists' Supplies (sold via retail
  method)</td>

 </tr>
 <tr>
  <td>2026</td>
  <td>Fluid Milk (except ultra-high temperature)</td>

 </tr>
 <tr>
  <td>2026</td>
  <td>Fluid Milk (ultra-high temperature)</td>

 </tr>
 <tr>
  <td>3593</td>
  <td>Fluid Power Cylinders and Actuators</td>

 </tr>
 <tr>
  <td>3594</td>
  <td>Fluid Power Pumps and Motors</td>

 </tr>
 <tr>
  <td>3492</td>
  <td>Fluid Power Valves and Hose Fittings</td>

 </tr>
 <tr>
  <td>2657</td>
  <td>Folding Paperboard Boxes �
   Including Sanitary (except paperboard backs for blister or skin
  packages)</td>

 </tr>
 <tr>
  <td>182</td>
  <td>Food Crops Grown Under Cover (except growing mushrooms)</td>

 </tr>
 <tr>
  <td>182</td>
  <td>Food Crops Grown Under Cover (growing mushrooms)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC (bouillon
  and potatoes dried and packaged with other ingredients produced in
  dehydrating plants)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC (dry pasta
  packaged with other ingredients made in dry pasta plants)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td >Food Preparations   NEC (except bouillon  marshmallow creme  spices �
   peanut butterperishable
  prepared foodstortillas  tea and tea extracts  dry dip mix   prepared dipsdry salad
  dressing mixseasoning mix  dried potatoes   pastaand rice mixed
  with other ingredients in mills or dehydrating plants  reducing maple sap to maple syrup  wool grease   and vinegar)</td>
 </tr>

 <tr>
  <td>2099</td>
  <td>Food Preparations NEC
  (marshmallow creme)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC (peanut
  butter)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC (perishable
  prepared food)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC (reducing
  maple sap to maple syrup)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC (rice  uncooked and packaged with other
  ingredients made in rice mills)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC
  (spicesdry dip mix  dry salad dressing mix  and seasoning mix)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC (tea)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC (tortillas)</td>

 </tr>
 <tr>
  <td>2099</td>
  <td>Food Preparations NEC
  (vinegarprepared dip)</td>

 </tr>
 <tr>
  <td>3556</td>
  <td>Food Products Machinery</td>

 </tr>
 <tr>
  <td>3149</td>
  <td>Footwear � Except Rubber   NEC</td>

 </tr>
 <tr>
  <td>5139</td>
  <td>Footwear (agents and brokers)</td>

 </tr>
 <tr>
  <td>5139</td>
  <td>Footwear (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5139</td>
  <td>Footwear (footwear sold via retail method)</td>

 </tr>
 <tr>
  <td>5139</td>
  <td>Footwear (merchant wholesalers except those selling footwear via retail
  method)</td>

 </tr>
 <tr>
  <td>6082</td>
  <td>Foreign Trade and International Banking Institutions (except
  international trade financing)</td>

 </tr>
 <tr>
  <td>6082</td>
  <td>Foreign Trade and International Banking Institutions (international trade
  financing)</td>

 </tr>
 <tr>
  <td>831</td>
  <td>Forest Nurseries and Gathering of Forest Products (forest products  except gathering of maple sap)</td>

 </tr>
 <tr>
  <td>831</td>
  <td>Forest Nurseries and Gathering of Forest Products (gathering maple sap)</td>

 </tr>
 <tr>
  <td>851</td>
  <td>Forestry Services</td>

 </tr>
 <tr>
  <td>4432</td>
  <td>Freight Transportation on the Great Lakes - St. Lawrence Seaway</td>

 </tr>
 <tr>
  <td>5148</td>
  <td>Fresh Fruits and Vegetables (agents and brokers)</td>

 </tr>
 <tr>
  <td>5148</td>
  <td>Fresh Fruits and Vegetables (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5148</td>
  <td>Fresh Fruits and Vegetables (fresh fruits and vegetables sold via retail
  method)</td>

 </tr>
 <tr>
  <td>5148</td>
  <td>Fresh Fruits and Vegetables (merchant wholesalers except those selling
  fresh fruits and vegetables via retail method)</td>

 </tr>
 <tr>
  <td>2053</td>
  <td>Frozen Bakery ProductsExcept
  Bread</td>

 </tr>
 <tr>
  <td>2037</td>
  <td>Frozen FruitsFruit Juices  and Vegetables</td>

 </tr>
 <tr>
  <td>2038</td>
  <td>Frozen Specialties NEC</td>

 </tr>
 <tr>
  <td>5431</td>
  <td>Fruit and Vegetable Markets (except temporary fruit and vegetable stands)</td>

 </tr>
 <tr>
  <td>5431</td>
  <td>Fruit and Vegetable Markets (temporary fruit and vegetable stands)</td>

 </tr>
 <tr>
  <td>179</td>
  <td>Fruits and Tree Nuts NEC
  (combination farms)</td>

 </tr>
 <tr>
  <td>179</td>
  <td>Fruits and
  Tree Nuts NEC (except combination
  farms) </td>

 </tr>
 <tr>
  <td>5989</td>
  <td>Fuel Dealers NEC</td>

 </tr>
 <tr>
  <td>5983</td>
  <td>Fuel Oil Dealers</td>

 </tr>
 <tr>
  <td>6099</td>
  <td>Functions Related to Depository Banking � NEC(escrow and fiduciary
  agencies)</td>

 </tr>
 <tr>
  <td>6099</td>
  <td>Functions Related to Depository Banking � NEC(foreign currency
  exchange)</td>

 </tr>
 <tr>
  <td>6099</td>
  <td>Functions Related to Depository Banking � NEC (electronic funds transfer networks and clearinghouse
  associations)</td>

 </tr>
 <tr>
  <td>6099</td>
  <td>Functions Related to Depository Banking � NEC (except electronic funds transfer networks and clearinghouses  foreign currency exchanges  escrow and fiduciary agencies and deposit
  brokers)</td>

 </tr>
 <tr>
  <td>7261</td>
  <td>Funeral Services and Crematories (crematories)</td>

 </tr>
 <tr>
  <td>7261</td>
  <td>Funeral Services and Crematories (funeral homes and services)</td>

 </tr>
 <tr>
  <td>2371</td>
  <td>Fur Goods (except contractors)</td>

 </tr>
 <tr>
  <td>2371</td>
  <td>Fur Goods (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>2371</td>
  <td>Fur Goods (women'sGirl's  and infants' contractors)</td>

 </tr>
 <tr>
  <td>271</td>
  <td>Fur-Bearing Animals and Rabbits</td>

 </tr>
 <tr>
  <td>5712</td>
  <td>FurnitureStores (custom made
  upholstered household furniture)</td>

 </tr>
 <tr>
  <td>5021</td>
  <td>Furniture (agents and brokers)</td>

 </tr>
 <tr>
  <td>5021</td>
  <td>Furniture (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5021</td>
  <td>Furniture (furniture sold via the retail method)</td>

 </tr>
 <tr>
  <td>5021</td>
  <td>Furniture (merchant wholesalers except those selling via retail method)</td>

 </tr>
 <tr>
  <td>2599</td>
  <td>Furniture and Fixtures NEC
  (except hospital beds)</td>

 </tr>
 <tr>
  <td>2599</td>
  <td>Furniture and Fixtures NEC
  (hospital beds)</td>

 </tr>
 <tr>
  <td>5712</td>
  <td>Furniture Stores (custom made nonupholstered wood household furniture
  except cabinets)</td>

 </tr>
 <tr>
  <td>5712</td>
  <td>Furniture Stores (custom wood cabinets)</td>

 </tr>
 <tr>
  <td>5712</td>
  <td>Furniture Stores (except custom furniture and cabinets)</td>

 </tr>
 <tr>
  <td>3944</td>
  <td>GamesToys  and Children's Vehicles  Except Dolls and Bicycles (metal
  tricycles)</td>

 </tr>
 <tr>
  <td>3944</td>
  <td>GamesToys  and Children's Vehicles  Except Dolls and Bicycles (except metal
  tricycles)</td>

 </tr>
 <tr>
  <td>7212</td>
  <td>Garment Pressingand Agents for
  Laundries and Drycleaners</td>

 </tr>
 <tr>
  <td>4932</td>
  <td>Gas and Other Services Combined (natural gas distribution)</td>

 </tr>
 <tr>
  <td>3053</td>
  <td>GasketsPacking  and Sealing Devices</td>

 </tr>
 <tr>
  <td>5541</td>
  <td>Gasoline Service Station (gasoline station with convenience store)</td>

 </tr>
 <tr>
  <td>5541</td>
  <td>Gasoline Service Station (gasoline station without convenience store)</td>

 </tr>
 <tr>
  <td>7538</td>
  <td>General Automotive Repair Shops</td>

 </tr>
 <tr>
  <td>1541</td>
  <td>General Contractors - Industrial Buildings and Warehouses (general
  contractors of grain elevators</td>

 </tr>
 <tr>
  <td>1542</td>
  <td>General Contractors - Nonresidential Buildings   Other than Industrial Buildings and Warehouses</td>

 </tr>
 <tr>
  <td>1522</td>
  <td>General Contractors - Residential Buildings Other Than Single-Family
  (dormitorybarrack  hotel �
   and motel construction contractors)</td>

 </tr>
 <tr>
  <td>1522</td>
  <td>General Contractors - Residential Buildings Other Than Single-Family
  (except remodeling contractorshotel
  and motel construction contractors �
   and dormitory and barrack construction contractors)</td>

 </tr>
 <tr>
  <td>1522</td>
  <td>General Contractors - Residential Buildings Other Than Single-Family
  (remodeling contractors)</td>

 </tr>
 <tr>
  <td>1521</td>
  <td>General Contractors - Single-Family Houses (remodeling contractors)</td>

 </tr>
 <tr>
  <td>1541</td>
  <td>General Contractors Industrial Buildings and Warehouses ( except grain
  elevators</td>

 </tr>
 <tr>
  <td>1521</td>
  <td>General Contractors--Single Family Houses (except remodeling contractors)</td>

 </tr>
 <tr>
  <td>191</td>
  <td>General FarmsPrimarily Crop</td>

 </tr>
 <tr>
  <td>291</td>
  <td>General FarmsPrimarily Livestock
  and Animal Specialties</td>

 </tr>
 <tr>
  <td>9199</td>
  <td>General Government NEC</td>

 </tr>
 <tr>
  <td>3569</td>
  <td>General Industrial Machinery and Equipment    NEC (electric swimming pool heaters)</td>

 </tr>
 <tr>
  <td>3569</td>
  <td>General Industrial Machinery and Equipment    NEC (except fire hoses and electric swimming pool heaters)</td>

 </tr>
 <tr>
  <td>3569</td>
  <td>General Industrial Machinery and Equipment    NEC (textile fire hose)</td>

 </tr>
 <tr>
  <td>219</td>
  <td>General LivestockExcept Dairy
  and Poultry</td>

 </tr>
 <tr>
  <td>8062</td>
  <td>General Medical and Surgical Hospitals</td>

 </tr>
 <tr>
  <td>4225</td>
  <td>General Warehousing and Storage (except self-storage and miniwarehouses)</td>

 </tr>
 <tr>
  <td>4225</td>
  <td>General Warehousing and Storage (miniwarehouses and self-storage units)</td>

 </tr>
 <tr>
  <td>5947</td>
  <td>GiftNovelty  and Souvenir Shops</td>

 </tr>
 <tr>
  <td>2361</td>
  <td>Girl's Children's  and Infants' Dresses  Blouses �
   and Shirts (boys' contractors)</td>

 </tr>
 <tr>
  <td>2361</td>
  <td>Girl's Children's  and Infants' Dresses  Blouses �
   and Shirts (boys' shirts except �
   contractors)</td>

 </tr>
 <tr>
  <td>2361</td>
  <td>Girl's Children's  and Infants' Dresses  Blouses �
   and Shirts (Girl's and infants' contractors)</td>

 </tr>
 <tr>
  <td>2361</td>
  <td>Girl's Children's  and Infants' Dresses  Blouses �
   and Shirts (Girl's blouses and shirts except contractors)</td>

 </tr>
 <tr>
  <td>2361</td>
  <td>Girl's Children's  and Infants' Dresses  Blouses �
   and Shirts (Girl's dresses except contractors)</td>

 </tr>
 <tr>
  <td>2361</td>
  <td>Girl's Children's  and Infants' Dresses  Blouses �
   and Shirts (infants' except contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (boys' contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (boys' other outerwear except
  contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (boys' robes except contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (boys' suits and coats except
  contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (boys' trousers  slacks �
   and jeans except contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (Girl's and infants' contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (Girl's other outerwear except
  contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (Girl's robes except contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (Girl's suits  coats �
   jacketsand skirts except
  contractors)</td>

 </tr>
 <tr>
  <td>2369</td>
  <td>Girl's Children's  and Infants' Outerwear   NEC (infants' except contractors)</td>

 </tr>
 <tr>
  <td>1793</td>
  <td>Glass and Glazing Work</td>

 </tr>
 <tr>
  <td>3221</td>
  <td>Glass Containers</td>

 </tr>
 <tr>
  <td>3231</td>
  <td>Glass Products Made of Purchased Glass</td>

 </tr>
 <tr>
  <td>1041</td>
  <td>Gold Ores</td>

 </tr>
 <tr>
  <td>5153</td>
  <td>Grain and Field Beans (agents and brokers)</td>

 </tr>
 <tr>
  <td>5153</td>
  <td>Grain and Field Beans (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5153</td>
  <td>Grain and Field Beans (grain and field beans sold via retail method)</td>

 </tr>
 <tr>
  <td>5153</td>
  <td>Grain and Field Beans (merchant wholesalers except those selling grains
  and field beans via retail method)</td>

 </tr>
 <tr>
  <td>172</td>
  <td>Grapes</td>

 </tr>
 <tr>
  <td>3321</td>
  <td>Gray and Ductile Iron Foundries</td>

 </tr>
 <tr>
  <td>2771</td>
  <td>Greeting Cards (flexographic printing of greeting cards)</td>

 </tr>
 <tr>
  <td>2771</td>
  <td>Greeting Cards (gravure printing of greeting cards)</td>

 </tr>
 <tr>
  <td>2771</td>
  <td>Greeting Cards (Internet greeting card publishers)</td>

 </tr>
 <tr>
  <td>2771</td>
  <td>Greeting Cards (lithographic printing of greeting cards)</td>

 </tr>
 <tr>
  <td>2771</td>
  <td>Greeting Cards (other printing of greeting cards)</td>

 </tr>
 <tr>
  <td>2771</td>
  <td>Greeting Cards (publishing greeting cards except Internet greeting card
  publishers)</td>

 </tr>
 <tr>
  <td>2771</td>
  <td>Greeting Cards (screen printing of greeting cards)</td>

 </tr>
 <tr>
  <td>5141</td>
  <td>GroceriesGeneral Line (agents
  and brokers)</td>

 </tr>
 <tr>
  <td>5141</td>
  <td>GroceriesGeneral Line (business
  to business electronic markets)</td>

 </tr>
 <tr>
  <td>5141</td>
  <td>GroceriesGeneral Line (general
  line groceries sold via retail method)</td>

 </tr>
 <tr>
  <td>5141</td>
  <td>GroceriesGeneral Line (merchant
  wholesalers except those selling general line groceries via retail method)</td>

 </tr>
 <tr>
  <td>5149</td>
  <td>Groceries and Related Products � NEC (agents and brokers)</td>

 </tr>
 <tr>
  <td>5149</td>
  <td>Groceries and Related Products � NEC (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5149</td>
  <td>Groceries and Related Products � NEC (groceries and related products �
   except pet foodsold via
  retail method)</td>

 </tr>
 <tr>
  <td>5149</td>
  <td>Groceries and Related Products � NEC (merchant wholesalers except processed bottled water manufacturing
  and merchant wholesalers selling groceries and related products via retail
  method)</td>

 </tr>
 <tr>
  <td>5149</td>
  <td>Groceries and Related Products � NEC (pet food sold via retail method)</td>

 </tr>
 <tr>
  <td>5149</td>
  <td>Groceries
  and Related Products NEC (processed
  bottled water manufacturing) </td>

 </tr>
 <tr>
  <td>5411</td>
  <td>Grocery Stores (convenience store with gas)</td>

 </tr>
 <tr>
  <td>5411</td>
  <td>Grocery Stores (convenience stores without gas)</td>

 </tr>
 <tr>
  <td>5411</td>
  <td>Grocery Stores (except convenience stores   freezer plansand
  grocery stores with substantial general merchandise)</td>

 </tr>
 <tr>
  <td>5411</td>
  <td>Grocery Stores (frozen food and freezer plan providers)</td>

 </tr>
 <tr>
  <td>5411</td>
  <td>Grocery Stores (grocery stores and supermarkets selling substantial
  amounts of nonfood items)</td>

 </tr>
 <tr>
  <td>3769</td>
  <td>Guided Missile and Space Vehicle Parts and Auxiliary Equipment   NEC (except research and development not
  producing prototypes)</td>

 </tr>
 <tr>
  <td>3769</td>
  <td>Guided Missile and Space Vehicle Parts and Auxiliary Equipment   NEC (research and development not
  producing prototypes)</td>

 </tr>
 <tr>
  <td>3764</td>
  <td>Guided Missile and Space Vehicle Propulsion Units and Propulsion Unit
  Parts (except research and development not producing prototypes))</td>

 </tr>
 <tr>
  <td>3764</td>
  <td>Guided Missile and Space Vehicle Propulsion Units and Propulsion Unit
  Parts (research and development not producing prototypes)</td>

 </tr>
 <tr>
  <td>3761</td>
  <td>Guided Missiles and Space Vehicles (except research and development not
  producing prototypes)</td>

 </tr>
 <tr>
  <td>3761</td>
  <td>Guided Missiles and Space Vehicles (research and development not
  producing prototypes)</td>

 </tr>
 <tr>
  <td>2861</td>
  <td>Gum and Wood Chemicals</td>

 </tr>
 <tr>
  <td>3275</td>
  <td>Gypsum Products</td>

 </tr>
 <tr>
  <td>3423</td>
  <td>Hand and Edge ToolsExcept
  Machine Tools and Handsaws</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware    NEC (except fire hose nozzles �
   hose couplingsvacuum and
  insulated bottlesjugs and chests  fireplace fixtures  time locks   turnbuckles �
   pulleystackle blocks  luggage and utility racks  sleep sofa mechanisms and chair
  glidestraps  handcuffs and leg irons  ladder jacks   and other like metal products)</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware NEC (fire hose nozzles
  and hose couplings)</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware NEC (fireplace
  fixturestraps  handcuffs and leg irons  ladder jacks   and other like metal products)</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware NEC (luggage and utility
  racks)</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware NEC (pulleys  tackle blocks   block and tackle assemblies)</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware NEC (sleep sofa
  mechanisms and chair glides)</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware NEC (time locks)</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware NEC (turnbuckles and
  hose clamps)</td>

 </tr>
 <tr>
  <td>3429</td>
  <td>Hardware NEC (vacuum and
  insulated bottlesjugs  and chests)</td>

 </tr>
 <tr>
  <td>5072</td>
  <td>Hardware (agents and brokers)</td>

 </tr>
 <tr>
  <td>5072</td>
  <td>Hardware (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5072</td>
  <td>Hardware (hardware sold via retail method)</td>

 </tr>
 <tr>
  <td>5072</td>
  <td>Hardware (merchant wholesalers except those selling hardware via retail
  method)</td>

 </tr>
 <tr>
  <td>5251</td>
  <td>Hardware Stores</td>

 </tr>
 <tr>
  <td>2426</td>
  <td>Hardwood Dimension and Flooring Mills (hardwood cut stock  resawing hardwood lumber  and planing purchased hardwood lumber
  except flooring)</td>

 </tr>
 <tr>
  <td>2426</td>
  <td>Hardwood Dimension and Flooring Mills (hardwood dimension lumber made
  from logs or bolts)</td>

 </tr>
 <tr>
  <td>2426</td>
  <td>Hardwood Dimension and Flooring Mills (hardwood flooring)</td>

 </tr>
 <tr>
  <td>2426</td>
  <td>Hardwood Dimension and Flooring Mills (wood furniture frames and finished
  furniture parts)</td>

 </tr>
 <tr>
  <td>2435</td>
  <td>Hardwood Veneer and Plywood</td>

 </tr>
 <tr>
  <td>2353</td>
  <td>HatsCaps  and Millinery (except contractors)</td>

 </tr>
 <tr>
  <td>2353</td>
  <td>HatsCaps  and Millinery (men's and boys'
  contractors)</td>

 </tr>
 <tr>
  <td>2353</td>
  <td>HatsCaps  and Millinery (women's  Girl's �
   and infants' contractors)</td>

 </tr>
 <tr>
  <td>8099</td>
  <td>Health and Allied Services NEC
  (blood and organ banks)</td>

 </tr>
 <tr>
  <td>8099</td>
  <td>Health and Allied Services NEC
  (childbirth preparation)</td>

 </tr>
 <tr>
  <td>8099</td>
  <td>Health and Allied Services NEC
  (except blood and organ banksmedical
  artistsmedical photography  and childbirth preparation classes)</td>

 </tr>
 <tr>
  <td>8099</td>
  <td>Health and Allied Services NEC
  (medical artists)</td>

 </tr>
 <tr>
  <td>8099</td>
  <td>Health and Allied Services NEC
  (medical photography)</td>

 </tr>
 <tr>
  <td>3433</td>
  <td>Heating EquipmentExcept Electric
  and Warm Air Furnaces</td>

 </tr>
 <tr>
  <td>1629</td>
  <td>Heavy Construction   NEC (except industrial nonbuilding
  structuresirrigation systems  sewage and water treatment plants  petrochemical plants and refineries  power generation plants [except
  hydroelectric dams] transmission and distribution stations  right-of-way clearing  line slashing   blastingand trenching)</td>
 </tr>
 <tr>
  <td>1629</td>
  <td>Heavy Construction NEC
  (Industrial nonbuilding structures [except petrochemical plants and petroleum
  refineries])</td>

 </tr>
 <tr>
  <td>1629</td>
  <td>Heavy Construction NEC
  (petrochemical plants and refineries)</td>

 </tr>
 <tr>
  <td>1629</td>
  <td>Heavy Construction NEC (power
  generation plants [except hydroelectric dams]   transmission stations �
   and distribution stations)</td>

 </tr>
 <tr>
  <td>1629</td>
  <td>Heavy Construction NEC
  (right-of-way clearing and line slashing �
   blastingand trenching)</td>

 </tr>
 <tr>
  <td>7353</td>
  <td>Heavy Construction Equipment Rental and Leasing (crane rental with
  operator)</td>

 </tr>
 <tr>
  <td>7353</td>
  <td>Heavy Construction Equipment Rental and Leasing (heavy construction
  equipment rental without operators)</td>

 </tr>
 <tr>
  <td>7353</td>
  <td>Heavy Construction Equipment Rental and Leasing (rental of construction
  equipment [except cranes] with operator)</td>

 </tr>
 <tr>
  <td>1629</td>
  <td>Heavy Construction  NEC (irrigation systems   sewage treatment plants �
   and water treatment plants)</td>

 </tr>
 <tr>
  <td>7363</td>
  <td>Help Supply Services (employee leasing services   professional employer organizations)</td>

 </tr>
 <tr>
  <td>7363</td>
  <td>Help Supply Services (temporary help services)</td>

 </tr>
 <tr>
  <td>1611</td>
  <td>Highway and Street Construction �
   Except Elevated Highways</td>

 </tr>
 <tr>
  <td>5945</td>
  <td>HobbyToy  and Game Stores</td>

 </tr>
 <tr>
  <td>213</td>
  <td>Hogs</td>

 </tr>
 <tr>
  <td>8082</td>
  <td>Home Health Care Services</td>

 </tr>
 <tr>
  <td>5023</td>
  <td>Homefurnishings (agents and brokers)</td>

 </tr>
 <tr>
  <td>5023</td>
  <td>Homefurnishings (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5023</td>
  <td>Homefurnishings (floor coverings sold via retail method)</td>

 </tr>
 <tr>
  <td>5023</td>
  <td>Homefurnishings (merchant wholesalers except those selling via retail
  method)</td>

 </tr>
 <tr>
  <td>272</td>
  <td>Horses and Other Equines</td>

 </tr>
 <tr>
  <td>2252</td>
  <td>Hosiery NEC (dyeing and finishing
  hosiery � except sheer  without knitting hosiery)</td>

 </tr>
 <tr>
  <td>2252</td>
  <td>Hosiery NEC (except Girl's
  full-length and knee-length sheer hosiery and dyeing and finishing hosiery
  without knitting hosiery)</td>

 </tr>
 <tr>
  <td>2252</td>
  <td>Hosiery NEC (Girl's full length
  and knee length sheer hosiery)</td>

 </tr>
 <tr>
  <td>6324</td>
  <td>Hospital and Medical Service Plans (health and medical insurers-direct)</td>

 </tr>
 <tr>
  <td>6324</td>
  <td>Hospital and Medical Service Plans (reinsurers)</td>

 </tr>
 <tr>
  <td>6324</td>
  <td>Hospital and Medical Service Plans (self insurers)</td>

 </tr>
 <tr>
  <td>7011</td>
  <td>Hotels and Motels (bed and breakfast inns)</td>

 </tr>
 <tr>
  <td>7011</td>
  <td>Hotels and Motels (casino hotels)</td>

 </tr>
 <tr>
  <td>7011</td>
  <td>Hotels and Motels (except hotels �
   motelsand bed and breakfast
  inns)</td>

 </tr>
 <tr>
  <td>7011</td>
  <td>Hotels and Motels (hotelsexcept
  casino hotelsand motels)</td>

 </tr>
 <tr>
  <td>3142</td>
  <td>House Slippers</td>

 </tr>
 <tr>
  <td>2392</td>
  <td>HousefurnishingsExcept Curtains
  and Draperies (blanketlaundry  and wardrobe bags)</td>

 </tr>
 <tr>
  <td>2392</td>
  <td>HousefurnishingsExcept Curtains
  and Draperies (dust rags)</td>

 </tr>
 <tr>
  <td>2392</td>
  <td>HousefurnishingsExcept Curtains
  and Draperies (except mopsdust
  ragsand bags)</td>

 </tr>
 <tr>
  <td>2392</td>
  <td>HousefurnishingsExcept Curtains
  and Draperies (floor and dust mops)</td>

 </tr>
 <tr>
  <td>5722</td>
  <td>Household Appliance Stores</td>

 </tr>
 <tr>
  <td>3639</td>
  <td>Household Appliances NEC (except
  floor waxing and floor polishing machines �
   and household sewing machines)</td>

 </tr>
 <tr>
  <td>3639</td>
  <td>Household Appliances NEC (floor
  waxing and floor polishing machines)</td>

 </tr>
 <tr>
  <td>3639</td>
  <td>Household Appliances NEC
  (household sewing machines)</td>

 </tr>
 <tr>
  <td>3651</td>
  <td>Household Audio and Video Equipment</td>

 </tr>
 <tr>
  <td>3631</td>
  <td>Household Cooking Equipment</td>

 </tr>
 <tr>
  <td>2519</td>
  <td>Household Furniture NEC</td>

 </tr>
 <tr>
  <td>3633</td>
  <td>Household Laundry Equipment</td>

 </tr>
 <tr>
  <td>3632</td>
  <td>Household Refrigerators and Home and Farm Freezers</td>

 </tr>
 <tr>
  <td>3635</td>
  <td>Household Vacuum Cleaners</td>

 </tr>
 <tr>
  <td>971</td>
  <td>Hunting and Trappingand Game
  Propagation</td>

 </tr>
 <tr>
  <td>2024</td>
  <td>Ice Cream and Frozen Desserts</td>

 </tr>
 <tr>
  <td>2835</td>
  <td>In Vitro and In Vivo Diagnostic Substances (except in-vitro diagnostic
  substances)</td>

 </tr>
 <tr>
  <td>2835</td>
  <td>In Vitro and In Vivo Diagnostic Substances (in-vitro diagnostic
  substances)</td>

 </tr>
 <tr>
  <td>8322</td>
  <td>Individual and Family Social Services ( community food assistance
  services)</td>

 </tr>
 <tr>
  <td>8322</td>
  <td>Individual and Family Social Services (child and youth services)</td>

 </tr>
 <tr>
  <td>8322</td>
  <td>Individual and Family Social Services (emergency and relief services)</td>

 </tr>
 <tr>
  <td>8322</td>
  <td>Individual and Family Social Services (except services for children  youth �
   elderlyand disabled</td>

 </tr>
 <tr>
  <td>8322</td>
  <td>Individual and Family Social Services (government parole and probation
  offices)</td>

 </tr>
 <tr>
  <td>8322</td>
  <td>Individual and Family Social Services (housing services except temporary
  shelter)</td>

 </tr>
 <tr>
  <td>8322</td>
  <td>Individual and Family Social Services (services for the elderly and
  disabled)</td>

 </tr>
 <tr>
  <td>8322</td>
  <td>Individual and Family Social Services (temporary shelter)</td>

 </tr>
 <tr>
  <td>3564</td>
  <td>Industrial and Commercial Fans and Blowers and Air Purification Equipment
  (air purification equipment)</td>

 </tr>
 <tr>
  <td>3564</td>
  <td>Industrial and Commercial Fans and Blowers and Air Purification Equipment
  (fans and blowers)</td>

 </tr>
 <tr>
  <td>3599</td>
  <td>Industrial and Commercial Machinery and Equipment   NEC (carnival amusement park equipment)</td>

 </tr>
 <tr>
  <td>3599</td>
  <td>Industrial and Commercial Machinery and Equipment   NEC (flexible metal hose)</td>

 </tr>
 <tr>
  <td>3599</td>
  <td>Industrial and Commercial Machinery and Equipment   NEC (gasoline   oiland intake filters
  for internal combustion engines �
   except for motor vehicles)</td>

 </tr>
 <tr>
  <td>3599</td>
  <td>Industrial and Commercial Machinery and Equipment   NEC (grinding castings for the trade)</td>

 </tr>
 <tr>
  <td>3599</td>
  <td>Industrial and Commercial Machinery and Equipment   NEC (machine shops)</td>

 </tr>
 <tr>
  <td>3599</td>
  <td>Industrial and Commercial Machinery and Equipment   NEC (other industrial and commercial
  machinery and equipment)</td>

 </tr>
 <tr>
  <td>3599</td>
  <td>Industrial and Commercial Machinery and Equipment   NEC (water leak detectors)</td>

 </tr>
 <tr>
  <td>5113</td>
  <td>Industrial and Personal Service Paper (agents and brokers)</td>

 </tr>
 <tr>
  <td>5113</td>
  <td>Industrial and Personal Service Paper (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5113</td>
  <td>Industrial and Personal Service Paper (industrial and personal service
  paper sold via retail method)</td>

 </tr>
 <tr>
  <td>5113</td>
  <td>Industrial and Personal Service Paper (merchant wholesalers except those
  selling industrial and personal service paper via retail method)</td>

 </tr>
 <tr>
  <td>2813</td>
  <td>Industrial Gases</td>

 </tr>
 <tr>
  <td>2819</td>
  <td>Industrial Inorganic Chemicals � NEC (activated carbon and charcoal)</td>

 </tr>
 <tr>
  <td>2819</td>
  <td>Industrial Inorganic Chemicals � NEC (alumina)</td>

 </tr>
 <tr>
  <td>2819</td>
  <td>Industrial Inorganic Chemicals � NEC (except activated carbon and charcoal   aluminarecovering
  sulfur from natural gasand inorganic
  dyes)</td>

 </tr>
 <tr>
  <td>2819</td>
  <td>Industrial Inorganic Chemicals � NEC (inorganic dyes)</td>

 </tr>
 <tr>
  <td>2819</td>
  <td>Industrial Inorganic Chemicals � NEC (recovering sulfur from natural gas)</td>

 </tr>
 <tr>
  <td>3823</td>
  <td>Industrial Instruments for Measurement �
   Displayand Control of Process
  Variables</td>

 </tr>
 <tr>
  <td>7218</td>
  <td>Industrial Launderers</td>

 </tr>
 <tr>
  <td>5084</td>
  <td>Industrial Machinery and Equipment (agents and brokers)</td>

 </tr>
 <tr>
  <td>5084</td>
  <td>Industrial Machinery and Equipment (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5084</td>
  <td>Industrial Machinery and Equipment (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>2869</td>
  <td>Industrial Organic Chemicals NEC
  (aliphatics)</td>

 </tr>
 <tr>
  <td>2869</td>
  <td>Industrial Organic Chemicals NEC
  (carbon bisulfide)</td>

 </tr>
 <tr>
  <td>2869</td>
  <td>Industrial Organic Chemicals NEC
  (cyclopropanediethylcyclohexane  naphthalene sulfonic acid)</td>

 </tr>
 <tr>
  <td>2869</td>
  <td>Industrial Organic Chemicals NEC
  (ethyl alcohol)</td>

 </tr>
 <tr>
  <td>2869</td>
  <td>Industrial Organic Chemicals NEC
  (except aliphaticscarbon
  bisulfideethyl alcohol  cyclopropane   diethylcyclohexane �
   napthalene sulfonic acid �
   synthetic hydraulic fluidsand
  fluorocarbon gases)</td>

 </tr>
 <tr>
  <td>2869</td>
  <td>Industrial Organic Chemicals NEC
  (fluorocarbon gases)</td>

 </tr>
 <tr>
  <td>2869</td>
  <td>Industrial Organic Chemicals NEC
  (synthetic hydraulic fluids)</td>

 </tr>
 <tr>
  <td>3543</td>
  <td>Industrial Patterns</td>

 </tr>
 <tr>
  <td>3567</td>
  <td>Industrial Process Furnaces and Ovens</td>

 </tr>
 <tr>
  <td>1446</td>
  <td>Industrial Sand</td>

 </tr>
 <tr>
  <td>5085</td>
  <td>Industrial Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5085</td>
  <td>Industrial Supplies (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5085</td>
  <td>Industrial Supplies (merchant wholesalers of fluid power accessories)</td>

 </tr>
 <tr>
  <td>5085</td>
  <td>Industrial Supplies (merchant wholesalers of industrial supplies except
  fluid power accessories and merchant wholesalers selling industrial supplies
  via retail method)</td>

 </tr>
 <tr>
  <td>5085</td>
  <td>Industrial Supplies (sold via retail method)</td>

 </tr>
 <tr>
  <td>3537</td>
  <td>Industrial TrucksTractors  Trailers �
   and Stackers (except metal pallets and metal air cargo containers)</td>

 </tr>
 <tr>
  <td>3537</td>
  <td>Industrial TrucksTractors  Trailers �
   and Stackers (metal air cargo containers)</td>

 </tr>
 <tr>
  <td>3537</td>
  <td>Industrial TrucksTractors  Trailers �
   and Stackers (metal pallets)</td>

 </tr>
 <tr>
  <td>3491</td>
  <td>Industrial Valves</td>

 </tr>
 <tr>
  <td>7375</td>
  <td>Information Retrieval Services (Internet service providers and Internet
  access providers)</td>

 </tr>
 <tr>
  <td>2816</td>
  <td>Inorganic Pigments (bone and lamp black)</td>

 </tr>
 <tr>
  <td>2816</td>
  <td>Inorganic Pigments (except bone and lamp black)</td>

 </tr>
 <tr>
  <td>1796</td>
  <td>Installation or Erection of Building Equipment    NEC (installation of equipment not elsewhere specified such as
  central vacuum cleaning systems and dumb waiters)</td>

 </tr>
 <tr>
  <td>1796</td>
  <td>Installation or Erection of Building Equipment    NEC (scrubberdust
  collectionand other industrial
  ventilation installation)</td>

 </tr>
 <tr>
  <td>3825</td>
  <td>Instruments for Measuring and Testing of Electricity and Electrical
  Signals (automotive ammeters and voltmeters)</td>

 </tr>
 <tr>
  <td>3825</td>
  <td>Instruments for Measuring and Testing of Electricity and Electrical
  Signals (except automotive instruments)</td>

 </tr>
 <tr>
  <td>6411</td>
  <td>Insurance AgentsBrokers  and Service (except processors  agents and brokers  and claims adjusters)</td>

 </tr>
 <tr>
  <td>6411</td>
  <td>Insurance AgentsBrokers  and Service (insurance agents and brokers)</td>

 </tr>
 <tr>
  <td>6411</td>
  <td>Insurance AgentsBrokers  and Service (insurance claims adjusters)</td>

 </tr>
 <tr>
  <td>6411</td>
  <td>Insurance AgentsBrokers  and Service (processors)</td>

 </tr>
 <tr>
  <td>6399</td>
  <td>Insurance Carriers NEC</td>

 </tr>
 <tr>
  <td>4131</td>
  <td>Intercity and Rural Bus Transportation</td>

 </tr>
 <tr>
  <td>8052</td>
  <td>Intermediate
  Care Facilities (continuing care retirement communities) </td>

 </tr>
 <tr>
  <td>8052</td>
  <td>Intermediate Care Facilities (except continuing care retirement
  communities and mental retardation facilities)</td>

 </tr>
 <tr>
  <td>8052</td>
  <td>Intermediate Care Facilities (mental retardation facilities)</td>

 </tr>
 <tr>
  <td>3519</td>
  <td>Internal Combustion Engines NEC
  (except stationary engine radiators)</td>

 </tr>
 <tr>
  <td>3519</td>
  <td>Internal Combustion Engines NEC
  (stationary engine radiators)</td>

 </tr>
 <tr>
  <td>9721</td>
  <td>International Affairs</td>

 </tr>
 <tr>
  <td>6282</td>
  <td>Investment Advice (except portfolio managers)</td>

 </tr>
 <tr>
  <td>6282</td>
  <td>Investment Advice (portfolio managers)</td>

 </tr>
 <tr>
  <td>6799</td>
  <td>Investors NEC (commodity contract
  pool operators)</td>

 </tr>
 <tr>
  <td>6799</td>
  <td>Investors NEC (commodity contract
  trading companies)</td>

 </tr>
 <tr>
  <td>6799</td>
  <td>Investors NEC (venture capital
  companiesinvestment clubs  and speculators for own account)</td>

 </tr>
 <tr>
  <td>134</td>
  <td>Irish Potatoes</td>

 </tr>
 <tr>
  <td>3462</td>
  <td>Iron and Steel Forgings</td>

 </tr>
 <tr>
  <td>1011</td>
  <td>Iron Ores</td>

 </tr>
 <tr>
  <td>4971</td>
  <td>Irrigation Systems</td>

 </tr>
 <tr>
  <td>3915</td>
  <td>Jewelers' Findings and Materials �
   and Lapidary Work (except watch jewels)</td>

 </tr>
 <tr>
  <td>3915</td>
  <td>Jewelers Findings and Materials and Lapidary Work (watch jewels)</td>

 </tr>
 <tr>
  <td>3911</td>
  <td>JewelryPrecious Metal</td>

 </tr>
 <tr>
  <td>5094</td>
  <td>JewelryWatches  Precious Stones   and Precious Metals (agents and brokers)</td>

 </tr>
 <tr>
  <td>5094</td>
  <td>JewelryWatches  Precious Stones   and Precious Metals (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5094</td>
  <td>JewelryWatches  Precious Stones   and Precious Metals (jewelry and related goods sold via retail
  method)</td>

 </tr>
 <tr>
  <td>5094</td>
  <td>JewelryWatches  Precious Stones   and Precious Metals (merchant wholesalers except those selling
  jewelry and related goods via retail method)</td>

 </tr>
 <tr>
  <td>5944</td>
  <td>Jewelry Stores</td>

 </tr>
 <tr>
  <td>8331</td>
  <td>Job Training and Vocational Rehabilitation Services</td>

 </tr>
 <tr>
  <td>8222</td>
  <td>Junior Colleges and Technical Institutes</td>

 </tr>
 <tr>
  <td>1455</td>
  <td>Kaolin and Ball Clay</td>

 </tr>
 <tr>
  <td>8092</td>
  <td>Kidney Dialysis Centers</td>

 </tr>
 <tr>
  <td>2253</td>
  <td>Knit Outerwear Mills (dyeing and finishing knit outerwear without
  knitting outerwear)</td>

 </tr>
 <tr>
  <td>2253</td>
  <td>Knit Outerwear Mills (except bath and lounging robes and dying and finish
  without knitting garments)</td>

 </tr>
 <tr>
  <td>2253</td>
  <td>Knit Outerwear Mills (knitting bath or lounging robes)</td>

 </tr>
 <tr>
  <td>2254</td>
  <td>Knit Underwear and Nightwear Mills (dyeing and finishing underwear and
  nightwear without knitting garments)</td>

 </tr>
 <tr>
  <td>2254</td>
  <td>Knit Underwear and Nightwear Mills (except dyeing and finishing underwear
  and nightwear without knitting garments)</td>

 </tr>
 <tr>
  <td>2259</td>
  <td>Knitting Mills NEC (dyeing and
  finishing knit gloves and mittens without knitting gloves or mittens)</td>

 </tr>
 <tr>
  <td>2259</td>
  <td>Knitting Mills NEC (knitting
  girdles and allied foundation garments)</td>

 </tr>
 <tr>
  <td>2259</td>
  <td>Knitting Mills NEC (knitting
  gloves and mittens)</td>

 </tr>
 <tr>
  <td>2259</td>
  <td>Knitting Mills NEC (knitting lace
  or warp fabric and fabricating textile products   such as bedspreads �
   curtainsor towels)</td>

 </tr>
 <tr>
  <td>2259</td>
  <td>Knitting Mills NEC (knitting weft
  fabric and fabricating textile products �
   such as bedspreads �
   curtainsor towels)</td>

 </tr>
 <tr>
  <td>8631</td>
  <td>Labor Unions and Similar Labor Organizations</td>

 </tr>
 <tr>
  <td>3826</td>
  <td>Laboratory Analytical Instruments</td>

 </tr>
 <tr>
  <td>3821</td>
  <td>Laboratory Apparatus and Furniture</td>

 </tr>
 <tr>
  <td>2258</td>
  <td>Lace and Warp Knit Fabric Mills (except finishing lace or warp fabric
  without knitting lace or warp fabric)</td>

 </tr>
 <tr>
  <td>2258</td>
  <td>Lace and Warp Knit Fabric Mills (finishing lace or warp fabric without
  knitting lace or warp fabric)</td>

 </tr>
 <tr>
  <td>3083</td>
  <td>Laminated Plastics Plate �
   Sheetand Profile Shapes</td>

 </tr>
 <tr>
  <td>9512</td>
  <td>LandMineral  Wildlife �
   and Forest Conservation</td>

 </tr>
 <tr>
  <td>6552</td>
  <td>Land Subdividers and Developers �
   Except Cemeteries</td>

 </tr>
 <tr>
  <td>781</td>
  <td>Landscape Counseling and Planning (except horticultural consulting)</td>

 </tr>
 <tr>
  <td>781</td>
  <td>Landscape Counseling and Planning (horticulture consulting)</td>

 </tr>
 <tr>
  <td>7219</td>
  <td>Laundry and Garment Services NEC
  (alteration and repair)</td>

 </tr>
 <tr>
  <td>7219</td>
  <td>Laundry and Garment Services NEC
  (diaper service)</td>

 </tr>
 <tr>
  <td>7219</td>
  <td>Laundry and Garment Services NEC
  (except diaper service and clothing alteration and repair)</td>

 </tr>
 <tr>
  <td>782</td>
  <td>Lawn and Garden Services</td>

 </tr>
 <tr>
  <td>3524</td>
  <td>Lawn and Garden Tractors and Home Lawn and Garden Equipment (except
  nonpowered lawnmowers)</td>

 </tr>
 <tr>
  <td>3524</td>
  <td>Lawn and Garden Tractors and Home Lawn and Garden Equipment (nonpowered
  lawnmowers)</td>

 </tr>
 <tr>
  <td>1031</td>
  <td>Lead and Zinc Ores</td>

 </tr>
 <tr>
  <td>3952</td>
  <td>Lead PencilsCrayons  and Artists' Materials (drafting tables
  and boards)</td>

 </tr>
 <tr>
  <td>3952</td>
  <td>Lead PencilsCrayons  and Artists' Materials (except drawing
  inkindia ink  drafting tables and drafting boards)</td>

 </tr>
 <tr>
  <td>3952</td>
  <td>Lead Pencils and Art Goods (drawing inks and india ink)</td>

 </tr>
 <tr>
  <td>2386</td>
  <td>Leather and Sheep-lined Clothing (except contractors)</td>

 </tr>
 <tr>
  <td>2386</td>
  <td>Leather and Sheep-Lined Clothing (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>2386</td>
  <td>Leather and Sheep-Lined Clothing (women's   Girl'sand infants'
  contractors)</td>

 </tr>
 <tr>
  <td>3151</td>
  <td>Leather Gloves and Mittens (except contractors)</td>

 </tr>
 <tr>
  <td>3151</td>
  <td>Leather Gloves and Mittens (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>3151</td>
  <td>Leather Gloves and Mittens (women's �
   Girl'sand infants'
  contractors)</td>

 </tr>
 <tr>
  <td>3199</td>
  <td>Leather Goods NEC</td>

 </tr>
 <tr>
  <td>3111</td>
  <td>Leather Tanning and Finishing</td>

 </tr>
 <tr>
  <td>9222</td>
  <td>Legal Counsel and Prosecution</td>

 </tr>
 <tr>
  <td>8111</td>
  <td>Legal Services</td>

 </tr>
 <tr>
  <td>9121</td>
  <td>Legislative Bodies</td>

 </tr>
 <tr>
  <td>6517</td>
  <td>Lessors of Railroad Property</td>

 </tr>
 <tr>
  <td>6519</td>
  <td>Lessors of Real Property NEC</td>

 </tr>
 <tr>
  <td>8231</td>
  <td>Libraries</td>

 </tr>
 <tr>
  <td>6311</td>
  <td>Life Insurance (burial insurance)</td>

 </tr>
 <tr>
  <td>6311</td>
  <td>Life Insurance (life insurers-direct)</td>

 </tr>
 <tr>
  <td>6311</td>
  <td>Life Insurance (reinsurers)</td>

 </tr>
 <tr>
  <td>3648</td>
  <td>Lighting Equipment NEC</td>

 </tr>
 <tr>
  <td>3274</td>
  <td>Lime</td>

 </tr>
 <tr>
  <td>7213</td>
  <td>Linen Supply</td>

 </tr>
 <tr>
  <td>3996</td>
  <td>LinoleumAsphalted-Felt-Base  and Other Hard Surface Floor
  Coverings NEC</td>

 </tr>
 <tr>
  <td>5984</td>
  <td>Liquefied Petroleum Gas (Bottled Gas) Dealers</td>

 </tr>
 <tr>
  <td>5921</td>
  <td>Liquor Stores</td>

 </tr>
 <tr>
  <td>5154</td>
  <td>Livestock (agents and brokers)</td>

 </tr>
 <tr>
  <td>5154</td>
  <td>Livestock (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5154</td>
  <td>Livestock (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>751</td>
  <td>Livestock ServicesExcept
  Veterinary (custom slaughtering)</td>

 </tr>
 <tr>
  <td>751</td>
  <td>Livestock ServicesExcept
  Veterinary (except custom slaughtering)</td>

 </tr>
 <tr>
  <td>6163</td>
  <td>Loan Brokers</td>

 </tr>
 <tr>
  <td>4111</td>
  <td>Local and Suburban Transit (airport transportation service)</td>

 </tr>
 <tr>
  <td>4111</td>
  <td>Local and Suburban Transit (bus and motor vehicle)</td>

 </tr>
 <tr>
  <td>4111</td>
  <td>Local and Suburban Transit (commuter rail)</td>

 </tr>
 <tr>
  <td>4111</td>
  <td>Local and Suburban Transit (except mixed mode   commuter railairport
  transportation serviceand bus and
  motor vehicle)</td>

 </tr>
 <tr>
  <td>4111</td>
  <td>Local and Suburban Transit (mixed mode)</td>

 </tr>
 <tr>
  <td>4141</td>
  <td>Local Bus Charter Service</td>

 </tr>
 <tr>
  <td>4119</td>
  <td>Local Passenger Transportation � NEC (employee transportation)</td>

 </tr>
 <tr>
  <td>4119</td>
  <td>Local Passenger Transportation � NEC (hearse rental with driver and carpool and vanpool operation)</td>

 </tr>
 <tr>
  <td>4119</td>
  <td>Local Passenger Transportation � NEC (land ambulance)</td>

 </tr>
 <tr>
  <td>4119</td>
  <td>Local Passenger Transportation � NEC (limousine rental with driver and automobile rental with driver)</td>

 </tr>
 <tr>
  <td>4119</td>
  <td>Local Passenger Transportation � NEC (sightseeing buses and cable and cog railways  except scenic)</td>

 </tr>
 <tr>
  <td>4119</td>
  <td>Local Passenger Transportation � NEC (special needs transportation)</td>

 </tr>
 <tr>
  <td>4214</td>
  <td>Local Trucking With Storage (general freight)</td>

 </tr>
 <tr>
  <td>4214</td>
  <td>Local Trucking With Storage (household goods moving)</td>

 </tr>
 <tr>
  <td>4214</td>
  <td>Local Trucking With Storage (specialized freight)</td>

 </tr>
 <tr>
  <td>4212</td>
  <td>Local Trucking Without Storage (general freight)</td>

 </tr>
 <tr>
  <td>4212</td>
  <td>Local Trucking Without Storage (hazardous waste collection without
  disposal)</td>

 </tr>
 <tr>
  <td>4212</td>
  <td>Local Trucking Without Storage (household goods moving)</td>

 </tr>
 <tr>
  <td>4212</td>
  <td>Local Trucking Without Storage (other waste collection without disposal)</td>

 </tr>
 <tr>
  <td>4212</td>
  <td>Local Trucking Without Storage (solid waste collection without disposal)</td>

 </tr>
 <tr>
  <td>4212</td>
  <td>Local Trucking Without Storage (specialized freight)</td>

 </tr>
 <tr>
  <td>2411</td>
  <td>Logging</td>

 </tr>
 <tr>
  <td>2992</td>
  <td>Lubricating Oils and Greases</td>

 </tr>
 <tr>
  <td>3161</td>
  <td>Luggage</td>

 </tr>
 <tr>
  <td>5948</td>
  <td>Luggage and Leather Goods Stores</td>

 </tr>
 <tr>
  <td>5031</td>
  <td>LumberPlywood  Millwork �
   and Wood Panels (agents and brokers)</td>

 </tr>
 <tr>
  <td>5031</td>
  <td>LumberPlywood  Millwork �
   and Wood Panels (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5031</td>
  <td>LumberPlywood  Millwork �
   and Wood Panels (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>5031</td>
  <td>LumberPlywood  Millwork �
   and Wood Panels (sold via retail method)</td>

 </tr>
 <tr>
  <td>5211</td>
  <td>Lumber and Other Building Materials Dealers (except home center stores)</td>

 </tr>
 <tr>
  <td>5211</td>
  <td>Lumber and Other Building Materials Dealers (home center stores)</td>

 </tr>
 <tr>
  <td>2098</td>
  <td>MacaroniSpaghetti  Vermicelli and Noodles</td>

 </tr>
 <tr>
  <td>3541</td>
  <td>Machine ToolsMetal Cutting Types</td>

 </tr>
 <tr>
  <td>3542</td>
  <td>Machine ToolsMetal Forming Type</td>

 </tr>
 <tr>
  <td>3695</td>
  <td>Magnetic and Optical Recording Media</td>

 </tr>
 <tr>
  <td>3322</td>
  <td>Malleable Iron Foundries</td>

 </tr>
 <tr>
  <td>2083</td>
  <td>Malt</td>

 </tr>
 <tr>
  <td>2082</td>
  <td>Malt Beverages (except malt extract)</td>

 </tr>
 <tr>
  <td>2082</td>
  <td>Malt Beverages (malt extract)</td>

 </tr>
 <tr>
  <td>8742</td>
  <td>Management Consulting Services (administrative management and general
  management consulting)</td>

 </tr>
 <tr>
  <td>8742</td>
  <td>Management Consulting Services (human resources and personnel management
  consulting)</td>

 </tr>
 <tr>
  <td>8742</td>
  <td>Management Consulting Services (manufacturing management  physical distribution  and site location consulting)</td>

 </tr>
 <tr>
  <td>8742</td>
  <td>Management Consulting Services (marketing consulting)</td>

 </tr>
 <tr>
  <td>6722</td>
  <td>Management Investment
  OfficesOpen-End </td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (commercial and institutional building construction
  management)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management
  Services (construction management for other heavy and civil engineering
  construction) </td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (construction management of oil and gas pipelines and
  related structureconstruction
  projects)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (construction management of power generation [except
  hydroelectric] facilitiesand
  transmission and distribution station construction projects)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (construction management of water  sewer �
   and related structure construction projects)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (except construction management)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (highway �
   streetand bridge construction
  management)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (industrial building and nonbuilding structure
  construction management)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (multifamily housing construction management)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (residential remodeling construction management)</td>

 </tr>
 <tr>
  <td>8741</td>
  <td>Management Services (single-family housing construction management)</td>

 </tr>
 <tr>
  <td>2761</td>
  <td>Manifold Business Forms</td>

 </tr>
 <tr>
  <td>2824</td>
  <td>Manmade Organic FibersExcept
  Cellulosic</td>

 </tr>
 <tr>
  <td>2097</td>
  <td>Manufactured Ice</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (beauty and barber chairs)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (beauty and barber shop equipment �
   except chairs)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (burnt wood articles)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (electric hair clippers for humans)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (embroidery kits)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (flocking metal products for the trade)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC (fur
  dressing and finishing)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (hand operated hair clippers for humans)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (lamp shades of paper or textile)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (matches)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (other miscellaneous metal products �
   such as combshair
  curlersetc.)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (other miscellaneous products not specially provided for previously)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (plastics products such as combshair
  curlersetc.)</td>

 </tr>
 <tr>
  <td>3999</td>
  <td>Manufacturing Industries NEC
  (tape measures)</td>

 </tr>
 <tr>
  <td>4493</td>
  <td>Marinas</td>

 </tr>
 <tr>
  <td>4491</td>
  <td>Marine Cargo Handling (all but dock and pier operations)</td>

 </tr>
 <tr>
  <td>4491</td>
  <td>Marine Cargo Handling (dock and pier operations)</td>

 </tr>
 <tr>
  <td>3953</td>
  <td>Marking Devices</td>

 </tr>
 <tr>
  <td>1741</td>
  <td>MasonryStone Setting  and Other Stone Work</td>

 </tr>
 <tr>
  <td>2515</td>
  <td>MattressesFoundations  and Convertible Beds (convertible beds)</td>

 </tr>
 <tr>
  <td>2515</td>
  <td>MattressesFoundations  and Convertible Beds (mattresses and
  foundations)</td>

 </tr>
 <tr>
  <td>3829</td>
  <td>Measuring and Controlling Devices � NEC (electronic chronometers)</td>

 </tr>
 <tr>
  <td>3829</td>
  <td>Measuring and Controlling Devices � NEC (except medical thermometers �
   electronic chronometers and motor vehicle gauges)</td>

 </tr>
 <tr>
  <td>3829</td>
  <td>Measuring and Controlling Devices � NEC (medical thermometers)</td>

 </tr>
 <tr>
  <td>3829</td>
  <td>Measuring and Controlling Devices � NEC (motor vehicle gauges)</td>

 </tr>
 <tr>
  <td>3586</td>
  <td>Measuring and Dispensing Pumps</td>

 </tr>
 <tr>
  <td>5421</td>
  <td>Meat and Fish (Seafood) Markets �
   Including Freezer Provisioners (freezer provisioners)</td>

 </tr>
 <tr>
  <td>5421</td>
  <td>Meat and Fish (Seafood) Markets �
   Including Freezer Provisioners (meat except freezer provisioners)</td>

 </tr>
 <tr>
  <td>5421</td>
  <td>Meat and Fish (Seafood) Markets �
   Including Freezer Provisioners (seafood)</td>

 </tr>
 <tr>
  <td>5147</td>
  <td>Meat and Meat Products (meat and meat products sold via retail method)</td>

 </tr>
 <tr>
  <td>2011</td>
  <td>Meat Packing Plants</td>

 </tr>
 <tr>
  <td>5147</td>
  <td>Meats and Meat Products (agents and brokers)</td>

 </tr>
 <tr>
  <td>5147</td>
  <td>Meats and Meat Products (boxed beef)</td>

 </tr>
 <tr>
  <td>5147</td>
  <td>Meats and Meat Products (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5147</td>
  <td>Meats and Meat Products (merchant wholesalers except boxed beef
  manufacturers and merchant wholesalers selling meats and meat products via
  retail method)</td>

 </tr>
 <tr>
  <td>3568</td>
  <td>Mechanical Power Transmission Equipment � NEC</td>

 </tr>
 <tr>
  <td>5047</td>
  <td>MedicalDental  and Hospital Equipment and Supplies
  (medicaldental  and hospital equipment and supplies sold
  via retail method)</td>

 </tr>
 <tr>
  <td>5047</td>
  <td>MedicalDental and Hospital
  Equipment and Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5047</td>
  <td>MedicalDental and Hospital
  Equipment and Supplies (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5047</td>
  <td>MedicalDental and Hospital
  Equipment and Supplies (merchant wholesalers except those selling
  medicaldental  and hospital equipment and supplies via
  retail method)</td>

 </tr>
 <tr>
  <td>7352</td>
  <td>Medical Equipment Rental and Leasing (home health furniture and equipment
  rental and leasing)</td>

 </tr>
 <tr>
  <td>7352</td>
  <td>Medical Equipment Rental and Leasing (medical machinery and
  equipmentexcept home health
  furniture and equipmentrental and
  leasing)</td>

 </tr>
 <tr>
  <td>8071</td>
  <td>Medical Laboratories (diagnostic imaging centers)</td>

 </tr>
 <tr>
  <td>8071</td>
  <td>Medical Laboratories (except diagnostic imaging centers)</td>

 </tr>
 <tr>
  <td>2833</td>
  <td>Medicinal Chemicals and Botanical Products</td>

 </tr>
 <tr>
  <td>8699</td>
  <td>Membership Organizations NEC
  (athletic associations)</td>

 </tr>
 <tr>
  <td>8699</td>
  <td>Membership Organizations NEC
  (except humane societiesfarm
  business organizationsathletic
  associationsand travel motor clubs)</td>

 </tr>
 <tr>
  <td>8699</td>
  <td>Membership Organizations NEC
  (farm business organizations)</td>

 </tr>
 <tr>
  <td>8699</td>
  <td>Membership Organizations NEC
  (humane societies)</td>

 </tr>
 <tr>
  <td>8699</td>
  <td>Membership Organizations NEC
  (travel motor clubs)</td>

 </tr>
 <tr>
  <td>7997</td>
  <td>Membership Sports and Recreation Clubs (flying clubs primarily providing
  a variety of flying services to the public using general purpose aircraft)</td>

 </tr>
 <tr>
  <td>7997</td>
  <td>Membership Sports and Recreation Clubs (flying fields operated by
  aviation clubs)</td>

 </tr>
 <tr>
  <td>7997</td>
  <td>Membership Sports and Recreation Clubs (golf clubs)</td>

 </tr>
 <tr>
  <td>7997</td>
  <td>Membership Sports and Recreation Clubs (recreation clubs with facilities)</td>

 </tr>
 <tr>
  <td>7997</td>
  <td>Membership Sports and Recreation Clubs (recreation clubs without
  facilities)</td>

 </tr>
 <tr>
  <td>2329</td>
  <td>Men's and Boys' Clothing NEC
  (contractors)</td>

 </tr>
 <tr>
  <td>2329</td>
  <td>Men's and Boys' Clothing NEC
  (except team athletic uniforms and contractors)</td>

 </tr>
 <tr>
  <td>2329</td>
  <td>Men's and Boys' Clothing NEC
  (team athletic uniforms except contractors)</td>

 </tr>
 <tr>
  <td>5611</td>
  <td>Men's and Boys' Clothing and Accessory Stores (accessories)</td>

 </tr>
 <tr>
  <td>5136</td>
  <td>Men's and Boys' Clothing and Furnishings (agents and brokers)</td>

 </tr>
 <tr>
  <td>5136</td>
  <td>Men's and Boys' Clothing and Furnishings (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5136</td>
  <td>Men's and Boys' Clothing and Furnishings (merchant wholesalers except
  wholesaling athletic uniforms and uniforms and merchant wholesalers selling
  work clothing via retail method)</td>

 </tr>
 <tr>
  <td>2323</td>
  <td>Men's and Boys'  NECkwear (except contractors)</td>

 </tr>
 <tr>
  <td>2325</td>
  <td>Men's and Boys' Separate Trousers and Slacks (contractors)</td>

 </tr>
 <tr>
  <td>2325</td>
  <td>Men's and Boys' Separate Trousers and Slacks (except  contractors)</td>

 </tr>
 <tr>
  <td>2321</td>
  <td>Men's and Boys' ShirtsExcept
  Work Shirts (contractors)</td>

 </tr>
 <tr>
  <td>2321</td>
  <td>Men's and Boys' ShirtsExcept
  Work Shirts (except contractors)</td>

 </tr>
 <tr>
  <td>2311</td>
  <td>Men's and Boys' SuitsCoats  and Overcoats (contractors)</td>

 </tr>
 <tr>
  <td>2311</td>
  <td>Men's and Boys' SuitsCoats  and Overcoats (except contractors)</td>

 </tr>
 <tr>
  <td>2322</td>
  <td>Men's and Boys' Underwear and Nightwear (contractors)</td>

 </tr>
 <tr>
  <td>2322</td>
  <td>Men's and Boys' Underwear and Nightwear (except contractors)</td>

 </tr>
 <tr>
  <td>2326</td>
  <td>Men's and Boys' Work Clothing (contractors)</td>

 </tr>
 <tr>
  <td>2326</td>
  <td>Men's and Boys' Work Clothing (except contractors)</td>

 </tr>
 <tr>
  <td>3143</td>
  <td>Men's FootwearExcept Athletic</td>

 </tr>
 <tr>
  <td>5611</td>
  <td>Men's and Boys' Clothing and Accessory Stores (clothing stores)</td>

 </tr>
 <tr>
  <td>5136</td>
  <td>Men's and Boys' Clothing and Furnishings (men's and boys' apparel  except uniforms and work clothing  sold via retail method)</td>

 </tr>
 <tr>
  <td>5136</td>
  <td>Men's and Boys' Clothing and Furnishings (merchant wholesalers of
  athletic uniforms)</td>

 </tr>
 <tr>
  <td>5136</td>
  <td>Men's and Boys' Clothing and Furnishings (uniforms and work clothing sold
  via retail method)</td>

 </tr>
 <tr>
  <td>2323</td>
  <td>Men's and Boys'  NECkwear (contractors)</td>

 </tr>
 <tr>
  <td>3411</td>
  <td>Metal Cans</td>

 </tr>
 <tr>
  <td>3442</td>
  <td>Metal DoorsSash  Frames �
   Moldingand Trim</td>

 </tr>
 <tr>
  <td>3497</td>
  <td>Metal Foil and Leaf (foil and foil containers)</td>

 </tr>
 <tr>
  <td>3497</td>
  <td>Metal Foil and Leaf (laminated aluminum foil rolls and sheets for
  flexible packaging uses)</td>

 </tr>
 <tr>
  <td>3398</td>
  <td>Metal Heat Treating</td>

 </tr>
 <tr>
  <td>2514</td>
  <td>Metal Household Furniture (except upholstered metal furniture and metal
  box spring frames)</td>

 </tr>
 <tr>
  <td>2514</td>
  <td>Metal Household Furniture (metal box spring frames)</td>

 </tr>
 <tr>
  <td>2514</td>
  <td>Metal Household Furniture (upholstered)</td>

 </tr>
 <tr>
  <td>1081</td>
  <td>Metal Mining Services (except site preparation and related activities
  performed on a contract or fee basis and geophysical surveying and mapping)</td>

 </tr>
 <tr>
  <td>1081</td>
  <td>Metal Mining Services (geophysical surveying and mapping)</td>

 </tr>
 <tr>
  <td>1081</td>
  <td>Metal Mining Services (site preparation and related construction
  activities on a contract basis)</td>

 </tr>
 <tr>
  <td>3412</td>
  <td>Metal Shipping BarrelsDrums  Kegs �
   and Pails</td>

 </tr>
 <tr>
  <td>3469</td>
  <td>Metal Stampings NEC (except
  kitchen utensilspots and pans for
  cookingcoins  and stamped metal boxes)</td>

 </tr>
 <tr>
  <td>3469</td>
  <td>Metal Stampings NEC (kitchen
  utensilspots  and pans for cooking)</td>

 </tr>
 <tr>
  <td>3469</td>
  <td>Metal Stampings NEC (stamped
  metal toolcash  mail �
   and lunch boxes)</td>

 </tr>
 <tr>
  <td>5051</td>
  <td>Metals
  Service Centers and Offices (agents and brokers) </td>

 </tr>
 <tr>
  <td>5051</td>
  <td>Metals
  Service Centers and Offices (business to business electronic markets) </td>

 </tr>
 <tr>
  <td>5051</td>
  <td>Metals
  Service Centers and Offices (merchant wholesalers) </td>

 </tr>
 <tr>
  <td>3549</td>
  <td>Metalworking Machinery NEC</td>

 </tr>
 <tr>
  <td>2431</td>
  <td>Millwork (except wood doors and windows)</td>

 </tr>
 <tr>
  <td>2431</td>
  <td>Millwork (wood windows and doors)</td>

 </tr>
 <tr>
  <td>3296</td>
  <td>Mineral Wool</td>

 </tr>
 <tr>
  <td>3295</td>
  <td>Minerals and EarthsGround or
  Otherwise Treated (except grinding �
   washingseparating  etc. of nonmetallic minerals)</td>

 </tr>
 <tr>
  <td>3295</td>
  <td>Minerals and EarthsGround or
  Otherwise Treated (grinding �
   washingseparating  etc. of chemical and fertilizer
  minerals NEC)</td>

 </tr>
 <tr>
  <td>3295</td>
  <td>Minerals and EarthsGround or
  Otherwise Treated (grinding �
   washingseparating  etc. of clay   ceramicand refractory
  minerals  NEC)</td>

 </tr>
 <tr>
  <td>3295</td>
  <td>Minerals and EarthsGround or
  Otherwise Treated (grinding �
   washingseparating  etc. of kaolin and ball clay)</td>

 </tr>
 <tr>
  <td>3295</td>
  <td>Minerals and EarthsGround or
  Otherwise Treated (grinding �
   washingseparating  etc. of nonmetallic minerals   NEC)</td>

 </tr>
 <tr>
  <td>3532</td>
  <td>Mining Machinery and Equipment �
   Except Oil and Gas Field Machinery and Equipment</td>

 </tr>
 <tr>
  <td>5699</td>
  <td>Miscellaneous Apparel and Accessory Stores (accessories)</td>

 </tr>
 <tr>
  <td>5699</td>
  <td>Miscellaneous Apparel and Accessory Stores (custom dressmakers)</td>

 </tr>
 <tr>
  <td>5699</td>
  <td>Miscellaneous Apparel and Accessory Stores (custom tailors)</td>

 </tr>
 <tr>
  <td>5699</td>
  <td>Miscellaneous Apparel and Accessory Stores (custom tailors)</td>

 </tr>
 <tr>
  <td>5699</td>
  <td>Miscellaneous Apparel and Accessory Stores (miscellaneous apparel except
  accessories and custom tailors)</td>

 </tr>
 <tr>
  <td>6159</td>
  <td>Miscellaneous Business Credit Institutions (except trade banks  farm mortgage companies  secondary market financing  and finance leasing combined with sales
  financing)</td>

 </tr>
 <tr>
  <td>6159</td>
  <td>Miscellaneous Business Credit Institutions (farm mortgage companies)</td>

 </tr>
 <tr>
  <td>6159</td>
  <td>Miscellaneous Business Credit Institutions (finance leasing combined with
  sales financing)</td>

 </tr>
 <tr>
  <td>6159</td>
  <td>Miscellaneous Business Credit Institutions (secondary market financing)</td>

 </tr>
 <tr>
  <td>6159</td>
  <td>Miscellaneous Business Credit Institutions (trade banks)</td>

 </tr>
 <tr>
  <td>7389</td>
  <td>Miscellaneous Business Services (bail bonding)</td>

 </tr>
 <tr>
  <td>3496</td>
  <td>Miscellaneous Fabricated Wire Products (except shopping carts and potato
  mashers)</td>

 </tr>
 <tr>
  <td>3496</td>
  <td>Miscellaneous Fabricated Wire Products (potato mashers)</td>

 </tr>
 <tr>
  <td>3496</td>
  <td>Miscellaneous Fabricated Wire Products (shopping carts made from
  purchased wire)</td>

 </tr>
 <tr>
  <td>5499</td>
  <td>Miscellaneous Food Stores (except food supplement stores and  poultry stores)</td>

 </tr>
 <tr>
  <td>5499</td>
  <td>Miscellaneous Food Stores (food supplements)</td>

 </tr>
 <tr>
  <td>5499</td>
  <td>Miscellaneous Food Stores (poultry and poultry products)</td>

 </tr>
 <tr>
  <td>5399</td>
  <td>Miscellaneous General Merchandise Stores (except warehouse club and
  supermarket/general merchandise combination)</td>

 </tr>
 <tr>
  <td>5399</td>
  <td>Miscellaneous General Merchandise Stores (warehouse clubs and
  supermarket/general merchandise combination)</td>

 </tr>
 <tr>
  <td>5719</td>
  <td>Miscellaneous Homefurnishings Stores (blinds and shades)</td>

 </tr>
 <tr>
  <td>5719</td>
  <td>Miscellaneous
  Homefurnishings Stores (except pottery and crafts made and sold on site
  andwindow furnishings) </td>

 </tr>
 <tr>
  <td>5719</td>
  <td>Miscellaneous Homefurnishings Stores (manufacturing and selling pottery
  on site)</td>

 </tr>
 <tr>
  <td>919</td>
  <td>Miscellaneous Marine Products (catching sea urchins)</td>

 </tr>
 <tr>
  <td>919</td>
  <td>Miscellaneous Marine Products (cultured pearl production)</td>

 </tr>
 <tr>
  <td>919</td>
  <td>Miscellaneous Marine Products (except plant aquaculture  cultured pearl production  and catching sea urchins)</td>

 </tr>
 <tr>
  <td>919</td>
  <td>Miscellaneous Marine Products (plant aquaculture)</td>

 </tr>
 <tr>
  <td>1099</td>
  <td>Miscellaneous Metal Ores NEC</td>

 </tr>
 <tr>
  <td>1499</td>
  <td>Miscellaneous Nonmetallic Minerals �
   Except Fuels (bituminous limestone and bituminous sandstone)</td>

 </tr>
 <tr>
  <td>1499</td>
  <td>Miscellaneous Nonmetallic Minerals �
   Except Fuels (except bituminous limestone and bituminous sandstone)</td>

 </tr>
 <tr>
  <td>7299</td>
  <td>Miscellaneous Personal Services � NEC (babysitting bureaus)</td>

 </tr>
 <tr>
  <td>7299</td>
  <td>Miscellaneous Personal Services � NEC (consumer bartering services)</td>

 </tr>
 <tr>
  <td>7299</td>
  <td>Miscellaneous Personal Services � NEC (consumer credit and debt counseling services)</td>

 </tr>
 <tr>
  <td>7299</td>
  <td>Miscellaneous Personal Services � NEC (diet and weight reducing services)</td>

 </tr>
 <tr>
  <td>7299</td>
  <td>Miscellaneous Personal Services   NEC (except diet and weight reducing
  servicespersonal care services  valet parking services  babysitting bureaus  debt and credit counseling  consumer bartering services  and formal wear and costume rental)</td>

 </tr>
 <tr>
  <td>7299</td>
  <td>Miscellaneous Personal Services � NEC (formal wear and costume rental)</td>

 </tr>
 <tr>
  <td>7299</td>
  <td>Miscellaneous Personal Services � NEC (personal care services)</td>

 </tr>
 <tr>
  <td>7299</td>
  <td>Miscellaneous Personal Services � NEC (valet parking services)</td>

 </tr>
 <tr>
  <td>2741</td>
  <td>Miscellaneous Publishing (directory publishers   except Internet publishers)</td>

 </tr>
 <tr>
  <td>2741</td>
  <td>Miscellaneous Publishing (except database   advertising periodicals �
   shopping newstechnical
  manuals and booksand sheet music
  publishing or publishing and printing and Internet versions of these
  activities)</td>

 </tr>
 <tr>
  <td>2741</td>
  <td>Miscellaneous Publishing (miscellaneous Internet publishing)</td>

 </tr>
 <tr>
  <td>2741</td>
  <td>Miscellaneous Publishing (sheet music publishing or publishing and
  printing)</td>

 </tr>
 <tr>
  <td>2741</td>
  <td>Miscellaneous Publishing (shopping news and advertising periodical
  publishing or publishing and printing except Internet)</td>

 </tr>
 <tr>
  <td>2741</td>
  <td>Miscellaneous Publishing (technical manuals and books publishing or
  publishing and printingexcept
  Internet)</td>

 </tr>
 <tr>
  <td>5999</td>
  <td>Miscellaneous Retail Stores � NEC(art dealer)</td>

 </tr>
 <tr>
  <td>5999</td>
  <td>Miscellaneous Retail Stores   NEC �
   (except art dealerspet and
  pet supplieshearing aids  artificial limbs   cosmetics �
   telephonessunglasses  manufacture of orthopedic devices to
  prescription in a retail environment �
   and typewriters)</td>

 </tr>
 <tr>
  <td>5999</td>
  <td>Miscellaneous Retail Stores NEC
  (cosmetics and perfumes)</td>

 </tr>
 <tr>
  <td>5999</td>
  <td>Miscellaneous Retail Stores NEC
  (hearing aids and artificial limbs)</td>

 </tr>
 <tr>
  <td>5999</td>
  <td>Miscellaneous Retail Stores NEC
  (manufacture of orthopedic devices to prescription in a retail environment)</td>

 </tr>
 <tr>
  <td>5999</td>
  <td>Miscellaneous Retail Stores NEC
  (pet and pet supplies)</td>

 </tr>
 <tr>
  <td>5999</td>
  <td>Miscellaneous Retail Stores NEC
  (typewriters and telephones)</td>

 </tr>
 <tr>
  <td>3449</td>
  <td>Miscellaneous Structural Metal Work (curtain wall and metal plaster bases
  and lath)</td>

 </tr>
 <tr>
  <td>3449</td>
  <td>Miscellaneous Structural Metal Work (custom roll forming)</td>

 </tr>
 <tr>
  <td>3449</td>
  <td>Miscellaneous Structural Metal Work (fabricated bar joists and concrete
  reinforcing bars)</td>

 </tr>
 <tr>
  <td>4925</td>
  <td>MixedManufactured  or Liquefied Petroleum Gas Production
  and/or Distribution</td>

 </tr>
 <tr>
  <td>5271</td>
  <td>Mobile Home Dealers</td>

 </tr>
 <tr>
  <td>2451</td>
  <td>Mobile Homes</td>

 </tr>
 <tr>
  <td>3061</td>
  <td>MoldedExtruded  and Lathe-Cut Mechanical Rubber Goods</td>

 </tr>
 <tr>
  <td>6162</td>
  <td>Mortgage Bankers and Loan Correspondents (mortgage  servicing)</td>

 </tr>
 <tr>
  <td>6162</td>
  <td>Mortgage Bankers and Loan Correspondents (mortgage bankers and
  originators)</td>

 </tr>
 <tr>
  <td>7822</td>
  <td>Motion Picture and Video Tape Distribution (except video tape and
  cassette wholesalers)</td>

 </tr>
 <tr>
  <td>7822</td>
  <td>Motion Picture and Video Tape Distribution (prerecorded video tape and
  cassette wholesalers)</td>

 </tr>
 <tr>
  <td>7812</td>
  <td>Motion Picture and Video Tape Production</td>

 </tr>
 <tr>
  <td>7832</td>
  <td>Motion Picture TheatersExcept
  Drive-In</td>

 </tr>
 <tr>
  <td>3716</td>
  <td>Motor Homes</td>

 </tr>
 <tr>
  <td>5511</td>
  <td>Motor Vehicle Dealers (New and Used)</td>

 </tr>
 <tr>
  <td>5521</td>
  <td>Motor Vehicle Dealers (Used Only)</td>

 </tr>
 <tr>
  <td>5015</td>
  <td>Motor Vehicle PartsUsed (agents
  and brokers)</td>

 </tr>
 <tr>
  <td>5015</td>
  <td>Motor Vehicle PartsUsed
  (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5015</td>
  <td>Motor Vehicle PartsUsed
  (merchant wholesalers except those selling via retail method)</td>

 </tr>
 <tr>
  <td>5015</td>
  <td>Motor Vehicle PartsUsed (used
  auto parts sold via the retail method)</td>

 </tr>
 <tr>
  <td>3714</td>
  <td>Motor Vehicle Parts and Accessories (brake and brake systems  including assemblies)</td>

 </tr>
 <tr>
  <td>3714</td>
  <td>Motor Vehicle Parts and Accessories (dump truck lifting mechanisms and
  fifth wheels)</td>

 </tr>
 <tr>
  <td>3714</td>
  <td>Motor
  Vehicle Parts and Accessories (except truck and bus bodies  trailers �
   engine and engine partsmotor
  vehicle electrical and electronic equipment �
   motor vehicle steering and suspension components  motor vehicle brake systems  and motor vehicle transmission and power
  train parts) </td>
 </tr>

 <tr>
  <td>3714</td>
  <td>Motor Vehicle Parts and Accessories (gasoline engines and engine parts
  including rebuilt)</td>

 </tr>
 <tr>
  <td>3714</td>
  <td>Motor Vehicle Parts and Accessories (steering and suspension parts)</td>

 </tr>
 <tr>
  <td>3714</td>
  <td>Motor Vehicle Parts and Accessories (transmissions and power train
  partsincluding rebuilding)</td>

 </tr>
 <tr>
  <td>3714</td>
  <td>Motor Vehicle Parts and Accessories (wiring harness sets  other than ignition</td>

 </tr>
 <tr>
  <td>5013</td>
  <td>Motor Vehicle Supplies and New Parts (agents and brokers)</td>

 </tr>
 <tr>
  <td>5013</td>
  <td>Motor Vehicle Supplies and New Parts (auto parts sold via retail method)</td>

 </tr>
 <tr>
  <td>5013</td>
  <td>Motor Vehicle Supplies and New Parts (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5013</td>
  <td>Motor
  Vehicle Supplies and New Parts (merchant wholesalers except those selling via
  retail method) </td>

 </tr>
 <tr>
  <td>3711</td>
  <td>Motor Vehicles and Passenger Car Bodies (automobiles)</td>

 </tr>
 <tr>
  <td>3711</td>
  <td>Motor Vehicles and Passenger Car Bodies (heavy duty trucks)</td>

 </tr>
 <tr>
  <td>3711</td>
  <td>Motor Vehicles and Passenger Car Bodies (kit car and other passenger car
  bodies)</td>

 </tr>
 <tr>
  <td>3711</td>
  <td>Motor Vehicles and Passenger Car Bodies (light trucks and utility
  vehicles)</td>

 </tr>
 <tr>
  <td>3711</td>
  <td>Motor Vehicles and Passenger Car Bodies (military armored vehicles)</td>

 </tr>
 <tr>
  <td>5571</td>
  <td>Motorcycle Dealers</td>

 </tr>
 <tr>
  <td>3751</td>
  <td>MotorcyclesBicycles  and Parts</td>

 </tr>
 <tr>
  <td>3621</td>
  <td>Motors and Generators</td>

 </tr>
 <tr>
  <td>8412</td>
  <td>Museums and Art Galleries (except historic and heritage sites)</td>

 </tr>
 <tr>
  <td>8412</td>
  <td>Museums and Art Galleries (historic and heritage sites)</td>

 </tr>
 <tr>
  <td>3931</td>
  <td>Musical Instruments</td>

 </tr>
 <tr>
  <td>5736</td>
  <td>Musical Instruments Stores</td>

 </tr>
 <tr>
  <td>2441</td>
  <td>Nailed and Lock Corner Wood Boxes and Shook</td>

 </tr>
 <tr>
  <td>2241</td>
  <td>Narrow Fabric and Other Smallware Mills: Cotton   WoolSilk and Manmade
  Fiber</td>

 </tr>
 <tr>
  <td>6021</td>
  <td>National Commercial Banks (banking)</td>

 </tr>
 <tr>
  <td>6021</td>
  <td>National Commercial Banks (credit card issuing)</td>

 </tr>
 <tr>
  <td>9711</td>
  <td>National Security</td>

 </tr>
 <tr>
  <td>2022</td>
  <td>NaturalProcessed  and Imitation Cheese</td>

 </tr>
 <tr>
  <td>4924</td>
  <td>Natural Gas Distribution</td>

 </tr>
 <tr>
  <td>1321</td>
  <td>Natural Gas Liquids</td>

 </tr>
 <tr>
  <td>4922</td>
  <td>Natural Gas Transmission</td>

 </tr>
 <tr>
  <td>4923</td>
  <td>Natural Gas Transmission and Distribution (distribution)</td>

 </tr>
 <tr>
  <td>4923</td>
  <td>Natural Gas Transmission and Distribution (transmission)</td>

 </tr>
 <tr>
  <td>5994</td>
  <td>News Dealers and Newsstands </td>

 </tr>
 <tr>
  <td>7383</td>
  <td>News Syndicates (except independent news correspondents)</td>

 </tr>
 <tr>
  <td>7383</td>
  <td>News Syndicates (independent news correspondents)</td>

 </tr>
 <tr>
  <td>2711</td>
  <td>Newspapers: Publishingor
  Publishing and Printing (except Internet newspaper publishing)</td>

 </tr>
 <tr>
  <td>2711</td>
  <td>Newspapers: Publishingor
  Publishing and Printing (Internet newspaper publishing)</td>

 </tr>
 <tr>
  <td>2873</td>
  <td>Nitrogenous Fertilizers</td>

 </tr>
 <tr>
  <td>3297</td>
  <td>Nonclay Refractories</td>

 </tr>
 <tr>
  <td>8733</td>
  <td>Noncommercial Research Organizations (physical   engineeringand life
  sciences)</td>

 </tr>
 <tr>
  <td>8733</td>
  <td>Noncommercial Research Organizations (social sciences and humanities)</td>

 </tr>
 <tr>
  <td>3644</td>
  <td>Noncurrent-Carrying Wiring Devices (except fishwire  electrical wiring tool)</td>

 </tr>
 <tr>
  <td>3644</td>
  <td>Noncurrent-Carrying Wiring Devices (fish wire   electrical wiring tool)</td>

 </tr>
 <tr>
  <td>6091</td>
  <td>Nondeposit Trust Facilities </td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (advertising
  specialties goods distributors)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (agents and
  brokers)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (business to
  business electronic markets)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (curios  statuary �
   giftsnovelties  and souvenirs sold via retail method)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods   NEC (merchant wholesalers except
  advertising specialties goods distributors �
   wholesaling footwear cutstock �
   wholesaling plastics foam �
   wholesaling industrial yarns and merchant wholesalers selling
  miscellaneous nondurable goods via the retail method)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (merchant
  wholesalers of footwear cutstock)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (merchant
  wholesalers of plastics foam)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (merchant
  wholesalers of yarnsexcept
  industrial)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (pets  pet supplies and tropical fish sold via
  retail method)</td>

 </tr>
 <tr>
  <td>5199</td>
  <td>Nondurable Goods NEC (smokers'
  supplies sold via retail method)</td>

 </tr>
 <tr>
  <td>3364</td>
  <td>Nonferrous Die-CastingsExcept
  Aluminum</td>

 </tr>
 <tr>
  <td>3463</td>
  <td>Nonferrous Forgings</td>

 </tr>
 <tr>
  <td>3369</td>
  <td>Nonferrous FoundriesExcept
  Aluminum and Copper</td>

 </tr>
 <tr>
  <td>3299</td>
  <td>Nonmetallic Mineral Products NEC
  (clay statuary)</td>

 </tr>
 <tr>
  <td>3299</td>
  <td>Nonmetallic Mineral Products NEC
  (except moldingsornamental and
  architectural plaster workclay
  statuaryand gypsum statuary)</td>

 </tr>
 <tr>
  <td>3299</td>
  <td>Nonmetallic Mineral Products NEC
  (moldingsornamental and
  architectural plaster workand gypsum
  statuary )</td>

 </tr>
 <tr>
  <td>1481</td>
  <td>Nonmetallic Minerals Services �
   Except Fuels (except geophysical surveying and mapping and site
  preparation and related construction activities performed on a contract or
  fee basis)</td>

 </tr>
 <tr>
  <td>1481</td>
  <td>Nonmetallic Minerals Services �
   Except Fuels (geophysical surveying and mapping)</td>

 </tr>
 <tr>
  <td>1481</td>
  <td>Nonmetallic Minerals Services �
   Except Fuels (site preparation and related construction activities on
  a contract basis)</td>

 </tr>
 <tr>
  <td>2297</td>
  <td>Nonwoven Fabrics</td>

 </tr>
 <tr>
  <td>8059</td>
  <td>Nursing and Personal Care Facilities � NEC (continuing care retirement communities)</td>

 </tr>
 <tr>
  <td>8059</td>
  <td>Nursing and Personal Care Facilities � NEC (except continuing care retirement communities  psychiatric convalescent homes with health
  careand homes for the mentally
  retarded with health care)</td>

 </tr>
 <tr>
  <td>8059</td>
  <td>Nursing and Personal Care Facilities � NEC (homes for the mentally retarded with health care)</td>

 </tr>
 <tr>
  <td>2542</td>
  <td>Office and Store Fixtures �
   PartitionsShelving  and Lockers   Except Wood (except lunchroom tables and chairs)</td>

 </tr>
 <tr>
  <td>2542</td>
  <td>Office and Store Fixtures �
   PartitionsShelving  and Lockers   Except Wood (lunchroom tables and chairs)</td>

 </tr>
 <tr>
  <td>5044</td>
  <td>Office Equipment (agents and brokers)</td>

 </tr>
 <tr>
  <td>5044</td>
  <td>Office Equipment (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5044</td>
  <td>Office Equipment (merchant wholesalers except those selling office
  equipment via retail method)</td>

 </tr>
 <tr>
  <td>5044</td>
  <td>Office Equipment (office equipment sold via retail method)</td>

 </tr>
 <tr>
  <td>2522</td>
  <td>Office FurnitureExcept Wood</td>

 </tr>
 <tr>
  <td>3579</td>
  <td>Office Machines NEC (except
  timeclockstime stamps  pencil sharpeners  stapling machines  etc.)</td>

 </tr>
 <tr>
  <td>3579</td>
  <td>Office Machines NEC (pencil
  sharpenersstaplers and other office
  equipment)</td>

 </tr>
 <tr>
  <td>3579</td>
  <td>Office Machines NEC (time clocks
  and other time recording devices)</td>

 </tr>
 <tr>
  <td>8041</td>
  <td>Offices and Clinics of Chiropractors</td>

 </tr>
 <tr>
  <td>8021</td>
  <td>Offices and Clinics of Dentists</td>

 </tr>
 <tr>
  <td>8011</td>
  <td>Offices and Clinics of Doctors of Medicine (ambulatory surgical and
  emergency centers)</td>

 </tr>
 <tr>
  <td>8011</td>
  <td>Offices and Clinics of Doctors of Medicine (except mental health
  specialistsHMO medical centers  and ambulatory surgical and emergency
  centers)</td>

 </tr>
 <tr>
  <td>8011</td>
  <td>Offices and Clinics of Doctors of Medicine (HMO Medical Centers)</td>

 </tr>
 <tr>
  <td>8011</td>
  <td>Offices and Clinics of Doctors of Medicine (mental health specialists)</td>

 </tr>
 <tr>
  <td>8031</td>
  <td>Offices
  and Clinics of Doctors of Osteopathy (except mental health specialists) </td>

 </tr>
 <tr>
  <td>8031</td>
  <td>Offices and Clinics of Doctors of Osteopathy (mental health specialists)</td>

 </tr>
 <tr>
  <td>8049</td>
  <td>Offices and Clinics of Health Practitioners    NEC (except mental health practitioners  physical �
   occupationalspeech
  therapistsand audiologists)</td>

 </tr>
 <tr>
  <td>8049</td>
  <td>Offices and Clinics of Health Practitioners    NEC (mental health practitioners except physicians)</td>

 </tr>
 <tr>
  <td>8049</td>
  <td>Offices and Clinics of Health Practitioners    NEC (physical �
   occupationalrecreational and
  speech therapistsand audiologists)</td>

 </tr>
 <tr>
  <td>8042</td>
  <td>Offices and Clinics of Optometrists</td>

 </tr>
 <tr>
  <td>8043</td>
  <td>Offices and Clinics of Podiatrists</td>

 </tr>
 <tr>
  <td>6712</td>
  <td>Offices of Bank Holding Companies</td>

 </tr>
 <tr>
  <td>6719</td>
  <td>Offices of Holding Companies NEC</td>

 </tr>
 <tr>
  <td>1382</td>
  <td>Oil and Gas Field Exploration Services (except geophysical mapping and
  surveying)</td>

 </tr>
 <tr>
  <td>1382</td>
  <td>Oil and Gas Field Exploration Services (geophysical surveying and
  mapping)</td>

 </tr>
 <tr>
  <td>3533</td>
  <td>Oil and Gas Field Machinery and Equipment</td>

 </tr>
 <tr>
  <td>1389</td>
  <td>Oil and Gas Field Services NEC
  (construction of field gathering lines on a contract or fee basis)</td>

 </tr>
 <tr>
  <td>1389</td>
  <td>Oil and Gas Field Services NEC
  (except construction of field gathering lines   site preparation and related construction activities performed
  on a contract or fee basis)</td>

 </tr>
 <tr>
  <td>1389</td>
  <td>Oil and Gas Field Services NEC
  (site preparation and related construction activities on a contract basis)</td>

 </tr>
 <tr>
  <td>6792</td>
  <td>Oil Royalty Traders (investing on own account)</td>

 </tr>
 <tr>
  <td>6792</td>
  <td>Oil Royalty Traders (oil and gas royalty leasing)</td>

 </tr>
 <tr>
  <td>1531</td>
  <td>Operative Builders (grain elevator �
   dry cleaning plantand
  manufacturing and industrial warehouse operative builders)</td>

 </tr>
 <tr>
  <td>1531</td>
  <td>Operative Builders (Operative builders of industrial and manufacturing
  buildings except grain elevatorsdry
  cleaning plantsand manufacturing and
  industrial warehouses)</td>

 </tr>
 <tr>
  <td>1531</td>
  <td>Operative Builders (residential operative builders)</td>

 </tr>
 <tr>
  <td>1531</td>
  <td>Operative Builders (residential operative remodelers)</td>

 </tr>
 <tr>
  <td>6513</td>
  <td>Operators of Apartment Buildings</td>

 </tr>
 <tr>
  <td>6514</td>
  <td>Operators of Dwellings Other Than Apartment Buildings</td>

 </tr>
 <tr>
  <td>6512</td>
  <td>Operators of Nonresidential Buildings (except stadium and arena owners)</td>

 </tr>
 <tr>
  <td>6512</td>
  <td>Operators of Nonresidential Buildings (stadium and arena owners)</td>

 </tr>
 <tr>
  <td>6515</td>
  <td>Operators of Residential Mobile Home Sites</td>

 </tr>
 <tr>
  <td>5048</td>
  <td>Ophthalmic Goods (agents and brokers)</td>

 </tr>
 <tr>
  <td>5048</td>
  <td>Ophthalmic Goods (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>3851</td>
  <td>Ophthalmic Goods (except intraocular lenses)</td>

 </tr>
 <tr>
  <td>3851</td>
  <td>Ophthalmic Goods (intraoccular lenses �
   i.e.surgical implants)</td>

 </tr>
 <tr>
  <td>5048</td>
  <td>Ophthalmic Goods (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>5995</td>
  <td>Optical Goods Stores (exceptlabs
  grinding prescription lenses)</td>

 </tr>
 <tr>
  <td>5995</td>
  <td>Optical Goods Stores (optical laboratories grinding lenses to
  prescription)</td>

 </tr>
 <tr>
  <td>3827</td>
  <td>Optical Instruments and Lenses</td>

 </tr>
 <tr>
  <td>3489</td>
  <td>Ordnance and Accessories NEC</td>

 </tr>
 <tr>
  <td>7041</td>
  <td>Organization Hotels and Lodging Houses �
   on Membership Basis (except hotels)</td>

 </tr>
 <tr>
  <td>7041</td>
  <td>Organization Hotels and Lodging Houses �
   on Membership Basis (hotels)</td>

 </tr>
 <tr>
  <td>181</td>
  <td>Ornamental Floriculture and Nursery Products (floriculture farming)</td>

 </tr>
 <tr>
  <td>181</td>
  <td>Ornamental Floriculture and Nursery Products (nursery farming)</td>

 </tr>
 <tr>
  <td>783</td>
  <td>Ornamental Shrub and Tree Services</td>

 </tr>
 <tr>
  <td>3842</td>
  <td>OrthopedicProsthetic  and Surgical Appliances and Supplies
  (anatomical models)</td>

 </tr>
 <tr>
  <td>3842</td>
  <td>OrthopedicProsthetic  and Surgical Appliances and Supplies
  (electronic hearing aids)</td>

 </tr>
 <tr>
  <td>3842</td>
  <td>OrthopedicProsthetic  and Surgical Appliances and Supplies
  (except electronic hearing aids �
   incontinent padsanatomical
  modelsand bed pads)</td>

 </tr>
 <tr>
  <td>3842</td>
  <td>OrthopedicProsthetic  and Surgical Appliances and Supplies
  (incontinent pads and bed pads)</td>

 </tr>
 <tr>
  <td>7312</td>
  <td>Outdoor Advertising Services</td>

 </tr>
 <tr>
  <td>3536</td>
  <td>Overhead Traveling Cranes �
   Hoistsand Monorail Systems</td>

 </tr>
 <tr>
  <td>5142</td>
  <td>Packaged Frozen Foods (agents and brokers)</td>

 </tr>
 <tr>
  <td>5142</td>
  <td>Packaged Frozen Foods (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5142</td>
  <td>Packaged Frozen Foods (frozen food sold via retail method)</td>

 </tr>
 <tr>
  <td>5142</td>
  <td>Packaged Frozen Foods (merchant wholesalers except those selling packaged
  frozen foods via retail method)</td>

 </tr>
 <tr>
  <td>3565</td>
  <td>Packaging Machinery</td>

 </tr>
 <tr>
  <td>2671</td>
  <td>Packaging Paper and Plastics Film �
   Coated and Laminated (except single-web and multi-web plastics
  packaging film and sheet)</td>

 </tr>
 <tr>
  <td>2671</td>
  <td>Packaging Paper and Plastics Film �
   Coated and Laminated (single-web and multi-web plastics packaging film
  and sheet)</td>

 </tr>
 <tr>
  <td>4783</td>
  <td>Packing and Crating</td>

 </tr>
 <tr>
  <td>5231</td>
  <td>PaintGlass  and Wallpaper Stores (except glass)</td>

 </tr>
 <tr>
  <td>5231</td>
  <td>PaintGlass  and Wallpaper Stores (glass)</td>

 </tr>
 <tr>
  <td>1721</td>
  <td>Painting and Paper Hanging</td>

 </tr>
 <tr>
  <td>1721</td>
  <td>Painting and Paper Hanging (traffic lane painting)</td>

 </tr>
 <tr>
  <td>5198</td>
  <td>PaintsVarnishes  and Supplies   (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5198</td>
  <td>Paints  Varnishes �
   and Supplies (agents and brokers) </td>

 </tr>
 <tr>
  <td>5198</td>
  <td>Paints  Varnishes �
   and Supplies (merchant wholesalers) </td>

 </tr>
 <tr>
  <td>2851</td>
  <td>PaintsVarnishes  Lacquers �
   Enamels and Allied Products</td>

 </tr>
 <tr>
  <td>3554</td>
  <td>Paper Industries Machinery</td>

 </tr>
 <tr>
  <td>2621</td>
  <td>Paper Mills (except newsprint mills)</td>

 </tr>
 <tr>
  <td>2621</td>
  <td>Paper Mills (newsprint mills)</td>

 </tr>
 <tr>
  <td>2631</td>
  <td>Paperboard Mills</td>

 </tr>
 <tr>
  <td>7515</td>
  <td>Passenger Car Leasing</td>

 </tr>
 <tr>
  <td>7514</td>
  <td>Passenger Car Rental</td>

 </tr>
 <tr>
  <td>6794</td>
  <td>Patent Owners and Lessors</td>

 </tr>
 <tr>
  <td>3951</td>
  <td>Pens  Mechanical Pencils  and Parts </td>

 </tr>
 <tr>
  <td>6371</td>
  <td>PensionHealth  and Welfare Funds (administrators)</td>

 </tr>
 <tr>
  <td>6371</td>
  <td>PensionHealth  and Welfare Funds (health and welfare
  funds)</td>

 </tr>
 <tr>
  <td>6371</td>
  <td>PensionHealth  and Welfare Funds (managers)</td>

 </tr>
 <tr>
  <td>6371</td>
  <td>PensionHealth  and Welfare Funds (pension funds)</td>

 </tr>
 <tr>
  <td>6371</td>
  <td>PensionHealth  and Welfare Funds (profit sharing funds)</td>

 </tr>
 <tr>
  <td>2844</td>
  <td>PerfumesCosmetics  and Other Toilet Preparations (except
  toothpastegel  and dentifrice powders)</td>

 </tr>
 <tr>
  <td>2844</td>
  <td>PerfumesCosmetics  and Other Toilet Preparations
  (toothpastegel  and dentifrice powders)</td>

 </tr>
 <tr>
  <td>2721</td>
  <td>Periodicals: Publishingor
  Publishing and Printing (except Internet periodical publishing)</td>

 </tr>
 <tr>
  <td>2721</td>
  <td>Periodicals: Publishingor
  Publishing and Printing (Internet periodical publishing)</td>

 </tr>
 <tr>
  <td>6141</td>
  <td>Personal Credit Institutions (credit card issuing)</td>

 </tr>
 <tr>
  <td>6141</td>
  <td>Personal Credit Institutions (except installment sales finance  industrial nondeposit banks  and credit card issuing)</td>

 </tr>
 <tr>
  <td>6141</td>
  <td>Personal Credit Institutions (industrial nondeposit banks)</td>

 </tr>
 <tr>
  <td>6141</td>
  <td>Personal Credit Institutions (installment sales finance)</td>

 </tr>
 <tr>
  <td>3172</td>
  <td>Personal Leather GoodsExcept
  Women's Handbags and Purses (except nonprecious metal personal goods  such as card cases  cigar cases   and comb cases)</td>

 </tr>
 <tr>
  <td>3172</td>
  <td>Personal Leather GoodsExcept
  Women's Handbags and Purses (nonprecious metal personal goods  such as card cases  cigar cases   and comb cases)</td>

 </tr>
 <tr>
  <td>2879</td>
  <td>Pesticides and Agricultural Chemicals � NEC</td>

 </tr>
 <tr>
  <td>5172</td>
  <td>Petroleum and Petroleum Products Wholesalers   Except Bulk Stations and Terminals (agents and brokers)</td>

 </tr>
 <tr>
  <td>5172</td>
  <td>Petroleum and Petroleum Products Wholesalers   Except Bulk Stations and Terminals (business to business
  electronic markets)</td>

 </tr>
 <tr>
  <td>5172</td>
  <td>Petroleum and Petroleum Products Wholesalers   Except Bulk Stations and Terminals (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>5171</td>
  <td>Petroleum Bulk Stations and Terminals (except petroleum sold via retail
  method)</td>

 </tr>
 <tr>
  <td>5171</td>
  <td>Petroleum Bulk Stations and Terminals (heating oil sold to final
  consumer)</td>

 </tr>
 <tr>
  <td>5171</td>
  <td>Petroleum Bulk Stations and Terminals (LP gas sold to final consumer)</td>

 </tr>
 <tr>
  <td>2911</td>
  <td>Petroleum Refining</td>

 </tr>
 <tr>
  <td>2834</td>
  <td>Pharmaceutical Preparations </td>

 </tr>
 <tr>
  <td>3652</td>
  <td>Phonograph Records and Prerecorded Audio Tapes and Disks (integrated
  record companiesexcept duplication
  only)</td>

 </tr>
 <tr>
  <td>3652</td>
  <td>Phonograph Records and Prerecorded Audio Tapes and Disks (reproduction of
  all other media except video)</td>

 </tr>
 <tr>
  <td>1475</td>
  <td>Phosphate Rock</td>

 </tr>
 <tr>
  <td>2874</td>
  <td>Phosphatic Fertilizers</td>

 </tr>
 <tr>
  <td>7334</td>
  <td>Photocopying and Duplicating Services (except quick printing)</td>

 </tr>
 <tr>
  <td>7334</td>
  <td>Photocopying and Duplicating Services (quick printing)</td>

 </tr>
 <tr>
  <td>7384</td>
  <td>Photofinishing Laboratories (except one-hour)</td>

 </tr>
 <tr>
  <td>7384</td>
  <td>Photofinishing Laboratories (one-hour)</td>

 </tr>
 <tr>
  <td>5043</td>
  <td>Photographic Equipment and Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5043</td>
  <td>Photographic Equipment and Supplies (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>3861</td>
  <td>Photographic Equipment and Supplies (except photographic film  paper �
   platesand chemicals)</td>

 </tr>
 <tr>
  <td>5043</td>
  <td>Photographic Equipment and Supplies (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>3861</td>
  <td>Photographic Equipment and Supplies (photographic films  paper �
   plates and chemicals)</td>

 </tr>
 <tr>
  <td>7221</td>
  <td>Photographic StudiosPortrait</td>

 </tr>
 <tr>
  <td>7991</td>
  <td>Physical Fitness Facilities</td>

 </tr>
 <tr>
  <td>2035</td>
  <td>Pickled Fruits and Vegetables �
   Vegetable Sauces and Seasonings �
   and Salad Dressings (pickled fruits and vegetables)</td>

 </tr>
 <tr>
  <td>2035</td>
  <td>Pickled Fruits and Vegetables �
   Vegetable Sauces and Seasonings �
   and Salad Dressings (sauces and salad dressings)</td>

 </tr>
 <tr>
  <td>5131</td>
  <td>Piece GoodsNotions  and Other Dry Goods (agents and brokers)</td>

 </tr>
 <tr>
  <td>5131</td>
  <td>Piece GoodsNotions  and Other Dry Goods (broadwoven
  converters)</td>

 </tr>
 <tr>
  <td>5131</td>
  <td>Piece GoodsNotions  and Other Dry Goods (business to business
  electronic markets)</td>

 </tr>
 <tr>
  <td>5131</td>
  <td>Piece GoodsNotions  and Other Dry Goods (merchant wholesalers
  except broadwoven and piece goods converters and merchant wholesalers selling
  piece goodsnotions and other dry
  goods via retail method)</td>

 </tr>
 <tr>
  <td>5131</td>
  <td>Piece GoodsNotions  and Other Dry Goods (piece goods  notions �
   and other dry goods sold via retail method)</td>

 </tr>
 <tr>
  <td>5131</td>
  <td>Piece GoodsNotions  and Other Dry Goods (piece goods
  convertersexcept broadwoven)</td>

 </tr>
 <tr>
  <td>4619</td>
  <td>Pipelines NEC</td>

 </tr>
 <tr>
  <td>1742</td>
  <td>PlasteringDrywall  Acoustical   and Insulation Work</td>

 </tr>
 <tr>
  <td>2673</td>
  <td>PlasticsFoil  and Coated Paper Bags (except single web
  or multi-web plastic bags)</td>

 </tr>
 <tr>
  <td>2673</td>
  <td>PlasticsFoil  and Coated Paper Bags (single-web and
  multi-web plastics bags)</td>

 </tr>
 <tr>
  <td>3085</td>
  <td>Plastics Bottles</td>

 </tr>
 <tr>
  <td>3086</td>
  <td>Plastics Foam Products (except polystyrene foam products)</td>

 </tr>
 <tr>
  <td>3086</td>
  <td>Plastics Foam Products (polystyrene foam products)</td>

 </tr>
 <tr>
  <td>2821</td>
  <td>Plastics MaterialsSynthetic and
  Resinsand Nonvulcanizable Elastomers</td>

 </tr>
 <tr>
  <td>5162</td>
  <td>Plastics Materials and Basic Forms and Shapes (agents and brokers)</td>

 </tr>
 <tr>
  <td>5162</td>
  <td>Plastics Materials and Basic Forms and Shapes (business to business
  electronic markets)</td>

 </tr>
 <tr>
  <td>5162</td>
  <td>Plastics Materials and Basic Forms and Shapes (merchant wholesalers
  except those selling plastics via retail method)</td>

 </tr>
 <tr>
  <td>5162</td>
  <td>Plastics Materials and Basic Forms and Shapes (plastics materials  forms �
   and basic shapes sold via retail method)</td>

 </tr>
 <tr>
  <td>3084</td>
  <td>Plastics Pipe</td>

 </tr>
 <tr>
  <td>3088</td>
  <td>Plastics Plumbing Fixtures</td>

 </tr>
 <tr>
  <td>3089</td>
  <td>Plastics Products NEC (except
  plastics pipe fittingsinflatable
  plastics life jacketsplastics
  furniture partsand plastics sausage
  casings)</td>

 </tr>
 <tr>
  <td>3089</td>
  <td>Plastics Products NEC (finished
  plastic furniture parts)</td>

 </tr>
 <tr>
  <td>3089</td>
  <td>Plastics Products NEC (inflatable
  plastic life jackets)</td>

 </tr>
 <tr>
  <td>3089</td>
  <td>Plastics Products NEC (pipe
  fittings)</td>

 </tr>
 <tr>
  <td>3089</td>
  <td>Plastics Products NEC (plastics
  sausage casings)</td>

 </tr>
 <tr>
  <td>2796</td>
  <td>Platemaking and Related Services</td>

 </tr>
 <tr>
  <td>2395</td>
  <td>PleatingDecorative and Novelty
  Stitchingand Tucking for the Trade
  (except apparel contractors)</td>

 </tr>
 <tr>
  <td>2395</td>
  <td>PleatingDecorative and Novelty
  Stitchingand Tucking for the Trade
  (men's and boy's apparel contractors)</td>

 </tr>
 <tr>
  <td>2395</td>
  <td>PleatingDecorative and Novelty
  Stitchingand Tucking for the Trade
  (women'sGirl's  and infants' apparel contractors)</td>

 </tr>
 <tr>
  <td>1711</td>
  <td>PlumbingHeating  and Air-Conditioning (environmental
  control installation contractors)</td>

 </tr>
 <tr>
  <td>1711</td>
  <td>PlumbingHeating  and Air-Conditioning (except environmental
  controls installation</td>

 </tr>
 <tr>
  <td>1711</td>
  <td>PlumbingHeating  and Air-Conditioning (septic tank  cesspool �
   and dry well construction contractors)</td>

 </tr>
 <tr>
  <td>5074</td>
  <td>Plumbing and Heating Equipment and Supplies (Hydronics) (agents and
  brokers)</td>

 </tr>
 <tr>
  <td>5074</td>
  <td>Plumbing and Heating Equipment and Supplies (Hydronics) (business to
  business electronic markets)</td>

 </tr>
 <tr>
  <td>5074</td>
  <td>Plumbing and Heating Equipment and Supplies (Hydronics) (merchant
  wholesalers except those selling �
   plumbing and hydronic heating equipment via retail method)</td>

 </tr>
 <tr>
  <td>5074</td>
  <td>Plumbing and Heating Equipment and Supplies (Hydronics)(plumbing and
  hydronic heating equipment sold via retail method)</td>

 </tr>
 <tr>
  <td>3432</td>
  <td>Plumbing Fixture Fittings and Trim (except shower rods  lawn hose nozzles  and lawn sprinklers)</td>

 </tr>
 <tr>
  <td>3432</td>
  <td>Plumbing Fixture Fittings and Trim (lawn hose nozzles and lawn
  sprinklers)</td>

 </tr>
 <tr>
  <td>3432</td>
  <td>Plumbing Fixture Fittings and Trim (metal shower rods)</td>

 </tr>
 <tr>
  <td>9221</td>
  <td>Police Protection</td>

 </tr>
 <tr>
  <td>8651</td>
  <td>Political Organizations</td>

 </tr>
 <tr>
  <td>3264</td>
  <td>Porcelain Electrical Supplies</td>

 </tr>
 <tr>
  <td>1474</td>
  <td>PotashSoda  and Borate Minerals</td>

 </tr>
 <tr>
  <td>2096</td>
  <td>Potato ChipsCorn Chips  and Similar Snacks</td>

 </tr>
 <tr>
  <td>3269</td>
  <td>Pottery Products NEC</td>

 </tr>
 <tr>
  <td>259</td>
  <td>Poultry and Eggs NEC</td>

 </tr>
 <tr>
  <td>5144</td>
  <td>Poultry and Poultry Products (agents and brokers)</td>

 </tr>
 <tr>
  <td>5144</td>
  <td>Poultry and Poultry Products (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5144</td>
  <td>Poultry and Poultry Products (merchant wholesalers except those selling
  poultry and poultry products via retail method)</td>

 </tr>
 <tr>
  <td>5144</td>
  <td>Poultry and Poultry Products (poultry and poultry products sold via
  retail method)</td>

 </tr>
 <tr>
  <td>254</td>
  <td>Poultry Hatcheries</td>

 </tr>
 <tr>
  <td>2015</td>
  <td>Poultry Slaughtering and Processing (egg processing)</td>

 </tr>
 <tr>
  <td>2015</td>
  <td>Poultry Slaughtering and Processing (poultry slaughtering and processing)</td>

 </tr>
 <tr>
  <td>3612</td>
  <td>PowerDistribution  and Specialty Transformers</td>

 </tr>
 <tr>
  <td>7211</td>
  <td>Power LaundriesFamily and
  Commercial</td>

 </tr>
 <tr>
  <td>3546</td>
  <td>Power-Driven Handtools</td>

 </tr>
 <tr>
  <td>3448</td>
  <td>Prefabricated Metal Buildings and Components</td>

 </tr>
 <tr>
  <td>2452</td>
  <td>Prefabricated Wood Buildings and Components</td>

 </tr>
 <tr>
  <td>7372</td>
  <td>Prepackaged Software (mass reproduction of software)</td>

 </tr>
 <tr>
  <td>7372</td>
  <td>Prepackaged Software (software publishing)</td>

 </tr>
 <tr>
  <td>2048</td>
  <td>Prepared Feeds and Feed Ingredients for Animals and Fowls  Except Dogs and Cats (except slaughtering
  animals for pet food)</td>

 </tr>
 <tr>
  <td>2048</td>
  <td>Prepared Feeds and Feed Ingredients for Animals and Fowls  Except Dogs and Cats (slaughtering animals
  for pet food)</td>

 </tr>
 <tr>
  <td>2045</td>
  <td>Prepared Flour Mixes and Doughs</td>

 </tr>
 <tr>
  <td>2092</td>
  <td>Prepared Fresh or Frozen Fish and Seafoods</td>

 </tr>
 <tr>
  <td>3229</td>
  <td>Pressed and Blown Glass and Glassware � NEC</td>

 </tr>
 <tr>
  <td>3692</td>
  <td>Primary BatteriesDry and Wet</td>

 </tr>
 <tr>
  <td>3399</td>
  <td>Primary Metal Products NEC
  (aluminum powderpaste  flakes �
   etc.)</td>

 </tr>
 <tr>
  <td>3399</td>
  <td>Primary Metal Products NEC
  (copper powderpaste  flakes �
   etc.)</td>

 </tr>
 <tr>
  <td>3399</td>
  <td>Primary Metal Products NEC
  (ferrous powderpaste  flakes �
   etc.)</td>

 </tr>
 <tr>
  <td>3399</td>
  <td>Primary Metal Products NEC (iron
  ore recovery from open hearth slag)</td>

 </tr>
 <tr>
  <td>3399</td>
  <td>Primary Metal Products NEC
  (laminating steel for the trade)</td>

 </tr>
 <tr>
  <td>3399</td>
  <td>Primary Metal Products NEC
  (nonferrous nailsbrads  staples �
   tacksetc. made from purchased
  nonferrous wire)</td>

 </tr>
 <tr>
  <td>3399</td>
  <td>Primary Metal Products NEC
  (nonferrous powderpaste  flakes �
   etc. except copper and aluminum)</td>

 </tr>
 <tr>
  <td>3334</td>
  <td>Primary Production of Aluminum</td>

 </tr>
 <tr>
  <td>3331</td>
  <td>Primary Smelting and Refining of Copper</td>

 </tr>
 <tr>
  <td>3339</td>
  <td>Primary Smelting and Refining of Nonferrous Metals  Except Copper and Aluminum</td>

 </tr>
 <tr>
  <td>3672</td>
  <td>Printed Circuit Boards</td>

 </tr>
 <tr>
  <td>5111</td>
  <td>Printing and Writing Paper (agents and brokers)</td>

 </tr>
 <tr>
  <td>5111</td>
  <td>Printing and Writing Paper (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5111</td>
  <td>Printing and Writing Paper (merchant wholesalers except those selling
  printing and writing paper via retail method)</td>

 </tr>
 <tr>
  <td>5111</td>
  <td>Printing and Writing Paper (printing and writing paper sold via retail
  method)</td>

 </tr>
 <tr>
  <td>2893</td>
  <td>Printing Ink</td>

 </tr>
 <tr>
  <td>3555</td>
  <td>Printing Trades Machinery and Equipment</td>

 </tr>
 <tr>
  <td>8811</td>
  <td>Private Households</td>

 </tr>
 <tr>
  <td>2999</td>
  <td>Products of Petroleum and Coal � NEC</td>

 </tr>
 <tr>
  <td>5049</td>
  <td>Professional Equipment and Supplies � NEC (agents and brokers)</td>

 </tr>
 <tr>
  <td>5049</td>
  <td>Professional Equipment and Supplies � NEC (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5049</td>
  <td>Professional
  Equipment and Supplies NEC (merchant
  wholesalers except those selling religious and teacher's school supplies via
  retail method) </td>

 </tr>
 <tr>
  <td>5049</td>
  <td>Professional Equipment and Supplies � NEC (religious and teacher's school supplies sold via retail method)</td>

 </tr>
 <tr>
  <td>8621</td>
  <td>Professional Membership Organizations</td>

 </tr>
 <tr>
  <td>7941</td>
  <td>Professional Sports Clubs and Promoters (professional sports clubs)</td>

 </tr>
 <tr>
  <td>7941</td>
  <td>Professional Sports Clubs and Promoters (sports agents)</td>

 </tr>
 <tr>
  <td>7941</td>
  <td>Professional Sports Clubs and Promoters (sports promoters)</td>

 </tr>
 <tr>
  <td>7941</td>
  <td>Professional
  Sports Clubs and Promoters (stadium operators promoting events in their own
  facilities) </td>

 </tr>
 <tr>
  <td>8063</td>
  <td>Psychiatric Hospitals</td>

 </tr>
 <tr>
  <td>2531</td>
  <td>Public Building and Related Furniture (blackboards)</td>

 </tr>
 <tr>
  <td>2531</td>
  <td>Public Building and Related Furniture (except motor vehicle seats and
  blackboards)</td>

 </tr>
 <tr>
  <td>2531</td>
  <td>Public Building and Related Furniture (seats for motor vehicles)</td>

 </tr>
 <tr>
  <td>9311</td>
  <td>Public FinanceTaxation  and Monetary Policy</td>

 </tr>
 <tr>
  <td>7992</td>
  <td>Public Golf Courses</td>

 </tr>
 <tr>
  <td>9229</td>
  <td>Public Order and Safety NEC</td>

 </tr>
 <tr>
  <td>8743</td>
  <td>Public Relations Services</td>

 </tr>
 <tr>
  <td>2611</td>
  <td>Pulp Mills (pulp mills producing newsprint)</td>

 </tr>
 <tr>
  <td>2611</td>
  <td>Pulp Mills (pulp mills producing paper except newsprint)</td>

 </tr>
 <tr>
  <td>2611</td>
  <td>Pulp Mills (pulp mills producing paperboard)</td>

 </tr>
 <tr>
  <td>2611</td>
  <td>Pulp Mills (pulp producing mills only)</td>

 </tr>
 <tr>
  <td>3561</td>
  <td>Pumps and Pumping Equipment</td>

 </tr>
 <tr>
  <td>7948</td>
  <td>RacingIncluding Track
  Operations(except track operators)</td>

 </tr>
 <tr>
  <td>7948</td>
  <td>RacingIncluding Track Operations
  (track operations)</td>

 </tr>
 <tr>
  <td>5731</td>
  <td>RadioTelevision  and Consumer Electronics Stores
  (automobile radios)</td>

 </tr>
 <tr>
  <td>5731</td>
  <td>RadioTelevision  and Consumer Electronics Stores (except
  automobile radios)</td>

 </tr>
 <tr>
  <td>7313</td>
  <td>RadioTelevision  and Publishers' Advertising
  Representatives</td>

 </tr>
 <tr>
  <td>3663</td>
  <td>Radio and Television Broadcasting and Communications Equipment</td>

 </tr>
 <tr>
  <td>7622</td>
  <td>Radio and Television Repair Shops (household antenna installation and
  household-type satellite dish installation)</td>

 </tr>
 <tr>
  <td>7622</td>
  <td>Radio and Television Repair Shops (new retail sales combined with
  repair-repair services as major source of receipts)</td>

 </tr>
 <tr>
  <td>7622</td>
  <td>Radio and Television Repair Shops (stereo   TVVCR  and radio repair)</td>

 </tr>
 <tr>
  <td>7622</td>
  <td>Radio and Television Repair Shops (telecommunication equipment repair)</td>

 </tr>
 <tr>
  <td>4832</td>
  <td>Radio Broadcasting Stations (except networks)</td>

 </tr>
 <tr>
  <td>4832</td>
  <td>Radio Broadcasting Stations (networks)</td>

 </tr>
 <tr>
  <td>4812</td>
  <td>Radiotelephone Communications (cellular carriers)</td>

 </tr>
 <tr>
  <td>4812</td>
  <td>Radiotelephone Communications (paging and cellular resellers)</td>

 </tr>
 <tr>
  <td>4812</td>
  <td>Radiotelephone Communications (paging carriers)</td>

 </tr>
 <tr>
  <td>3743</td>
  <td>Railroad Equipment (except locomotive fuel lubricating or cooling medium
  pumps)</td>

 </tr>
 <tr>
  <td>3743</td>
  <td>Railroad Equipment (locomotive fuel lubricating or cooling medium pumps)</td>

 </tr>
 <tr>
  <td>4013</td>
  <td>Railroad Switching and Terminal Establishments (except short line
  railroads)</td>

 </tr>
 <tr>
  <td>4013</td>
  <td>Railroad Switching and Terminal Establishments (short line railroads)</td>

 </tr>
 <tr>
  <td>4011</td>
  <td>RailroadsLine-Haul Operating</td>

 </tr>
 <tr>
  <td>3273</td>
  <td>Ready-Mixed Concrete</td>

 </tr>
 <tr>
  <td>6531</td>
  <td>Real Estate Agents and Managers (agents and brokers)</td>

 </tr>
 <tr>
  <td>6531</td>
  <td>Real Estate Agents and Managers (appraisers)</td>

 </tr>
 <tr>
  <td>6531</td>
  <td>Real Estate Agents and Managers (cemetery management)</td>

 </tr>
 <tr>
  <td>6531</td>
  <td>Real Estate Agents and Managers (condominium associations)</td>

 </tr>
 <tr>
  <td>6531</td>
  <td>Real Estate Agents and Managers (except property managers  condominium associations  cemetery management  agents and brokers  operating housing authorities  and appraisers)</td>

 </tr>
 <tr>
  <td>6531</td>
  <td>Real Estate Agents and Managers (nonresidential property managers)</td>

 </tr>
 <tr>
  <td>6531</td>
  <td>Real Estate Agents and Managers (operating housing authorities)</td>

 </tr>
 <tr>
  <td>6531</td>
  <td>Real Estate Agents and Managers (residential property managers)</td>

 </tr>
 <tr>
  <td>6798</td>
  <td>Real Estate Investment Trusts (hybrid or equity REITs primarily leasing
  miniwarehouses and self-storage units)</td>

 </tr>
 <tr>
  <td>6798</td>
  <td>Real Estate Investment Trusts (hybrid or equity REITs primarily leasing
  nonresidential Buildings)</td>

 </tr>
 <tr>
  <td>6798</td>
  <td>Real Estate Investment Trusts (hybrid or equity REITs primarily leasing
  other real estate property)</td>

 </tr>
 <tr>
  <td>6798</td>
  <td>Real Estate Investment Trusts (hybrid or equity REITs primarily leasing
  residential Buildings and Dwellings)</td>

 </tr>
 <tr>
  <td>6798</td>
  <td>Real Estate Investment Trusts (hybrid or mortgage REITs primarily in
  underwriting or investing in mortgages)</td>

 </tr>
 <tr>
  <td>2493</td>
  <td>Reconstituted Wood Products</td>

 </tr>
 <tr>
  <td>5735</td>
  <td>Record and Prerecorded Tape Stores</td>

 </tr>
 <tr>
  <td>5561</td>
  <td>Recreational Vehicle Dealers</td>

 </tr>
 <tr>
  <td>7033</td>
  <td>Recreational Vehicle Parks and Campsites</td>

 </tr>
 <tr>
  <td>4613</td>
  <td>Refined Petroleum Pipelines</td>

 </tr>
 <tr>
  <td>4222</td>
  <td>Refrigerated Warehousing and Storage</td>

 </tr>
 <tr>
  <td>7623</td>
  <td>Refrigeration and Air-Conditioning Service and Repair Shops (except
  commercial refrigeration equipment repair �
   and sales locations with repair as major source of receipts)</td>

 </tr>
 <tr>
  <td>7623</td>
  <td>Refrigeration and Air-Conditioning Services and Repair Shops (commercial
  refrigerator equipment repair)</td>

 </tr>
 <tr>
  <td>7623</td>
  <td>Refrigeration and Air-Conditioning Services and Repair Shops (new retail
  sales combined with repair-repair services as major source of receipts)</td>

 </tr>
 <tr>
  <td>5078</td>
  <td>Refrigeration Equipment and Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5078</td>
  <td>Refrigeration Equipment and Supplies (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5078</td>
  <td>Refrigeration Equipment and Supplies (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>4953</td>
  <td>Refuse Systems (hazardous waste treatment and disposal)</td>

 </tr>
 <tr>
  <td>4953</td>
  <td>Refuse Systems (materials recovery facilities)</td>

 </tr>
 <tr>
  <td>4953</td>
  <td>Refuse Systems (other nonhazardous waste treatment and disposal)</td>

 </tr>
 <tr>
  <td>4953</td>
  <td>Refuse Systems (solid waste combustors and incinerators)</td>

 </tr>
 <tr>
  <td>4953</td>
  <td>Refuse Systems (solid waste landfills)</td>

 </tr>
 <tr>
  <td>9651</td>
  <td>RegulationLicensing  and Inspection of Miscellaneous Commercial
  Sectors</td>

 </tr>
 <tr>
  <td>9631</td>
  <td>Regulation and Administration of Communications   ElectricGas  and Other Utilities</td>

 </tr>
 <tr>
  <td>9621</td>
  <td>Regulation and Administration of Transportation Programs (except air
  traffic control)</td>

 </tr>
 <tr>
  <td>9621</td>
  <td>Regulation and Administration of Transportation Programs (government air
  traffic control)</td>

 </tr>
 <tr>
  <td>9641</td>
  <td>Regulation of Agricultural Marketing and Commodities</td>

 </tr>
 <tr>
  <td>3625</td>
  <td>Relays and Industrial Controls</td>

 </tr>
 <tr>
  <td>8661</td>
  <td>Religious Organizations</td>

 </tr>
 <tr>
  <td>4741</td>
  <td>Rental of Railroad Cars (grain
  leveling in railroad carsgrain
  trimming for railroad equipment �
   precooling of fruits and vegetables in con NECtion with transportation  and railroad car cleaning  icing �
   ventilatingand heating)</td>

 </tr>
 <tr>
  <td>4741</td>
  <td>Rental of Railroad Cars (rental of railroad cars)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (boiler cleaning �
   chippingand scaling)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (camera repair)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (cesspool and septic tank cleaning)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (custom picture framing shops)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (dental instrument repair �
   laboratory instrument repair �
   medical equipment and other electronic and precision equipment
  repairexcept typewriters)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (except industrial �
   electronichome and
  gardenappliance  and leather goods)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (farriers)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (furnaceduct  gutter �
   and drain cleaning services)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (gas appliance repair service �
   sewing machine repairstove
  repair shopsand other non-electrical
  appliance)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (lawnmower repair shops �
   sharpening and repairing knives �
   saws and tools)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (leather goods repair shops �
   luggage repair shops �
   pocketbook repair shops)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (locksmith shops)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (new bicycle retail sales combined with repair-repair services for
  bicycles as major source of receipts)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (new lawn and garden equipment retail sales combined with
  repair-repair services as major source of receipts)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (new power tool retail sales combined with repair-repair services
  as major source of receipts)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (other non-automotive transportation equipment and industrial
  machines and equipmentand sharpening
  commercial blades)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (sewer cleaning and rodding)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair
  Shops and Related Services NEC (ship
  scaling) </td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (taxidermists and antique repair and restoration  except antique car restoration)</td>

 </tr>
 <tr>
  <td>7699</td>
  <td>Repair Shops and Related Services � NEC (typewriter repair �
   refilling or recycling ink jet cartridges)</td>

 </tr>
 <tr>
  <td>8361</td>
  <td>Residential Care (except mental health and substance abuse
  facilitieshomes for the elderly  and homes for the mentally handicapped
  with incidental health care)</td>

 </tr>
 <tr>
  <td>8361</td>
  <td>Residential Care (homes for the elderly)</td>

 </tr>
 <tr>
  <td>8361</td>
  <td>Residential Care (homes for the mentally handicapped with incidental
  health care)</td>

 </tr>
 <tr>
  <td>8361</td>
  <td>Residential
  Care (mental health and substance abuse facilities) </td>

 </tr>
 <tr>
  <td>3645</td>
  <td>Residential Electric Lighting Fixtures</td>

 </tr>
 <tr>
  <td>5461</td>
  <td>Retail Bakeries (breadcake and
  related products baked and sold on premise)</td>

 </tr>
 <tr>
  <td>5461</td>
  <td>Retail Bakeries (selling only)</td>

 </tr>
 <tr>
  <td>5461</td>
  <td>Retail Bakeries (snacks)</td>

 </tr>
 <tr>
  <td>5261</td>
  <td>Retail NurseriesLawn and Garden
  Supply Stores (except outdoor power equipment)</td>

 </tr>
 <tr>
  <td>5261</td>
  <td>Retail NurseriesLawn and Garden
  Supply Stores (outdoor power equipment)</td>

 </tr>
 <tr>
  <td>7641</td>
  <td>Reupholstery and Furniture Repair</td>

 </tr>
 <tr>
  <td>112</td>
  <td>Rice </td>

 </tr>
 <tr>
  <td>2044</td>
  <td>Rice Milling</td>

 </tr>
 <tr>
  <td>2095</td>
  <td>Roasted Coffee</td>

 </tr>
 <tr>
  <td>2384</td>
  <td>Robes and Dressing Gowns (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>2384</td>
  <td>Robes and Dressing Gowns (men's except contractors)</td>

 </tr>
 <tr>
  <td>2384</td>
  <td>Robes and Dressing Gowns (women's �
   Girl'sand infants'
  contractors)</td>

 </tr>
 <tr>
  <td>2384</td>
  <td>Robes and Dressing Gowns (women's except contractors)</td>

 </tr>
 <tr>
  <td>3351</td>
  <td>RollingDrawing  and Extruding of Copper</td>

 </tr>
 <tr>
  <td>3356</td>
  <td>RollingDrawing  and Extruding of Nonferrous Metals  Except Copper and Aluminum</td>

 </tr>
 <tr>
  <td>3547</td>
  <td>Rolling Mill Machinery and Equipment</td>

 </tr>
 <tr>
  <td>5033</td>
  <td>RoofingSiding  and Insulation Materials (agents and
  brokers)</td>

 </tr>
 <tr>
  <td>5033</td>
  <td>RoofingSiding  and Insulation Materials (business to
  business electronic markets)</td>

 </tr>
 <tr>
  <td>5033</td>
  <td>RoofingSiding  and Insulation Materials (merchant
  wholesalers except those selling via retail method)</td>

 </tr>
 <tr>
  <td>5033</td>
  <td>RoofingSiding  and Insulation Materials (roofing  siding �
   and insulation materials sold via retail method)</td>

 </tr>
 <tr>
  <td>1761</td>
  <td>RoofingSiding  and Sheet Metal Work (except roofing and
  siding work)</td>

 </tr>
 <tr>
  <td>1761</td>
  <td>RoofingSiding  and Sheet Metal Work (roofing contractors)</td>

 </tr>
 <tr>
  <td>1761</td>
  <td>RoofingSiding  and Sheet Metal Work (siding contractors)</td>

 </tr>
 <tr>
  <td>7021</td>
  <td>Rooming and Boarding Houses</td>

 </tr>
 <tr>
  <td>3021</td>
  <td>Rubber and Plastics Footwear</td>

 </tr>
 <tr>
  <td>3052</td>
  <td>Rubber and Plastics Hose and Belting</td>

 </tr>
 <tr>
  <td>2068</td>
  <td>Salted and Roasted Nuts and Seeds</td>

 </tr>
 <tr>
  <td>2656</td>
  <td>Sanitary Food ContainersExcept
  Folding</td>

 </tr>
 <tr>
  <td>2676</td>
  <td>Sanitary Paper Products</td>

 </tr>
 <tr>
  <td>4959</td>
  <td>Sanitary Services NEC (all but
  remediation servicesmalaria
  controlmosquito eradication  snow plowing   street sweepingand
  airport runway vacuuming)</td>

 </tr>
 <tr>
  <td>4959</td>
  <td>Sanitary Services NEC (cleaning
  parking lots and driveways)</td>

 </tr>
 <tr>
  <td>4959</td>
  <td>Sanitary Services NEC (mosquito
  eradication)</td>

 </tr>
 <tr>
  <td>4959</td>
  <td>Sanitary Services NEC
  (remediation services)</td>

 </tr>
 <tr>
  <td>4959</td>
  <td>Sanitary Services NEC (snow
  plowing and sweeping streets and highways)</td>

 </tr>
 <tr>
  <td>4959</td>
  <td>Sanitary Services NEC (vacuuming
  of runways)</td>

 </tr>
 <tr>
  <td>2013</td>
  <td>Sausages and Other Prepared Meat Products (except lard made from
  purchased materials)</td>

 </tr>
 <tr>
  <td>2013</td>
  <td>Sausages and Other Prepared Meat Products (lard made from purchased
  materials)</td>

 </tr>
 <tr>
  <td>6035</td>
  <td>Savings InstitutionsFederally
  Chartered</td>

 </tr>
 <tr>
  <td>6036</td>
  <td>Savings InstitutionsNot
  Federally Chartered</td>

 </tr>
 <tr>
  <td>3425</td>
  <td>Saw Blades and Handsaws</td>

 </tr>
 <tr>
  <td>2421</td>
  <td>Sawmills and Planing Mills �
   General (box lumber made from purchased lumber)</td>

 </tr>
 <tr>
  <td>2421</td>
  <td>Sawmills and Planing Mills �
   General (kiln drying)</td>

 </tr>
 <tr>
  <td>2421</td>
  <td>Sawmills and Planing Mills �
   General (lumber manufacturing from purchased lumber  softwood cut stock  wood lath �
   fence picketsand planing mill
  products)</td>

 </tr>
 <tr>
  <td>2421</td>
  <td>Sawmills and Planing Mills �
   General (sawmills)</td>

 </tr>
 <tr>
  <td>2421</td>
  <td>Sawmills and Planing Mills �
   General (softwood flooring)</td>

 </tr>
 <tr>
  <td>3596</td>
  <td>Scales and BalancesExcept
  Laboratory</td>

 </tr>
 <tr>
  <td>2397</td>
  <td>Schiffli Machine Embroideries</td>

 </tr>
 <tr>
  <td>4151</td>
  <td>School Buses</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational Services � NEC (artdrama  and music schools)</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational Services � NEC (automobile driving instruction)</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational Services � NEC (baton instruction)</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational Services � NEC (cooking and modeling schools)</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools
  and Educational Services NEC (exam
  preparation and tutoring) </td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational
  Services NEC (except professional and
  management trainingaviation and
  flight trainingfine arts schools  language schools   exam preparation and tutoring �
   automobile driving schoolsand
  educational support services)</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational Services � NEC (flying instruction)</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational Services � NEC (language schools)</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational Services � NEC (professional and management development training)</td>

 </tr>
 <tr>
  <td>8299</td>
  <td>Schools and Educational Services  NEC (educational support services)</td>

 </tr>
 <tr>
  <td>5093</td>
  <td>Scrap and Waste Materials (agents and brokers)</td>

 </tr>
 <tr>
  <td>5093</td>
  <td>Scrap
  and Waste Materials (business to business electronic markets) </td>

 </tr>
 <tr>
  <td>5093</td>
  <td>Scrap and Waste Materials (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>3451</td>
  <td>Screw Machine Products</td>

 </tr>
 <tr>
  <td>3812</td>
  <td>SearchDetection  Navigation   Guidance �
   Aeronauticaland Nautical
  Systems and Instruments</td>

 </tr>
 <tr>
  <td>3341</td>
  <td>Secondary Smelting and Refining of Nonferrous Metals (aluminum)</td>

 </tr>
 <tr>
  <td>3341</td>
  <td>Secondary Smelting and Refining of Nonferrous Metals (copper)</td>

 </tr>
 <tr>
  <td>3341</td>
  <td>Secondary Smelting and Refining of Nonferrous Metals (except copper and
  aluminum)</td>

 </tr>
 <tr>
  <td>7338</td>
  <td>Secretarial and Court Reporting (court reporting services)</td>

 </tr>
 <tr>
  <td>7338</td>
  <td>Secretarial and Court Reporting (secretarial services)</td>

 </tr>
 <tr>
  <td>6231</td>
  <td>Security and Commodity Exchanges</td>

 </tr>
 <tr>
  <td>6211</td>
  <td>Security BrokersDealers  and Flotation Companies (except security
  dealers and underwritersand security  oil lease �
   and gas lease brokers)</td>

 </tr>
 <tr>
  <td>6211</td>
  <td>Security BrokersDealers  and Flotation Companies (oil lease and gas
  lease brokers offices)</td>

 </tr>
 <tr>
  <td>6211</td>
  <td>Security BrokersDealers  and Flotation Companies (security
  brokersnote brokers)</td>

 </tr>
 <tr>
  <td>6211</td>
  <td>Security BrokersDealers  and Flotation Companies (security dealers
  and underwriters)</td>

 </tr>
 <tr>
  <td>7382</td>
  <td>Security Systems Services</td>

 </tr>
 <tr>
  <td>3674</td>
  <td>Semiconductors and Related Devices</td>

 </tr>
 <tr>
  <td>5087</td>
  <td>Service Establishment Equipment and Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5087</td>
  <td>Service Establishment Equipment and Supplies (beauty and barber shop
  equipment and supplies sold via retail method)</td>

 </tr>
 <tr>
  <td>5087</td>
  <td>Service Establishment Equipment and Supplies (business to business
  electronic markets)</td>

 </tr>
 <tr>
  <td>5087</td>
  <td>Service Establishment Equipment and Supplies (merchant wholesalers except
  those selling beauty and barber shop equipment and supplies via retail
  method)</td>

 </tr>
 <tr>
  <td>3589</td>
  <td>Service Industry Machinery NEC</td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services NEC (actuarial
  consulting)</td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services   NEC (authors   artistsand related
  technical servicesindependent) </td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services NEC (environmental
  consultants)</td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services NEC (Internet
  broadcastingspecial interest web
  sitesentertainment sites  and interactive game sites)</td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services NEC (Internet web search
  portals)</td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services NEC (music publishing)</td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services NEC (record production)</td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services NEC (scientific and
  related consulting services)</td>

 </tr>
 <tr>
  <td>8999</td>
  <td>Services NEC (weather forecasting
  services)</td>

 </tr>
 <tr>
  <td>7829</td>
  <td>Services Allied to Motion Picture Distribution (commercial distribution
  film libraries)</td>

 </tr>
 <tr>
  <td>7829</td>
  <td>Services Allied to Motion Picture Distribution (except commercial film
  distribution libraries and film archives)</td>

 </tr>
 <tr>
  <td>7829</td>
  <td>Services Allied to Motion Picture Distribution (film archives)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture Production (casting bureaus)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture
  Production (except casting bureaus �
   wardrobe and equipment rental �
   talent payment services �
   teleproduction and other postproduction services  reproduction of videos  independent film directors  and other independent motion picture
  production related services)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture Production (film directors and related
  motion picture production services �
   independent)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture Production (motion picture consulting)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture Production (motion picture equipment
  rental)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture Production (reproduction of video)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture Production (talent payment services)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture Production (teleproduction and
  postproduction services)</td>

 </tr>
 <tr>
  <td>7819</td>
  <td>Services Allied to Motion Picture Production (wardrobe rental for motion
  picture film production)</td>

 </tr>
 <tr>
  <td>6289</td>
  <td>Services Allied With the Exchange of Securities or Commodities   NEC (except security custodians)</td>

 </tr>
 <tr>
  <td>6289</td>
  <td>Services Allied With the Exchange of Securities or Commodities   NEC (security custodians)</td>

 </tr>
 <tr>
  <td>2652</td>
  <td>Setup Paperboard Boxes</td>

 </tr>
 <tr>
  <td>4952</td>
  <td>Sewerage Systems</td>

 </tr>
 <tr>
  <td>5949</td>
  <td>SewingNeedlework  and Piece Goods Stores</td>

 </tr>
 <tr>
  <td>214</td>
  <td>Sheep and Goats (goat farms)</td>

 </tr>
 <tr>
  <td>214</td>
  <td>Sheep and Goats (sheep farms)</td>

 </tr>
 <tr>
  <td>3444</td>
  <td>Sheet Metal Work (cooling towers �
   sheet metal)</td>

 </tr>
 <tr>
  <td>3444</td>
  <td>Sheet Metal Work (except sheet metal bins and vats  skylights �
   and sheet metal cooling towers)</td>

 </tr>
 <tr>
  <td>3444</td>
  <td>Sheet Metal Work (metal bins and vats)</td>

 </tr>
 <tr>
  <td>3444</td>
  <td>Sheet Metal Work (stamped metal skylights)</td>

 </tr>
 <tr>
  <td>913</td>
  <td>Shellfish</td>

 </tr>
 <tr>
  <td>3731</td>
  <td>Ship Building and Repairing (except repairs in floating drydocks)</td>

 </tr>
 <tr>
  <td>3731</td>
  <td>Ship Building and Repairing (repair services provided by floating
  drydocks)</td>

 </tr>
 <tr>
  <td>7251</td>
  <td>Shoe Repair Shops and Shoeshine Parlors (hatcleaning and blocking shops)</td>

 </tr>
 <tr>
  <td>7251</td>
  <td>Shoe Repair Shops and Shoeshine Parlors (shoe repair shops)</td>

 </tr>
 <tr>
  <td>7251</td>
  <td>Shoe Repair Shops and Shoeshine Parlors (shoeshine parlors)</td>

 </tr>
 <tr>
  <td>5661</td>
  <td>Shoe Stores</td>

 </tr>
 <tr>
  <td>6153</td>
  <td>Short Term Business Credit Institutions �
   Except Agricultural (short term inventory credit and purchasing
  accounts receivable)</td>

 </tr>
 <tr>
  <td>2079</td>
  <td>ShorteningTable Oils  Margarine �
   and Other Edible Fats and Oils � NEC (except processing vegetable and soybean oils into edible oils
  from oilseeds and vegetables crushed in the same establishment)</td>

 </tr>
 <tr>
  <td>2079</td>
  <td>ShorteningTable Oils  Margarine �
   and Other Edible Fats and Oils � NEC (processing soybean oil into edible cooking oils from soybeans
  crushed in the same establishment)</td>

 </tr>
 <tr>
  <td>2079</td>
  <td>ShorteningTable Oils  Margarine and Other Edible Fats and
  Oils NEC (processing vegetable
  oilsexcept soybean  into edible cooking oils from oilseeds and
  vegetables crushed in the same establishment)</td>

 </tr>
 <tr>
  <td>6153</td>
  <td>Short-Term Business Credit Institutions �
   Except Agricultural (business sales finance).</td>

 </tr>
 <tr>
  <td>6153</td>
  <td>Short-Term Business Credit Institutions �
   Except Agricultural (credit card issuing)</td>

 </tr>
 <tr>
  <td>6153</td>
  <td>Short-Term Business Credit Institutions �
   Except Agricultural (credit card service)</td>

 </tr>
 <tr>
  <td>6153</td>
  <td>Short-Term Business Credit Institutions �
   Except Agricultural (except credit card service and issuing  short term inventory credit  purchasing accounts receivable  and business sales finance)</td>

 </tr>
 <tr>
  <td>3993</td>
  <td>Signs and Advertising Specialties (screen printing purchased advertising
  specialties)</td>

 </tr>
 <tr>
  <td>3993</td>
  <td>Signs and Advertising Specialties (signs)</td>

 </tr>
 <tr>
  <td>1044</td>
  <td>Silver Ores</td>

 </tr>
 <tr>
  <td>3914</td>
  <td>SilverwarePlated Ware  and Stainless Steel Ware (cutlery and
  flatwarenonprecious and precious
  plated)</td>

 </tr>
 <tr>
  <td>3914</td>
  <td>SilverwarePlated Ware  and Stainless Steel Ware (except  nonprecious and precious plated metal
  cutleryflatware  and hollowware)</td>

 </tr>
 <tr>
  <td>3914</td>
  <td>SilverwarePlated Ware  and Stainless Steel Ware (precious metal
  plated hollowware)</td>

 </tr>
 <tr>
  <td>8051</td>
  <td>Skilled Nursing Care Facilities (continuing care retirement communities)</td>

 </tr>
 <tr>
  <td>8051</td>
  <td>Skilled Nursing Care Facilities (except continuing care retirement
  communities and mental retardation hospitals)</td>

 </tr>
 <tr>
  <td>8051</td>
  <td>Skilled Nursing Care Facilities (mental retardation hospitals)</td>

 </tr>
 <tr>
  <td>3484</td>
  <td>Small Arms</td>

 </tr>
 <tr>
  <td>3482</td>
  <td>Small Arms Ammunition</td>

 </tr>
 <tr>
  <td>2841</td>
  <td>Soaps and Other DetergentsExcept
  Specialty Cleaners</td>

 </tr>
 <tr>
  <td>8399</td>
  <td>Social Services NEC
  (environmentconservation  and wildlife advocacy)</td>

 </tr>
 <tr>
  <td>8399</td>
  <td>Social Services NEC (except human
  rightsenvironment  conservation and wildlife advocacy
  organizationsgrantmaking and
  givingand voluntary health
  organizations)</td>

 </tr>
 <tr>
  <td>8399</td>
  <td>Social Services NEC (grantmaking
  and giving)</td>

 </tr>
 <tr>
  <td>8399</td>
  <td>Social Services NEC (human rights
  organizations)</td>

 </tr>
 <tr>
  <td>8399</td>
  <td>Social Services NEC (voluntary
  health organizations)</td>

 </tr>
 <tr>
  <td>2436</td>
  <td>Softwood Veneer and Plywood</td>

 </tr>
 <tr>
  <td>711</td>
  <td>Soil Preparation Services</td>

 </tr>
 <tr>
  <td>2075</td>
  <td>Soybean Oil Mills (processing purchased soybean oil)</td>

 </tr>
 <tr>
  <td>2075</td>
  <td>Soybean Oil Mills (soybean processing �
   except edible soybean oil)</td>

 </tr>
 <tr>
  <td>116</td>
  <td>Soybeans</td>

 </tr>
 <tr>
  <td>9661</td>
  <td>Space Research and Technology</td>

 </tr>
 <tr>
  <td>3544</td>
  <td>Special Dies and ToolsDie
  SetsJigs and Fixtures  and Industrial Molds (except molds)</td>

 </tr>
 <tr>
  <td>3544</td>
  <td>Special Dies and ToolsDie
  SetsJigs and Fixtures  and Industrial Molds (industrial molds)</td>

 </tr>
 <tr>
  <td>3559</td>
  <td>Special Industry Machinery NEC
  (automotive maintenance equipment)</td>

 </tr>
 <tr>
  <td>3559</td>
  <td>Special Industry Machinery NEC
  (cotton ginning machinery)</td>

 </tr>
 <tr>
  <td>3559</td>
  <td>Special Industry Machinery NEC
  (except rubber and plastics manufacturing machinery   semiconductor manufacturing machinery   and automotive maintenance equipment)</td>

 </tr>
 <tr>
  <td>3559</td>
  <td>Special Industry Machinery NEC
  (nuclear control rod drive mechanisms)</td>

 </tr>
 <tr>
  <td>3559</td>
  <td>Special Industry Machinery NEC
  (rubber and plastics manufacturing machinery)</td>

 </tr>
 <tr>
  <td>3559</td>
  <td>Special Industry Machinery NEC
  (semiconductor machinery manufacturing)</td>

 </tr>
 <tr>
  <td>2429</td>
  <td>Special Product Sawmills NEC
  (excelsior)</td>

 </tr>
 <tr>
  <td>2429</td>
  <td>Special Product Sawmills NEC
  (shingle millsshakes)</td>

 </tr>
 <tr>
  <td>2429</td>
  <td>Special Product SawmillsNot
  Elsewhere Classified (cooperage stock)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (anchored earth retention contractors)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (asbestos abatement and lead paint removal contractors)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (building equipment installation contractors for service station
  equipmentboiler  duct �
   and pipe insulation</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors   NEC (building finishing contractors for
  weather stripping and damp proofing �
   window covering fixture installation �
   bathtub refinishingmodular
  furniture installationtrade show
  exhibit installation and removaland
  spectator seating installation) )</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (countertopresidential-type  installation)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (dewatering contractorstest drilling
  for constructionand core drilling
  for construction)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (except indoor swimming pool contractors �
   anchored earth retention contractors</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (forming contractors and ornamental metal work contractors)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (glass tinting work)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (indoor swimming pool construction contractors)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (paint and wallpaper stripping and removing contractors)</td>

 </tr>
 <tr>
  <td>1799</td>
  <td>Special Trade Contractors NEC
  (power washing building exteriorsnot
  associated with construction)</td>

 </tr>
 <tr>
  <td>4226</td>
  <td>Special Warehousing and Storage � NEC (except fur storage and warehousing in foreign trade zones)</td>

 </tr>
 <tr>
  <td>4226</td>
  <td>Special Warehousing and Storage � NEC (fur storage)</td>

 </tr>
 <tr>
  <td>4226</td>
  <td>Special Warehousing and Storage � NEC (warehousing in foreign trade zones)</td>

 </tr>
 <tr>
  <td>2842</td>
  <td>Specialty CleaningPolishing  and Sanitation Preparations</td>

 </tr>
 <tr>
  <td>8069</td>
  <td>Specialty HospitalsExcept
  Psychiatric (children's hospitals)</td>

 </tr>
 <tr>
  <td>8069</td>
  <td>Specialty
  HospitalsExcept Psychiatric (except
  children's and substance abuse hospitals) </td>

 </tr>
 <tr>
  <td>8069</td>
  <td>Specialty HospitalsExcept
  Psychiatric (substance abuse hospitals)</td>

 </tr>
 <tr>
  <td>8093</td>
  <td>Specialty Outpatient Facilities � NEC (except family planning centers �
   mental health centersand
  respritory therapy clinics and offices)</td>

 </tr>
 <tr>
  <td>8093</td>
  <td>Specialty Outpatient Facilities � NEC (family planning centers)</td>

 </tr>
 <tr>
  <td>8093</td>
  <td>Specialty Outpatient Facilities � NEC (mental health facilities)</td>

 </tr>
 <tr>
  <td>8093</td>
  <td>Specialty Outpatient Facilities � NEC (respiratory therapy clinics and offices)</td>

 </tr>
 <tr>
  <td>3566</td>
  <td>Speed ChangersIndustrial
  High-Speed Drivesand Gears</td>

 </tr>
 <tr>
  <td>3949</td>
  <td>Sporting and Athletic Goods NEC</td>

 </tr>
 <tr>
  <td>7032</td>
  <td>Sporting and Recreational Camps</td>

 </tr>
 <tr>
  <td>5091</td>
  <td>Sporting and Recreational Goods and Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5091</td>
  <td>Sporting and Recreational Goods and Supplies (business to business
  electronic markets)</td>

 </tr>
 <tr>
  <td>5091</td>
  <td>Sporting and Recreational Goods and Supplies (merchant wholesalers except
  those selling sporting and recreational goods via retail method)</td>

 </tr>
 <tr>
  <td>5091</td>
  <td>Sporting and Recreational Goods and Supplies (sporting and recreational
  goods sold via retail method)</td>

 </tr>
 <tr>
  <td>5941</td>
  <td>Sporting Goods Stores and Bicycle Shops</td>

 </tr>
 <tr>
  <td>6022</td>
  <td>State Commercial Banks (commercial banking)</td>

 </tr>
 <tr>
  <td>6022</td>
  <td>State Commercial Banks (credit card issuing)</td>

 </tr>
 <tr>
  <td>6022</td>
  <td>State Commercial Banks (private and industrial banking)</td>

 </tr>
 <tr>
  <td>2678</td>
  <td>StationeryTablets  and Related Products</td>

 </tr>
 <tr>
  <td>5112</td>
  <td>Stationery and Office Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5112</td>
  <td>Stationery and Office Supplies (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5112</td>
  <td>Stationery and Office Supplies (merchant wholesalers except those selling
  stationery and office supplies via retail method)</td>

 </tr>
 <tr>
  <td>5112</td>
  <td>Stationery and Office Supplies (stationery and office supplies sold via
  retail method)</td>

 </tr>
 <tr>
  <td>5943</td>
  <td>Stationery Stores</td>

 </tr>
 <tr>
  <td>3511</td>
  <td>SteamGas  and Hydraulic Turbines  and Turbine Generator Set Units</td>

 </tr>
 <tr>
  <td>4961</td>
  <td>Steam and Air-Conditioning Supply</td>

 </tr>
 <tr>
  <td>3325</td>
  <td>Steel Foundries NEC</td>

 </tr>
 <tr>
  <td>3324</td>
  <td>Steel Investment Foundries</td>

 </tr>
 <tr>
  <td>3317</td>
  <td>Steel Pipe and Tubes</td>

 </tr>
 <tr>
  <td>3493</td>
  <td>Steel SpringsExcept Wire</td>

 </tr>
 <tr>
  <td>3315</td>
  <td>Steel Wiredrawing and Steel Nails and Spikes (nails  spikes �
   paper clipsand wire not made
  in wiredrawing plants)</td>

 </tr>
 <tr>
  <td>3315</td>
  <td>Steel Wiredrawing and Steel Nails and Spikes (steel wire drawing)</td>

 </tr>
 <tr>
  <td>3312</td>
  <td>Steel WorksBlast Furnaces
  (Including Coke Ovens)and Rolling
  Mills (coke ovens)</td>

 </tr>
 <tr>
  <td>3312</td>
  <td>Steel WorksBlast Furnaces
  (Including Coke Ovens)and Rolling
  Mills (except coke ovens not integrated with steel mills and hot-rolling
  purchased steel)</td>

 </tr>
 <tr>
  <td>3312</td>
  <td>Steel WorksBlast Furnaces
  (Including Coke Ovens)and Rolling
  Mills (hot-rolling purchased steel)</td>

 </tr>
 <tr>
  <td>3691</td>
  <td>Storage Batteries</td>

 </tr>
 <tr>
  <td>3259</td>
  <td>Structural Clay Products NEC</td>

 </tr>
 <tr>
  <td>1791</td>
  <td>Structural Steel Erection (cooling tower installation)</td>

 </tr>
 <tr>
  <td>1791</td>
  <td>Structural Steel Erection (curtain wall installation and metal furring
  installation)</td>

 </tr>
 <tr>
  <td>1791</td>
  <td>Structural Steel Erection (structural steel work)</td>

 </tr>
 <tr>
  <td>2439</td>
  <td>Structural Wood Members NEC
  (except trusses)</td>

 </tr>
 <tr>
  <td>2439</td>
  <td>Structural Wood Members NEC
  (trusses)</td>

 </tr>
 <tr>
  <td>133</td>
  <td>Sugarcane and Sugar Beets (sugar beet farms)</td>

 </tr>
 <tr>
  <td>133</td>
  <td>Sugarcane and Sugar Beets (sugarcane farms)</td>

 </tr>
 <tr>
  <td>6351</td>
  <td>Surety Insurance (financial responsibility insurers-direct)</td>

 </tr>
 <tr>
  <td>6351</td>
  <td>Surety Insurance (reinsurers)</td>

 </tr>
 <tr>
  <td>6351</td>
  <td>Surety Insurance (warranty insurance �
   home)</td>

 </tr>
 <tr>
  <td>2843</td>
  <td>Surface Active AgentsFinishing
  AgentsSulfonated Oils  and Assistants</td>

 </tr>
 <tr>
  <td>3841</td>
  <td>Surgical and Medical Instruments and Apparatus (except tranquilizer guns
  and operating room tables)</td>

 </tr>
 <tr>
  <td>3841</td>
  <td>Surgical and Medical Instruments and Apparatus (operating room tables)</td>

 </tr>
 <tr>
  <td>3841</td>
  <td>Surgical and Medical Instruments and Apparatus (tranquilizer guns)</td>

 </tr>
 <tr>
  <td>8713</td>
  <td>Surveying Services (except geophysical surveying)</td>

 </tr>
 <tr>
  <td>8713</td>
  <td>Surveying Services (geophysical surveying )</td>

 </tr>
 <tr>
  <td>3613</td>
  <td>Switchgear and Switchboard Apparatus</td>

 </tr>
 <tr>
  <td>2822</td>
  <td>Synthetic Rubber</td>

 </tr>
 <tr>
  <td>3795</td>
  <td>Tanks and Tank Components</td>

 </tr>
 <tr>
  <td>7291</td>
  <td>Tax Return Preparation Services</td>

 </tr>
 <tr>
  <td>4121</td>
  <td>Taxicabs</td>

 </tr>
 <tr>
  <td>4822</td>
  <td>Telegraph and Other Message Communications</td>

 </tr>
 <tr>
  <td>3661</td>
  <td>Telephone and Telegraph Apparatus (consumer external modems)</td>

 </tr>
 <tr>
  <td>3661</td>
  <td>Telephone and Telegraph Apparatus (except consumer external modems)</td>

 </tr>
 <tr>
  <td>4813</td>
  <td>Telephone CommunicationsExcept
  Radiotelephone (except resellers)</td>

 </tr>
 <tr>
  <td>4813</td>
  <td>Telephone CommunicationsExcept
  Radiotelephone (resellers)</td>

 </tr>
 <tr>
  <td>4833</td>
  <td>Television Broadcasting
  Stations </td>

 </tr>
 <tr>
  <td>4231</td>
  <td>Terminal and Joint Terminal Maintenance Facilities for Motor Freight
  Transportation</td>

 </tr>
 <tr>
  <td>4173</td>
  <td>Terminal and Service Facilities for Motor Vehicle Passenger
  Transportation</td>

 </tr>
 <tr>
  <td>1743</td>
  <td>TerrazzoTile  Marble �
   and Mosaic Work (except fresco work)</td>

 </tr>
 <tr>
  <td>1743</td>
  <td>TerrazzoTile  Marble �
   and Mosaic Work (fresco work)</td>

 </tr>
 <tr>
  <td>8734</td>
  <td>Testing Laboratories (except veterinary testing laboratories)</td>

 </tr>
 <tr>
  <td>8734</td>
  <td>Testing Laboratories (veterinary testing laboratories)</td>

 </tr>
 <tr>
  <td>2393</td>
  <td>Textile Bags</td>

 </tr>
 <tr>
  <td>2299</td>
  <td>Textile Goods NEC (broadwoven
  fabrics of jutelinen  hemp �
   and ramie and hand woven fabrics)</td>

 </tr>
 <tr>
  <td>2299</td>
  <td>Textile Goods NEC (finishing hard
  fiber thread and yarn without manufacturing thread or yarn)</td>

 </tr>
 <tr>
  <td>2299</td>
  <td>Textile Goods NEC (hemp bags made
  in spinning mills)</td>

 </tr>
 <tr>
  <td>2299</td>
  <td>Textile Goods NEC (manufacturing
  other textile products)</td>

 </tr>
 <tr>
  <td>2299</td>
  <td>Textile Goods NEC (manufacturing
  thread of hemplinen  and ramie)</td>

 </tr>
 <tr>
  <td>2299</td>
  <td>Textile Goods NEC (narrow woven
  fabric of jutelinen  hemp �
   and ramie)</td>

 </tr>
 <tr>
  <td>2299</td>
  <td>Textile Goods NEC (nonwoven felt)</td>

 </tr>
 <tr>
  <td>2299</td>
  <td>Textile Goods NEC (spinning yarn
  of flaxhemp  jute �
   and ramie)</td>

 </tr>
 <tr>
  <td>3552</td>
  <td>Textile Machinery</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Picture) and Miscellaneous Theatrical
  Services (casting agencies and television employment agencies)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Picture) and Miscellaneous Theatrical
  Services (producers of radio programs)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Picture) and Miscellaneous Theatrical
  Services (theater operators)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Picture) and Miscellaneous Theatrical
  Services (theatrical agents)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Picture) and Miscellaneous Theatrical
  Services (theatrical costume design)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Picture) and Miscellaneous Theatrical
  Services (theatrical equipment rental)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Picture) and Miscellaneous Theatrical
  Services (theatrical promoters)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Picture) and Miscellaneous Theatrical
  Services (theatrical ticket agencies)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Pictures) and Miscellaneous
  Theatrical Services (ballet and dance companies)</td>

 </tr>
 <tr>
  <td>7922</td>
  <td>Theatrical Producers (Except Motion Pictures) and Miscellaneous
  Theatrical Services (theater companies �
   opera companies)</td>

 </tr>
 <tr>
  <td>2284</td>
  <td>Thread Mills (except finishing thread without manufacturing thread)</td>

 </tr>
 <tr>
  <td>2284</td>
  <td>Thread Mills (finishing thread without manufacturing thread)</td>

 </tr>
 <tr>
  <td>811</td>
  <td>Timber Tracts (long term timber farms)</td>

 </tr>
 <tr>
  <td>811</td>
  <td>Timber Tracts (short rotation woody crops)</td>

 </tr>
 <tr>
  <td>2296</td>
  <td>Tire Cord and Fabrics</td>

 </tr>
 <tr>
  <td>7534</td>
  <td>Tire Retreading and Repair Shops (rebuilding tires and retreaded tire
  manufacturing)</td>

 </tr>
 <tr>
  <td>7534</td>
  <td>Tire Retreading and Repair Shops (tire repair)</td>

 </tr>
 <tr>
  <td>3011</td>
  <td>Tires and Inner Tubes</td>

 </tr>
 <tr>
  <td>5014</td>
  <td>Tires and Tubes (agents and brokers)</td>

 </tr>
 <tr>
  <td>5014</td>
  <td>Tires and Tubes (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5014</td>
  <td>Tires and Tubes (merchant wholesalers except those selling via retail
  method)</td>

 </tr>
 <tr>
  <td>5014</td>
  <td>Tires and Tubes (tires and tubes sold via retail method)</td>

 </tr>
 <tr>
  <td>6541</td>
  <td>Title Abstract Offices</td>

 </tr>
 <tr>
  <td>6361</td>
  <td>Title Insurance (reinsurers)</td>

 </tr>
 <tr>
  <td>6361</td>
  <td>Title Insurance (title insurers-direct)</td>

 </tr>
 <tr>
  <td>132</td>
  <td>Tobacco</td>

 </tr>
 <tr>
  <td>5194</td>
  <td>Tobacco and Tobacco Products (agents and brokers)</td>

 </tr>
 <tr>
  <td>5194</td>
  <td>Tobacco and Tobacco Products (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5194</td>
  <td>Tobacco and Tobacco Products (merchant wholesalers except those selling
  tobacco and tobacco products via retail method)</td>

 </tr>
 <tr>
  <td>5194</td>
  <td>Tobacco and Tobacco Products (sold via retail method)</td>

 </tr>
 <tr>
  <td>2141</td>
  <td>Tobacco Stemming and Redrying (reconstituted tobacco)</td>

 </tr>
 <tr>
  <td>2141</td>
  <td>Tobacco Stemming and Redrying (stemming and redrying tobacco)</td>

 </tr>
 <tr>
  <td>5993</td>
  <td>Tobacco Stores and Stands</td>

 </tr>
 <tr>
  <td>7532</td>
  <td>TopBody  and Upholstery Repair Shops and Paint
  Shops</td>

 </tr>
 <tr>
  <td>3824</td>
  <td>Totalizing Fluid Meters and Counting Devices</td>

 </tr>
 <tr>
  <td>4725</td>
  <td>Tour Operators</td>

 </tr>
 <tr>
  <td>4492</td>
  <td>Towing and Tugboat Services </td>

 </tr>
 <tr>
  <td>5092</td>
  <td>Toys and Hobby Goods and Supplies (agents and brokers)</td>

 </tr>
 <tr>
  <td>5092</td>
  <td>Toys and Hobby Goods and Supplies (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5092</td>
  <td>Toys and Hobby Goods and Supplies (merchant wholesalers except those
  selling toys and hobby goods and supplies via retail method)</td>

 </tr>
 <tr>
  <td>5092</td>
  <td>Toys and Hobby Goods and Supplies (toys and hobby goods and supplies sold
  via retail method)</td>

 </tr>
 <tr>
  <td>3799</td>
  <td>Transportation Equipment NEC
  (automobileboat  utility and light truck trailers)</td>

 </tr>
 <tr>
  <td>3799</td>
  <td>Transportation Equipment NEC
  (except automobileboat  utility light truck trailers  trailer hitches   and wheelbarrows)</td>

 </tr>
 <tr>
  <td>3799</td>
  <td>Transportation Equipment NEC
  (trailer hitches)</td>

 </tr>
 <tr>
  <td>3799</td>
  <td>Transportation Equipment NEC
  (wheelbarrows)</td>

 </tr>
 <tr>
  <td>5088</td>
  <td>Transportation Equipment and Supplies �
   Except Motor Vehicles (agents and brokers)</td>

 </tr>
 <tr>
  <td>5088</td>
  <td>Transportation Equipment and Supplies �
   Except Motor Vehicles (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5088</td>
  <td>Transportation Equipment and Supplies �
   Except Motor Vehicles (merchant wholesalers)</td>

 </tr>
 <tr>
  <td>4789</td>
  <td>Transportation Services NEC (car
  loading and unloadingcleaning of
  railroad ballast</td>

 </tr>
 <tr>
  <td>4789</td>
  <td>Transportation Services NEC
  (dining car operations on a fee or contract basis)</td>

 </tr>
 <tr>
  <td>4789</td>
  <td>Transportation Services NEC
  (horse-drawn cabs and carriages)</td>

 </tr>
 <tr>
  <td>4789</td>
  <td>Transportation Services NEC
  (pipeline terminals and stockyards for transportation)</td>

 </tr>
 <tr>
  <td>4724</td>
  <td>Travel Agencies</td>

 </tr>
 <tr>
  <td>3792</td>
  <td>Travel Trailers and Campers</td>

 </tr>
 <tr>
  <td>173</td>
  <td>Tree Nuts</td>

 </tr>
 <tr>
  <td>3713</td>
  <td>Truck and Bus Bodies</td>

 </tr>
 <tr>
  <td>7513</td>
  <td>Truck Rental and Leasing Without Drivers</td>

 </tr>
 <tr>
  <td>3715</td>
  <td>Truck Trailers</td>

 </tr>
 <tr>
  <td>4213</td>
  <td>TruckingExcept Local (general
  freightless than truckload)</td>

 </tr>
 <tr>
  <td>4213</td>
  <td>TruckingExcept Local (general
  freighttruckload)</td>

 </tr>
 <tr>
  <td>4213</td>
  <td>TruckingExcept Local (household
  goods moving)</td>

 </tr>
 <tr>
  <td>4213</td>
  <td>TruckingExcept Local
  (specialized freight)</td>

 </tr>
 <tr>
  <td>6733</td>
  <td>TrustsExcept Educational  Religious �
   and Charitable (administrators of private estates)</td>

 </tr>
 <tr>
  <td>6733</td>
  <td>TrustsExcept Educational  Religious �
   and Charitable (managers)</td>

 </tr>
 <tr>
  <td>6733</td>
  <td>TrustsExcept Educational  Religious �
   and Charitable (personal trusts �
   estatesand agency accounts)</td>

 </tr>
 <tr>
  <td>6733</td>
  <td>TrustsExcept Educational  Religious �
   and Charitable (vacation funds for employees)</td>

 </tr>
 <tr>
  <td>253</td>
  <td>Turkeys and Turkey Eggs</td>

 </tr>
 <tr>
  <td>2791</td>
  <td>Typesetting</td>

 </tr>
 <tr>
  <td>2674</td>
  <td>Uncoated Paper and Multiwall Bags</td>

 </tr>
 <tr>
  <td>6726</td>
  <td>Unit Investment Trusts �
   Face-Amount Certificate Offices �
   and Closed-End Management Investment Offices</td>

 </tr>
 <tr>
  <td>4311</td>
  <td>United States Postal Service</td>

 </tr>
 <tr>
  <td>3081</td>
  <td>Unsupported Plastics Film and Sheet</td>

 </tr>
 <tr>
  <td>3082</td>
  <td>Unsupported Plastics Profile Shapes</td>

 </tr>
 <tr>
  <td>1094</td>
  <td>Uranium-Radium-Vanadium Ores</td>

 </tr>
 <tr>
  <td>5932</td>
  <td>Used Merchandise Stores (except pawn shops)</td>

 </tr>
 <tr>
  <td>5932</td>
  <td>Used Merchandise Stores (pawnshops)</td>

 </tr>
 <tr>
  <td>7519</td>
  <td>Utility Trailers and Recreational Vehicle Rental</td>

 </tr>
 <tr>
  <td>3494</td>
  <td>Valves and Pipe Fittings NEC
  (except metal pipe hangers and supports)</td>

 </tr>
 <tr>
  <td>3494</td>
  <td>Valves and Pipe Fittings NEC
  (metal pipe hangers and supports)</td>

 </tr>
 <tr>
  <td>5331</td>
  <td>Variety Stores</td>

 </tr>
 <tr>
  <td>2076</td>
  <td>Vegetable Oil MillsExcept
  CornCottonseed  and Soybean (oilseed processing)</td>

 </tr>
 <tr>
  <td>2076</td>
  <td>Vegetable Oil MillsExcept
  CornCottonseed  and Soybean (processing purchased
  vegetable and oilseed oils)</td>

 </tr>
 <tr>
  <td>161</td>
  <td>Vegetables and Melons</td>

 </tr>
 <tr>
  <td>3647</td>
  <td>Vehicular Lighting Equipment</td>

 </tr>
 <tr>
  <td>742</td>
  <td>Veterinary Services for Animal Specialties</td>

 </tr>
 <tr>
  <td>741</td>
  <td>Veterinary Services for Livestock</td>

 </tr>
 <tr>
  <td>7841</td>
  <td>Video Tape Rental</td>

 </tr>
 <tr>
  <td>3261</td>
  <td>Vitreous China Plumbing Fixtures and China and Earthenware Fittings and
  Bathroom Accessories</td>

 </tr>
 <tr>
  <td>3262</td>
  <td>Vitreous China Table and Kitchen Articles</td>

 </tr>
 <tr>
  <td>8249</td>
  <td>Vocational Schools NEC (aviation
  schoolsexcluding flying instruction)</td>

 </tr>
 <tr>
  <td>8249</td>
  <td>Vocational Schools NEC (except
  aviation and flight training and apprenticeship training)</td>

 </tr>
 <tr>
  <td>8249</td>
  <td>Vocational Schools NEC
  (vocational apprenticeship training)</td>

 </tr>
 <tr>
  <td>5075</td>
  <td>Warm Air Heating and Air-Conditioning Equipment and Supplies (agents and
  brokers)</td>

 </tr>
 <tr>
  <td>5075</td>
  <td>Warm Air Heating and Air-Conditioning Equipment and Supplies (business to
  business electronic markets)</td>

 </tr>
 <tr>
  <td>5075</td>
  <td>Warm Air Heating and Air-Conditioning Equipment and Supplies (merchant
  wholesalers)</td>

 </tr>
 <tr>
  <td>7631</td>
  <td>WatchClock  and Jewelry Repair (except new retail
  sales combined with repair services)</td>

 </tr>
 <tr>
  <td>7631</td>
  <td>WatchClock  and Jewelry Repair (new retail sales
  combined with repair-repair services as major source of receipts)</td>

 </tr>
 <tr>
  <td>3873</td>
  <td>WatchesClocks  Clockwork Operated Devices  and Parts</td>

 </tr>
 <tr>
  <td>1623</td>
  <td>WaterSewer  Pipeline �
   and Communications and Power Line Construction (gas and oil
  pipelinesmains  and pumping stations)</td>

 </tr>
 <tr>
  <td>1623</td>
  <td>WaterSewer  Pipeline �
   and Communications and Power Line Construction (power and
  communications transmission lines)</td>

 </tr>
 <tr>
  <td>1623</td>
  <td>WaterSewer  Pipeline �
   and Communications and Power Line Construction (water and sewer
  pipelines and related construction)</td>

 </tr>
 <tr>
  <td>4941</td>
  <td>Water Supply</td>

 </tr>
 <tr>
  <td>4449</td>
  <td>Water Transportation of Freight � NEC</td>

 </tr>
 <tr>
  <td>4489</td>
  <td>Water Transportation of Passengers � NEC (airboatsexcursion
  boatsand sightseeing boats)</td>

 </tr>
 <tr>
  <td>4489</td>
  <td>Water Transportation of Passengers � NEC (water taxi)</td>

 </tr>
 <tr>
  <td>4499</td>
  <td>Water Transportation Services NEC
  (all but lighthouse operations �
   piloting vessels in and out of harbors   boat and ship rental �
   marine salvagelighterage  marine surveyor services  and canal operations)</td>

 </tr>
 <tr>
  <td>4499</td>
  <td>Water Transportation Services NEC
  (boat and ship rentalcommercial)</td>

 </tr>
 <tr>
  <td>4499</td>
  <td>Water Transportation Services NEC
  (lighterage)</td>

 </tr>
 <tr>
  <td>4499</td>
  <td>Water Transportation Services NEC
  (lighthouse and canal operations)</td>

 </tr>
 <tr>
  <td>4499</td>
  <td>Water Transportation Services NEC
  (marine surveying services)</td>

 </tr>
 <tr>
  <td>4499</td>
  <td>Water Transportation Services NEC
  (piloting vessels in and out of harbors and marine salvage)</td>

 </tr>
 <tr>
  <td>1781</td>
  <td>Water Well Drilling</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (accessories �
   such as apronsbibs  and other miscellaneous waterproof
  itemsmade from rubberized
  fabricplastics  etc. except contractors)</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (infants' waterproof outerwear made from rubberized
  fabricplastics  etc. except contractors)</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (men's and boys' contractors)</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (men's and boys' water resistant or water repellent
  nontailored outerwearexcept made
  from rubberized fabricplastics  etc. and contractors)</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (men's and boys' water resistant or water repellent
  tailored overcoatsexcept  made from rubberized fabric  plastics �
   etc. and contractors)</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (men's �
   boys'women's  and Girl's waterproof outerwear made from
  rubberized fabricplastics  etc. except contractors)</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (other women's and Girl's water resistant or water
  repellent nontailored outerwear �
   except made fromrubberized
  fabricplastics  etc. and contractors)</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (women's �
   Girl'sand infants'
  contractors)</td>

 </tr>
 <tr>
  <td>2385</td>
  <td>Waterproof Outerwear (women's and Girl's water resistant or water
  repellent tailored coatsexcept made
  from rubberized fabricplastics  etc. and contractors)</td>

 </tr>
 <tr>
  <td>2257</td>
  <td>Weft Knit Fabric Mills (except finishing without knitting weft fabric)</td>

 </tr>
 <tr>
  <td>2257</td>
  <td>Weft Knit Fabric Mills (finishing weft fabric without knitting weft
  fabric)</td>

 </tr>
 <tr>
  <td>7692</td>
  <td>Welding Repair</td>

 </tr>
 <tr>
  <td>2046</td>
  <td>Wet Corn Milling (except refining purchased corn oil)</td>

 </tr>
 <tr>
  <td>2046</td>
  <td>Wet Corn Milling (refining purchased corn oil)</td>

 </tr>
 <tr>
  <td>111</td>
  <td>Wheat</td>

 </tr>
 <tr>
  <td>5182</td>
  <td>Wine and Distilled Alcoholic Beverages (agents and brokers)</td>

 </tr>
 <tr>
  <td>5182</td>
  <td>Wine and Distilled Alcoholic Beverages (business to business electronic
  markets)</td>

 </tr>
 <tr>
  <td>5182</td>
  <td>Wine and Distilled Alcoholic Beverages (merchant wholesalers except those
  selling wine and distilled beverages via retail method)</td>

 </tr>
 <tr>
  <td>5182</td>
  <td>Wine and Distilled Alcoholic Beverages (wine and distilled alcoholic
  beverages sold via retail method)</td>

 </tr>
 <tr>
  <td>2084</td>
  <td>WinesBrandy  and Brandy Spirits</td>

 </tr>
 <tr>
  <td>3495</td>
  <td>Wire Springs (clock and watch springs)</td>

 </tr>
 <tr>
  <td>3495</td>
  <td>Wire Springs (except watch and clock springs)</td>

 </tr>
 <tr>
  <td>5137</td>
  <td>Women'sChildren's  and Infants' Clothing and Accessories
  (agents and brokers)</td>

 </tr>
 <tr>
  <td>5137</td>
  <td>Women'sChildren's  and Infants' Clothing and Accessories
  (business to business electronic markets)</td>

 </tr>
 <tr>
  <td>5137</td>
  <td>Women'sChildren's  and Infants' Clothing and Accessories
  (merchant wholesalers except wholesaling athletic uniforms and uniforms and
  merchant wholesalers selling work clothing via retail method)</td>

 </tr>
 <tr>
  <td>5137</td>
  <td>Women'sChildren's  and Infants' Clothing and Accessories
  (uniforms and work clothing sold via retail method)</td>

 </tr>
 <tr>
  <td>2331</td>
  <td>Women'sMisses'  and Juniors' Blouses and Shirts
  (contractors)</td>

 </tr>
 <tr>
  <td>2331</td>
  <td>Women'sMisses'  and Juniors' Blouses and Shirts (except
  contractors)</td>

 </tr>
 <tr>
  <td>2335</td>
  <td>Women'sMisses'  and Juniors' Dresses (contractors)</td>

 </tr>
 <tr>
  <td>2335</td>
  <td>Women'sMisses'  and Juniors' Dresses (except contractors)</td>

 </tr>
 <tr>
  <td>2339</td>
  <td>Women'sMisses'  and Juniors' Outerwear   NEC (contractors)</td>

 </tr>
 <tr>
  <td>2339</td>
  <td>Women'sMisses'  and Juniors' Outerwear   NEC (except team athletic uniforms  scarves ��
   and contractors)</td>

 </tr>
 <tr>
  <td>2339</td>
  <td>Women'sMisses'  and Juniors' Outerwear   NEC (scarves except contractors)</td>

 </tr>
 <tr>
  <td>2339</td>
  <td>Women'sMisses'  and Juniors' Outerwear   NEC (team athletic uniforms except
  contractors)</td>

 </tr>
 <tr>
  <td>2337</td>
  <td>Women'sMisses'  and Juniors' Suits  Skirts �
   and Coats (contractors)</td>

 </tr>
 <tr>
  <td>2337</td>
  <td>Women'sMisses'  and Juniors' Suits  Skirts �
   and Coats (except contractors)</td>

 </tr>
 <tr>
  <td>2341</td>
  <td>Women'sMisses'  Children's   and Infants' Underwear and Nightwear (boys' contractors)</td>

 </tr>
 <tr>
  <td>2341</td>
  <td>Women'sMisses'  Children's   and Infants' Underwear and Nightwear (boys' except contractors)</td>

 </tr>
 <tr>
  <td>2341</td>
  <td>Women'sMisses'  Children's   and Infants' Underwear and Nightwear (infants' except
  contractors)</td>

 </tr>
 <tr>
  <td>2341</td>
  <td>Women'sMisses'  Children's   and Infants' Underwear and Nightwear (women and Girl's except
  contractors)</td>

 </tr>
 <tr>
  <td>2341</td>
  <td>Women'sMisses'  Children's   and Infants' Underwear and Nightwear (women's  Girl's �
   and infants' contractors)</td>

 </tr>
 <tr>
  <td>5632</td>
  <td>Women's Accessory and Specialty Stores (specialty stores)</td>

 </tr>
 <tr>
  <td>3144</td>
  <td>Women's FootwearExcept Athletic</td>

 </tr>
 <tr>
  <td>2251</td>
  <td>Women's Full-Length and Knee-Length Hosiery   Except Socks (dyeing and finishing sheer hosiery without
  knitting sheer hosiery)</td>

 </tr>
 <tr>
  <td>2251</td>
  <td>Women's Full-Length and Knee-Length Hosiery   Except Socks (except dyeing and finishing sheer hosiery without
  knitting sheer hosiery)</td>

 </tr>
 <tr>
  <td>3171</td>
  <td>Women's Handbags and Purses</td>

 </tr>
 <tr>
  <td>5137</td>
  <td>Women'sChildren's  and Infants' Clothing and Accessories
  (selling a general line of womens clothing via retail method)</td>

 </tr>
 <tr>
  <td>5137</td>
  <td>Women'sChildren's and Infants'
  Clothing and Accessories (merchant wholesalers of athletic uniforms)</td>

 </tr>
 <tr>
  <td>5137</td>
  <td>Women'sChildren's and Infants'
  Clothing and Accessories (selling a general line of children's and infants'
  clothing via retail method)</td>

 </tr>
 <tr>
  <td>5632</td>
  <td>Women's Accessory and Specialty Stores (accessories)</td>

 </tr>
 <tr>
  <td>5621</td>
  <td>Women's Clothing Stores (dress shops and bridal shops)</td>

 </tr>
 <tr>
  <td>5621</td>
  <td>Women's Clothing Stores (except dress shops and bridal shops)</td>

 </tr>
 <tr>
  <td>2449</td>
  <td>Wood Containers NEC</td>

 </tr>
 <tr>
  <td>2511</td>
  <td>Wood Household FurnitureExcept
  Upholstered (except wood box spring frames)</td>

 </tr>
 <tr>
  <td>2511</td>
  <td>Wood Household FurnitureExcept
  Upholstered (wood box spring frames(parts))</td>

 </tr>
 <tr>
  <td>2512</td>
  <td>Wood Household Furniture �
   Upholstered</td>

 </tr>
 <tr>
  <td>2434</td>
  <td>Wood Kitchen Cabinets</td>

 </tr>
 <tr>
  <td>2541</td>
  <td>Wood Office and Store Fixtures �
   PartitionsShelving  and Lockers ( custom architectural
  millwork)</td>

 </tr>
 <tr>
  <td>2541</td>
  <td>Wood Office and Store Fixtures �
   PartitionsShelving  and Lockers (counter tops)</td>

 </tr>
 <tr>
  <td>2541</td>
  <td>Wood Office and Store Fixtures �
   PartitionsShelving  and Lockers (except custom architectural
  millworkcounter tops  and lunchroom tables and chairs)</td>

 </tr>
 <tr>
  <td>2541</td>
  <td>Wood Office and Store Fixtures �
   PartitionsShelving  and Lockers (wood lunchroom tables and
  chairs)</td>

 </tr>
 <tr>
  <td>2521</td>
  <td>Wood Office Furniture</td>

 </tr>
 <tr>
  <td>2448</td>
  <td>Wood Pallets and Skids</td>

 </tr>
 <tr>
  <td>2491</td>
  <td>Wood Preserving</td>

 </tr>
 <tr>
  <td>2499</td>
  <td>Wood Products NEC (cork life
  preservers)</td>

 </tr>
 <tr>
  <td>2499</td>
  <td>Wood Products NEC (except wood
  containerswood cooling towers  cork life preservers  mirror or picture frames  and laundry hampers of reed  rattan �
   and willow)</td>

 </tr>
 <tr>
  <td>2499</td>
  <td>Wood Products NEC (laundry
  hampers of reedrattan  and willow)</td>

 </tr>
 <tr>
  <td>2499</td>
  <td>Wood Products NEC (mirror and
  picture frames)</td>

 </tr>
 <tr>
  <td>2499</td>
  <td>Wood Products NEC (wood
  containerssuch as noncoopered vats
  and reed or straw baskets)</td>

 </tr>
 <tr>
  <td>2499</td>
  <td>Wood Products NEC (wood cooling
  towers)</td>

 </tr>
 <tr>
  <td>2517</td>
  <td>Wood TelevisionRadio  Phonograph   and Sewing Machine Cabinets</td>

 </tr>
 <tr>
  <td>3553</td>
  <td>Woodworking Machinery</td>

 </tr>
 <tr>
  <td>1795</td>
  <td>Wrecking and Demolition Work</td>

 </tr>
 <tr>
  <td>3844</td>
  <td>X-Ray Apparatus and Tubes and Related Irradiation Apparatus</td>
 </tr>

 <tr>
  <td>2281</td>
  <td>Yarn Spinning Mills</td>
 </tr>

 <tr>
  <td>2282</td>
  <td>Yarn
  TexturizingThrowing  Twisting and Winding Mills </td>
 </tr>
</table>