<?
    if(($User_ID !="") && ($CompName !=""))
    {
      if($CookieYears <= .01)
	  {
		if(COOKIE_YEAR < 1)
			$CookieYears = 1;
		else
	 		$CookieYears = COOKIE_YEAR;
	   }
	   $CookieTime = time() +  ($CookieYears*31536000);
       $CookieSuccess = setcookie("User_ID", $User_ID, $CookieTime , '/' );
       setcookie("CompName", stripslashes($CompName), $CookieTime , '/' ); // almost a year
	   setcookie("Username", $Username, $CookieTime , '/' );
    }
?>