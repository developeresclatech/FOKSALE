 <div id="manager_links">	
     <a href="SearchQueriesView.php" class="">Search Query Monitor</a> |  <a href="./">Manager</a> |  <a href="/">Site Home</a> |  <a href="/consumer_records_search.php">Consumer</a> | <a href="/business_records_search.php">Business</a> | <a href="customer_data_manager.php" class="">Customer Data</a>
 </div>