<? include_once("includes/resetPassword.php"); ?>
<table width="700" style="font-size:10pt;" id="tblLogin">
	<tr>
    	<td width="50%">
        	<table width="304" align="center" class="tabcls" >
            	<tr>
					<td align="center" colspan="2"  height="10">
				       <p><strong style="">If Previously Registered, Login Here </strong></p>
                    </td>
                </tr>
                <tr>
	                <td width="55%" align="right" height="25">
					    <label for="frmUsername"><span class="style1">Username</span><span class="required">*</span>:</label>
				    </td>
	 			    <td width="45%" align="left"> 
				   	<input type="text"  class="text" name="frmUsername"  id="frmUsername" size="16" maxlength = "16" tabindex="1"/>
			  		</td>
                </tr>
                <tr>
                  	<td align="right" height="25">
                    	<label for="CPassword"><span class="style1">Enter Password</span><span class="required">*</span>:</label>
                  	</td>
                  	<td align="left"> 
                    	<input class="text" type="password" name="frmCPassword"  id="frmCPassword" size="16" maxlength = "16"  tabindex="2" /> 
                  	</td>                
                </tr>
               <tr>
               	<td  align="center" width="26%" height="50">&nbsp;</td>
               <td align="left"><input type="submit" value="Login" name="cmdLogin" id="cmdLogin" style="width:100px ;color:#000066;" title="Login Here if previously registered" accesskey="p"  tabindex="3" />
               </td>
               </tr>
            </table>
      </td>
        
        <td width="50%">
        	<table width="100%" align="center" class="tabcls" >
            	<tr>
                	<td colspan="2" align="center" height="10">
				    	<p><strong style="">Lost Your Password? Reset it Here.	</strong></p> 
                    </td>
                </tr>
                <tr>
                	<td align="right" width="55%" height="25">
                        <label for="frmEmail"><span class="style1">Email on File</span><span class="required">*</span>:</label>
                  </td>
                      <td align="left" width="45%"> 
                        <input type="text" name="frmEmail"  id="frmEmail" size="16" maxlength = ""  tabindex="4"/>
                      </td>
                </tr>
                <tr>
                	<td align="right" height="25">
                         <label for="frmUsername2"><span class="style1">Or Username</span><span class="required">*</span>:</label>
                  </td>
                      <td align="left"> 
                        <input type="text" name="frmUsername2"  id="frmUsername2" size="16" maxlength = "16"  tabindex="5" /> 
                      </td>
                </tr>
                <tr>
                	<td colspan="2" align="center" height="50">
						<input type="submit" value="Reset Your Password" name="subResetPW" id="subResetPW" style="width:180px ;color:#000066; padding-top:-10px" title="Reset your password, or alt-z" accesskey="z"  tabindex="5"  />
					</td>
                </tr>
            </table>
      </td>
    </tr>       
</table>
<h2><?=$_SESSION['login'] ;?>&nbsp;</h2><br />