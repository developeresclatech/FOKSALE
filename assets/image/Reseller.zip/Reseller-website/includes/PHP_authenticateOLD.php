<?php
  if(1)//$_SERVER['PHP_AUTH_USER']  !=  PHP_AUTH_USER || $_SERVER['PHP_AUTH_PW'] !=  PHP_AUTH_PW ) 
  {
    header('WWW-Authenticate: Basic realm="Website Management Section"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'You need to login with proper username and password to gain access to this page'.PHP_AUTH_USER.",  ".PHP_AUTH_PW;
    exit;
 } 
  else 
 {
    $welcomeMessage = "<h3>Hello , welcome to the Customer Management  Suite</h3>".PHP_AUTH_USER.",  ".PHP_AUTH_PW;
   // echo "<p>You entered {$_SERVER['PHP_AUTH_PW']} as your password.</p>";
 }
?>