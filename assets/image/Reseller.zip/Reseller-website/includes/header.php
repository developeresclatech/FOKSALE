 <!--  begin header  -->
<div align="center" id="divCenter"><a name="top"></a>
<div id="header" align="center">
   <div class="container">
      <div class="row-1">
       <div class="fleft"><a href="/"><img src="images/logo.png" alt="logo" title="<?=$SiteName;  ?> logo, click for home"></a></div>
       <!-- <div class="fleft" style="padding:20px 0 0 200px;">&nbsp;<?  //  if(!User_ID)  include("includes/login_top.php"); else echo "&nbsp;";?></div> -->
       <div class="fright">
<?
	if($User_ID)
	{
	   echo "<div id='divGreeting'><a href='customer_profile.php'>Welcome Back, $CompName</a> <a href='".SELF."?LO=1' style='display: inline;'>Log Out</a></div>\n";
	 }
	 else{
	  include("includes/login_top.php");
	 }
?>
         </div>
      </div>
      <div class="row-2">
        <? include("includes/menu-bar.php"); ?>
      </div>
   </div>
</div>
<div class="tail-middle1">
<div id="divContentALL" style="padding: 0 50px; color:#FFF; width:890px;">
