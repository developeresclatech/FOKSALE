<div align="left">
    <? if ($CompID) {
        include_once(ROOT . "/includes/resetPassword.php"); ?>
        <form method="post" action="<?= SELF2; ?>" name="frmLoginSmall" id="frmLoginSmall">
            <div id="tblLoginSmall" class="logn_slide">
                <div class="se-1">
                    <a class="button button-sm button-default-outline button-winona" style="height:27px; visibility:hidden;"
                        href="customer_data.php"><i class="bi bi-person"></i>Create Account</a> &nbsp;&nbsp;<a
                        href="javascript:void(0)" class="button button-sm button-default-outline button-winona"
                        style="height:27px; font-size: 1.1rem"><i
                            class="bi bi-box-arrow-in-right"></i><!-- <span class="yesShow">DBEM: </span>noShow -->Login /
                        Create &nbsp;Profile</a>
                </div>
           
            </div>
            <div id="tblLoginSmall2">
                <div class="login_user_input">
                    <h4 class="text-center" style="font-weight: 700;">Login</h4>
                    <div><label for="frmUsername1">Username:</label> <input type="text" name="frmUsername" id="frmUsername1"
                            size="16" maxlength="16" placeholder="Username"><br></div>
                    <div><label for="frmCPassword1">Password:</label> <input type="password" name="frmCPassword"
                            id="frmCPassword1" size="16" maxlength="16" placeholder="Password"></div>
                    <div align="center"><input type="submit" name="cmdLogin" id="cmdLogin" value="Login" accesskey="l"
                            title="Login to your account"><br>
                        <span class="or">OR</span>
                        <a href="/customer_data.php"><b>Create a Profile</b></a>
                    </div>
                </div>
            </div>
            <?
            if ($_SESSION['login'])
                echo "<h4>" . $_SESSION['login'] . "</h4>";
            ?>
        </form>
    <? } else
        echo "<div><a class=\"button button-sm button-default-outline button-winona btn-user\" href=\"customer_data.php\" title='Manage Your Profile' id='buttLoggedIn'><i class=\"bi bi-person\"></i>Hello, $CompName</a></div>"; ?>
</div>