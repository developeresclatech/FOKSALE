<? //this code snipppet is on top of any file, before any HTML or doctype stuff, or it will bomb, 8/17/2006, JDF
    {
        $CC1 = setcookie("CompName", "FUCK", time() -15000, '/' ); 
        $CC2= setcookie("User_ID", "YOU", time() -15000, '/' );
        $CC3 = setcookie("Username", "ASS", time() -15000, '/' );
	   //header("Location: ".$_SERVER['PHP_SELF']);
	   //echo "LO";
    }
?>