<!-- new nav bar 23-aug-2024 -->
<!-- <link rel="stylesheet" type="text/css" href="https://dbe.bss.design/assets/bootstrap/css/bootstrap.min.css?h=a549af2a81cd9900ee897d8bc9c4b5e9"> -->


<nav class="navbar navbar-expand-md sticky-top bg-secondary-subtle shadow sellernav">
    <div class="container-fluid">
        <a class="navbar-brand gettrustlogo" href="index.php">
            <img src="/images/getTrustAdviceLogo.jpeg" alt="gettrustlogo">
        </a>
        <button data-bs-toggle="collapse" data-bs-target="#navcol-1" class="navbar-toggler"><span class="visually-hidden">Toggle navigation</span>
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse datasearchclass" id="navcol-1">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#">Free Data Searches Here</a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="/consumer_records_search.php">Consumer Opt-in Email 576+ Million 23 Data Fields</a>
                        <a class="dropdown-item" href="/business_records_search.php">Business Data 240+ Million SIC &amp; NAICS Codes, Titles Revenue</a>
                        <a class="dropdown-item" href="/non_email_consumer_records_search.php">Consumer Phone &amp; Postal 220+ Million 216 Data Fields</a>
                        <a class="dropdown-item" href="/cell_phone_search.php">Cell Phones SMS Texting 250 Million Data Query</a>
                        <a class="dropdown-item" href="/purchase_software_data.php">Purchase Software Data</a>
                        <a class="dropdown-item" href="/vehicle.php">Vehicles 100 Million</a>

                        <a class="dropdown-item" href="/software.php">Software</a>

                        <a class="dropdown-item" href="#">Close Menu</a></div>
                </li>


               <li class="nav-item dropdown">
                    <a class="dropdown-toggle nav-link" aria-expanded="false" data-bs-toggle="dropdown" href="#">Login / Create&nbsp;Profile</a>
                    <div class="dropdown-menu p-4">
                        <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>" name="frmLoginSmall" id="frmLoginSmall">
                            <div class="mb-3">
                                <label for="frmUsername1" class="form-label">Username:</label>
                                <input type="text" class="form-control" name="frmUsername" id="frmUsername1" maxlength="16" placeholder="Enter username" />
                            </div>
                            <div class="mb-3">
                                <label for="frmCPassword1" class="form-label">Password:</label>
                                <input type="password" class="form-control" name="frmCPassword" id="frmCPassword1" maxlength="16" placeholder="Enter password" />
                            </div>
                            <div class="d-grid gap-2">
                                <input type="submit" class="btn btn-primary" name="cmdLogin" id="cmdLogin" value="Login" title="Login to your account" />
                            </div>
                            <div class="mt-3 text-center">
                                <span class="or">OR</span><br />
                                <a href="/customer_profile.php">Create a Profile</a>
                            </div>
                            <div class="mt-3">
                                <h4 class="text-center"><?= $_SESSION['login']; ?></h4>
                            </div>
                        </form>
                    </div>
                </li>


            </ul>
        </div>
    </div>
</nav>
<script type="text/javascript">
    $(document).ready(function() {
    // Toggle the login form when clicking on "Login / Create Profile"
    $('#toggleLogin').click(function() {
        $('#tblLoginSmall2').toggle(); // Show or hide the form
    });
});

</script>

<!-- new search other tab option -->
<section class="d-flex py-xl-5" style="margin-top: 0px;background: rgba(255,255,255,0.5);padding-top: 0px!important;border: none;max-height: none;height: auto;">
        <!-- Start: Hero Parallax -->
        <section class="d-flex flex-row flex-grow-1 align-items-start flex-wrap justify-content-sm-center" data-bss-parallax-bg="true" style="background: transparent; min-height: auto; height: auto; position: relative; overflow: hidden;">
            <div class="d-flex flex-column align-items-center flex-wrap align-items-xxl-center" style="/*height: 600px;*/padding-top: 50px;">

                 <!-- Top images -->
                <div class="row d-flex d-md-flex flex-row">
                    <div class="col-md-12 p-2 mb-2" style="text-align: center;">
                        <!-- <img src="https://www.databaseemailer.com/images/logo.png" width=""> -->
                        <img class="img-fluid" src="/images/microsoft-partner.png" width="231" height="81">
                    </div>
                </div>

                <div class="container d-flex justify-content-center flex-wrap h-100 sec1">
                    <div class="row d-flex flex-row pb-lg-4">
                        <div class="w-100"></div>

                         <!-- left section -->
                        <div class="col-md-6 col-xxl-6 text-center text-md-start d-flex d-sm-flex d-md-flex flex-column justify-content-center align-items-center my-auto justify-content-md-start align-items-md-center justify-content-xl-center justify-content-xxl-center leftsellersection" style="border-radius: 5px;">

                            <!-- Start: AIT Research Award -->
                            <div class="d-flex d-xl-flex flex-column align-items-lg-center py-2 px-4 w-75 shadow atiResearch">
                                <img class="img-fluid mx-5" src="/images/AITResearchAward.png">
                                <p class="text">"The largest opt-in email database in the United States. Opt-in means that people have expressly agreed to receive product offers and specials by email."</p>
                                <a class="d-flex align-self-end" href="https://aitprofiles.wordpress.com/2009/09/29/database-emailer/" target="_blank">Read More</a>
                            </div>
                            <!-- End: AIT Research Award -->

                            <!-- Start: Innovative Solution Award -->
                             <div class="d-flex flex-column flex-grow-1 py-2 px-4 w-75 shadow mt-2" style="background: rgba(255,255,255,0.8);border: 2px solid var(--bs-secondary-bg);border-radius: 10px;">
                                <div class="row">
                                    <div class="col-xl-5 d-xl-flex justify-content-xl-center align-items-xl-center">
                                        <img class="img-fluid" src="/images/2009-Innovative-Solution.gif">
                                    </div>
                                    <div class="col">
                                        <p class="text-center">&nbsp;"The Innovative Solutions Award recognizes solutions that are groundbreaking & provide quantifiable business value for end-users."</p>
                                    </div>
                                </div>
                                <p class="fw-bold mt-2 text-center" style="color:#7f7f7f;">Julie Langekamp, Information Management Magazine Editor-in-chief</p>
                                <p class="fw-bold text-center" style="margin-top: -10px;"></p>
                                 <a class="d-flex align-self-end" href="https://www.pr.com/press-release/194928" target="_blank">Read More</a>
                            </div>

                            <!-- End: Innovative Solution Award -->

                            <!-- Start: Microsoft Partner -->
                            <div class="d-flex flex-column flex-grow-1 py-2 px-4 w-75 shadow mt-2" style="background: rgba(255,255,255,0.8);border: 2px solid var(--bs-secondary-bg);border-radius: 10px;">
                                <div class="row">
                                    <div class="col-xl-5 d-xl-flex justify-content-xl-center align-items-xl-center">
                                        <img class="img-fluid" src="/images/microsoft-partner.png">
                                    </div>
                                    <div class="col">
                                        <p class="fw-bold text-center" style="color: #a90000;">Microsoft Opted-in Emailing<br>Lowest Cost &amp; Best Deliverability</p>
                                    </div>
                                </div>
                                <p class="fw-bold mt-2 text-center microsoft365">Microsoft 365: Only $4.75 per 300,000 using our software!<br>OR<br>Microsoft Emails! Unlimited & No Cost! Use our software! </p>
                                <p class="fw-bold text-center" style="margin-top: -10px;"></p>
                            </div>
                            <!-- End: Microsoft Partner -->
                        </div>

                         <!-- right section -->
                        <div class="col text-center rightOption my-auto">
                            <div class="row d-flex flex-row flex-grow-0 justify-content-around align-content-center">
                                <div class="col-md-5 col-lg-2 col-xxl-5 justify-content-xxl-center col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-2 shadow">
                                    <a href="/consumer_records_search.php">
                                       <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/consumeroptin.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4><strong>Consumer Opt-in Email</strong></h4>
                                            <p style="text-align: center; line-height:20px;" class="mt-2">576+ Million, 23 Data Fields</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-5 col-lg-2 col-xxl-5 justify-content-xxl-center col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-2 shadow">
                                      <a href="/business_records_search.php">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/businessdata.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4><strong>Business Data</strong></h4>
                                            <p style="text-align: center; line-height:20px;" class="mt-2">247+ Million, SIC Codes, Geo Location and More</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-5 col-lg-2 col-xxl-5 justify-content-xxl-center col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-2 shadow">
                                    <a href="/non_email_consumer_records_search.php">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/consumercellphone.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4><strong>Consumer Phone &amp; Postal</strong></h4>
                                            <p style="text-align: center; line-height:20px;" class="mt-2">226+ Million, 216 Data Fields</p>
                                        </div>
                                    </a>
                                </div>

                                 <div class="col-md-3 col-lg-2 col-xxl-5 col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-2 shadow">
                                    <a href="/cell_phone_search.php">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-center mt-2">
                                            <img class="rounded-circle d-md-flex img-fluid" src="/images/consumercell.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4 class="flex-column" style="text-align: center;"><strong>Cell Phone / SMS Numbers</span></strong></h4>
                                            <p class="mt-2" style="text-align: center; line-height:20px;">250 Million</p>
                                        </div>
                                    </a>
                                </div>

                                <div class="col-md-3 col-xxl-5 col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-2 shadow">
                                    <a href="/purchase_software_data.php">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/linkedintarget.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4><strong>Purchase Software Data</strong></h4>
                                            <p class="mt-2" style="text-align: center; line-height:20px;">100 Million</p>
                                        </div>
                                    </a>
                                </div>
                               

                                <div class="col-md-3 col-lg-2 col-xxl-5 col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-2 shadow">
                                    <a href="vehicle.php">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/vehicle.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4 class="justify-content-lg-center" style="text-align: center;"><strong>Vehicles</strong></h4>
                                            <p class="text-center d-lg-flex justify-content-lg-center mt-2" style="text-align: center; line-height:20px;">100 Mllion</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-3 col-lg-2 col-xxl-5 col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-2 shadow">
                                     <a href="/software.php">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/listleakertarget.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4 style=""><strong>Software</strong></h4>
                                            <p class="mt-2" style="text-align: center;line-height:20px;">Export Files</p>
                                        </div>
                                    </a>
                                </div>

                                <div class="col-md-3 col-lg-2 col-xxl-5 col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-2 shadow">
                                    <a href="https://tipscloud.egnyte.com/fl/I4viZ44bES" target="_blank">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/cleanemail.png" width="60px" height="60px"></div>
                                        <h4 style="margin-bottom: 0px;"><strong>Software Downloads</strong></h4>
                                        <p class="mt-2" style="text-align: center;line-height:20px;">Trials Too!</p>
                                    </a>
                                </div>
                                <div class="col-md-3 col-lg-2 col-xxl-5 col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-0 shadow">
                                    <a href="#">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/othercounts.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4 class="flex-column" style=""><strong>See Counts</strong></h4>
                                            <p class="mt-2" style="text-align: center; line-height:20px;">Your Recent Data Queries</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-md-3 col-lg-2 col-xxl-5 col-sm-6 col-md-6 col-lg-6 border border-secondary card-button mb-0 shadow">
                                    <a href="#">
                                        <div class="d-flex d-md-flex justify-content-center justify-content-md-center mt-2">
                                            <img class="rounded-circle img-fluid" src="/images/recentcounts.png" width="60px" height="60px"></div>
                                        <div>
                                            <h4 style=""><strong>See Counts</strong></h4>
                                            <p class="mt-2" style="text-align: center;">Other's Data Queries</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <div style="background-image: url(/images/hero-bg-overlay.jpg); background-size: cover; background-position: center center; position: absolute; height: 200%; width: 100%; top: 0px; left: 0px; z-index: -100; transform: translate3d(0px, -30.7727%, 0px);"></div></section><!-- End: Hero Parallax -->
    </section>

