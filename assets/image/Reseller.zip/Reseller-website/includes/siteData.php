<?php
 $SiteURL = "https://www.siteurl.com";
 error_reporting(E_ERROR | E_WARNING);
 session_start();
 mysqli_report(MYSQLI_REPORT_OFF);
 $antiSpamQuestion = "What is the Current Month in Full? "; //$antiSpamReply
 $antiSpamAnswer = date("F");
 $secure  = 1;
  if($secure > 0) //secure page
  {
	if(!isset($_SERVER['HTTPS']))
	{ 
      header("Location: $SiteURL".$_SERVER['REQUEST_URI']);
	}
	elseif( !stristr($_SERVER['SERVER_NAME'], "www."))
	{ 
      header("Location: $SiteURL".$_SERVER['REQUEST_URI']);
	}
  }
  else//regular non secure 
  {
	if(isset($_SERVER['HTTPS']))
	{ 
      header("Location: $SiteURL");
	}  
	elseif(!stristr($_SERVER['SERVER_NAME'], "www."))
	{ 
      header("Location: $SiteURL".$_SERVER['REQUEST_URI']);
	}
  }
 ///////////////////////// FOR LOGIN //////////////////////////////////////////////////////////////////////////////////////////  2/26/2010
  function checkLogin($dbhi, $Type = 0)
  {
  		 $queryS ="SELECT * FROM  `tblResellerCustomers` WHERE `Username` ='".$_POST['frmUsername']."' AND `CPassword` = PASSWORD('".$_POST['frmCPassword']."')  LIMIT 1  ;  ";
          /* print_r($_POST);
		 echo"<h3>$queryS</h3>"; */
	     $resultsS = mysqli_query($dbhi,$queryS);
		 if(mysqli_num_rows($resultsS))
		 {
             $_SESSION['login_attempts'] = 0;
			 $data = mysqli_fetch_assoc($resultsS);
			 if($data['Stopped'] =='Y')
             {
				 $_SESSION['login'] ="<span style=\"color:red;\">Your Account Has Been Deactivated, Contact Management</span>";
			    return 0;
			 }
			 else
             {
			    extract($data);
				$_SESSION['login'] ="<span style=\"color:green;\">Login Successful!</span>";
 			    include("includes/cookie.php");
			    return $data;
			 }
	     }
		else
	    {
             $_SESSION['login_attempts']++;
			 $_SESSION['login'] ="<span style=\"color:red;\"> Your username or password are incorrect, LOGIN FAILED</span>";
             if($_SESSION['login_attempts'] > 6)
            {
                  $queryStop =  "UPDATE  `tblResellerCustomers` SET Stopped ='Y'  WHERE  `Username` ='".$_POST['frmUsername']."' ; ";
	              $resultsStop = mysqli_query($dbhi,$queryStop);
				  $_SESSION['login'] .="<span style=\"color:red;\">Account Suspended.</span>";
            }
		} // end ELSE
    }
 //////////////////////////////////////////////////////////   END FUNCTION   /////////////////////////////////////////////////////////////////////////////////
   define("SELF", htmlspecialchars($_SERVER['PHP_SELF']));
   if(isset($_GET['LO'])) //LOGOUT HANDLER
   {
      include("./includes/deletecookie.php");
	 //unset($_POST);
	 unset($_POST['User_ID']);
	 unset($_POST['CompName']);
	 unset($_POST['Username']);
	 unset($User_ID);
	 unset($CompName);
	 unset($Username);
     $_SESSION['login'] ="<span style=\"color:green;\">Logged Out</span>";
	 header("location:".SELF);
   }
   elseif(isset($_COOKIE['User_ID']))
   {
	$CompName = trim($_COOKIE['CompName']);
	$Username = trim($_COOKIE['Username']);
	$User_ID = trim($_COOKIE['User_ID']);
   }
   else
   {
	$CompName = "";
	$Username = "";
	$User_ID = 0;
   }
////////////////////   END LOGOUT HANDLER ////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//$PullData = $_COOKIE['PullData'];
	date_default_timezone_set ("America/New_York");
    define("ROOT", $_SERVER['DOCUMENT_ROOT']);
	$CookieYears = 1;
	define("COOKIE_YEAR", $CookieYears);
	if(!isset($_SESSION['RenewCookie']) && $User_ID)
	{
        include(ROOT."/includes/cookie.php");
        $_SESSION['RenewCookie'] = 1;
	}
/////////////////////////////////////////////////////
$cURL_URL = "http://www.databaseemailer.com";

$Reseller_UN = "demo_value";
$Reseller_ID = "XXX";
$SiteName = "Site Name here";
$SiteNameShort = "short_name_here";
$SiteURL = "https://www.siteurl.com";
$SiteAddress = "site_address_here";
$SiteContact = "site_contact_name";
$SiteEmail = "demo@example.com";
$PayPalEmail = "demo@example.com"; 
$SiteEmailFull = "\"$SiteName\"<$SiteEmail>";
$SitePhone = "XXX-XXX-XXXX";

$dbName = "db_name";
$dbHost = 'localhost';
$dbUserName = 'username';
$dbPW = 'password';

$ftp_address = 'demo.example.com';
$ftp_username = 'demo@example.com';
$ftp_pw = 'password_here';
$ftp_dir = 'demo_dir_here/';

define('cURL_URL', $cURL_URL);
define("SITEURL", $SiteURL);
define("dbName", $dbName);
define("dbHost", $dbHost);
define("dbUserName", $dbUserName);
define("dbPW", $dbPW);
define("PHP_AUTH_USER", 'user_name_here');
define("PHP_AUTH_PW", 'password_here');
$ftp_dir ='pulls/';
	////////////////////////////////////////////////////////////////////////
    $SiteEmailFull ="\"$SiteName\"<$SiteEmail>";
	$WebmasterEmail ="demo@example.com";
	// db info

   //dbHost, dbUserName, dbPW, dbName
    define("QDMultiplier", 1.3);
    define("QDMINPRICE", 10.00);
    define("FREECREDITS", 0);
    define("ADDCREDITS", 0);
    define("FC", 0);
	  ///////////////////////////////////////////
	function ClickToCall($ShopPhone, $IH=0)
	{
		 if(!$IH)
			 $IH = $ShopPhone;
		 $str = "<a href=\"tel:";
		 $str .=  preg_replace("/\D/","", $ShopPhone);
		 $str .= "\" title=\"click to call\" class=\"CTC\">$IH</a>";
		 return $str;
	}
//////////////////////////////////////////////
	 function ClickToEmail($ShopEmail, $Name, $InnerHTML="Email Us")
	{
		 $str = "<a href=\"mailto:$ShopEmail?Subject=From $Name Website\" title=\"click to email us\" class=\"CTC\">$InnerHTML</a>";
		 return $str;
	}
///////////////////////////////////////////////
   function functNewPrice($CNR, $dbhi, $debug=0)
   {
            $NOREC = intval($CNR);
			$qQDHi ="SELECT MIN(Item_Price),  MIN(Item_Records) , MIN(Item_ID) FROM tblItems WHERE Item_Records >= $NOREC AND  Item_Type ='data'  AND Active =1  ; ";
			if(!$rQDHi  = mysqli_query($dbhi, $qQDHi))
			{
				echo $qQDHi . mysqli_error($dbhi);
				exit();
			}
			else
			{
                if(mysqli_num_rows($rQDHi))
				{
				  $dQDHi = mysqli_fetch_row($rQDHi);
				  if($dQDHi[0] > 0)
				    $QDRecPriceHi =  ($dQDHi[1]/$dQDHi[0]);
				  $RecordsHi = $dQDHi[1];
				}
				  $qQDLo ="SELECT MAX(Item_Price),  MAX(Item_Records) , MAX(Item_ID)  FROM tblItems WHERE Item_Records < $NOREC AND  Item_Type ='data' AND Active =1  ; ";
					  if(!$rQDLo = mysqli_query($dbhi, $qQDLo))
						  echo"PART 2<BR>".$qQDLo. mysqli_error($dbhi);
					 else
					 {
						  $dQDLo = mysqli_fetch_row($rQDLo);
						  if($dQDLo[0]>0)
						    $QDRecPriceLo =  ($dQDLo[1]/$dQDLo[0]);
				          $RecordsLo = $dQDLo[1];
					 }
				  }
               if($RecordsHi > 0 && $RecordsLo > 0)
			   {
                    $DELTA = ($RecordsHi - $RecordsLo);
					$Multiplier = ($NOREC -  $RecordsLo)/($DELTA);
                    $PriceMultiplierRec = ($QDRecPriceHi - $QDRecPriceLo)*$Multiplier + $QDRecPriceLo;
                    $PriceMultiplier = (1/$PriceMultiplierRec);
			   }
			   elseif(!$RecordsHi) {// More credits than the highest level
			      $QDPriceMult = $QDRecPriceLo;
                  $PriceMultiplier = 1/$QDRecPriceLo;
			   }
			   elseif(!$RecordsLo) {// More credits than the highest level
			      $QDPriceMult = $QDPriceHi;
                  $PriceMultiplier = 1/$QDRecPriceHi;
			   }
              $QDPrice2 = $PriceMultiplier* $NOREC*QDMultiplier;
            if($debug)
				echo"L188  $QDPrice2 = $PriceMultiplier * $NOREC<br />";
			   If($QDPrice2 < QDMINPRICE)
                   $QDPrice2 = QDMINPRICE;
            if($debug)
			  echo"RecordsHi  $RecordsHi | PriceHI \$$dQDHi[0] | QDPriceHi $QDRecPriceHi | RecordsLo $RecordsLo | PriceLo \$$dQDLo[0] | QDPriceLo $QDRecPriceLo | BreakPoint $BreakPoint | QDPriceMult $QDPriceMult | QDPrice \$$QDPrice | QDPrice2 \$$QDPrice2 | PriceMultiplier $PriceMultiplier | PriceMultiplierRec $PriceMultiplierRec | Multiplier  $Multiplier | DELTA $DELTA<br />";
		return $QDPrice2;
   }
?>