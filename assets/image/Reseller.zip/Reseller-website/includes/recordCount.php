<?
    $Balance = checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID);
 	 echo "<span  style=\"font-size:12pt;\">Welcome Back $CompName<br />You have ".number_format(intval($Balance))." records left in your account.</span>";
?>