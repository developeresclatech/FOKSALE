   <meta name="keywords" content="<?=$SiteName; ?>Email Blast Software, Bulk Emailer, Opt In Email List,telemarketing lists,call lists, phone numbers, postal, mailing, lists,business, consumer, b2b, residential, USA,Canada,demographics, Marketing software downloads" />
   <meta name="description" content="<?=$SiteName; ?> has over 500 million opt in business &amp; residential email, postal addresses as well as phone numbers for telemarketing ." />
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <meta http-equiv="Content-Style-Type" content="text/css" />  
    <link rel="icon" href="/images/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon" />
<link href="/css/style.css?ver=<?php echo rand(); ?>" rel="stylesheet" type="text/css" />
    <link href="/css/layout.css?ver=<?php echo rand();?>" rel="stylesheet" type="text/css" />