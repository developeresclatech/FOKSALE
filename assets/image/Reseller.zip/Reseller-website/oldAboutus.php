<?   
        include("./includes/siteData.php");
        include("./includes/dbConnect.php");
 ?><!DOCTYPE html>
  <html lang="en">
  <head>
    <title><?=$SiteName; ?>; Consumer and Business Email Addresses: About Us</title>
   <? include("includes/metas.php"); ?>
</head>
<body>
  <? include("includes/header.php"); ?>


<table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" style="background:none;" >
  <tr>
    <td align="left" valign="top" class="p2"><table width="100%" border="0" cellspacing="0" cellpadding="5">
      <tr>
        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td align="left" valign="top" class="contenttitlered">About Us</td>
            </tr>
          </table>
          <table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <td align="left" valign="top"><p class="content"><?=$SiteName; ?>  has been in business over 13 years helping the business owner make money.&nbsp; During that time we learned the more open you  are with your customer and by giving them full and complete access to managing  their own marketing campaigns the more they trust you.&nbsp; At <?=$SiteNameShort; ?> you have full control of your budget  and campaign by building you campaign &ldquo;your way&rdquo; in searching our database <span class="contenttitlered">"Anonymously"</span> and being rewarded with unlimited <span class="contenttitlered">"FREE SELECTS".</span>&nbsp; Yes you save time and money!</p>
                <p class="content">It&rsquo;s  a known fact while most of our competitors keep paying high priced IT people to  run <strong class="contenttitlered">Business  Data Searches</strong> and <strong class="contenttitlered">Consumer Data Searches</strong> to obtain record counts for  their prospective customers, our website allows for the ability to select  dozens of socio, economic, and demographics right from this website and get the  counts immediately with <span class="contenttitlered">"FREE"</span> selects.&nbsp; No more running around on the  phone waiting for counts and prices when you have a change to your database  demographics.&nbsp; At <?=$SiteNameShort; ?> you control your  time and budget by having access to our 300 Million Consumer and 30 Million  Business master database. It&rsquo;s all in your hands.</p>
                <span class="contenttitlered">Own Your Own Targeted Data versus Renting It!<br /> 
				</td>
              </tr>
            <tr>
              <td align="left" valign="top"><p align="left" class="content"><?=$SiteName; ?>
                  allows you to own your opt-in email data, which is better quality than our  competitors and is<br />
                <div align="" style="padding-left:20px; color: #111111; font-size: 11pt;">
                  A) Highly targeted  with 20+ demographics per record<br />
                B) You can use the database as many times as you want <br />
                C) We provide a 100% bounce back replacement guarantee! <br />
                D) We offer full email  deployment for a small fee<br />
                E) We offer full email  flyer design for a small fee
                </div>
				
				</p>
                <p align="center" class="content"><strong><?=$SiteName; ?> means  now in real time for the future.</strong></p>
			  </td>
            </tr>
            <tr>
              <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="5">
                <tr>
                  <td align="left" valign="top"><img src="images/office_staff.jpg" width="280" height="260" alt="our office staff"></td>
                  <td align="left" valign="top"><img src="images/woman_with_at.jpg" width="280" height="260" alt="woman holding an  '@'"></td>
                  <td align="left" valign="top"><img src="images/drawing_figures_money.jpg" width="280" height="260" alt="drawing"></td>
                </tr>
              </table></td>
              </tr>
	         </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
  <br />
  <?    include("./includes/footer.php"); ;?>
 </body>
</html>