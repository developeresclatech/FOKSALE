<?
      $Type = "Boats";
      include("./includes/siteData.php");
	  include("./includes/cURL_other_functions.php");
	  include("./includes/dbConnect.php");
 	  extract($_POST);
?><!DOCTYPE html>
  <html>
   <head>
   <title><?=$SiteName; ?>: Boats and Yacht Data</title>
    <? include("includes/metas.php"); ?>
    <style>

     </style>
     <script src="Scripts/query_scripts.js" type="text/javascript"></script>
     <script src="Scripts/getModels.js" type="text/javascript"></script>
  </head>
  <body>
   <? include("includes/header.php"); ?>
  <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" >
    <tr>
	 <td width="5">&nbsp;</td>
     <td  align="center">
	     <div id="divContent" style="">
              <h1>Boats and Yacht Data</h1>
		  <div align="center"  class="contenttitlered">
	         SEARCH ANONYMOUSLY,   FREE SELECTS<br />
          "Build Your Database Your Way"
	       </div>
      <!--  content area  -->
	 	      <?
			   if($User_ID)
			   {
				  include("includes/recordCount.php");
			   }
		  ?>
  <!--   <hr /> BEGIN FORM  -->
 <form method="post" action="<?=SELF; ?>#results"  id="frmSearch"  name="frmSearch"  onsubmit="return CheckForm();">
  <h1>Boats and Yachts Records</h1>
	<?
	    $submiturl = "$cURL_URL/Boat_Data_Insides.php";
        $data = GetDatacURL($submiturl, $_POST);
		echo $data;// this is the form contents with all the controls and query parameters
		 include("includes/query_buttons.php");
		?>
		</div><!--  end divContent  -->
	   </td>
	   <td width="5">&nbsp;</td>
	  </tr>
	</table>
	 <? include('includes/footer.php') ?>
 </body>
</html>