<?    include("./includes/siteData.php"); ;?><!DOCTYPE html>
  <html lang="en">
  <head>
    <title><?=$SiteName; ?>; Consumer and Business Email Address: Our Emailing Software</title>
	   <? include("includes/metas.php"); ?>
	  <script src="Scripts/scriptaculous.js?load=effects,builder" type="text/javascript"></script>
	  <script src="Scripts/lightbox.js" type="text/javascript"></script>
	  <style type="text/css" title="">
		.red
		{
		 color: #E7A856;
		 text-shadow: 1px 1px 1px black;
		}
		p.content
		{
           text-align: left;
        }
		input[type=button]
		{
			width: 234px;
			font-size: 14pt;
			font-weight: 700;
			height:50px;
			background-color: #FFFF66;
        }
         h1
		{
		    color: #E7A856;
		   text-shadow: 1px 1px 1px black;
		   font-size:19pt;
		   margin-bottom:21px;
		}
	</style>
  </head>
 <body>
   <? include("includes/header.php"); ?>
      <p>&nbsp;</p>
   	   <p><a href="http://www.filesanywhere.com/fs/v.aspx?v=8a6e688d5c6676af9da6" target="_blank" style="font-size:13pt; font-weight:800; color: blue;'">Go to this Link for the Software Downloads</a>
      </p>
      <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" style="background:none;">
        <tr>
     <td align="left" valign="top" class="p2">
	 <table width="800" border="0" align="center" cellpadding="5" cellspacing="0" style="width: 800px">
      <tr>
        <td align="left" valign="top">
		<table width="800" border="0" cellspacing="0" cellpadding="5" align="center">

            <tr>
              <td align="center" valign="top" class="content"><br /><br />
			        <h1>Control the Emailing Yourself and Save Substantial Money!</h1><hr />
                At <?=$SiteName; ?>, our goal is  always to give our customers full control of their marketing campaigns for the  lowest cost possible.� We have some  clients who want to go it alone and run their own campaign right from their  office PC.</p>
                <p align="center" ><span class="red"><u>They can do that now and more.</u></span></p>
                <p align="center" >We also have many clients who are  technically challenged, don't have the resources in-house or budgets to run  their own campaign so they outsource it to
                    <?=$SiteName; ?>
                  to manage their marketing campaigns.</p>
                <p align="center" ><span class="red"><u>They still can do that now and more.</u></span></p>
                <p>In addition to our email deployment  services, <?=$SiteName; ?> offers the following software and services to</p>
                <p> "The Company Who Wants To Go It Alone". </p>
                <p><span class="red">Please email us or  call your broker for pricing and questions.</span></p></td>
            </tr>
            <tr>
              <td align="left" valign="top" class="contenttitlered">&nbsp;</td>
            </tr>
            <tr>

              <td align="left" valign="top" class="contenttitlered"> <em>Our Featured </em><em>Software</em></td>
            </tr>
          </table>

            <table width="800" border="0" align="center" cellpadding="5" cellspacing="0" style="width: 100%">

              <tr>

                <td width="32%" align="left" valign="middle"><p class="contentinner"><a href="images/image1.jpg" rel="lightbox"><img src="images/emailer.jpg" width="235" height="234" alt="emailer" /></a></p>

                  <input type="button" value="Live Demonstration" onclick="window.location='listen-to-webinar.php';" /> </td>

                <td width="68%" align="center" valign="top">
				            <h1>Blast Email Marketing Machine</h1>

                  <p class="content"><span class="style26">Blast Email Marketing Machine</span> allows you to e-mail for $7 per 350,000 from the IP address of USA based email servers, with by far has the best deliverability in the industry! How? </p>

					 <p class="content"><span class="style26">GE</span>  simultaneously rotates your email through many webhosting companies SMTP's (you own), so you do not utilize contiguous IP addresses and exceed the ISP speed thresholds. Also rotated are your: From Names, From E-mails, Subject Lines, parts of the email body and many presentations, to reduce commonality to the filters, and includes a built in spam-checker.</p>

					 <p class="content"><span class="style26">Blast Email Marketing Machine</span> has a robust database built into it that allows you to query data that we supply or other data suppliers by dozens of socio, economic and demographic selects.  <span class="style26">GE</span> also interfaces with our squeeze/landing pages we can design for you so to provide <span class="contenttitlered">"ANONYMOUS"</span>  tracking of opens, click throughs, landing page visits and includes an auto-responder.  Dozens of other unique benefits which simultaneously allows you to have not only the lowest email sending costs but by far the best deliverability!</p>
    	             <p><a href="http://www.filesanywhere.com/fs/v.aspx?v=8a6e688d5c6676af9da6" target="_blank" style="font-size:13pt; font-weight:800; color: blue;'">Go to this Link for the Software Downloads</a></p>
    	             <p>&nbsp; </p>
    	             <p class="content" align="center" style="font-weight:800;"><b>Blast Email Marketing Machine Has Simply Revolutionized The Email Industry!</b><br/><br/>
     <a class="terms" href="contact.php" target="_blank" align="center" style="font-size:13pt; font-weight:800; color: blue;'">Call or email  for pricing ..........Today!...</a></p>
      </td>
    </tr>
    <tr>
       <td colspan="2" align="left" valign="top" style="padding:15px 0px 15px 0px;"><img src="images/line.jpg" width="798" height="3"  alt="line" /></td>
   </tr>
   <tr>
     <td align="left" valign="top"><a href="images/image2.jpg" rel="lightbox">
	    <img src="images/contact.jpg" width="235" height="164"   alt="contact"/></a><br /><br/> <input type="button" value="Live Demonstration" onclick="window.location='listen-to-webinar.php';" />
   </td>
   <td align="center" valign="top">
            <h1>Contact Page Marketing Machine</h1>
   <p class="style26" align="center">You're Treated As A Guest In The Website Owners House Compared To Emailing! Contact Page Marketing Machine Automatically Personalizes Every Website Submission.</p>
   <p class="content"><span class="style26">Contact Page Marketing Machine</span> simply allows you to  upload the home page of millions of websites that you want to contact and <span class="style26">WS</span> automates the posting and submitting of your message into the <span class="style26" style="font-weight:800;">websites contact page!</span> No emailing! No Can SPAM Email Requirements!</p>
   <p class="content">It appears as if you visited each website, as the software will even insert the name of the key executive from the uploaded data record right into each submission.</p>
	 <p class="content">The response is <span class="style26" style="font-weight:800;">"30X Greater Than E-Mailing"</span> as 100% of people open their contact page submissions as opposed to emails AND of course there are no email filters to deal with as this is not emailing!</p>

	 <p class="content"><span class="style26">Contact Page Marketing Machine</span> lets your custom message contain your website link and handles Unicode for foreign website submissions as well. The software will run all day at no cost from any desktop PC and will contact about 150,000 websites per day.</p>
	 <p class="content" style="font-weight:800;"><b>The Days of Typing Captcha Are Over</b></p>
	 <p class="content"><span class="style26">Contact Page Marketing Machine</span> software also has an added <span class="style26"  style="font-weight:800;">"DECAPTCHA"</span>  OPTION where it will use a service bureau in real time which will enter captcha codes into the approximately 20% of websites which have captcha codes at a cost of only one cent per correct submission. <span class="style26">This has never been offered before!!!</span></p>
	 <p class="content"><span class="style26">Contact Page Marketing Machine</span> has an additional feature that allows you to post your message into the contact pages of representatives from many top Multi-Level-Marketing companies as well. The possibilities are endless!!!!!</p>
	 <p class="style26" align="center">No More Relying upon Emails that Go Bad Quickly! --- No Email Filter Issues! --- No More Getting Black Listed!
	 Just one very inexpensive Contact Page Marketing Machine License can submit tens of thousands per day!<br/>
	<a class="terms" href="http://contactpagemarketingmachine.com" target="_blank" align="center" style="font-size:13pt; font-weight:800; color: blue;'">Click here for VIDEOS and Pricing Specials</a></p>
  </td>
 </tr>
 <tr>
     <td colspan="2" align="left" valign="top" style="padding:15px 0px 15px 0px;"><img src="images/line.jpg" width="798" height="3"  alt="line" /></td>
 </tr>
  <tr>
   <td align="left" valign="middle"><a href="images/image3.jpg" rel="lightbox"><img src="images/ace.jpg" alt="ace" width="235" height="179" /></a><br /><br/>
   <input type="button" value="Live Demonstration" onclick="window.location='listen-to-webinar.php';" /></td>
    <td align="center" valign="top">
	         <h1>Search Engine Extractor</h1>

                  <p class="content">Consumers Report: Its Google, Yahoo and Bing on Steroids! </p>
					<p class="content"><span class="style26">Unlimited FREE Data</span></p>
					<p class="content"><span class="style26">Unlimited FREE Access To Highly Targeted Business Data Records!</span></p>
					<p class="content"><span class="style26">Search Engine Extractor</span> simultaneously uses Google, Bing and Yahoo search engines to obtain <span style="font-weight:800;">unlimited, free, targeted, fresh business data records.</span>  </p>
					<p class="content">Unlike a traditional search engine in which the results are controlled and listed 10 per page, <span class="style26">Search Engine Extractor</span> vertically lists the results and allows you to further target, analyzing and manipulating to further refine your search!</p>
					<p class="content">Unlike any other search engine <span class="style26">Search Engine Extractor</span>  search results can be exported as a standard .csv file with a dozen data fields!  You even have the ability to append a SIC and NAISC business code to the exported results to build an unlimited, free, targeted, fresh, database.   FREE data at your fingertips!! </p>
					<p class="content"><span class="style26">Search Engine Extractor</span>  unlimited  FREE and fresh businesses data is collected at No Cost and can then be uploaded into our <span class="style26">Webpage Submitter</span> software to contact the <span class="style26">Search Engine Extractor</span> prospects you just obtained for FREE! </p>
					<p class="content" style="font-weight:800;"><b>It's FREE Marketing Worldwide At Its Best </b>  </p>
					<a class="terms" href="contact.php" target="_blank" align="center" style="font-size:13pt; font-weight:800; color: blue;'">Call or email  for pricing ..........Today!...</a>
		    	</td>
              </tr>
               <tr>
                 <td colspan="2" align="left" valign="top" style="padding:15px 0px 15px 0px;"><img src="images/line.jpg" alt="line" width="798" height="3" /></td>
               </tr>

              <tr>
                <td align="left" valign="middle">
				    <p class="content"><a href="images/image4.jpg" rel="lightbox"><img src="images/localdata.jpg" alt="local data" width="235" height="150" /></a><br/><br/>
                    <input type="button" value="Live Demonstration" onclick="window.location='listen-to-webinar.php';" /></p>
                </td>

                <td align="center" valign="top">
				    <h1>Yellow Pages Lead Finder</h1> 
                   <p class="content">Enter a business industry and City or State and the software will   automatically collect from a major Yellow Pages business directory the business name, postal address, phone, fax, website, and email addresses of the businesses and exports to a data file!</p>
                   
                   <a class="terms" href="http://b2bmarketingmagic.com" target="_blank" align="center" style="font-size:13pt; font-weight:800; color: blue;'">Please visit B2B Marketing Magic for VIDEOS and Specials</a>                
				</td>
              </tr>
               <tr>
                <td colspan="2" align="left" valign="top" style="padding:15px 0px 15px 0px;"><img src="images/line.jpg" alt="line" width="798" height="3" /></td>
              </tr>
              <tr>
                <td align="left" valign="middle"><p class="content"><a href="images/image5.jpg" rel="lightbox">
				   <img src="images/b2b.jpg" alt="b2b" width="235" height="148" /></a><br/><br/>        
                  <input type="button" value="Live Demonstration" onclick="window.location='listen-to-webinar.php';" /></p>
                </td>
                <td align="center" valign="top">
				    <h1>B2B Lead Generator</h1> 
                    <p class="content">Enter a business industry and City or States/Canadian Provinces and the software will automatically collect from a major search engine business directory the business name, postal address, phone, fax, website, and email addresses of the businesses and exports to a data   file!</p>
				 <a class="terms" href="http://b2bmarketingmagic.com" target="_blank" align="center" style="font-size:13pt; font-weight:800; color: blue;'">Please visit B2B Marketing Magic for VIDEOS and Specials</a>     </td>
              </tr>
              <tr><td colspan="2" align="left" valign="top" style="padding:15px 0px 15px 0px;"><img src="images/line.jpg" alt="line" width="798" height="3" /></td></tr>
              <tr>
                <td align="left" valign="middle"><p class="content"><a href="images/image6.jpg" rel="lightbox"><img src="images/clasified.jpg" alt="business classified" width="235" height="149" /></a><br/><br/>
                <input type="button" value="Live Demonstration" onclick="window.location='listen-to-webinar.php';" /></p>

                <p class="content">&nbsp;</p></td>

                <td align="center" valign="top">	   				    <h1>Classifieds Collector </h1>
                    <a href="http://www.filesanywhere.com/fs/v.aspx?v=8a6e688d5c6676af9da6" target="_blank" style="font-size:13pt; font-weight:800; color: blue;'">Go to this Link for the Software Downloads</a>
                <p class="content">Designed for obtaining targeted email addresses by keyword from any classified website.</p>
                <p class="content">Classifieds Collector is very fast,   reliable and affordable way for collecting   email addresses for your   targeted marketing needs.</p>
                <p class="content"> Classifieds Collector  works with   any classified website with so you can use the extracted data to promote   your business worldwide.  This data may include Email Address, Business Name, Contact Name,   Business Address, Website Address and Telephone Number.</p>
                <p class="content"> Classifieds Software allows users to collect email addresses from   (Craigs Lists, Gumtree, Kiiji, and Backpage) by dozens of targeted   online classifieds categories in dozens of targeted geographic   locations! It even has a built-in emailer to email a presentation and   deliverability is over 99% due to these fresh classified postings.</p>
                <p class="content">It is an all in one solution as Classifieds   software also has a robust built�in emailer which allows users to send   their presentations to the emails collected from its database.</p>
                <p class="content">The software freely runs off a PC and can collect 100,000 targeted data leads per day. </p>
			   </td>
              </tr>
               <tr><td colspan="2" align="left" valign="top" style="padding:15px 0px 15px 0px;"><img src="images/line.jpg" alt="line" width="798" height="3" /></td></tr>

              <tr>
                <td align="left" valign="top"><p class="content"><a href="images/realtor.jpg" rel="lightbox"><img src="images/relator.jpg" alt="realtor" width="235" height="154" /></a> </p>

                <p class="content"><input type="button" value="Live Demonstration" onclick="window.location='listen-to-webinar.php';" /></p></td>

                <td align="center" valign="top">
				    <h1>Realtor Marketing Magic</h1>

                  <p class="content">Our Realtor Marketing Magic software freely runs on your PC and allows you to post and   submit your message into the contact page of over hundred thousand   Realtors by geographic location.</p>
                 <p class="content"> The software bypasses any email filters   since it is posting directly to their contact page and of course since   you are not emailing it is CAN-SPAM compliant. It simply automates you   going to tens of thousands of contact pages per day and writing a note   to each Realtor as if you were visiting their contact page.</p>
                  <p class="content">Realtor Marketing Magic is in high demand by many:</p>
                  <p class="content">1) Realtors look to reach out to other Realtors to advise them about a new property   coming on the market or a price change in a property.</p>
                 <p class="content">2) Mortgage Companies want to reach Realtors so they can advise them of unique   mortgage plans that would enable Realtors buyers to afford the property.</p>
                 <p class="content">3) Car Companies like Realtors because they spend money on nice cars and need to buy often.</p>
                  <p class="content">4) People who sell business opportunities like contacting Realtors because   Realtors are entrepreneurial types and are typically open to ways of   making money on commission; especially now that the real estate industry   is slow.</p>
                <p class="content">5) Companies selling communications equipment and services want to reach Realtors because they are always on the go.</p></td>
              </tr>
           </table></td>
      </tr>
    </table></td>
  </tr>
</table>
      <p><a href="http://www.filesanywhere.com/fs/v.aspx?v=8a6e688d5c6676af9da6" target="_blank" style="font-size:13pt; font-weight:800; color: blue;'">Go to this Link for the Software Downloads</a></p>
	   <p>&nbsp; </p>
	   <? include("includes/footer.php"); ?>
 </body>
</html>