<?php
// part of the AJAX function for the check username feature on compdata_Include.php, along with AJAX_username.js
  header("Cache-Control: no-cache, must-revalidate");
 // Date in the past
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
 include("../includes/siteData.php");
 include("../includes/dbConnect.php");

 $response = '<span style=" color: #000000;">Good Username</span>';
 $UN = $_GET['UN'];
 if(strlen($UN) < 7)
 {
	$response = '<span style=" color: red;">Too Short, 7 character minimum</span>';
 }
 elseif(strlen($UN) > 16)
 {
	$response = '<span style=" color: red;">Too Long, 16 character max</span>';
 }
 elseif(preg_match('/[^0-9a-zA-Z]/', $UN))
 {
	$response = '<span style="color: red;">Only Letters and Numbers Please</span>';
 }
 else
 {
    $query = "SELECT `User_ID` FROM `tblResellerCustomers` WHERE `Username` = '$UN'  ;   ";
    $results = mysql_query($query);
	if($results)
	{
	  if(mysql_num_rows($results) > 0)
	  {
		$response = '<span style=" color: red;">Sorry, Username Taken!</span>';
	  }
	  else
	  {
		$response = "";
	  }
    }
	else
		echo $query.mysql_error();
  } 
  echo $response;
?>