<?
     $table = "`tblVehicleYearMakeModelAll`";
      include("../includes/siteData.php");
	  include("../includes/dbConnect.php");	
     $Make = mysql_real_escape_string($_GET['Make']);
     $GetMakes = intval($_GET['GetMakes']);
     $Year = intval($_GET['Year']);
     //print_r($_GET);
      if($GetMakes && $Year) //MAKES
	  {
				 $query =    "SELECT DISTINCT `Make` FROM $table WHERE   `Year` = '$Year'   ORDER BY  `Make`  ; ";
				  $resultMake = mysql_query($query);
				  $O = 1;
				 // $Options .= "\"";
				  while($dataMake = mysql_fetch_assoc($resultMake))
				  {
					  extract($dataMake);
					  //$Make = trim($Make);
					  $Options .= "S.options[$O] = new Option('$Make' , '$Make'); ";
					  $O++;
				  }
				   //$Options .= "\"";
				   if($resultMake)
				       echo $Options;
				   else
					   echo $query.mysql_error();
	  }
	  elseif($Make != "") //MODELS
	  {
		   if($Year)
				   $query =    "SELECT DISTINCT `Model` FROM $table WHERE Year = '$Year' AND Make = '$Make' ORDER BY  `Model`   ; ";
		   else
				   $query =    "SELECT DISTINCT `Model` FROM $table WHERE  Make = '$Make' ORDER BY  `Model`  ; ";

					  $resultMake = mysql_query($query);
					  $O = 1;
					  //$Options .= "\"";
                   if($resultMake)
		          {
					  while($dataMake = mysql_fetch_assoc($resultMake))
					  {
						  extract($dataMake);
						  $Model = trim($Model);
						  $Options .= "S.options[$O] = new Option('$Model',  '$Model'); ";
						  $O++;
					  }
					  echo $Options;
				  }
				  else
					  echo $query.mysql_error();
	  }
?>