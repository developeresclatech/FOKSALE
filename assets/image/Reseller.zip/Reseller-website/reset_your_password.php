<?
		include("./includes/siteData.php");
     include("./includes/dbConnect.php");
	session_start();
   extract($_POST);
   $CompMessageLoggedIn =   "You are already logged in!";
	if($subChangePW) // changes pw for customers, Thursday, September 03, 2009
	{
		if(strlen($CPassword)  >  5 && strlen($CPassword) < 17  &&  $CPassword == $XCPassword )
		{
         // if($Username)
			  $Condition = " `Username` = '$Username' ";
		    /*  else
			  $Condition = " `CompEmail` = '$CompEmail' ";  */

  		  $queryS = "UPDATE  `tblResellerCustomers` SET CPassword = '' WHERE `ResetCode` = '$ResetCode'  AND  $Condition LIMIT 1;";
	      $resultsS = mysql_query($queryS); // get a fresh password in there so the change can work on it, affected rows won't work unless something was changed

  		 $queryS = "UPDATE  `tblResellerCustomers` SET CPassword = PASSWORD('$CPassword') WHERE ResetCode = '$ResetCode'  AND  $Condition LIMIT 1;";
	     $resultsS = mysql_query($queryS);
		 if(mysql_affected_rows() == 1)
		 {
             $CompMessageLoggedIn = "Your Password Has Been Updated, You Are Now Logged In!";
			 $fontColor = "green";
			 $queryS = "SELECT *  FROM `tblResellerCustomers` WHERE ResetCode = '$ResetCode'  AND  $Condition  LIMIT 1;";
			 $resultsS = mysql_query($queryS);
			 $data = mysql_fetch_assoc($resultsS);
		  if($data['Stopped'] == 'Y')
          {
				 $CompMessage  .=  ("<br />Your Account Has Been Deactivated, Contact Management");
		  }
		 else
         {
			    extract($data);
 			    include("includes/cookie.php");
		  }
	     }
		 else
		 {
			// $CompMessage =  mysql_error(). $queryS;
             $CompMessage  = "Password Not Changed, Email Or Reset Code Entered Must Be Wrong";
			 $fontColor = "red";

			 $queryS = "SELECT  ResetCode  FROM `tblResellerCustomers` WHERE   CompEmail = '$CompEmail'  LIMIT 1;";
			 $resultsS = mysql_query($queryS);
			 $data = mysql_fetch_assoc($resultsS);
         }
		}
	   else
       {
             $CompMessage = "Password Length Wrong it's ".strlen($CPassword) . ' characters long  or the 2 don\'t match ';
			 $fontColor = "red";
       }
    }


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
   <title><?=$SiteName;?>: Reset Your Password</title>
   <? include("includes/metas.php"); ?>
  <meta name="keywords" content="Double Opt In Email, Email Mailing List, Opt In Leads, consumer addresses,zip,age,gender,income,ethnic,interest" />
  <meta name="description" content="Visitors please visit here to take complete overview and it will give you instructions and some tips on searching and obtaining opt-in full record data using this Consumer Data Search page." />
	<script language="javascript" type="text/javascript">
          function checkForm()
		  {
			  x = document.frmCompData;
			  Resetme = true;
              message = 'ERROR\n';
				  if(x.ResetCode.value == '')
                  {
                       Resetme = false;
					   message = message +  'Enter the reset code from the email\n';
				  }
				  if(x.CompEmail.value == '')
                  {
                       Resetme = false;
					  message = message +  'Enter your email address\n';
				  }

				  if(x.CPassword.value.length < 6)
                  {
                       Resetme = false;
					  message = message +  'Enter a password of at least 6 characters\n';
				  }

				  if(x.CPassword.value.length > 16)
                  {
                       Resetme = false;
					  message = message +  'Enter a password of not greater than 16 characters\n';
				  }
				  if(x.CPassword.value !=  x.XCPassword.value)
                  {
                       Resetme = false;
					  message = message +  'The two passwords entered do not match\n';
				  }
                  if(!Resetme)
				  {
					  alert(message);
					  return false;
				  }
				  else
					  return true;
			  }
	</script>
   <style type="text/css">
  	   body
	   {
         width:500px;
		 margin: 20px;
		 font-family: arial, tahoma, helvetica;
	   }
	  caption
	   {
         font-weight:700;
		 font-family: arial, tahoma, helvetica;
		 font-size: 19pt;
	   }
	   label
	   {
         font-weight:700;
		 font-family: arial, tahoma, helvetica;
		 font-size: 10pt;


	   }
	   .cue
	   {
         font-weight:700;
		 font-family: arial, tahoma, helvetica;
		 font-size: 8pt;
	   }
	   .required
	   {
		  color: red;
		  font-size:11px;

	   }
	   #order
	   {
          padding:7px;
	   }
	   select
		{
			/*background-color: #CCCCDD;*/
			margin:1px;

			background-color: #FFF;
		}

  </style>
 </head>

<body>
   <? include("includes/header.php"); ?>
  <div id="contentwrapper">
    <div id="contentmainwrapper">
   <div class="wide" id="searchContent">
	 <div id="order" >
       	  <?
	        if($User_ID > 0)
			{
			  echo "<h3>$CompMessageLoggedIn</h3>";
            }
			else
			{
        ?><a name="status"></a>
  	<form name="frmCompData" id="frmCompData"  onsubmit="return checkForm();" action=""  method="post">
<? if($_GET['un']) { ?>
  <h3>Reset Your Password Below</h3>
  <h3><?=$CompMessage ;?>&nbsp;</h3>
	  <table cellspacing="10" cellpadding="10">
	  <? if(!$_GET['mult']) { ?>
       <tr >
	      <td align="left">
   				<label for="ResetCode">&nbsp;&nbsp;Enter the Reset Code from the Email:</label><span class="required">*</span>
		 </td>
	     <td>
   		    <input type="text" class="longtext"  name="ResetCode" id="ResetCode"  size="30"  value="<?=$_GET['rc'];?>" />
		 </td>
	   </tr>

<!--  	   <tr >
	    <td align="left">
	      <label for="CompEmail" >&nbsp;&nbsp;Enter Your  Email Address of that Email:<span class="required">*</span> </label>
		 </td>
	    <td>
	      <input type="text" class="longtext" name="CompEmail" id="CompEmail" size="30"  value="<?=$_GET['em'];?>"   />
		 </td>
	   </tr>  -->
  
  <? if($_GET['un']) {  ?>
	   <tr >
	    <td align="left">
	      <label for="Username" >&nbsp;&nbsp;Enter Your  Username<span class="required">*</span> </label>
		 </td>
	    <td>
	      <input type="text" class="longtext" name="Username" id="Username" size="30"  value="<?=$_GET['un'];?>"   />
		 </td>
	   </tr>
  <? } ?>

	   <tr >
	    <td align="left">
  			 <label for="CPassword" >&nbsp;&nbsp;Enter New Password Here<span class="required">*</span></label>:<br />
  		</td>
	    <td>
  			 <input  type="password" class="text"   name="CPassword" id="CPassword" maxlength="16" size="20"   autocomplete="off"/>
		</td>
	   </tr>

	   <tr >
	     <td align="center" colspan="2">	<span class="cue">(Password should be 6 -16 letters and numbers, DO NOT USE QUOTES!)</span></td>
	   </tr>

	   <tr >
	    <td align="left">
   				<label for="XCPassword" >&nbsp;&nbsp;Confirm New Password:<span class="required">*</span></label>
		</td>
	    <td>
   		    <input type="password" class="text"  name="XCPassword" id="XCPassword"  maxlength= "16" size="20"  autocomplete="off" />
	    </td>
	   </tr>
	     <tr >
	      <td align="left">
   				<label  for="subChangePW">&nbsp;&nbsp;Submit</label>:
		 </td>
	     <td>
   		    <input type="submit" class="text"  name="subChangePW" id="subChangePW"  maxlength= "16" size="12" value="Change Password"  />
		 </td>
	   </tr>
<? } else {
		     if(isset($subEnter))
		     {
                  $NewPW = substr(md5(uniqid(rand(),1)),3,10);
                  $queryRPW = "UPDATE tblResellerCustomers SET `ResetCode` = '$NewPW'  WHERE `User_ID` = $optUser_ID LIMIT 1    ;    ";
		          @$resultsRPW = mysql_query($queryRPW);
				  if($resultsRPW)
				   {
                     $queryID = "SELECT * FROM  tblResellerCustomers WHERE `User_ID` = $optUser_ID LIMIT 1    ;    ";
		             $resultsID = mysql_query($queryID);
					 extract($dataID = mysql_fetch_assoc($resultsID));
                     $subject = "From $SiteName PW Reset";
				     $body  = "Hello $CompFName  $CompLName, \nto reset your password  go to this page $SiteURL/reset_your_password.php?em=$CompEmail&rc=$NewPW&un=$Username and enter your email address and this reset code,\t  $NewPW\n";
                     $body .= "Your username is $Username\n";
                    $body .= "If you didn't request or do not need your password changed, then ignore this email and nothing will happen.\n";
                     $body .= "Thank You\n The Systems Management Crew";
                     $headers = "From: $SiteName<$SiteEmail>\r\nReply-To: \"No Reply\"<a@a.com>";
					 //print_r($data);
					//echo $data['CompEmail'] .'  = COMPEMAIL<br />';
				     $mc = mail($CompEmail, $subject, $body, $headers);
					 if($mc)
					   {
                        echo "<tr><td>Your password reset instructions have been sent to your email address,  $CompEmail</td></tr>\n";
						//echo "mail($CompEmail, $subject, $body, $headers)<br />";
					   }
					 else
					    echo "<tr><td>Email Failed</td></tr>\n";
                  }
				  else 
					  echo $queryRPW.mysql_error();
			}// END   if(isset($SubEnter))

            else //display the choices then
		    {

        	 $queryMult = "SELECT *, DATE_FORMAT(`DateEntered`, '%m/%d/%Y') AS `DE`  FROM `tblResellerCustomers` WHERE  CompEmail = '".$_GET['em']."' ORDER BY User_ID DESC   ;";
			 $resultsMult = mysql_query($queryMult);
			 echo "<caption>These are the Accounts Associated with email address ".$_GET['em']."</caption>";
			 echo "<tr><td>Company Name</td><td>User Name</td><td>First Name</td><td>Last Name</td><td>Date Created</td><td>Select</td></tr>\n";
			 while($dataMult = mysql_fetch_assoc($resultsMult))
		     {
		         extract($dataMult);
    			 echo "<tr><td>$CompName</td><td>$Username</td><td>$CompFName</td><td>$CompLName</td><td>$DE</td>";
				 echo "<td><input type=\"radio\" name=\"optUser_ID\"   value=\"$User_ID\" /></td></tr>\n";
             }
             echo '<tr><td colspan="3">Select the account, then hit enter to have reset instructions emailed to you</td>';
			 echo '<td colspan="3"><input type="submit" name="subEnter" id="subEnter"   value="Enter"  accesskey="e"   title="or alt e" /></td></tr>';
		}
  }
 ?>
	</table>
<? 
	     } 
            elseif(!$User_ID) 
			{
	             include("includes/loginNew.php");
				 $_SESSION['login'] = NULL;
			}
?>
 </form>
 <? } ?>
</div><!-- end Content area -->

 	</div><!-- end contentmainwrapper -->
   </div><!-- end contentwrapper -->
   </div>
   <? include('includes/footer.php') ?>
  </body>
</html>