<?php
  include("./includes/cURL_other_functions.php");
  include("./includes/siteData.php");
  include("./includes/dbConnect.php");
?>
<html>
   <head>
     <title>Your Search Queries and Downloads</title>
     <? include("includes/metas.php"); ?>
	 <style type="text/css" title="">
	 	fieldset
		{
			border: 2px blue solid;
			width: 400px;
			padding: 10px;
        }
		input[type=text], input[type=password]
		{
			background-color: #FFFFCC;
		}
       #divMain, #tblSearch td, #tblSearch  th
		{
			color: #111111;
        }
	 </style>
 </head>
<body>
   <? include("includes/header.php"); ?>	   

  <div align="center" style="" id="divMain">
 	 <table width="900" id="tblContents">
	  <tr>
	   <td width="100%" align="center" valign="top">
	    <h2>Your Search Queries and Downloads</h2>	    
 <!--  CONTENT AREA, INSERT GUTS HERE  -->
  <?      //  include("./includes/recordCount.php"); 
		 		$submiturl = "$cURL_URL/api/customer_queries_api.php";
                $OUT_ARRAY = array("CompID" => $Reseller_ID, "User_ID" => $User_ID, "Username" =>$Reseller_UN, "Export"=> 1 );
                $data = GetDatacURL($submiturl, $OUT_ARRAY);
                echo $data;
 	       
	?>

	    </td>
	  </tr>
	</table>
	</div>
   <? include("includes/footer.php"); ?>	   
 </body>
</html>