<!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Get Trusted Advice </title>
    <?    include("./includes/links.php"); ?>
</head>
   <body>
   <div class="page newhome">
       <?    include("./includes/newhome_header.php"); ?>

    <!-- Start: Email Fetcher Appending -->
    <section id="services-1">
        <div class="container">
            <div class="d-flex flex-column section-title text-center">
                <h1 class="mb-0">600 million in Opt-In email leads, business leads, telemarketing leads - Get Trusted Advice</h1>
               
            </div>
            <div class="row flex-shrink-1 row-cols-1 row-cols-md-3">
                <div class="col d-flex flex-column flex-shrink-1 mt-4">
                    <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                     <img class="align-self-center img-fluid" src="/images/slide1.png" width="160">
                        <h4><span class="font28">Targeted  E-mail Lists</span></h4>
                        <p>Upload csv that has the employees name and their URL website. Your email appending credits account is only debited when deliverable emails are added.&nbsp;You don’t have to split your file into records with and without emails. We will simply skip records that already have emails.</p>
                    </div>
                </div>
                <div class="col d-flex flex-column flex-shrink-1 mt-4">
                    <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                     <img class="align-self-center img-fluid" src="/images/slide2.png" width="160">
                        <h4><span class="font28">Consumer Data</span></h4>
                        <p>As per independent AIT Research we own the largest data business, so we already know the email addresses of 250 million employees. We will run the appended email through email verification to confirm deliverability.</p>
                        <p class="blankspace">&nbsp</p>

                    </div>
                </div>
                <div class="col d-flex flex-column flex-shrink-1 mt-4" >
                    <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                     <img class="align-self-center img-fluid" src="/images/slide3.png" width="160">
                        <h4><span class="font28">Business Data</span></h4>
                        <p>If we do not have the data record, we will apply the email pattern for the website URL and verify the email. If we don’t know the email pattern, we apply many common email patterns and run them all through verification to find the deliverable email.</p>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End: Email Fetcher Appending -->
    <!-- Start: Deep List Cleaning -->
    <section id="services-2">
        <div class="container d-flex flex-column align-items-center my-5">
                <div class="d-flex flex-column section-title text-center">
                <h1 class="free">FREE</h1>
                <h1 class="mb-0">Clean Email Lists</h1>
                <p class="text-center text-uppercase text-secondary">Verify Deliverability Before Emailing! Why?</p>
            </div>
            <div class="row flex-shrink-1 row-cols-1 row-cols-md-3 my-0">
                <div class="col d-flex flex-column mt-4 p-3">
                   <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <div class="d-flex justify-content-center icon py-2 align-items-center bgcolor1" ><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -64 640 640" width="1em" height="1em" fill="currentColor" class="font72">
                            
                                <path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c1.8 0 3.5-.2 5.3-.5c-76.3-55.1-99.8-141-103.1-200.2c-16.1-4.8-33.1-7.3-50.7-7.3H178.3zm308.8-78.3l-120 48C358 277.4 352 286.2 352 296c0 63.3 25.9 168.8 134.8 214.2c5.9 2.5 12.6 2.5 18.5 0C614.1 464.8 640 359.3 640 296c0-9.8-6-18.6-15.1-22.3l-120-48c-5.7-2.3-12.1-2.3-17.8 0zM591.4 312c-3.9 50.7-27.2 116.7-95.4 149.7V273.8L591.4 312z"></path>
                            </svg></div>
                        <h4 class="mt-3"><span >Protect Your Reputation</span></h4>
                        <p>Protect your IP and domain reputation by removing spammy, risky, or role-based emails, helping you maintain a high sender score.</p>
                    </div>
                </div>

                 <div class="col d-flex flex-column mt-4 p-3">
                   <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <div class="d-flex justify-content-center icon py-2 align-items-center bgcolor2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -64 640 640" width="1em" height="1em" fill="currentColor" class="font72">
                                 <path d="M400 96l0 .7c-5.3-.4-10.6-.7-16-.7H256c-16.5 0-32.5 2.1-47.8 6c-.1-2-.2-4-.2-6c0-53 43-96 96-96s96 43 96 96zm-16 32c3.5 0 7 .1 10.4 .3c4.2 .3 8.4 .7 12.6 1.3C424.6 109.1 450.8 96 480 96h11.5c10.4 0 18 9.8 15.5 19.9l-13.8 55.2c15.8 14.8 28.7 32.8 37.5 52.9H544c17.7 0 32 14.3 32 32v96c0 17.7-14.3 32-32 32H512c-9.1 12.1-19.9 22.9-32 32v64c0 17.7-14.3 32-32 32H416c-17.7 0-32-14.3-32-32V448H256v32c0 17.7-14.3 32-32 32H192c-17.7 0-32-14.3-32-32V416c-34.9-26.2-58.7-66.3-63.2-112H68c-37.6 0-68-30.4-68-68s30.4-68 68-68h4c13.3 0 24 10.7 24 24s-10.7 24-24 24H68c-11 0-20 9-20 20s9 20 20 20H99.2c12.1-59.8 57.7-107.5 116.3-122.8c12.9-3.4 26.5-5.2 40.5-5.2H384zm64 136a24 24 0 1 0 -48 0 24 24 0 1 0 48 0z"></path>
                            </svg></div>
                        <h4 class="mt-3"><span >Save Money</span></h1>
                        <p>Save on your email marketing bill by sending campaigns to contacts who actually will respond to your email campaigns. Reduce your bill.</p>
                    </div>
                </div>

                 <div class="col d-flex flex-column mt-4 p-3">
                   <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <div class="d-flex justify-content-center icon py-2 align-items-center bgcolor3"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -64 640 640" width="1em" height="1em" fill="currentColor" class="font72">
                               <path d="M470.7 9.4c3 3.1 5.3 6.6 6.9 10.3s2.4 7.8 2.4 12.2l0 .1v0 96c0 17.7-14.3 32-32 32s-32-14.3-32-32V109.3L310.6 214.6c-11.8 11.8-30.8 12.6-43.5 1.7L176 138.1 84.8 216.3c-13.4 11.5-33.6 9.9-45.1-3.5s-9.9-33.6 3.5-45.1l112-96c12-10.3 29.7-10.3 41.7 0l89.5 76.7L370.7 64H352c-17.7 0-32-14.3-32-32s14.3-32 32-32h96 0c8.8 0 16.8 3.6 22.6 9.3l.1 .1zM0 304c0-26.5 21.5-48 48-48H464c26.5 0 48 21.5 48 48V464c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V304zM48 416v48H96c0-26.5-21.5-48-48-48zM96 304H48v48c26.5 0 48-21.5 48-48zM464 416c-26.5 0-48 21.5-48 48h48V416zM416 304c0 26.5 21.5 48 48 48V304H416zm-96 80a64 64 0 1 0 -128 0 64 64 0 1 0 128 0z"></path>
                            </svg></div>
                        <h4 class="mt-3"><span>Make Money</span></h1>
                        <p>Increase your email campaigns' return on investment (ROI) by getting rid of junk emails and sending them to verified emails.</p>
                    </div>
                </div>

            </div>
        </div>


    </section><!-- End: Deep List Cleaning -->

    <!-- End: Verified Deliverability -->

<section id="services-4a" class="mt-4 mb-4">
        <h1 class="display-4 text-center col" id="scrape" style="margin-bottom: 15px;">The #1 Trusted Email List Provider</h1>
        <div class="container d-flex" >
            <div class="row d-flex flex-column-reverse m-auto flex-md-row" >
                <div class="col-md-6" >
                    <h2 class="display-5 fw-bolder text-center mt-4">Our Services</h2>
                    <p class="fs-4 mt-4 mb-4">Get Trusted Advice has the largest opt-in consumer email database in the United States.</p>
                    <div class="card mt-4">
                        <div class="card-header" style="background: rgb(211,244,252);" >
                            <h4 class="display-6 fw-normal mb-0 text-center">True Get Trusted Advice Lists:</h4>
                        </div>
                        <div class="card-body" style="background: rgba(213,228,242,0.31);" >
                            <p class="fs-5 card-text">Only 5<svg xmlns="http://www.w3.org/2000/svg" viewBox="-64 0 512 512" width="1em" height="1em" fill="currentColor" class="fs-6 currentColor">
                                    <path d="M224 0c17.7 0 32 14.3 32 32V66.7c30.9 5.2 59.2 17.7 83.2 35.8c14.1 10.6 17 30.7 6.4 44.8s-30.7 17-44.8 6.4C279.4 137.5 252.9 128 224 128c-70.7 0-128 57.3-128 128s57.3 128 128 128c28.9 0 55.4-9.5 76.8-25.6c14.1-10.6 34.2-7.8 44.8 6.4s7.8 34.2-6.4 44.8c-24 18-52.4 30.6-83.2 35.8V480c0 17.7-14.3 32-32 32s-32-14.3-32-32V445.3C101.2 430.1 32 351.1 32 256s69.2-174.1 160-189.3V32c0-17.7 14.3-32 32-32z"></path>
                                </svg>&nbsp;to scrape the entire site!<br><br> Opt-in means that consumers have agreed to receive product offerings and specials by email.<svg xmlns="http://www.w3.org/2000/svg" viewBox="-64 0 512 512" width="1em" height="1em" fill="currentColor" class="fs-6 currentColor">
                             
                                    <path d="M224 0c17.7 0 32 14.3 32 32V66.7c30.9 5.2 59.2 17.7 83.2 35.8c14.1 10.6 17 30.7 6.4 44.8s-30.7 17-44.8 6.4C279.4 137.5 252.9 128 224 128c-70.7 0-128 57.3-128 128s57.3 128 128 128c28.9 0 55.4-9.5 76.8-25.6c14.1-10.6 34.2-7.8 44.8 6.4s7.8 34.2-6.4 44.8c-24 18-52.4 30.6-83.2 35.8V480c0 17.7-14.3 32-32 32s-32-14.3-32-32V445.3C101.2 430.1 32 351.1 32 256s69.2-174.1 160-189.3V32c0-17.7 14.3-32 32-32z"></path>
                                </svg>&nbsp;per email!</p>
                            <p class="fs-4 text-center mt-4 mb-4">Volume discounts over 1,000 sites!</p>
                            <p class="fs-5 text-center text-black-50 mt-4 mb-4">Trap Email, “planted seeds”, are not added!<br>Added emails are in 1 column to easily upload to email!</p>
                            <!-- <a href="/contact.php" style="margin-left: 10px;">Contact Us!</a> -->
                        </div>
                    </div>
                </div>
                <div class="col-md-6 text-center d-flex flex-column align-items-sm-center justify-content-md-center align-items-md-center" ><img class="align-self-center" src="/images/scrapping.png" style="    width: 300px;"></div>
            </div>
        </div>
    </section>
        <section id="services-4b" class="services section-bg mb-3">
        <div class="container d-flex flex-column align-items-center">
            <div class="d-flex flex-column section-title text-center">
                <h1>Microsoft Free Unlimited Emailing</h1>
                <h3>by using our Viva Engage Social Media Software!</h3>
            </div>
            <div class="row flex-shrink-1 row-cols-1 row-cols-md-3">
                <div class="col d-flex flex-column flex-shrink-1 mt-4">
                    <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <img class="align-self-center img-fluid width160" src="/images/e1.png">
                        <h4><span class="emailverifyh4">Software Automates MSFT Emailing</span></h4>
                        <p class="fs-5 emailverify">Simply enter into software a sales pitch & upload unlimited emails! Files are created and auto uploaded repeatedly to Microsoft to email your invitation to your social media group.</p>

                    </div>
                </div>
                <div class="col d-flex flex-column flex-shrink-1 mt-4">
                    <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <img class="align-self-center img-fluid width160" src="/images/e2.png">
                        <h4><span class="emailverifyh4">Microsoft Emails Invitations!</span></h4>
                        <p class="fs-5 emailverify">Residents and/or Businesses see your sales pitch, get a link to your website, and are invited to join your Free Viva Engage social media Group! </p>
                    
                        
                    </div>
                </div>
                <div class="col d-flex flex-column flex-shrink-1 mt-4">
                    <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <img class="align-self-center img-fluid width160" src="/images/e3.png">
                        <h4><span class="emailverifyh4">Moderate your Social Media Group!</span></h4>
                        <p class="fs-5 emailverify">People join your group, and you decide if only you, or all members can post in the group.  <br>Members can see the posts in a free phone app or receive a Microsoft email.   </p>
                       
                    </div>
                </div>
            </div>
        </div>
    </section>
   <!-- overpriced email  -->
   <section id="services-4">
        <!-- Start: 1 Row 1 Column -->
        <div class="container">
            <div class="row">
                <div class="text-center col">
                    <h1>Consumer Data</h1>
                </div>
            </div>
            <div class="row d-flex">
                <div class="col">
                  <img class="img-fluid" src="/images/em_sli.png">
               </div>
                <div class="col d-flex align-items-xl-center">
                    <div class="px-2 mx-1 my-1">
                        <p class="fs-5">Our opt-in data has been categorized into subscribers interests based upon the opt-in website thereby providing you with highly targeted leads.</p>
                        <p class="fs-5">In addition to subscribers interests, you can do real time online queries using free selects such as: age, income, gender, ethnicity, dwelling status, geographic location, age of the data and more! Try our Consumer Data Query FREE</p>
                        <p class="fs-5">Additionally, it is also important to know if the traffic is direct traffic or referral traffic. This enables you to analyze the level of viral activity.</p>
                        <p class="fs-5">Much more!</p>
                    </div>
                </div>
            </div>
        </div><!-- End: 1 Row 1 Column -->
   </section>
  <!-- Start: Shut.link WLE -->
    <section id="services-5">
       <div class="text-center col mb-4">
        <h1>Business Data</h1>
       </div>
        <div class="container d-flex justify-content-center">
            <div class="row d-flex flex-column flex-xl-row">
                <div class="col d-flex flex-column align-items-sm-center">
                    <div style="height: 20px;">
                     <img width="320px" src="/images/em_abi.png"></div><img class="d-flex img-fluid" data-aos="slide-right" data-aos-duration="1000" src="/images/em_about.png" width="462" height="515">
                </div>
                <div class="col d-flex flex-column mt-4">
              
                    <div class="d-flex flex-column align-items-sm-center">

                        <p class="fs-4 p-3">Target by industry, geographic location, titles of executives, employee size, company revenues and more! Try our Business Data Query FREE</p>
                        <p class="fs-4 p-3">Create a Non Expiring Data Records Account! Our database is constantly being updated. We average 40 million fresh, full data records monthly!</p>
                        <p class="fs-4 p-3">Additionally our email software reports bounces in real time against the database, thereby removing these bounces from the query pool!.</p>
                        <p class="fs-4 p-3">Your non-expiring, full record data credits account enables you to pull targeted fresh data from our constantly refreshed database now or any time in the future!</p>
                    </div>
                </div>
            </div>
        </div>
<div id="threebox" class="threebox mt-4 mb-4">
<div class="container">
    <div class="row">
        <div class="col-md-12 p-3 text-center ">
            <img src="https://i.ibb.co/Z2McXs6/newmovers.png" class="newmovers">
            <h1 class="mb-3 mt-4">New Mover Daily Leads</h1>
        </div>
    </div>
            <div class="row flex-shrink-1 row-cols-1 row-cols-md-3 newmovers-daily">
                <div class="col d-flex flex-column flex-shrink-1 mt-4">
                     <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <img class="align-self-center img-fluid width160" src="/images/save.png">
                        <p class="fs-5 emailverify">Save your  criteria (zip codes, home price, mortgage amount, etc.) We then auto search the daily new movers feed, for data values that meet your targeted criteria!</p>
                    </div>
                </div>
                <div class="col d-flex flex-column flex-shrink-1 mt-4">
                     <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <img class="align-self-center img-fluid width160" src="/images/sales-letter.png">
                        <p class="fs-5 emailverify">Save a sales letter and we will personalize it, by automatically inserting the new mover contact info, and other saved data values, into your letter!</p>
                    </div>
                </div>
                <div class="col d-flex flex-column flex-shrink-1 mt-4">
                     <div class="d-flex flex-column justify-content-lg-center align-items-lg-center icon-boxcus shadow p-3">
                        <img class="align-self-center img-fluid width160" src="/images/email.png">
                        <p class="fs-5 emailverify">Automatically we email you the prepared sales letters to simply fold and mail from the local post office so you're there first! Ask us how to get their email too!</p>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-6 pt-4">
                   <h3 class="mb-4 mt-4 text-left">Full Access To Our 600 Million + Consumer Data</h3>
                   <h3 class="mb-4 mt-4 text-left">Full Access To Our 300 Million + Business Data</h3>
                   <h3 class="mb-4 mt-4 text-left">Full Access To Our 250 Million + US Houshold Demographics Data</h3>
                   <h3 class="mb-4 mt-4 text-left">Full Access To Our 350 Million + US Cell Phone Data</h3>
                  
                </div>
                <div class="col-md-6">
                <video width="100%" height="100%" controls>
                  <source src="/images/mover.mp4" type="video/mp4">
                  <source src="/images/mover.mp4" type="video/ogg">
                </video>
                </div>
            </div>
    </div>
</div>
</section>
<section class="PhoneNumbers">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="mb-4 text-center">&nbsp;New Phone Numbers Weekly Feed for&nbsp;B2C &amp; B2B!</h1>
                    </div>
                </div>
                <div class="row mb-5">
                    <div class="col-md-4">
                        <h3 class="mb-3 text-center fw-bold">Residential Gold Mine</h3>
                        <ul class="shadow">
                            <li class="fs-5" style="margin-bottom: 10px;"><span class="fw-semibold">Beat the Do Not Call List:</span> Reach new residents before restrictions apply</li>
                            <li class="fs-5" style="padding-bottom: 0px;margin-bottom: 10px;"><span class="fw-semibold">30-Day Window of Opportunity:</span> Connect with valuable leads during their transition period</li>
                            <li class="fs-5"><span class="fw-semibold">Tap into the Lucrative New Movers Market:</span>&nbsp;Offer timely, relevant services to fresh prospects</li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h3 class="mb-3 text-center fw-bold">Business Bonanza</h3>
                         <ul class="shadow">
                            <li class="fs-5" style="margin-bottom: 10px;"><span class="fw-semibold">First Mover Advantage:</span> Engage new businesses before your competitors</li>
                            <li class="fs-5" style="padding-bottom: 0px;margin-bottom: 10px;"><span class="fw-semibold">Shape Business Decisions:</span> Influence product and service choices from day one</li>
                            <li class="fs-5"><span class="fw-semibold">Build Lasting Relationships:</span> Be the first to welcome and support emerging enterprises</li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h3 class="mb-3 text-center fw-bold">Supercharge Your Outreach</h3>
                        <ul class="shadow">
                            <li class="fs-5" style="margin-bottom: 10px;"><span class="fw-semibold">Seamless Integration:</span> Effortlessly incorporate our data feed into your existing database</li>
                            <li class="fs-5" style="padding-bottom: 0px;margin-bottom: 10px;"><span class="fw-semibold">Multi-Channel Marketing:</span> Compatible with ringless voicemail services and AI dialers</li>
                            <li class="fs-5"><span class="fw-semibold">Enhanced Contact Information:</span> Cross-append with our extensive B2B and B2C data to add valuable email addresses</li>
                        </ul>
                    </div>
                </div>
            </div>
            
        </section>
<section id="cta-1" class="cta ConnectsDataNow">
        <div class="container">
            <div class="text-center">
                <h3>Seize the Moment - Get Your New Connects Data Now!</h3>
                <p> Stay ahead of the curve. Capitalize on fleeting opportunities. Transform new connects into loyal customers with our premium, time-sensitive data.</p><a class="cta-btn" href="#accordion-1">Act Now</a>
            </div>
        </div>
</section>
  <section class="award">
        <h1 class="text-center mt-5 mb-3">Award Winner</h1><!-- Start: Awards -->
        <div class="container mt-2">
            <div class="row">
                <div class="col-md-6 d-flex flex-column justify-content-between py-5">
                    <div class="d-flex flex-column">
                        <h2 class="txbdstitle sttwo hlight">Multiple Award Winner for Custom Development of Email Software!</h2>
                        <p class="fs-5 my-3" style="text-align: left;">#1 ProSoftwarePack.com's Email Filter Pro"EFP has all the features you could ever want in an antispam program, too numerous to mention here." </p><a class="fs-5 witr_btn" href="#">Read more </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="bounce animated elementor-element elementor-element-a9e2d7c elementor-widget elementor-widget-image slideInRight" data-id="a9e2d7c" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;slideInRight&quot;}" data-widget_type="image.default">
                        <div class="elementor-widget-container"><a href="#"><img class="img-fluid" width="988" height="702" src="https://whitelistemailing.com/wp-content/uploads/2024/05/pc-doc-and-inno.jpeg" alt="" srcset="https://whitelistemailing.com/wp-content/uploads/2024/05/pc-doc-and-inno.jpeg 988w, https://whitelistemailing.com/wp-content/uploads/2024/05/pc-doc-and-inno-300x213.jpeg 300w, https://whitelistemailing.com/wp-content/uploads/2024/05/pc-doc-and-inno-768x546.jpeg 768w" sizes="(max-width: 988px) 100vw, 988px"></a></div>
                    </div>
                </div>
            </div>
        </div><!-- End: Awards -->
    </section>
    <!-- End: Shut.link WLE -->

   <!-- Start: Email Options -->
   
     <section id="cta" class="cta">
        <div class="container d-flex justify-content-center">
            <div class="row d-flex flex-lg-row flex-column-reverse">
                <div class="col d-flex flex-column align-items-center m-auto">
                    <div class="text-center"></div>
                    <h1 class="text-light mb-3">Other Ways to Grow Your Business.</h1>
                    <div class="row d-flex flex-row">
                        <div class="col d-flex flex-row py-3">
                            <div class="d-flex flex-row"></div>
                            <div class="d-flex flex-row justify-content-end gap-5 w-100 growBusinesssection">
                                <div class="d-flex col-5 mob-tw-img">
                                    <img class="align-self-center img-fluid" src="https://whitelistemailing.com/wp-content/uploads/2023/10/em_bi5.png" width="74" height="74">
                                    <h4 class="fs-5 text-start text-light d-flex mx-2">Sales Leads <br>&amp; Buying Power</h4>
                                </div>
                                <div class="d-flex gap-2 col-5 mob-tw-img">
                                    <img class="align-self-center img-fluid" src="https://whitelistemailing.com/wp-content/uploads/2023/10/em_bi3.png" width="75" height="75">
                                    <h4 class="fs-5 text-start text-light mx-2">Free Promotion<br>of your Deals</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center">
                        <div class="col d-flex flex-row justify-content-center">
                           <div class="d-flex d-lg-flex flex-row justify-content-center gap-2 mob-tw-img">
                              <img class="flex-grow-1 img-fluid col-sm-6" src="/images/savingssites.jpg" alt="">
                              <img class="d-sm-flex flex-grow-1 col-5" src="/images/hugegroups.jpg">
                           </div>
                        </div>
                    </div>
                </div>
                <div class="col"><img class="m-auto img-fluid" src="/images/tracking_serices.png"></div>
            </div>
        </div>
    </section>
     <?php  include("includes/newFooter.php") ?>

      <!--Footer Section End -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/3.0.0-beta.6/aos.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/10.2.2/swiper-bundle.min.js"></script>

     <?php  include("includes/footerASH.php") ?>
    </div>
  </body>
</html>