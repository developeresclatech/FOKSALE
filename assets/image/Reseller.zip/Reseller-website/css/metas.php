   <meta name="keywords" content="<?=$CompanyName; ?>,Email Blast Software, Bulk Emailer, Opt In Email List,telemarketing lists,call lists,phone numbers,postal,mailing,lists,business,consumer,b2b,residential,USA,Canada,demographics,downloads" />
   <meta name="description" content="<?=$CompanyName; ?>,Email Blast and Bulk Emailer Software is a great Opt In Email utility which sends your emails to its respected or targeted client to generate business. We have over 500 million business &amp; residential email, postal addresses as well as phone numbers for telemarketing & bulk postal mailings.." />
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <meta http-equiv="Content-Style-Type" content="text/css" />  
    <link rel="icon" href="/images/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon" />
<link href="/css/style.css" rel="stylesheet" type="text/css" />
<link href="/css/layout.css" rel="stylesheet" type="text/css" />
<!--  <script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="js/cufon-yui.js" type="text/javascript"></script>
<script src="js/cufon-replace.js" type="text/javascript"></script>
<script src="js/Delicious_500.font.js" type="text/javascript"></script>
<script src="js/Delicious_500_Heavy.font.js" type="text/javascript"></script>
<script src="js/loopedslider.js" type="text/javascript"></script>
<script type="text/javascript" src="../../info.template-help.com/files/ie6_warning/ie6_script.js"></script>  -->