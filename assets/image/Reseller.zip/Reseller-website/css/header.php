 <!--  begin header  -->
<div align="center">
<!--   <div width="900" height="420" align="right" valign="top" style="background-image('images/headerbg.png');">
      <br /><br /><img src="images/lead_generation.jpg" alt="Lead Generation" width="250" height="100" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 </div>   -->
<div id="header">
   <div class="container">
      <div class="row-1">
         <div class="fleft"><a href="index.php"><img src="images/logo.png" alt="" /></a></div>
      <div class="fright">
           <?
	       if(User_ID)
		   {
			   echo "<div id='divGreeting'>Welcome Back, $CompName <a href='$_SERVER[PHP_SELF]?LO=Y' style='display: inline; color: #330066;'>Log Out</a></div>\n";
		   }
		   ?>
         </div>
      </div>
      <div class="row-2">
         <div class="fleft">
             <ul> 
            <li><a href="index.php" ><span>Home</span></a></li>
            <li><a href="Aboutus.php" <? if($_SERVER['PHP_SELF']=="/Aboutus.php") { echo 'class="active"'; } ?> ><span>
			About</span></a></li>
            <li><a href="consumer_records_search.php" <? if($_SERVER['PHP_SELF']=="/consumer_records_search.php") { echo 'class="active"'; } ?> ><span>Consumer Data Search</span></a></li>
            <li><a href="business_records_search.php" <? if($_SERVER['PHP_SELF']=="/business_records_search.php") { echo 'class="active"'; } ?>><span>B2B Data Search</span></a></li>
            <li><a href="contact.php" <? if($_SERVER['PHP_SELF']=="/contact.php") { echo 'class="active"'; } ?>><span>Contact</span></a></li>
            <li><a href="software.php" <? if($_SERVER['PHP_SELF']=="/software.php") { echo 'class="active"'; } ?>><span>Software</span></a></li>
            <li ><a href="purchase_data.php" <? if($_SERVER['PHP_SELF']=="/purchase_data.php") { echo 'class="active"'; } ?>><span>Purchase</span></a></li>
            <li><a href="listen-to-webinar.php" <? if($_SERVER['PHP_SELF']=="/listen-to-webinar.php") { echo 'class="active"'; } ?>><span>Webinar</span></a></li>
            <? if(User_ID) { ?>
            <li><a href="customer_profile.php" <? if($_SERVER['PHP_SELF']=="/customer_profile.php") { echo 'class="active"'; } ?>> <span>Manage Account</span></a></li>
            <li><a href="retrieve_data_files.php" <? if($_SERVER['PHP_SELF']=="/retrieve_data_files.php") { echo 'class="active"'; } ?>><span>Download Data</span></a></li>
            <li><a href="/customers_queries.php"  <? if($_SERVER['PHP_SELF']=="/customers_queries.php") { echo 'class="active"'; } ?>><span>Saved Queries</span></a></li>
            <? } else { ?>
             <li><a href="customer_profile.php" <? if($_SERVER['PHP_SELF']=="/customer_profile.php") { echo 'class="active"'; } ?>><span>Create Account</span></a></li>
           <? } ?>

          </ul> 

         </div>
        
      </div>
   </div>
</div>
<div class="tail-middle1">
<div id="divContent" style="padding: 0 50px; color:#FFF; width:890px;" >