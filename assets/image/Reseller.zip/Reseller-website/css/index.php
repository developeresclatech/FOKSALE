<?   
        include("./includes/siteData.php");
        include("./includes/dbConnect.php");
 ?><!DOCTYPE html>
  <html lang="en">
  <head><!--  Business Mailing List � Buy Email List,B2B, Consumer  Sales Leads, Email Marketing Software, Telephone Call Lists, Business Address Directory � - <?=$SiteName; ?>  -->
    <title>400 million in Opt In email leads, business leads, telemarketing leads - <?=$SiteName; ?></title>
    <? include("includes/metas.php"); ?>
    <? // include("includes/meta_dublin_core.php"); ?>
	<style type="text/css">
	  #tdLinks a
	  {
		  color:black;
		  text-decoration: none;
		  font-size:9pt;
	  }
	  #tdLinks 
	  { padding-left: 42px; }

	  .lg{
		  font-size:12pt;
	  }
	 .pagination a,  .pagination strong
	 {
		 color: #EEE;
	 }
	</style>
	<script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>
	<script src="js/Delicious_500.font.js" type="text/javascript"></script>
	<script src="js/cufon-replace.js" type="text/javascript"></script>
	<script src="js/cufon-yui.js" type="text/javascript"></script>
	<script src="js/Delicious_500_Heavy.font.js" type="text/javascript"></script>
	<script src="js/loopedslider.js" type="text/javascript"></script>
</head>

<body id="page1">
 <div class="extra-bg" id="top"></div>
 <?    include("./includes/home_header.php"); ?>
 <h1>400 million in Opt In email leads, business leads, telemarketing leads - <?=$SiteName; ?></h1>
 <div id="content" align="center">
   <div class="tail-middle1" >
      <div class="tail-middle1-top">
         <div class="row-1">
            <div class="inside" align="left">
               <div id="loopedSlider">
                  <div class="container">
                     <div class="slides">
                        <div class="slide"><img src="images/slide1-big.jpg" alt="slide 1" /></div>
                        <div class="slide"><img src="images/slide2-big.jpg" alt="slide 2" /></div>
                        <div class="slide"><img src="images/slide3-big.jpg" alt="slide 3" /></div>
                        <div class="slide"><img src="images/slide4-big.jpg" alt="slide 4" /></div>
                     </div>
                  </div>
                  <ul class="pagination">
                     <li><a href="/consumer_records_search.php"><strong><img src="images/slide1.png" alt="Targeted  E-mail Lists" />Targeted  E-mail Lists</strong><span>&nbsp;</span></a></li>
                     <li><a href="http://opt-in-email-marketing-lists.com/consumer_records_search.php"><strong><img src="images/slide2.png" alt="Consumer Data" />Consumer Data</strong><span>&nbsp;</span></a></li>
                     <li><a href="/business_records_search.php"><strong><img src="images/slide3.png" alt="Business Data" />Business Data</strong><span>&nbsp;</span></a></li>
                     <li><a href="/business_records_search.php"><strong><img src="images/slide4.png" alt="Solutions You Need!" />Solutions You Need!</strong><span>&nbsp;</span></a></li>
                  </ul>
   </div>
  <div  align="center" >
	<div id="divContent" style="padding: 0 50px; color:#FFF; width:800px; ">
	  <table width="800" border="0" align="center" cellpadding="5" cellspacing="0" class="textareacolor" style="width: 800px">
      <tbody class="style7">
        <tr>
          <td width="800" align="center" valign="top" class="style2">&quot;The #1 Trusted Email List Provider&quot;</td>
        </tr>
        <tr>
		   <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="5">
         <tr>
            <td align="left" valign="top" class="contenttitlered"><span class="style16">Our Services:</span> </td>
         </tr>
        </table>

         <table width="100%" border="0" cellspacing="0" cellpadding="5">
               <tr>
                 <td align="left" valign="top"><h1><img src="images/global.jpg" width="360" height="136" style="float:right;" alt="globe"  />
                    <br/><span class="style16">True Opt-In Targeted  E-mail Lists:</span>
                
				     <h1><span class="content"><?=$SiteName; ?>   has the largest opt-in consumer email database in the United   States.<br /><br />
                        Opt-in means that consumers have agreed to receive  product offerings and specials by email.</span></h1>
                    <br/> <h1><span class="style26"><strong>Consumer Data:</strong></span></h1>
                        <p class="content"><span class="content">Our opt-in data has been categorized into 	subscribers interests based upon the opt-in website thereby  providing you with highly targeted leads. </span></p>
                   <p class="content"> In addition to subscribers interests, you can do real time online queries using free selects such as: age, income, gender, ethnicity, dwelling status, geographic location, age of the data and more!   <a href="/consumer_records_search.php">Try our Consumer Data Query FREE</a></p>
                <p class="style11"><span class="style26">Business Data:</span><br />
                     <span class="content">Target by industry, geographic location, titles of executives, employee size, company revenues and more! <a href="/business_records_search.php">Try our Business Data Query FREE</a></span></p>
                    <p class="style11"><span class="style21"><span class="style26"> <strong>Create a Non Expiring Data Records Account! </strong></span><span class="style23"><br />
                      </span><span class="content">Our database is constantly being updated. We average 40 million fresh, full data records monthly!</span></span></p>
                    <p class="content">Additionally our email software reports bounces in real time against the database, thereby removing these bounces from the query pool!.</p>
                    <p class="style11"><span class="content">Your non-expiring, full record data credits account enables you to pull targeted fresh data from our constantly refreshed database now or any time in the future! </span></p><br />
				  </td>
                </tr>
                <tr>
                  <td align="center" valign="top">
                  <hr />
                      <h1><span  class="style2">� Search Anonymously �</span></h1>
                      <table width="800">
                        <tr>
                          <td  class="style17">
						   <ul>
                             <li class="style25"><h3>Full Access  To Our 450 Million + Consumer Data</h3></li>

                             <li class="style25"><h3>Full Access To Our 300 Million + Business Data</h3></li>
                             
                              <li class="style25"><h3>Full Access To Our 250 Million + US Houshold Demograpohics Data</h3></li>
                              
                               <li class="style25"><h3>Full Access To Our 350 Million + US Cell Phone Data</h3></li>
                               
                                <li class="style25"><h3>Full Access To Our 300 Million + US Automotive Registrations with email address</h3></li>
                               
                       <!--       <li><p class="style25"><strong>Additional Text</strong></p></li>
                            <li><p class="style25"><strong>Additional Text</strong></p></li>  -->
                         </ul>
						</td>
                        <td width="350" align="right" valign="middle"><img src="images/http.jpg" alt="http image" width="350" height="121" /></td>
                       </tr>
                    </table></td>
                </tr>
                <tr>
                  <td align="center" valign="top">
				    <p><span class="content">Check often for new updates to our database.<br/>
                    Contact  Us with your special needs or requests.</span></p>
				</td>
                </tr>
            </table></td>
        </tr>
      </tbody>
     </table>
	</div><!--  end content  -->
  </div>
 </div>
</div>
</div>
   <div class="tail-middle2">
      <div class="row-2"></div>


   <? include('includes/footer.php') ?>

</div>
<script type="text/javascript"> Cufon.now(); </script>
<script type="text/javascript" charset="utf-8">
	$(function(){
		// Option set as a global variable
		$.fn.loopedSlider.defaults.addPagination = true;
		$('#loopedSlider').loopedSlider();
	});
</script>

</body>
</html>