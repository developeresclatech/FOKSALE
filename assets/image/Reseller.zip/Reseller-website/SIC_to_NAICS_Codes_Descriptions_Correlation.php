<?
	  include("./includes/siteData.php");
	 extract($_POST);
?><!DOCTYPE html>
  <html lang="en">
<head>
 <title><?=$SiteName; ?>: NAICS to SIC Codes Descriptions &amp; Correlations</title>
  <? include("includes/metas.php"); ?>
  <style type="text/css">
	   input[type=text], input[type=password], textarea
		{

			margin:1px;
			margin-right:2px;
			margin-top:2px;
			border:2px solid #7f7f7f;
			background-color: #F2f2f2;
		}
		select
		{
			background-color: #CCCCDD;
		}
		h5
		{
             text-align: center;
			 font-style:italic;
			 font-size: 14pt;
			 color:#FF0011;
		}
		#fsLast label
		{
          font-size: 11pt;
		  font-weight: bold;
		}
		.narrowNew   /*  lhs column height  */
		{
			height:6250px;
        }
		label, *
		{
			 font-size: 9pt;
			 color:#330066;
		}
	   #searchContent b,  #NAICS_SIC td, #tblHeader th
		{
			 font-size: 10pt;
			 color:#FFFF99;
			 font-weight: 800;
	   }
	   caption
		{
			 font-size: 12pt;
			 color:#FFFF99;
			 font-weight: 800;
	   }
	   #NAICS_SIC td
		{
			 font-size: 10pt;
			 color:#000000;
			 font-weight: 800;
	   }
	 #frmRelations *
	 {
			 color:#222222;
			 font-weight: 600;
	   }
   </style>
<!--    <script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
  <script src="Scripts/checkconsumer.js" type="text/javascript"></script>
  <script language="javascript" type="text/javascript" src="Scripts/fadescript.js"></script>  -->
</head>

<body>
   <? include("includes/header.php"); ?>
   <table  border="0" align="center" cellpadding="0" cellspacing="0" id="tblContent">
	  <tr>
	   <td width="10%">&nbsp;</td>
	   <td width="80%" align="center">
 <!--  CONTENT AREA, INSERT GUTS HERE  -->
	<div  id="searchContent" >
		<form method="post" action="<?=$_SERVER['PHP_SELF']; ?>"  onsubmit="" name="" id="frmRelations">
	        <h3>Search on SIC or NAICS Code. You can enter full or partial code:</h3><hr />
			 SIC   Code: <input type="text" name="SIC_CODE" style=";" id="SIC_CODE"  maxlength="4" size="4"  value="<?=$SIC_CODE ;?>"  />&nbsp;OR&nbsp;
			 NAICS   Code: <input type="text" name="NAICS_CODE" style=";" id="NAICS_CODE"  maxlength="6" size="4"  value="<?=$NAICS_CODE ;?>"  />
			<input type="submit" name="subSearch" id="subSearch"  style=";" value="Search on Codes"  accesskey="s"   title="Search on and entered code above" />
		</form>
         <?php
            $SIC =  trim($_REQUEST['SIC_CODE']);
		    if(preg_match("/^\d{1,6}$/", $SIC))
			{
			   $SIC_CODE =   $SIC ;       
			   $cond = "for SIC Code of $SIC_CODE";
			}

		    $NAICS = (trim($_REQUEST['NAICS_CODE']));
		    if(preg_match("/^\d{1,6}$/",$NAICS))
			{
			   $NAICS_CODE =   $NAICS ;  
			   $cond = "for NAICS Code of $NAICS_CODE";
			}


		     $fh = fopen("includes/SIC_and_NAICS_Business_CODES_Correlation.csv", "r");
			 if($fh)
			 {
			  echo "<table width=\"100%\" id=\"NAICS_SIC\">\n<caption style='color:#222222;'>NAICS to SIC Codes Descriptions &amp; Correlations $cond</caption>\n";
			  echo "<tr id=\"tblHeader\"><th width=\"4%\">SIC Code</th><th width=\"46%\">SIC Description</th><th  width=\"5%\">NAICS Code</th><th width=\"45%\">NAICS Description</th></tr>\n";
			  while(!FEOF($fh))
			  {
				 $strArray = fgetcsv($fh, 2000, ",");
				 if( $r%2)
                   $BGColor = "#FFFF99";
				 else
                   $BGColor = "#FFFFFF";
				 if($SIC_CODE > 0)
                 {
                    if(strlen($SIC_CODE) < 4)
					{
						$len = strlen($SIC_CODE);
                        if(substr($SIC_CODE,0, $len) == substr($strArray[0],0, $len))
						 {
						   echo "<tr style=\"background-color: $BGColor;\"><td>$strArray[0]</td><td>$strArray[1]</td><td>$strArray[2]</td><td>$strArray[3]</td></tr>\n";
						   $r++;
						 } 
                     }
                    elseif($SIC_CODE == $strArray[0])
					{
				      echo "<tr style=\"background-color: $BGColor;\"><td>$strArray[0]</td><td>$strArray[1]</td><td>$strArray[2]</td><td>$strArray[3]</td></tr>\n";
					  $r++;
					}
				 }
				 elseif($NAICS_CODE > 0)
                 {
           		    if(strlen($NAICS_CODE) < 6)
					{
						$len = strlen($NAICS_CODE);
                        if(substr($NAICS_CODE,0, $len) == substr($strArray[2],0, $len))
						 {
						   echo "<tr style=\"background-color: $BGColor;\"><td>$strArray[0]</td><td>$strArray[1]</td><td>$strArray[2]</td><td>$strArray[3]</td></tr>\n";
						   $r++;
						 } 
                     }
                    elseif($NAICS_CODE == $strArray[2])
                     {
				       echo "<tr style=\"background-color: $BGColor;\"><td>$strArray[0]</td><td>$strArray[1]</td><td>$strArray[2]</td><td>$strArray[3]</td></tr>\n";
					   $r++;
                     } 
				 }		
				 else
                 {
				      echo "<tr style=\"background-color: $BGColor;\"><td>$strArray[0]</td><td>$strArray[1]</td><td>$strArray[2]</td><td>$strArray[3]</td></tr>\n";
					  $r++;
				 }	               
              }
			  echo "</table>\n";
			 }


?>
      </div>

	  </td>
	  <td width="10%">&nbsp; </td>
	 </tr>
	</table><!-- end Content area -->	

     <? include("includes/footer.php"); ?>
</body>
</html>