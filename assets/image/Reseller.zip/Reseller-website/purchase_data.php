<?
        include("./includes/siteData.php");
        include("./includes/dbConnect.php");
 ?><!DOCTYPE html>
  <html lang="en">
  <head>
    <title><?=$SiteName; ?>; Consumer and Business Email Address: Purchase Data</title>
    <? include("includes/metas.php"); ?>
  <style type="text/css" >

         h1
		{
		    color: #E7A856;
		   text-shadow: 1px 1px 1px black;
		   font-size:19pt;
		   margin: 21px 0;
		}
	</style>
  <link href="css/style.css" rel="stylesheet" type="text/css" />
  <link href="css/layout.css" rel="stylesheet" type="text/css" />
  </head>
<body>
   <? include("includes/header.php"); ?>
   
    <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" style="background:none">
  <tr>
    <td align="left" valign="top" class="p2">
	<table border="0" cellspacing="0" cellpadding="5" style="width: 800px" align="center">
      <tr>
        <td align="left" valign="top">
		  <table width="75%" border="0" align="center" cellpadding="5" cellspacing="5" style="width: 100%">
            <tr>
              <td align="left" valign="top"><span class="contenttitlered">Purchase</span></td>
            </tr>
            <tr>
              <td align="left" valign="top">
			  <h1>Data Only</h1>
			 			 
              <tr>
    <th width="254" scope="col"><strong><u>Data Only</u></strong></th>
    <th width="690" scope="col"><strong><u>Discount Pricing
     </u></strong></th>
  </tr>
  <tr>
    <td>10,000</td>
    <td>$195</td>
  </tr>
  <tr>
    <td>100,000</td>
    <td>$395</td>
  </tr>
  <tr>
    <td>500,000</td>
    <td>$595<span class="redbig"> * * * * On Sale $495</span></td>
  </tr>
  <tr>
    <td>1,000,000</td>
    <td>$795</td>
  </tr>
  <tr>
    <td>2,000,000</td>
    <td>$995</td>
  </tr>
  <tr>
    <td>10,000,000</td>
    <td>$2,995</td>
  </tr>
  <tr>
    <td>20,000,000</td>
    <td>$3,995</td>
  </tr>
  <tr>
    <td>30,000,000</td>
    <td>$4,995</td>
  </tr>
  <tr>
    <td>50,000,000</td>
    <td>$5,995</td>
  
            </tr>
          </table><br /><br />
          
 <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="UGBKART9DR8VG">
<table width="472">
<tr><td width="430"><input type="hidden" name="on0" value=":">
Purchase Data Here - Select Data Quantity From Drop Down List</td></tr><tr><td><select name="os0">
	<option value="10,000 Data Credits">10,000 Data Credits $195.00 USD</option>
	<option value="100,000 Data Credits">100,000 Data Credits $395.00 USD</option>
	<option value="500,000 Data Credits">500,000 Data Credits $495.00 USD</option>
	<option value="1,000,000  Data Credits">1,000,000  Data Credits $795.00 USD</option>
	<option value="2,000,000 Data Credits">2,000,000 Data Credits $995.00 USD</option>
	<option value="10,000,000 Data Credits">10,000,000 Data Credits $2,995.00 USD</option>
	<option value="20,000,000 Data Credits">20,000,000 Data Credits $3,995.00 USD</option>
	<option value="30,000,000 Data Credits">30,000,000 Data Credits $4,995.00 USD</option>
	<option value="50,000,000 Data Credits">50,000,000 Data Credits $5,995.00 USD</option>
	<option value="60,000,000 Data Credits">60,000,000 Data Credits $6,995.00 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>         
          <br /><br />
          
 <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" style="background:none">
  <tr>
    <td align="left" valign="top" class="p2">
	<table border="0" cellspacing="0" cellpadding="5" style="width: 800px" align="center">
      <tr>
        <td align="left" valign="top">
        
         <hr/><hr/>
         
         
		  <table border="0" cellspacing="0" cellpadding="5" style="width: 100%" align="center">
            
              <td align="left" valign="top">
			  <h1>Blast Email Marketing Machine Software + Data</h1>  
<h1>Monthly Payment Options</h1>  
			  </td> 
            </tr> </table>
            <table cellpadding="5" cellspacing="5">
            
  <tr align="center">
    <th width="69" scope="col">Data Included</th>
    <th width="150" scope="col"> Blast Email Marketing Machine Software License(s)</th>
    <th width="125" scope="col">Data Records to Start</th>
    <th width="125" scope="col">More Data Records Every Month</th>
    <th width="50" scope="col">First Months Payment</th>
    <th width="50" scope="col">Monthly Payment</th>
    <th width="188" scope="col">Sign Up Now</th>
  </tr>
  <tr>
    <td>1 Million</td>
    <td align="center">1</td>
    <td>175,000</td>
    <td>75,000</td>
    <td>$495</td>
    <td>$150</td>
    <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="EYGDHWE6Q9XRY">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</td>
  </tr>
  <tr>
    <td>5 Million</td>
    <td align="center">1</td>
    <td>1,150,000</td>
    <td>350,000</td>
    <td>$795</td>
    <td>$250</td>
    <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="AZ79GRXERLYAU">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</td>
  </tr>
  <tr>
    <td>15 Million</td>
    <td align="center">1</td>
    <td>4,000,000</td>
    <td>1,000,000</td>
    <td>$1495</td>
    <td>$300</td>
    <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="QRGB4VBB5VH4C">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</td>
  </tr>
  <tr>
    <td>30 Million</td>
    <td align="center">2</td>
    <td>8,000,000</td>
    <td>2,000,000</td>
    <td>$2495</td>
    <td>$350</td>
    <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="LAA44LPWFKTLY">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</td>
  </tr>
  <tr>
    <td>60 Million</td>
    <td align="center">2</td>
    <td>16,000,000</td>
    <td>4,000,000</td>
    <td>$3495</td>
    <td>$500</td>
    <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="YABCB4BWF25X6">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</td>
  </tr>
  <tr>
    <td>120 Million</td>
    <td align="center">3</td>
    <td>32,000,000</td>
    <td>8,000,000</td>
    <td>$4995</td>
    <td>$1000</td>
    <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="EQ7LVXCZD67JS">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
</td>
  </tr>
</table>
            
    <hr/>        <hr/>
         
		 
		  <table border="0" cellspacing="5" cellpadding="5" style="width: 100%" align="center">
            <tr>
              <td align="left" valign="top">
			     <h1>Contact Page Marketing Machine</h1> 
			     <p>For details and videos please visit <a href="http://contactpagemarketingmachine.com/" class="blue">ContactPageMarketingMachine.com.</a> FREE Software demo available <a href="http://forms.aweber.com/form/45/669726545.htm" target="_blank" class="blue">here</a></p></td>
            </tr>
            <tr>
              <td align="left" valign="top"><table width="799" border="0" cellpadding="5" cellspacing="5">
                <tr>
                  <td width="595">1 Contact Page Marketing Machine License +  1 Million FREE Data Records = $1,995</td>
                  <td width="188">&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post"><input type="hidden" name="cmd" value="_s-xclick" /> <input type="hidden" name="hosted_button_id" value="4Q24JXXGW8AYJ" /> <input type="image" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" alt="PayPal - The safer, easier way to pay online!" /> <img src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" alt="" width="1" height="1" border="0" /></form></td>
                </tr>
                <tr>
                  <td>2 Contact Page Marketing Machine Licenses + 3 Million FREE Data Records = $2,995</td>
                  <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post"><input type="hidden" name="cmd" value="_s-xclick" /> <input type="hidden" name="hosted_button_id" value="5NCM8JGJEVU2S" /> <input type="image" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" alt="PayPal - The safer, easier way to pay online!" /> <img src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" alt="" width="1" height="1" border="0" /></form></td>
                </tr>
                <tr>
                  <td>3 Contact Page Marketing Machine Licenses + 5 Million FREE Data Records = $3,995</td>
                  <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post"><input type="hidden" name="cmd" value="_s-xclick" /> <input type="hidden" name="hosted_button_id" value="VWNLMENJMPTRE" /> <input type="image" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" alt="PayPal - The safer, easier way to pay online!" /> <img src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" alt="" width="1" height="1" border="0" /></form></td>
                </tr>
              </table>
                <br />
                <p>Payment plans also available, please visit <a href="http://contactpagemarketingmachine.com/" class="blue">ContactPageMarketingMachine.com</a> for details.</p></td>
            </tr>
          </table>
		   <hr/><hr/>

		  
		   


		<table border="0" cellspacing="0" cellpadding="5" style="width: 100%" align="center">
          
            <tr>
              <td align="left" valign="top" class="style23">
			   <h1>B2B Lead Generator:</h1>
			   <h1>Yellow Pages Lead Finder: </h1>
			   </h1>
			   <p>Please visit <a href="http://b2bmarketingmagic.com" target="_blank" class="blue">B2B Markting Magic</a> for more information and demonstration videos. FREE Software demos are available <a href="http://forms.aweber.com/form/45/669726545.htm" target="_blank" class="blue">here</a></p>
               <table width="800" border="0" cellspacing="5" cellpadding="5">
                 <tr>
                   <td><span class="banner-indent">
                     <h6>&nbsp;</h6>
                   </span></td>
                   <td>Subscription Plan</td>
                   <td>Ordew Now </td>
                 </tr>
                 <tr>
                   <td><span class="banner-indent">
                     <h6><strong>B2B Lead Generator </strong><br/>
                       Subscription</h6>
                   </span></td>
                   <td><span class="banner-indent">
                     <h6></h6>
First month $145 then only $45 per month thereafter. </span></td>
                   <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="DMZ8DLDJVPM3U">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form></td>
                 </tr>
                 <tr>
                   <td><strong>Yellow Pages Lead Finder </strong><br/>
                     Subscription</td>
                   <td><span class="banner-indent">
                     <h6></h6>
First month $145 then only $45 per month thereafter. </span></td>
                   <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="WCH8Z58N35Y2Q">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form></td>
                 </tr>
                 <tr>
                   <td><p>Combo - Both <strong>B2B Lead Generator </strong>AND <strong>Yellow Pages Lead Finder </strong><br/>Subscription</p></td>
                   <td><span class="banner-indent"> First month $245 then only $65 per month thereafter. </span></td>
                   <td>&nbsp;<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="77YMGALJTK592">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form></td>
                 </tr>
                 <tr>
                   <td>&nbsp;</td>
                   <td>&nbsp;</td>
                   <td>&nbsp;</td>
                 </tr>
                 <tr>
                   <td>&nbsp;</td>
                   <td>&nbsp;</td>
                   <td>&nbsp;</td>
                 </tr>
               </table>
                <hr/><hr/>
			     <h1>Classifieds Collector: <br />
			     </h1>
			     <p>FREE Software demo available <a href="http://forms.aweber.com/form/45/669726545.htm" target="_blank" class="blue">here</a></p>
			    <hr/><hr/> <h1>&nbsp;</h1>
			     <h1>Realtor Marketing Machine:
			       </h1>			   
  <br />
			       </h1>			     <p>FREE Software demo available <a href="http://forms.aweber.com/form/45/669726545.htm" target="_blank" class="blue">here</a></p>

                </td>
            </tr>
          </table>
           <hr/><hr/>
           <table border="0" cellspacing="0" cellpadding="5" style="width: 100%" align="center">
            <tr>
              <td align="left" valign="top">
			    <h1>Search Engine Extractor</h1>
			 </td>
            </tr>
            <tr>
              <td align="left" valign="top"><br />
                <span class="style26">Purchase Options:</span><br /><br />
					<p>1 <span class="style26">Search Engine Extractor</span> License + 250 Thousand FREE Records = $1,695</p>
					<p>2 <span class="style26">Search Engine Extractor</span> Licenses + 1 Million FREE Records = $2,370</p>
					<p>2+ <span class="style26">Search Engine Extractor</span> Licenses ...Please Contact Us For Special Pricing</p>
               </td>
            </tr>
          </table>
		   <hr/><hr/>

		 <table border="0" cellspacing="0" cellpadding="5" style="width: 100%" align="center">
            <tr>
               <td align="left" valign="top" class="redbig"><h1>Combination Packages:</h1></td>
            </tr>
            <tr>
              <td align="left" valign="top" class="style26"><p class="style26">We Offer Special Pricing For "Combination Packages". </p>
                   <p class="style26"><a href="contact.php"class="blue">Please Contact Us For Pricing</a> (we will definitely make you a valuable proposition)</p>
              </td>
            </tr>
          </table>
         </td>
      </tr>
    </table></td>
  </tr>

</table>
  <? include("includes/footer.php"); ?>
 </body>
</html>