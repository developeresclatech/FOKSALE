<?php
session_start();
//error_reporting(E_ALL);
//ini_set('display_errors', true);
//ini_set('html_errors', true);
if(isset($_REQUEST['orgid'])) {
	$_SESSION['s_orgid'] = base64_decode($_REQUEST['orgid']);
	//echo "the orgid is now ".$_SESSION['s_orgid']."<br>";
} 
//if(isset($_REQUEST['cat'])) {
//	$mycat = $_REQUEST['cat'];
//} else $mycat = "";

include ( $_SERVER['DOCUMENT_ROOT'] . "/conf.php" );
include(str_replace("public_html", "", $_SERVER['DOCUMENT_ROOT']) . 'defines.php');
$css_dir = "business_web/css/";
$image_dir = "business_web/include/";


#handle one click unsubscribes here:
if (isset($_GET['unsubscribe'])) {
	$query = "select idsubscriber from subscriber where email='".addslashes(urldecode($_GET['unsubscribe']))."' and idorg=".intval(base64_decode($_REQUEST['orgid']));
	$d->query($query);
	if($d->num_rows() == 0) {
		$msg = "Your email, ".urldecode($_GET['unsubscribe']).", was not found in our system";
		//echo "query was $query";
	} else {
		$d->next_record();
		$thisSid = $d->f('idsubscriber');
//		$query = "delete from subscriber where idsubscriber=$thisSid";
		$query = "update subscriber set idsubtype=2 where idsubscriber=$thisSid";
		$d->query($query);
//		$query = "delete from organization_has_subscriber where idsubscriber=$thisSid";
//		$d->query($query);
		$msg = "Your email, ".urldecode($_GET['unsubscribe']).", was removed from the email list";
	}
	echo $msg;
	exit;
}

if(isset($_POST['submit'])) {
	$username = addslashes($_POST['blog_username']);
	$password = base64_encode($_POST['blog_password']);
	//echo "password is $password, unencoded is ".$_POST['blog_password']."<br>";

	$query = "select idsubscriber from subscriber where email='$username' && password='$password' ";
	$d->query($query);
	//echo "query was $query<br>";
	if($d->num_rows() == 0) {
		$msg = "Your login was unsuccessful, please try again";
//		header("location: http://www.emailnotices.com/blog_login.php");
//		exit;
	} else {
		$d->next_record();
		$sid = base64_encode($d->f('idsubscriber')); 
		$myOrgID=base64_encode($_SESSION['s_orgid']);
		//echo $d->f('email') . ' ' . $d->f('idsubscriber') . ' ' . base64_decode($d->f('password')) . ' ' . $d->num_rows();
		header("location: http://www.emailnotices.com/edit_profile/resident_edit.php?sid=$sid=&orgid=$myOrgID");
	}
}
?>
<html>
<head>
<script type='text/javascript'>
<!-- //
function popup(myorgid,myorgname)
{
	myurl = 'forgot_password.php';
	email = document.login.blog_username.value;
	if(email == "")
	{
		alert('Please input email address!');
		return;
	}
	url = myurl + '?mail=' + email + '&id=' + myorgid + '&name=' + myorgname;
	window_parms = 'width=400,height=210,toolbars=no,scrollbars=no,resizable=yes';
	mywindow = window.open(url, 'mywindow', window_parms); 
	mywindow.moveTo(0,0);
}
// -->
</script>
</head>
<body leftmargin="0" topmargin="0" bgcolor="#ffffff" marginheight="0" marginwidth="0">
<?php
$query = "select name,defaultemailtemplate from organization where idorg='" . $_SESSION['s_orgid'] . "' ";
$result = $d->query($query);
$row = mysql_fetch_object($result);
$showName=true;
if(isset($row->name)) {
	$name = str_ireplace(array('e-Notices', 'Email Notices'), "", $row->name);
	if(strlen($name) > 20)
		$name = substr($name, 0, 16) . '...';
	if(isset($row->defaultemailtemplate)) {
		if ($row->defaultemailtemplate==="F") {
			$showName=false;
		}
	}
} else {
	$name = 'No Town';
}
?>
<center>
  <!--<table width="1000" height="150" border="0" cellpadding="0" cellspacing="0" bgcolor="#336699">-->
  <table border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
  <tbody>
  <tr>
<?
//echo "the town name query was $query<br>";
//$result = $d->query("select template_id from tbl_template where org_id='" . $_SESSION['s_orgid'] . "' ");
//$row = mysql_fetch_object($result);

if (isset($_GET['tid'])) {
	$myFolder = $_GET['tid'];
	$image_dir = "template/$myFolder/images/";
} else {
	$image_dir = "template/25/images/"; // this is where the default template is
	$showName=true;
	$name= "Resident Email Notices";
}
if ($showName) {
	$bannerLHeight = "height='115'";
	$bannerRHeight = "height='150'";
	?>
    <td width="260" height="35" align="left" bgcolor="336699">
		<div align="center" class="style9" style='border:1px none white'>
		<?
		print "\t<span style='color: #e8e8e8; font-size: 1.2em;font-weight:bold'>$name</span></b>";
		?>
		</div>
    </td>
	<?
} else {
	$bannerLHeight = "";
	$bannerRHeight = "";
	echo "<td></td>";
}
?>
    <!--<td height="150" rowspan="2" align="left">
	<img src="<?php echo $image_dir; ?>bannerR.jpg" alt="BannerR" width="740" height="150">-->
    <td rowspan="2" align="left">
	<img src="<?php echo $image_dir; ?>bannerR.jpg" alt="BannerR" <? echo $bannerRHeight; ?>>
    </td>
  </tr>
  <tr>
    <!--<td width="260" <? echo $bannerLHeight; ?> align="left">
	<img src="<?php echo $image_dir; ?>bannerL.jpg" alt="BannerL" width="260" <? echo $bannerLHeight; ?>>-->
    <td <? echo $bannerLHeight; ?> align="left">
	<img src="<?php echo $image_dir; ?>bannerL.jpg" alt="BannerL" <? echo $bannerLHeight; ?>>
    </td>
  </tr>
  <tr>
	<? 
	if (!isset($_GET['tid'])) {
		?>
	    <td height='500' bgcolor="#336699">
		&nbsp;
	    </td>
	    <?
	} else {
		?>
		<td bgcolor='#ffffff' height='500'></td>
		<?
	}
	?>
    <td bgcolor='#ffffff' valign='top'>
	<?
	if (isset($msg)) echo "<center>$msg</center>";
	?>
 	<form name='login' action='#' method='post'>
	<table width='400' height='150' border='0' cellspacing='0' cellpadding='6'>
	  <tr>
	    <td align='center' colspan='3'>
		<span style='font-size: 1.2em; color: #336699; font-weight: bold'>
		Profile Login
		</span>
	    </td>
	  </tr>
	  <tr>
	    <td width='10'>
		&nbsp;
	    </td>
	    <td align='right'>
		<span style='font-size: .8em; color: #888888; font-weight: bold;'>
		Email address:
		</span>
	    </td>
	    <td>
		<input type='text' name='blog_username' size='30' value=''>
	    </td>
	  </tr>
	  <tr>
	    <td width='10'>
		&nbsp;
	    </td>
	    <td align='right'>
		<span style='font-size: .8em; color: #888888; font-weight: bold;'>
		Password:
		</span>
	    </td>
	    <td>
		<input type='password' name='blog_password' size='12' value=''>
	    </td>
	  </tr>
	  <tr>
	    <td colspan='3' align='center'>
		<a href="javascript:popup('<?echo $_SESSION['s_orgid']; ?>','<?php echo $name; ?>')">
		<span style='font-size: .8em; font-weight: bold; color: #336699; text-decoration: none'>
		Forgot password?
		</span>
		</a>
	    </td>
	  <tr>
	    <td colspan='3' align='center'>
		<input type='submit' name='submit'>
	    </td>
	  </tr>
	  <tr>
	    <td colspan='3' align='center'>
	    <span style='font-size: .8em; font-weight: bold; color: #336699; text-decoration: none'>
		If this is the first time you are attempting to access your change of profile
registration page, we have temporarily assigned you the password: "changeme" 
You will be able to change this temporary "changeme" password when you login
		</span>
		</td>
	  </tr>
	</table>
	</form>
    </td>
  </tr>  
  </tbody>
</table>


</body>
</html>

