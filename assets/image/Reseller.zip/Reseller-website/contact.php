<?
////////////////////// OPEN DB  ////////////////////////////////////
include_once("./includes/siteData.php");
include_once("./includes/dbConnect.php");
extract($_POST);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title><?= $SiteName; ?>: Contact Us</title>
    <? include("includes/metas.php");
    include("includes/links.php"); ?>
    <script type="text/javascript">
        function NextBox(boxID, event) {
            if (event.keyCode > 47) {
                Box = document.getElementsByTagName('input');
                BoxL = Box.length;
                llen = document.getElementById(boxID).value.length;
                maxL = document.getElementById(boxID).maxLength;
                if (llen >= maxL) {
                    for (x = 0; x < BoxL; x++) {
                        if (boxID == Box[x].id) {
                            Box[++x].focus();
                            //Box[x].select();
                            break;
                        }
                    }
                }
            }
        }

    </script>
    <style type="text/css">
        .required {
            color: red;
            font-size: 19px;
        }

        input[type=text],
        input[type=password],
        textarea {

            margin: 1px;
            margin-right: 2px;
            margin-top: 2px;
            color: #000000;
        }

        h5 {
            text-align: center;
            font-style: italic;
            font-size: 14pt;
            color: #FF0011;
        }

        #fsLast label {
            font-size: 11pt;
            font-weight: bold;
        }

        label {
            font-size: 9pt;
            color: #ffffff;
        }

        b {
            font-size: 9pt;
            color: #ffffff;
            font-weight: 800;
        }

        #divStatus,
        #divStatus * {
            color: brown;
            font-size: 14pt;
            height: 30px;
        }

        #divCenter .tail-middle1 #divContentALL #tblContents tr td #frmMail #div_mail #tbl_email tbody tr .contenttitlered h1 {
            color: #000;
        }

        #frmMail label {
            color: #000;
        }

        #frmMail .inp {
            width: 100% !important;
        }
        .sendcontact{
            padding: 14px 65px;
            font-size: 17px;
            border: 1px solid #fff;
            color: #fff;
            background-color: #000;
            border-radius: 35px;
            font-weight: 600; 
        }
    </style>
</head>

<body>

    <? include("includes/newhome_header.php"); ?>

    <section class="section section-xs content newcheckbusiness con7">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1>Contact Us</h1>
                    <p>If you are having trouble logging in, please include the email you used to register with us,
                        and/or
                        your account username and account ID# too</p>
                </div>
            </div>
            <div
                class="row d-flex flex-sm-column-reverse flex-md-row justify-content-center flex-xs-column-reverse w-100">
                <div
                    class="col-md-6 col-lg-8 col-xl-7 offset-lg-0 d-lg-flex justify-content-lg-center align-items-lg-center">
                    <ul class="list-group">
                        <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                            <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                    width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                    <path
                                        d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                    </path>
                                </svg>
                                <p class="mx-2 list-text">Data Credits don't expire!</p>
                            </div>
                        </li>
                        <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                            <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                    width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                    <path
                                        d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                    </path>
                                </svg>
                                <p class="mx-2 list-text">One credit for one full record!</p>
                            </div>
                        </li>
                        <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                            <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                    width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                    <path
                                        d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                    </path>
                                </svg>
                                <p class="mx-2 list-text">No extra cost to select many criteria!</p>
                            </div>
                        </li>
                        <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                            <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                    width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                    <path
                                        d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                    </path>
                                </svg>
                                <p class="mx-2 list-text">You can require your search results include executives emails.
                                </p>
                            </div>
                        </li>
                        <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                            <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                    width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                    <path
                                        d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                    </path>
                                </svg>
                                <p class="mx-2 list-text">We'll give you extra records to more than cover any bounces!
                                </p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-md-6 col-lg-4 d-sm-flex justify-content-sm-center"><img src="/images/search-db-1080.png"
                        width="320px"></div>
            </div>
            <?
            extract($_POST);
            if (isset($sendemail)) {

                if (1) {
                    if (($lname != "" || $fname != "") && $comment != "") {
                        $headers = "From: \"$SiteName Contact Page\" <a@a.com>\r\nReply-To: ";
                        if ($email != "")
                            $headers .= "\"$fname $lname\" <$email>";
                        else
                            $headers .= "\"No Reply\" <a@a.com>";
                        $headers .= "\r\nBCC: $WebmasterEmail";


                        $subject = "From $SiteName Contact Page:  $fname $lname ($areacode) $phoneExch-$phoneBody"; // placeholder f
            
                        $body = "E-Mail from $SiteName website " . date("m/d/Y h:i A") . ": \n\t Name: $fname $lname\n\t Phone: ($areacode) $phoneExch-$phoneBody \n\t Email: $email \n\tMessage: \n\t $comment";
                        $to = $SiteEmailFull;
                        if ($aff_email) {
                            $to .= "; " . $aff_email;
                            $SS = $affiliate->get_affiliate_company();
                            $body .= "\r\n\tFrom Affiliate = $SS";
                            //echo $body.$affiliate_id;
                        }
                        $body .= "\n\tFrom IP Address = " . $_SERVER['REMOTE_ADDR'];
                        if ($_COOKIE['User_ID'] > 0)
                            $body .= "\nSite   ID = #" . $_COOKIE['User_ID'];

                        if ($debug)
                            echo "<h3>$to</h3>";
                        $body = str_ireplace("\\r\\n", "\n\t", $body);
                        // echo $body;
                        $mtest = mail($to, $subject, stripslashes($body), $headers);
                        //echo "<H4>mail($to, $subject, stripslashes($body), $headers)</h4>";
                        if ($mtest) //, $headers
                        {
                            $NoReload = 1;
                            $states = "";
                            $status = "<span style=\"color: green;\">Mail Sent</span>";
                            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                $headers = "From: $SiteEmailFull \r\nReply-To: $SiteEmailFull";
                                $subject = "In Regards to Your  Inquiry to $SiteName";
                                $body = "$fname $lname,\nThank you for your inquiry, we will get back to you as soon as possible. We value all our customers.\n-- $SiteName Management.";
                                $mtest = mail($email, $subject, stripslashes($body), $headers);
                            }
                        } else
                            $status = "<span style=\"color: red;\">Mail Failed</span>";
                    } else// lacks name and comment
                        $status = "<span style=\"color: red;\">Your must enter your name and a comment</span>";
                }// end good recapcha part
                else  //recaptcha good
                {
                    // What happens when the CAPTCHA was entered incorrectly
                    $status = "<span style=\"color: red;\">The reCAPTCHA wasn't entered correctly. Go back and try it again!</span>";   //<br /> reCAPTCHA said: " . $resp->error."
                }

            }// end handler  
            else
                $status = "<span style=\"color: brown;\">&nbsp;</span>"; //default status message   
            ?>

            <!--  BEGIN MAIL FORM  -->

            <div id="div_mail">
                <h3 class="contenttitlered mt-4 mb-5">Just provide us with your information &amp; we'll get back to
                    you<br><br>Call Us Toll Free (888) 450-2659 ASAP</h3>

                <div class="row row-50 justify-content-center justify-content-lg-start align-items-center mt-5">
                    <div class="col-md-7 wow fadeIn" data-wow-delay=".3s"
                        style="visibility: visible; animation-delay: 0.3s;">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h1>Contact Form</h1>

                            </div>
                            <div class="col-md-12 text-left">
                                <span class="required">*</span>
                                These Are Required Fields.</span>
                            </div>
                        </div>

                        <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>#status" onsubmit="" name="frmMail" id="frmMail">
                            <div class="form-wrap">
                                <label class="form-label rd-input-label" for="fname">Name: <span
                                        class="required">*</span></label>
                                <div class="flexbox">
                                    <div class="col-md-6"> <input class="form-input inp" placeholder="First Name"
                                            name="fname" id="fname" type="text" value="<? if (!$NoReload)
                                                echo $fname; ?>" /></div>
                                    <div class="col-md-6"><input class="form-input inp" placeholder="Last Name"
                                            name="lname" id="lname" type="text" value="<? if (!$NoReload)
                                                echo $lname; ?>" /></div>
                                </div>
                            </div>

                            <div class="form-wrap">
                                <label class="form-label rd-input-label d-block mt-2" for="city">Email:</label>
                                <input class="form-input inp" placeholder="Email" name="email" type="text" value="<? if (!$NoReload)
                                    echo $email; ?>" />
                            </div>

                            <div class="form-wrap">
                                <label class="form-label rd-input-label d-block mt-2" for="city">Phone:</label>
                                <input class="form-input" maxlength="3" size="1" name="areacode" id="areacode"
                                    type="text" onkeyup="NextBox(this.id, event);" value="<? if (!$NoReload)
                                        echo $areacode; ?>" />
                                - <input class="form-input" maxlength="3" size="1" id="phoneExch" name="phoneExch"
                                    type="text" onkeyup="NextBox(this.id, event);" value="<? if (!$NoReload)
                                        echo $phoneExch; ?>" />
                                - <input class="form-input" maxlength="4" size="2" name="phoneBody" id="phoneBody"
                                    type="text" onkeyup="NextBox(this.id, event);" value="<? if (!$NoReload)
                                        echo $phoneBody; ?>" />
                            </div>

                            <div class="form-wrap">
                                <label class="form-label rd-input-label mt-2" for="city">Message: <span
                                        class="required">*</span></label>
                                <textarea cols="45" rows="5" name="comment" id="comment"><? if (!$NoReload)
                                    echo $comment; ?></textarea>
                            </div>

                            <div class="mt-4" id="divStatus">
                                &nbsp;<?= $status; ?><a name="status"></a>
                            </div>

                            <div>
                                <button type="submit" class="sendcontact" name="sendemail" title="send message">Send Message</button>
                            </div>
                        </form>
                    </div>

                    <div class="col-md-5 wow fadeIn" data-wow-delay=".3"
                        style="visibility: visible; animation-delay: 0.3s;">
                        <img src="images/contact.png" style=" width:100%">
                    </div>
                </div>

            </div>
    </section>
    <!--</div> end search area -->

    <? include("includes/newFooter.php"); ?>
</body>

</html>