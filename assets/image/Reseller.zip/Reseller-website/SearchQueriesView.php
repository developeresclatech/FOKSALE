<?php
  extract($_POST);
  include("./includes/cURL_other_functions.php");
  include("./includes/siteData.php");
  include("./includes/dbConnect.php");
?>
<html>
   <head>
     <title>Consumer and Business Search Queries on this Site</title>
     <? include("includes/metas.php"); ?>  
	 <style type="text/css" title="">
	 	fieldset
		{
			border: 2px blue solid;
			width: 400px;
			padding: 10px;
        }
		input[type=text]
		{
			background-color: #FFFFCC;
		}
        #tblQuery td, #tblQuery th, td, th
		{
			color: #111111;
        } 
	 </style>
 </head>
<body>
   <? include("includes/header.php"); ?>  
 	 <table width="100%" id="tblContents">
	  <caption></caption>
	  <tr>
<!--  	   <td width="50">&nbsp;</td>  -->
	   <td width="100%" align="center" valign="top">
 <!--  CONTENT AREA, INSERT GUTS HERE  -->
<form method="post" action=""   name="frm1" id="frm1" style="background-color: #EEEEEE; color: #111111;">
		<?php
				$submiturl = "$cURL_URL/api/cURLSearchQueryMonitor.php";
				{
					  $_POST["Reseller_ID"] = $Reseller_ID;
					  $data = GetDatacURL($submiturl, $_POST);
					  echo  $data;
				}

		?>
	 </form>
<!-- end Content area -->
	  </td>
	  <!--  <td width="50">&nbsp; </td>  -->
	 </tr>
	</table>

    
	  <? include('includes/footerDIV.php') ?>
 </body>
</html>