<?
      $tableName = $tableNameCon;
      $Type = "Consumer";
      include("./includes/siteData.php");
	  include("./includes/cURL_other_functions.php");
	  include("./includes/dbConnect.php");
 	  extract($_POST);
	    ////////////////////// OPEN DB  ////////////////////////////////////
?><!DOCTYPE html>
  <html lang="en">
<head>
 <title><?=$SiteName; ?>: Search for Consumer Residential Addresses </title>
<? include("includes/metas.php"); ?>
  <style type="text/css">
	   input[type=text], input[type=password], textarea
		{

			margin:1px;
			margin-right:2px;
			margin-top:2px;
			border:2px solid #7f7f7f;
			background-color: #F2f2f2;
			color:#000000;
		}
		select
		{
			color:#000000;
		}
		h5
		{
		 color: #111111;
         font-family: Arial,Helvetica,sans-serif;
	     font-size: 14pt;
	     font-style:italic;
		}
		h3 ,h4
		{
			color: #E7A856;
			font-family: Arial,Helvetica,sans-serif;
			font-size: 20px;
			font-weight: bold;
			line-height: normal;
			text-decoration: none;
			text-shadow: 1px 1px 1px black;
		}
		#fsLast label
		{
          font-size: 11pt;
		  font-weight: bold;
		}
		.narrowNew   /*  lhs column height  */
		{
			height:6250px;
        }
		caption
		{
			 font-size: 12pt;
			 color:#E7A856;
		}
		b
		{
			 font-size: 9pt;
			 font-weight: 800;
	 }
   </style>
      <script src="Scripts/query_scripts.js" type="text/javascript"></script>
  </head>
  <body>
   <? include("includes/header.php"); ?>

  <table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" style="background:none;" >
    <tr>
	 <td width="5">&nbsp;</td>
     <td  align="center">
	     <div id="divContent">

		  <div align="center"  class="contenttitlered">
	         SEARCH ANONYMOUSLY,   FREE SELECTS<br />
          "Build Your Database Your Way"
	       </div>
      <!--  content area  -->
<?
			   if($User_ID)
			   {
				  include("includes/recordCount.php");
			   }
?>
  <!--   <hr /> BEGIN FORM  -->
		  <form method="post" action="<?=$_SERVER['PHP_SELF']; ?>#results"  id="frmSearch"  name="frmSearch"  onsubmit="if(button == 'check') return CheckForm(subCounties); else if(button == 'county') return CheckCounties();">
		         <div id="divCENTER">
				  <?
						$submiturl = "$cURL_URL/checkconsumer_Insides.php";
						$data = GetDatacURL($submiturl, $_POST);
						echo $data;
						include("includes/query_buttons.php");
				  ?>
			  </div><!--   end   divCENTER-->
	   </td>
	   <td width="5">&nbsp;</td>
	  </tr>
	</table>
   <? include('includes/footer.php') ?>
 </body>
</html>