<?php
 extract($_POST);
 include("../includes/cURL_other_functions.php");
 include("../includes/siteData.php");
 include("../includes/dbConnecti.php");
 include("PHP_authenticate.php");
?>
<html>
  <head>
   <title>All Customer Queries and Downloads</title>
	   <meta http-equiv="content-type" content="UTF-8" />
		 <meta http-equiv="refresh" content="1000" />
   <script language="JavaScript" type="text/javascript" src="../Scripts/customer_profile.js"></script>
	 <script type="text/javascript">
		 <!--
      //////////////////////////////////////////////////////////////////////////////////////////////
			 function checkDownload()
			 {
					 a = document.frmGetOutfile;

					 if(a.export_name.value == '')
				   {
						 alert('Enter a Filename');
						 highLightBox('export_name');
						 a.export_name.focus();
						 return false;
					 }
					 xx = a.custNumOfRecords.value;
					 yy = a.txtStep.value;
				   NumOfRecords =  a.hidNumOfRecords.value;
					 xx = parseInt(xx);
					 if(xx < 1 || xx > NumOfRecords || isNaN(xx))
					 {
						 alert('The number of records you entered is not correct, it is either too high, too low or is not a number');
						 highLightBox('custNumOfRecords');
						 a.custNumOfRecords.select();
						 return false;
					 }
					 a.custNumOfRecords.value = xx;

					 if(yy != '')
					 {
						yy = parseInt(yy);
						a.txtStep.value= yy;
						// checks the record offset value
							 if(yy < 1 || isNaN(yy) )
							 {
								 alert('The record offset value is not correct, it is too high or low or is not a number');
								  highLightBox('txtStep');
								 return false;
							 }
							 else if( (xx + yy) > NumOfRecords)
							 {
								 alert('The sum of the record offset value and records requested value '+ (xx + yy) + ' is greater than the total records available '+ NumOfRecords + ', make one or the other lower.');
								  highLightBox('txtStep');
								 return false;
							 }
					 }
					 else
						 yy = "1";
					 return  confirm('Do You Want to Download These '+ xx + ' Records Starting from Record '+ yy  +'? If OK, then your account here will be charged for all the records that you requested.');
			 }
			 ////////////////////////////////////////////////////////////////////////////////////// END FUNCTION //////////////////////////////////////////////////////////////////
			 function EnableSubmit(qid)
			 {
				a = document.frmGetOutfile;
				a.subGetOutFile.disabled = false;
			  a.custNumOfRecords.value = a.hidNumOfRecords.value = document.getElementById(qid).value;
			 }
		//-->
		</script>
	 <style type="text/css">
	 	fieldset
		{
			border: 2px blue solid;
			width: 400px;
			padding: 10px;
    }
		input[type=text], input[type=password]
		{
			background-color: #FFC;
		}
    #tblQuery td, #tblQuery th, td, th
		{
			color: #111;
    }
		#tblOutfiles *
		{
			font-size: 10pt;
			font-weight: 600;
		}
	 </style>
	 <link rel="stylesheet" href="manager.css" type="text/css" />
 </head>

<body>
  <? include("manager_links.php");  ?>

 	 <div align="center" id="divMain">
	  <h1>Recent User Data Searches</h1>
 	  <table width="100%" id="tblContents">
	 <tr>
<!-- 	  <td width="50">&nbsp;</td> -->
	  <td width="100%" align="center" valign="top">
 <!-- CONTENT AREA, INSERT GUTS HERE -->
 <?  include("../includes/recordCount.php");
    echo "<br />You are logged in as User_ID #$User_ID<br />All Downloads from this Page Will Be Charged to and Made Available Only To this User Account<br />";
 ?>
<form method="post" onsubmit="return checkDownload();"  name="frmGetOutfile" id="frmGetOutfile" style="background-color: #EEEEEE; color: #111111;">
		<?php
		 		$submiturl = "$cURL_URL/api/customer_queries_api_new.php";
        $OUT_ARRAY = array("CompID" => $Reseller_ID, "Username" =>$Reseller_UN, 'AllQueries'=>1 );
        $data = GetDatacURL($submiturl, $OUT_ARRAY);
        echo $data;
			  if($Balance >0) {
     ?>
 	        Create a name for your data export file(letters, numbers, or '_'s only): <input type="text" name="export_name" id="export_name" size="20"/><br />
					Remember to be specific so you won't mix up your clients' data!<br />
					Change this to a lower value if you don't want all the records in the search: (opt) <input onBlur="document.getElementById('divStep').style.display='block'; document.frmGetOutfile.txtStep.focus();" onChange="document.getElementById('divStep').style.display='block'; document.frmGetOutfile.txtStep.focus();" type="text" name="custNumOfRecords" id="custNumOfRecords"  size="12" value="<?=$NumOfRecords;?>" /><br />
					<div align="center" id="divStep" style="display:none; padding: 2px 20px;">
					 if selecting less than the whole record count, start from this record: (opt) <input type="text" name="txtStep" style=";" id="txtStep" maxlength=" " size="12" value="<?=$txtStep ;?>" /><br />
           Otherwise you will get the records sorted A to Z by email address from the top of the list.<br />
					 Example you want only 10K records of a 101K count, but starting from the 20,000th record since you already downloaded the first two sets of 10K., you'd enter 10000 in the first box then 20000 in the one above.
					</div>
				 <input type="hidden" name="hidNumOfRecords" id="hidNumOfRecords" />
				 <input type="submit" value="Download Results" id="subGetOutFile" name="subGetOutFile" disabled="disabled" accesskey="g" title="Get the Outfile, or alt-g" /><br />
         <small>(First, Select one of the Queries Above)</small>
				<?
				  if(isset($subGetOutFile))
				  {
					  echo "<br /><b>It may take a while depending on traffic and size</b>";
					  echo "<div style='background-color:#6aa727; padding:20px; margin:20px; color:white;'>";
						$submiturl = "$cURL_URL/api/outfiles/remote_api_file_interface.php";
						$_POST["CompID"] = $Reseller_ID;
						$_POST["User_ID"] = $User_ID; // all files go to site owner
						$_POST["Username"] = $Reseller_UN;
						$_POST["ChargeReseller"] = 1;
						$_POST["Owner"] = 1;
						$data = GetDatacURL($submiturl, $_POST);

						echo "$data <h3 style='color:white;'>DONE</h3>";
						echo "</div>";
				  }
      }// END DISPLAY ONLY IF THEY HAVE A BALANCE
	?>
	    </form>
<!-- Retrieve Files Section -->
     <h2>Retrieve Completed Files Below</h2>
		 	<?
			  {
					$dirR = "../pulls";
					//echo "SEARCH DIR ".$dirR.' | '.$ID.'<br />';
					$d = dir($dirR);
					$x = array();
					while (false !== ($r = $d->read()))
					{
						if(stripos($r, $User_ID."_") === 0)
						{
							$x[$r] = true;
						}
					}
					//ksort($x);
         if(count($x))
				  {
					 echo "<h3>Your Address Files</h3>\n<hr />\n";
					 echo "<table id='tblOutfiles'>\n<tr><th>Created On</th><th>File Size</th><th>Download Link</th></tr>\n";;
           foreach($x AS $K=>$V)
					  {
						 $RR = filemtime("../pulls/".$K);
             $TimeStamp = date( 'm/d/y H:i',$RR);
						 $FS = number_format(intval(filesize("../pulls/".$K)/1024,2));
						 $files[$RR] = "<tr><td>$TimeStamp&nbsp;&nbsp;</td><td>$FS Kbs&nbsp;&nbsp;</td><td>&nbsp;&nbsp;<a href='/pulls/$K'>$K</a></td></tr>\n";
					 }
					 ksort($files);
					 foreach($files AS $K=>$V)
						  echo $V;
   				 echo "</table>\n<hr /><h3>There is a one million record limit on file size, so for downloads larger than 1,000,000 records, you will have to wait for all of the data files to show up</h3>\n" ;
				  }
				  else
   					 echo "<h3>There are no Address Files ready now, if you just started one, it may take a while to show up, sometimes over an hour or more for really big downloads</h3>\n" ;
			  }// END IF USER_ID
	  ?>
	  			 <div align="left" style=";" id="divInstructions">
					 Your emailer program can unpack/unzip these compressed files or you can go to this site and get this simple free proven program to unpack the files: <a href="http://www.7-zip.org/" target="_blank">Compressed File Unzipper</a>. Newer Window's OSs use this one: "Download 	.msi 	64-bit x64 1MB". <br /><br />
					When you have installed the 7zip program and downloaded the data file from us. open up Windows Explorer and find the data file you just downloaded from this site. It will have a filename like mydatafromohio.csv.tar.bz.. Now highlight the data file and right click on it, then select "Extract Here" It will create another file called mydatafromohio.csv.tar . Now highlight the new file and right click on it, then select "Extract Here" <b>AGAIN</b>. It will create a new file mydatafromohio.csv. Now you will have the basic CSV text file that you can open with Excel, Notepad, or any other editor or word processing program.
			</div><br /><hr /><br />

<!-- end Content area -->
	  </td>
	 </tr>
	</table>
	 <? include("manager_links.php");  ?>
 	 </div>
 </body>
</html>