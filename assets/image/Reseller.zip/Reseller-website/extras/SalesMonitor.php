<?
  include("../includes/siteData.php");
  include("../includes/dbConnecti.php");
  include("../includes/cURL_other_functions.php");
// include("../includes/PHP_authenticate.php");
  $CompName = $User_ID = $Username = ""; //blanks out cookie data
  extract($_POST);
 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <title><?=$SiteNameSh; ?>: Sales Monitor</title>
 <meta http-equiv="content-type" content="text/html; charset=windows-1251">
 <link rel="stylesheet" href="manager.css" type="text/css" />
 <meta http-equiv="refresh" content="6000" />
 
 </head>

 <body>
 <? include("manager_links.php");?>
<!-- imageready slices (0005_red.psd - slices: 03, 04, 05) -->
	  <?
       // echo mysqli_error($dbhi);

		  $txtDaysBack = (int) $txtDaysBack;

			if(!isset($DaysBack))
			  $DaysBack = 31;

      if($txtDaysBack > 0)
			{
			  $query= "SELECT *, DATE_FORMAT(`SalesDate`, '%m/%d/%y %H:%i' ) AS `TS` FROM `tblSales`, `tblResellerCustomers` WHERE DATEDIFF( NOW(), `SalesDate`) = $txtDaysBack AND `tblSales`.`User_ID` = `tblResellerCustomers`.`User_ID` $CompletedOrders ORDER BY `SalesDate` DESC ; ";
			  $Interval = " = ".$txtDaysBack;
			  $timeDaysBack = time() - ($txtDaysBack*60*60*24);
        $dateDaysBack = " ON ". date(' l, F d, Y', $timeDaysBack) ;
      }
			elseif($chkAll == 1)
			{
			  $query= "SELECT *, DATE_FORMAT(`SalesDate`, '%m/%d/%y %H:%i' ) AS `TS` FROM `tblSales`, `tblResellerCustomers` WHERE `tblSales`.`User_ID` = `tblResellerCustomers`.`User_ID` $CompletedOrders ORDER BY `SalesDate` DESC ; ";
        $dateDaysBack = " All Sales, from Last to First" ;  // date like Monday, January 4, 2009
			  $txtDaysBack = "";
      }

			elseif($DaysBack == "ALL")
			{

			  $query= "SELECT *, DATE_FORMAT(`SalesDate`, '%m/%d/%y %H:%i' ) AS `TS` FROM `tblSales`, `tblResellerCustomers` WHERE `tblSales`.`User_ID` = `tblResellerCustomers`.`User_ID` $CompletedOrders ORDER BY `SalesDate` DESC ; ";
        $dateDaysBack = " All Sales " ;  // date like Monday, January 4, 2009
			  $txtDaysBack = "";
      }
			elseif($DaysBack >= 0)
			{

			  $query= "SELECT *, DATE_FORMAT(`SalesDate`, '%m/%d/%y %H:%i' ) AS `TS` FROM `tblSales`, `tblResellerCustomers` WHERE DATEDIFF( NOW(), `SalesDate`) <= $DaysBack AND `tblSales`.`User_ID` = `tblResellerCustomers`.`User_ID` $CompletedOrders ORDER BY `SalesDate` DESC ; ";
			  $Interval = " <= ".$DaysBack;
			  $timeDaysBack = time() - ($DaysBack*60*60*24);
        $dateDaysBack = " FROM ".date(' l, F d, Y', $timeDaysBack) ;  // date like Monday, January 4, 2009
			  $txtDaysBack = "";
      }
		  $results = mysqli_query($dbhi,$query);
			$daysQueries = mysqli_num_rows($results);
      // echo $query.mysqli_error($dbhi);
     
        
     if(isset($subUpdateSale)&& $UpdatePrice > 0)
		 {
			  $UpdatePrice = floatval($UpdatePrice);
			  $queryUP = "UPDATE `tblSales` SET `payment_status` = '10', `CCPayment` = '$UpdatePrice' , `Completed`= 1 WHERE `SalesID` = '$SalesID' ;  ";
			  $resultsUP = mysqli_query($dbhi,$queryUP);
			  if(!$resultsUP)
			    echo $queryUP . mysqli_error($dbhi) ;
			  else 
				  $Status = "Order ID #$SalesID completed with $$UpdatePrice";
        
		 }
 

     ?>
   <h1>Online Sales Record</h1><hr />
    <!-- BEGIN FORM -->
	  <form method="post" id="frmSearch">
	   All Sales Dates: <input type="checkbox" name="chkAll" id="chkAll" style=";" value="1"  />&nbsp;&nbsp; <label for="CompletedOrdersY">Only Successful Sales: <input type="radio" name="CompletedOrders" id="CompletedOrdersY" value=" AND `payment_status` = 1 " /></label> &nbsp;&nbsp; <label for="CompletedOrdersN">Only Failed Sales: <input type="radio" name="CompletedOrders" id="CompletedOrdersN" value=" AND payment_status != 1 " /></label><br />
	   Select Days Back from Today that You want to See: <select name="DaysBack" id="DaysBack" style=";" onchange="document.getElementById('txtDaysBack').value=''; document.forms[0].submit();">
	    <option value="0"<? if($DaysBack == "0") echo ' selected = "selected"'; ?>>Today</option>
	    <option value="1"<? if($DaysBack == "1") echo ' selected = "selected"'; ?>>One Day</option>
	    <option value="2"<? if($DaysBack == "2") echo ' selected = "selected"'; ?>>Two Days</option>
			<option value="3"<? if($DaysBack == "3") echo ' selected = "selected"'; ?>>Three Days</option>
	    <option value="7"<? if($DaysBack == "7") echo ' selected = "selected"'; ?>>One Week</option>
	    <option value="14"<? if($DaysBack == "14") echo ' selected = "selected"'; ?>>Two Weeks</option>
			<option value="21"<? if($DaysBack == "21") echo ' selected = "selected"'; ?>>Three Weeks</option>
			<option value="31"<? if($DaysBack == "31" || $DaysBack == "") echo ' selected = "selected"'; ?>>Month</option>
			<option value="ALL"<? if($DaysBack == "ALL") echo ' selected = "selected"'; ?>>All of Them</option>
	   </select>&nbsp;| &nbsp;
		 <input type="submit" name="subDaysBack" id="subDaysBack" style=";" value="Set Days Back" accesskey="d"  title="How many days back do you want to see?" /><br />
		  Or Select A Day back for just that Day's readout:  <input type="text" name="txtDaysBack" style=";" id="txtDaysBack" maxlength=" " size="4" value="<?=$txtDaysBack; ?>" /> <br />

		 (Default is just Today's Sales.)
    </form>
	   <h2>&nbsp;<?=$Status; ?></h2>
	  <table width="98%" style="font-size: 8pt; font-weight: 700;">
		 <caption><h3>Sales Record <?=$dateDaysBack .' | '. $daysQueries;?> Sales</h3>(<small>Click on Cust ID for More Customer Data</small>)<hr /></caption>
	   <tr valign="top" style="border-bottom: 3px solid black;"><th width="5%">Date</th><th width="4%">Cust ID</th><th>Order ID</th><th width="">Company Name</th><th>Name</th><th>IP Address</th><th width="">Description</th><th width="">Approved</th><th width="">Credit<br />Amount</th><th width="5%">Original<br />Price</th><th>Complete Sale</th></tr>
		 <!-- <tr><td colspan="11"><hr /></td></tr> -->
	  <?
			 if($results)
			 {
        $TotalSales = $TotalBuys = 0;
			  while($dataX = mysqli_fetch_assoc($results))
				 {
				  if($c++%2)
            $bgColor = "#CCFFFF";
					else
            $bgColor = "#CACACA";
					extract($dataX);
					echo "<tr valign=\"top\" bgColor=\"$bgColor\"><td>$TS</td> ";
					echo "<td onclick=\"window.open('index.php?User_ID=$User_ID', 'freddy');\" title=\"click for customer info\" ";
					echo ">$User_ID</td><td>$SalesID</td>";
					echo "<td>$CompName</td>";
					echo "<td >$CompFName $CompLName</td><td>$IPAddress</td><td>#$Item_ID | $Description</td><td";
					if($payment_status == 2)
						echo " style=\"background-color: #F3C;\">YES";
					elseif($payment_status == 1)
						echo " style=\"background-color: #CFF;\">Partial";
					elseif($payment_status == 10)
						echo " style=\"background-color: #CFF;\">Manual";
					else
           {
						echo ">NO";
						if($Error)
							echo "<br>$Error";
					 }

					echo "</td><td align=\"right\"> $".number_format($CCPayment,2)."</td><td align=\"right\">$".number_format($Price,2)."</td><td>";
					if($CCPayment <= 0)
						echo "<form method=\"post\" id='frmUpdate".++$frm."'>\n
						       $<input type=\"text\" name=\"UpdatePrice\" id=\"UpdatePrice\"  size=\"6\" value='$Price' />
									 <input type=\"submit\" name='subUpdateSale' id=='subUpdateSale'  style='font-size:8pt;' value=\"Complete Sale\"  title=\"Manually Complete Sale\" />\n
									 <input type=\"hidden\" name=\"SalesID\" id=\"SalesID\" value='$SalesID' />
						</form>\n";
            else
							echo "&nbsp;";
					echo "</td></tr>\n";

					if($payment_status > 0)
					 {
					  $TotalSales += $CCPayment;
					  $TotalBuys++;
           }
				 }// title=\"$Query\"
			 }
			 else
			  echo $query.mysqli_error($dbhi);


		;?>
	 </table>
  <?
   echo "<span style='font-size: 13pt; font-weight:600;'>For This Interval: Total Revenue = $$TotalSales.00 from $TotalBuys Approved Purchases</span><br />";
	  $queryAbsolute= "SELECT SUM(CCPayment) AS `AbsoluteTotalSales` , SUM(Price) AS `GrossSales` , COUNT(`Price`) AS `AbsoluteTotalBuys` FROM `tblSales` WHERE `payment_status` IN (1, 10) ; ";
	  $r = mysqli_query($dbhi,$queryAbsolute);
	  $d = mysqli_fetch_assoc($r);
	  extract($d);
   echo "<span style='font-size: 14pt; font-weight:700;'>Cumulative Total Sales = $".number_format($GrossSales,2).", Total Revenue = $".number_format($AbsoluteTotalSales,2)." from $AbsoluteTotalBuys Approved Purchases</span><br />";
	 mysqli_free_result($results);
   mysqli_close($dbhi);
 ?>
	  <a href="../purchase_data.php" target="_blank">Purchase Data or Software Page</a><br />
 <? include("manager_links.php");?>
 </body>
</html>