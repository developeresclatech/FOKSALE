<?
   //////////////// UPLOAD HANDLER ////////////////////////////////////////// 4/16/2014
		  if(isset($_FILES['fUploadFile']) && isset($_POST['subFile']) )
		  {
			 $targetDirectory .= "../pulls/";
			 $NEWNAME = preg_replace("/[^a-zA-Z0-9_\.\-]/", "", $_POST['txtFileName']);
		    if($NEWNAME != "")
          $_FILES['fUploadFile']['name'] = $NEWNAME;
			    $source = $_FILES['fUploadFile']['tmp_name'];
			    $target = $targetDirectory.$_FILES['fUploadFile']['name'];
       	  if(copy($source, $target))
			    {
					  $FStatus = "SUCCESS";
				  }
				  else
				  {
					  $FStatus = "File Rejected by server!";
				  }
						 /*   }
      else
			 $FStatus = "You must enter a valid filename"; */
			}
		 else
			$FStatus = "&nbsp;";
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      extract($_POST);
			$PULL = "../pulls/";
				function getFiles($dirR)
				{
					 $d = dir($dirR);
					 $x = array();
					 while (false !== ($r = $d->read()))
					 {
						if(preg_match( "/^[\d{2,}_]/", $r))
						{
							$x[filemtime($dirR.$r)] = $r;
						}
					 }
         if($_GET['rev'] == 2)
				  rsort($x);
         elseif($_GET['rev'] == 1)
				  sort($x);
         elseif($_GET['revt']==1)
				  ksort($x);
				 elseif($_GET['revt']==2)
				  krsort($x);
				 else // DEFAULT SORT, NEWEST TO OLDEST FILE
				  krsort($x);
				  return $x;
				 }
/////////////////////// END FUNCTION /////////////////////////////////////////////.
if(isset($subDeleteAll))
{
	 $delArray =  getFiles($PULL);
   if(count($delArray))
	 {
     foreach($delArray AS $V)
		 {
			  if(unlink($PULL.$V))
				  $del++;
		 }
	 }
	 if($del)
     $Message = " $del files deleted";
}
elseif($_GET['Del'])
{
  if(unlink($PULL.$_GET['Del']))
	{
		$Message = " 1 file deleted";
	}
}
	  ////////////////////// OPEN DB ////////////////////////////////////
 include("../includes/cURL_other_functions.php");
 include("../includes/siteData.php");
 include("../includes/dbConnecti.php");
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <title><?=$SiteNameSh; ?>: All Data Files</title>
 <link rel="stylesheet" href="manager.css" type="text/css" />
  <meta http-equiv="refresh" content="3600" />

 <style>
   #tblOutfiles td, #tblOutfiles th
	 {
		 padding:5px;
	 }
  </style>
 </head>

<body>
<? include("manager_links.php"); ?>
   <h1>Download Address Files in System</h1>
      <h2>Status:&nbsp;<?=$Message; ?></h2>

		<div class="wide" style="padding:10px;">
		 	<?
         $x = getFiles($PULL);
         if( $countF = count($x))
				  {
					 echo "<h3>$countF Address Files</h3>\n<hr />\n";
					 echo "<table id='tblOutfiles'>\n<tr><th>";
					    if($_GET['rev'] !=1)
								echo "<a href='admin_retrieve_data_files.php?rev=1' title='sort by oldest user'>";
							elseif($_GET['rev'] !=2)
								echo "<a href='admin_retrieve_data_files.php?rev=2' title='sort by newest user'>"							;
					 echo "Who</a></th><th>";
					    if($_GET['revt'] != 1)
								echo "<a href='admin_retrieve_data_files.php?revt=1' title='sort by oldest file'>";
							elseif($_GET['revt'] != 2)
								echo "<a href='admin_retrieve_data_files.php?revt=2' title='sort by newest file'>";
					 echo "Created On</a></th><th>File Size</th><th>Download File</th><th>Delete File</th></tr>\n";;
           foreach($x AS $KV)
					  {
						 $USER = explode("_", $KV);
						 $query = "SELECT * FROM tblResellerCustomers WHERE User_ID = $USER[0]  ; ";
						 $results = mysqli_query($dbhi,$query);
						// echo $query;
						 while($data = mysqli_fetch_assoc($results))
					        extract($data);
             // echo $query.mysqli_error($dbhi);
						 $FT = filemtime("../pulls/".$KV);
             $TimeStamp = date( 'm/d/y H:i',$FT);
						 $FSRaw = filesize("../pulls/".$KV);
						 if($FSRaw >= 10000000)
						   $FS = number_format($FSRaw/1048576,2). " Mb" ;
						 elseif($FSRaw < 10000000 && $FSRaw >= 1000)
						   $FS = number_format($FSRaw/1024,1). " Kb" ;
						 else
						   $FS = $FSRaw. " Bytes" ;
             $WHO = "$CompFName $CompLName, $CompName ";
						 $ROWS[] = "<tr valign='top'><td>$WHO</td><td>$TimeStamp&nbsp;&nbsp;</td><td align='right'>$FS&nbsp;</td><td>&nbsp;&nbsp;<a href='/pulls/$KV'>$KV</a></td><td>&nbsp;&nbsp;<a href='".SELF."?Del=$KV'>Delete</a></td></tr>\n";
					 }
					// ksort($ROWS);
					 foreach($ROWS AS $K=>$V)
						  echo $V;
   				 echo "</table>\n<hr />\n" ;
				  }
				  else
   					 echo "<h3>There are no Address Files Currently On the Site</h3>\n" ;
	  ?>
	  <form method="post" action="<?=SELF; ?>" onsubmit="return confirm('Do You want to Purge All Data Files?');" name="frmDelete" id="frmDelete">
	     <input type="submit" name="subDeleteAll" id="subDeleteAll" style="color:red; font-weight: 700; font-size: 12pt;" value="DELETE ALL DATA FILES" accesskey="x"  title=" Purge All Data Files" />
	  </form>


	  <fieldset>
		 <legend style="font-size: 13pt;"><b>Upload Customer Files Here</b></legend>
     <h3>Name all files starting with the Customer's ID and Underscore at the start of the file's filename: <b style="font-size: 19pt; color:red;">410_</b>C_1M_CT_MALES.csv.tar.bz2. DON'T USE SPACES or stupid punctuation marks in your filename. Just use letters, numbers, periods, dashes and underscores<br />
		 File Status: <?=$FStatus; ?></h3>

     <form method="post" action="<?=SELF; ?>"  enctype="multipart/form-data" id="frmUpload" name="frmUpload" onsubmit="return CheckForm();">
		 Enter the Name for the New File Here: <input type="text" name="txtFileName" style=";" id="txtFileName" maxlength="" size="30" value="<?=$txtFileName ;?>" /><br />
		 <span style="font-size:12pt; color:red;">WARNING: Multiple uploads using the same filename entered above will over-write the last file</span><br />
		   <input type="hidden" name="MAX_FILE_SIZE" value="10000000" />
	    <input type="file" size="40" name="fUploadFile" id="fUploadFile"  style="color:blue; font-weight: 700; font-size: 12pt;"/><br /><br />
			<input type="submit" id="subFile" name="subFile" value="Upload File" accesskey="u" title="shortcut: alt-u" style="color:blue; font-weight: 700; font-size: 12pt;"/>
	  </fieldset>
    </div><!-- end search area -->
	<? include("manager_links.php"); ?>
 </body>
</html>