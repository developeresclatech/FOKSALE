<?
  include("../includes/siteData.php");
  $RID = $Reseller_ID;
  include("../includes/dbConnecti.php");
  include("../includes/cURL_other_functionsWL.php");
  include("PHP_authenticate.php");
  //include("index_inc.php");
  $CompName = $User_ID = $Username = ""; //blanks out cookie data
  include("index_code2.php");
?><!DOCTYPE html>
<html>
 <head>
 <title><?=$SiteName; ?>: Customer Data Management Page</title>
 <meta http-equiv="content-type" content="text/html; charset=windows-1251" />
 <link rel="stylesheet" href="manager.css" type="text/css" />
 <style type="text/css">
	  #keys td
	  {
		  text-align: center;
    }
   #mainlist option
	 {
	  font-size: 9pt;
	 }
	 h3
	 {
	  font-size: 15pt;
		font-weight: bold;
	 }
	 legend
	 {
	  font-size: 13pt;
		font-weight: bold;
	 }
	  /* a, label
	 {
	  font-size: 12pt;
		font-weight: bold;
	 } */
	  input[type=text], input[type=password], textarea, select
	  {
			margin:1px;
			margin-right:2px;
			margin-top:2px;
			color: #000;
			border:2px solid #7f7f7f;
			background-color: #F2F2F2;
		}
		#tblEdit td:first-child{text-align:right;}
		#tblEdit td:[colspan]{text-align:center;}
 </style>
 <script type="text/javascript">
  <!--
   //////////////////////////////// BOX JUMPER FUNCTION ////////////////////////////////////////////
  /* USE inside input element  onkeyup="NextBox(this.id, event);"  id="<?=$phIndex++; ?>_phone" */
	  function NextBox(boxID, event)
	  {
       if(event.keyCode > 47)
	   {
			Box = document.getElementsByTagName('input');
			BoxL = Box.length;
			Els = document.forms.frmCompData.elements;
			ElsLen = Els.length;
			llen = document.getElementById(boxID).value.length;
			maxL = document.getElementById(boxID).maxLength;
			if(llen >= maxL)
		  {
            for (x=0; x<ElsLen; x++ )
            {
				if(boxID == Els[x].id )
				{
          Els[++x].focus();
					break;
				}
            }
         }
	  }
    }
/////////////////////// END FUNCTION ///////////////////////////////////
	  function CheckForm(b)// var b is the button clicked, in this case the delete but leaves room for more
	  {
     if(b == 'Del' )
			 return confirm('Do you want to delete this customer, #<?=$User_ID;?>?');
		 else
			 return true;
	 }

  //-->
 </script>

 </head>

 <body>
  <? include("manager_links.php");?>
  <h1><?=$SiteName; ?>: Customer Management Page</h1>
  <h3 style="color:<?=$fontColor ;?>;background-color: #FFF; text-align: center;">Status: <?=$CompMessage ;?></h3>
 <table width="100%" id="tbleMain">
 <tr><td colspan="2"><?="<h3>Current DBEM Normal Record Balance is $formatRB Credits<br />Current DBEM New Movers Record Balance is $formatNMRB Credits<br />Current DBEM White List Record Balance is $formatWLRB</h3>"; ?></td></tr><!-- ".number_format($RecordBalance, 0)." -->
  <tr valign="top">
    <td width="50%">
	  <h2>Current Users</h2>
 	  <form name="frmCompList" id="frmCompList" action="<?=SELF; ?>" method="post">
	   <fieldset>
	     <legend>Users in System</legend>
		  <label for="chkNoBuy" title="Check this first then press button to the right., this enables the button" >Only Those With No Purchases:</label> <input type="checkbox" name="chkNoBuy" id="chkNoBuy" title="Check this first then press button to the right., this enables the button" onclick="if(this.checked == true) document.getElementById('subNoBuy').disabled = false;"  value="1"<?if($chkNoBuy == "1") echo ' checked="checked"'; ?> /><input type="submit" name="subNoBuy" id="subNoBuy" style="subNoBuy;" value="Show Only No Purchases" disabled="disabled" title="Check the box to the left first" /><br />
		  <small>ID# | Company Name | Last Name | User Name | Deactivated | Admin | Date Started</small><br />
		  Doubleclick On User to Bring Up His Account<br />
     <select name="mainlist" size="20" id="mainlist" style="width:420px; font-size: 9pt;" ondblclick="cmdRetrieveCompData.click()" onchange="document.getElementById('cmdRetrieveCompData').disabled = false;" >
<? //ORDER BY User_ID DESC
		    $query = "SELECT CompName, CompFName, CompLName, Username, User_ID, Stopped , Admin, Date_Format(DateEntered, '%m/%d/%y') AS DE FROM $dbName.tblResellerCustomers WHERE 1";
			  if(isset($chkNoBuy))
		         //$query = "SELECT `CompName`, `CompFName`, `CompLName`, `Username`, `tblResellerCustomers`.`User_ID`, `Stopped`, Admin, Date_format(DateEntered, '%m/%d/%y') AS DE FROM `tblResellerCustomers` LEFT OUTER JOIN `tblCustomerCredits` USING (`User_ID`) WHERE `tblCustomerCredits`.`User_ID` IS NULL ";
              $query = "SELECT `CompName`, `CompFName`, `CompLName`, `Username`, `User_ID`, `Stopped`, Admin, Date_format(DateEntered, '%m/%d/%y') AS DE FROM `tblResellerCustomers` WHERE `User_ID` NOT IN (".getNoPurchaseCustomers($Reseller_UN,$Reseller_ID).")  ";
			  if(isset($cmdSearch) && $selSearchField !="" && $txtSearchField !="" )
			  {
			    $query .= " AND $selSearchField LIKE '".trim($txtSearchField)."%'";
			  }
			  $query .= " ORDER BY `tblResellerCustomers`.`User_ID` DESC";
             //$query = "SELECT CompName, CompFName, CompLName, User_ID FROM tblResellerCustomers ORDER BY User_ID ASC";
        $results = mysqli_query($dbhi,$query);
	    if($results)
		{
          $c = 0;
		  while($data = mysqli_fetch_array($results))
		  {
             if(!$c)
					 $SpecialID = $data['User_ID'];
				 $sCompName = $data['CompName'];
                 $sUser_ID = $data['User_ID'];
                 $sCompFName = $data['CompFName'];
				 $sCompLName = $data['CompLName'];
				 $sUsername = $data['Username'];
				 $sStopped = $data['Stopped'];
				 $sDE = $data['DE'];
				 if($sStopped == 'Y')
					 $RRR = ' Disabled ';
				 else
                     $RRR = '';
				 if($data['Admin'] > 0)
					 $RADMIN = "| ADMIN";
				 else
					 $RADMIN = "";
        echo "<option value=\"$sUser_ID\">$sUser_ID | $sCompName&nbsp;|&nbsp;$sCompLName | $sUsername $RRR $RADMIN | $sDE</option>\n";
			  $c++;
			 }//end while
			 $message = "&nbsp;";
			 $num_of_customers = mysqli_num_rows($results);
			 mysqli_free_result($results);
      }//end if

		  else
		  { //error message
			 $message = "$query<br /> ". mysqli_error($dbhi) . mysqli_errno($dbhi);
		  } //disabled="disabled"
?>
	  	</select><br />
		 <input type="submit" value="Retrieve Customer Data or Reload Data Set" name="cmdRetrieveCompData" id="cmdRetrieveCompData" accesskey="d" title="Retrieves data on selected customer, or alt-d, select someone first, or reload the whole set over again." /><br />
          <small>(Doubleclick User or Select User Then Click Button Above)</small><br />
	<!-- </form> -->
		There are <?=$num_of_customers ;?> users in the database<? if(isset($chkNoBuy)) echo "<br />who have not purchased any records"; ;?><br />
		<?=$message ;?><hr /><br />
		Download Customer Data: <input type="submit" name="subMakeCustomerList" id="subMakeCustomerList" value="Create Customer Data File" accesskey="C" title="Customer Data File" />
 </fieldset>

 <fieldset>
	 <legend>Search for Customers By Various Fields</legend>
	  <h4>Enter All or Just the First Part of your Search String</h4>
	  <p style="font-size: 8pt;">
	   For Example, Seaching on First Name = "Jo" will give every customer with a firstname beginning with "Jo' like Joe, John, Jody, etc. Entering a State like "TX" will give every customer in Texas or a phone beginning with 272 will give you every phone starting with 272. Remember, nothing but numbers for phones, zips or area codes. Results will appear in the list box above.
	  </p>
	   <select name="selSearchField" id="selSearchField" >
		 <option value="">Select a Field</option>
		 <option value="tblResellerCustomers.User_ID" <?if($selSearchField=="tblResellerCustomers.User_ID") echo ' selected="selected"';?>>User ID</option>
	   <option value="Username"<?if($selSearchField=="Username") echo ' selected="selected"';?>>Username</option>
	   <option value="CompEmail"<? if($selSearchField=="CompEmail") echo ' selected="selected"';?>>Email</option>
	   <option value="CompURL"<? if($selSearchField=="CompURL") echo ' selected="selected"';?>>Website</option>
	   <option value="CompName"<? if($selSearchField=="CompName") echo ' selected="selected"';?>>Company Name</option>
	   <option value="CompFName"<? if($selSearchField=="CompFName") echo ' selected="selected"';?>>First Name</option>
	   <option value="CompLName"<? if($selSearchField=="CompLName") echo ' selected="selected"';?>>Last Name</option>
	   <option value="CompCity"<? if($selSearchField=="CompCity") echo ' selected="selected"';?>>City</option>
	   <option value="CompSt"<? if($selSearchField=="CompSt") echo ' selected="selected"';?>>State(2 letters)</option>
	   <option value="CompZip"<? if($selSearchField=="CompZip") echo ' selected="selected"';?>>Zip Code</option>
	   <option value="CompPhone"<? if($selSearchField=="CompPhone") echo ' selected="selected"';?>>Phone</option>
	   <option value="CompAreaCode"<? if($selSearchField=="CompAreaCode") echo ' selected="selected"';?>>Area Code</option>
	   <option value="CompCountry"<? if($selSearchField=="CompCountry") echo ' selected="selected"';?>>Country(2 letters)</option>
	  </select>
	  <input type="text" name="txtSearchField" id="txtSearchField" size="50" value="<?=$txtSearchField; ?>" /><br />
	  <input type="submit" name="cmdSearch" id="cmdSearch" value="Search By A Field" accesskey="s"  title="Searchs Comapny Profiles By Selected Field" /><br />
	  <b> Results will appear in the "Users in System" list box above.</b>
  </fieldset>
	 </form>

  </td>
	<td>
	<?
	if(($cmdRetrieveCompData && $mainlist !="" ) || $_GET['User_ID'] || $User_ID || $cmdSearch) //JUST GET DATA IF good User_ID
	{

     if(($cmdRetrieveCompData && $mainlist !="" ))
 		  $queryS = "SELECT * , DATE_FORMAT(DateEntered, '%m/%d/%Y') AS DE  FROM tblResellerCustomers WHERE User_ID = $mainlist ;";
		 elseif($_GET['User_ID'])
 		  $queryS = "SELECT *, DATE_FORMAT(DateEntered, '%m/%d/%Y') AS DE  FROM tblResellerCustomers WHERE User_ID =".$_GET['User_ID']."  ;" ;
		 elseif($cmdSearch && $SpecialID > 0)
 		  $queryS = "SELECT * , DATE_FORMAT(DateEntered, '%m/%d/%Y') AS DE  FROM tblResellerCustomers WHERE User_ID = $SpecialID  ;  " ;
		 else
 		  $queryS = "SELECT * , DATE_FORMAT(DateEntered, '%m/%d/%Y') AS DE FROM tblResellerCustomers WHERE User_ID = $User_ID";
	   $resultsS = mysqli_query($dbhi,$queryS);
		 if($resultsS && mysqli_num_rows( $resultsS))
		 {
			 $data = mysqli_fetch_assoc($resultsS);
			 extract($data);
			 $states = $CompSt;
			 $XCompEmail = $CompEmail;
	   }
		$UNPrompt = '<span class="cue">(Can not be changed)</span>';
		$RO = 'readonly="readonly" ';
		$ButtonCaption = "Save Changes";
	  $Profile = "Edit Customer Profile";
		$Reset = '<input type="reset" value="Clear Form" accesskey="c" title="Clear Form, or alt-c" />';
		$ChangePWButton = '<input type="submit" name="subChangePW" id="subChangePW" value="Change Password" accesskey=""  title="" />';
		$SS = false;
  }
	else
	{
		 $Profile = "Create A Profile";
		 $UNPrompt = '<span class="cue">(6 -16 letters and numbers. Must be unique)</span>';
  }

?><!--  target="_blank" -->
	<form name="frmCompData" id="frmCompData" method="post" action="<?=SELF;?>" onsubmit="if(DEL==1) return CheckForm('Del');">
	 <div id="order" >
	  <h2><? if($User_ID) echo "Edit Existing"; else echo "Enter New"; ?> Customer Data</h2>
	 <table width="100%" cellpadding="2" id="tblEdit">
      <caption><p><span class="required">Red Fields</span> Are Required.</p> </caption>
<? if($User_ID) {?>
	  <tr>
	    <td><input type="hidden" name="User_ID" id="User_ID" value="<?=$User_ID ;?>" /><label class="required">ID Number:</label></td>
	    <td><b><?=$User_ID; ?></b></td>
	  </tr>

	  <tr>
	    <td><label>Date Entered:</label> </td>
	    <td><?=$DE; ?></td>
	  </tr>
<? }?>
	  <tr>
	    <td><label>IP Address:</label></td>
        <td><?=$IPAddress; ?></td>
	  </tr>
	  <tr>
	    <td><label for="username" class="required">Username:</label><br /><?=$UNPrompt;?></td>
	    <td><?="<input type=\"text\" class=\"text\" name=\"Username\" id=\"Username\" value=\"$Username\" maxlength=\"16\" size=\"12\" onblur=\"CheckUsername(this.value);\" $RO />";  ?></td>
	  </tr>

	  <tr>
	    <td><label for="YYCPassword" class="required">Password</label>:<br /><span class="cue">(6 -16 letters and numbers)</span></td>
	    <td><input type="text" class="text" name="YYCPassword" id="YYCPassword" onclick="subButton='CP';" maxlength="16" size="9" value="" /> <?=$ChangePWButton; ?></td>
	  </tr>

	  <tr>
	    <td><label for="CompName" class="optional">Company Name:</label></td>
	    <td><input type="text" name="CompName" id="CompName" maxlength="60" size="40" value="<?=$CompName; ?>"/></td>
	  </tr>
	  <tr>
	     <td><label for="CompFName" class="required">First &amp Last Names:</label></td>
	     <td>
	       <input type="text" class="text" name="CompFName" id="CompFName" maxlength="30" size="15" value="<?=$CompFName; ?>"/>&nbsp;&nbsp;
  		    <input type="text" class="text" name="CompLName" id="CompLName" maxlength="30" size="15" value="<?=$CompLName; ?>"/>
	     </td>
	  </tr>
	  <tr>
	    <td><label for="CompAddress1">Address:</label></td>
	    <td><input type="text" name="CompAddress1" id="CompAddress1" maxlength="60" size="25" value="<?=$CompAddress1; ?>"/></td>
	  </tr>
	  <tr>
	    <td><label for="CompCity">City:</label></td>
	    <td><input type="text" name="CompCity" id="CompCity" maxlength="60" size="25" value="<?=$CompCity; ?>"/></td>
	  </tr>

	  <tr>
	    <td><label for="states">State or Province:</label></td>
	     <td><? include("../includes/US_states_CA_provs.php"); ?></td>
	  </tr>

	   <tr id="tblProvince">
	    <td><label for="CompProvince">Province:</label><br /><small>(Outside USA &amp; Canada)</small></td>
	    <td><input type="text"  name="CompProvince" id="CompProvince" maxlength="48" size="25" value="<?=$CompProvince; ?>"/></td>
	   </tr>

	  <tr>
	    <td><label for="CompCountry">Country:</label></td>
	    <td><? include("../includes/country.php"); ?></td>
	  </tr>

	  <tr>
	  <td>
	   <label for="CompZip" >Zip or Postal Code:</label>
	  </td>
	  <td>
	   <input type="text" name="CompZip" id="CompZip" maxlength="10" size="5" value="<?=$CompZip; ?>"/> -
     <input type="text" name="CompPlus4" id="CompPlus4" maxlength="4" size="4" value="<?=$CompPlus4; ?>" title="US Zip+4" onkeyup="NextBox(this.id, event);" />
	  </td>
	  </tr>
<?
	  if(isset($subEmail))
	  {
			 $headers = "From: $SiteName<$SiteEmail>";
			 $headers .= "\r\nBCC: $WebmasterEmail";
			 $subject = "From $SiteName Manager:"; // placeholder f
			 $body = "From $SiteName Manager\r\n";
			 $body .= $taEmail;
			 $body= str_ireplace("\\r\\n", "\r\n", $body);
			// echo $body;
			 //echo "<H4>mail($to, $subject, stripslashes($body), $headers)</h4>";
			 if($mtest = mail($CompEmail, $subject, $body, $headers))
				 $MStatus= "Mail Sent to $CompEmail ";
			 else
				 $MStatus= "Mail Failed";
	  }
?>
	  <tr>
	  <td><label for="aSendEmail">Send an Email:</label><br /><?=$MStatus; ?>&nbsp;</td>
	  <td>
	       <a name="aSendEmail" id="aSendEmail" href="mailto:<?=$CompEmail;?>?Subject=From <?=$SiteName;?>">Email Link for your own email handler</a><br />
		  Or send an email from form below:<br />
		  <textarea name="taEmail" id="taEmail" rows="4" cols="40"><?//=stripslashes($taEmail);?></textarea><br />
		  <input type="submit" name="subEmail" id="subEmail" style=";" value="Send Email from Site" accesskey="E"  title="" />
	  </td>

	  <tr>
	    <td><label for="CompEmail" class="required">Email Address:</label></td>
	    <td><input type="text" name="CompEmail" id="CompEmail" maxlength="50" size="30" value="<?=$CompEmail; ?>"/></td>
	  </tr>

	  <tr>
 	    <td><label for="XCompEmail" class="required">Confirm Email Address:</label></td>
	    <td><input type="text" name="XCompEmail" id="XCompEmail" maxlength="50" size="30" value="<?=$XCompEmail; ?>"/></td>
	  </tr>
	  <tr>
	    <td><label for="CompAreaCode" class="required">Phone:</label></td>
	  <td>
		<?
		   if($CompPhone)
			 {
				  $CompExc = substr($CompPhone,0,3);
				  $CompBody = substr($CompPhone,3,4);
			 }
?>
	   (<input type="text" class="phone" name="CompAreaCode" id="CompAreaCode" maxlength="3" size="2" value="<?=$CompAreaCode; ?>" onkeyup="NextBox(this.id, event);" />)
     <input type="text" class="phone" name="CompExc" id="CompExc" maxlength="3" size="2" value="<?=$CompExc; ?>" onkeyup="NextBox(this.id, event);" /> -
     <input type="text" class="phone" name="CompBody" id="CompBody" maxlength="4" size="3" value="<?=$CompBody; ?>" onkeyup="NextBox(this.id, event);" /> xx
     <input type="text" class="phone" name="CompExt" id="CompExt" size="1" maxlength="6" value="<?=$CompExt;?>"/>
	  </td>
	  </tr>

	  <tr>
	    <td><label for="CompURL" class="optional">Web Site:</label></td>
	    <td><input type="text" name="CompURL" id="CompURL" maxlength="60" size="40" value="<?=$CompURL; ?>"/></td>
	  </tr>

	  <tr>
	    <td><label for="Stopped" class="optional">Account Activated:</label></td>
	    <td>
		  <label for="StoppedNo" class="optional">Yes</label> <input type="radio" name="Stopped" id="StoppedNo" value="N"<? if($Stopped != "Y") echo ' checked="checked"'; ?> />&nbsp;|&nbsp;
	    <label for="StoppedYes" class="optional">No</label> <input type="radio" name="Stopped" id="StoppedYes" value="Y"<?if($Stopped == "Y") echo ' checked="checked"'; ?> />
	  </td>
	  </tr>
	  </tr>
<? if($User_ID) { ?>
	  <tr>
    	 <td><label class="required" for="subMakeAdmin">Change User Adminstrator Status:</label></td>
	     <td>This is for your partners + you so you can log into this admin section by using your normal user credentials, not just the master one.<br />
	       <input type="submit" name="subMakeAdmin" id="subMakeAdmin" accesskey="8" title="or alt-8" value="<? if($Admin == 0) echo 'Make User an Admin'; else echo 'Remove Admin Status';?>" />
		  <input type="hidden" name="Admin" id="Admin" value="<?=$Admin ; ?>" />
	     </td>
	 </tr>
<? } ?>
	  <tr>
	    <td><label for="RefererType" >How they heard of us?: (Opt)</label></td>
	  <td>
         <select name="RefererType" id="RefererType">
			  <option value="" >Select One</option>
			  <option value="website"<? if($RefererType == "website") echo ' selected="selected"'; ?>>A Website</option>
			  <option value="forum"<? if($RefererType == "forum") echo ' selected="selected"'; ?>>Online Forum</option>
			  <option value="newspaper"<? if($RefererType == "newspaper") echo ' selected="selected"'; ?>>Newspaper</option>
			  <option value="newsletter"<? if($RefererType == "newsletter") echo ' selected="selected"'; ?>>Newsletter</option>
			  <option value="sales_rep"<? if($RefererType == "sales_rep") echo ' selected="selected"'; ?>>Sales Rep</option>
			  <option value="company"<? if($RefererType == "company") echo ' selected="selected"'; ?>>Company</option>
			  <option value="search_engine"<? if($RefererType == "search_engine") echo ' selected="selected"'; ?>>Search Engine</option>
			  <option value="other"<? if($RefererType == "other") echo ' selected="selected"'; ?>>Other</option>
          </select>
		</td>
	  </tr>
	  <tr>
	    <td><label for="RefererSource" >Name or URL of Referrer: (Opt)</label></td>
	    <td><input type="text" class="text" name="RefererSource" id="RefererSource" value="<?=$RefererSource ;?>" maxlength= "128" size="20" onkeyup="NextBox(this.id, event);" /></td>
	  </tr>

	  <tr>
	    <td><label for="DataNeeded" >Data Desired: (Opt)</label></td>
	    <td><textarea name="DataNeeded" id="DataNeeded" rows="4" cols="40"><?=$DataNeeded ;?></textarea></td>
	  </tr>

	  <tr>
	     <td><label class="required" for="subActivate">Change Customer Account Status:</label></td>
	     <td><input type="submit" name="subActivate" id="subActivate" onclick="subButton='upIns';" accesskey="j" title="or alt-j" value="<? if($Stopped == "Y") echo 'Activate'; else echo 'Deactivate';?>" /></td>
	  </tr>

	  <tr>
	    <td><label class="required"><?=$Profile; ?></label></td>
	    <td><input type="submit" name="cmdCompData" id="cmdCompData" onclick="subButton='upIns';" accesskey="e" title="or alt-e" value="<?=$Profile; ?>" />
		  <? if($SS) echo $Reset; //echo $User_ID;?>
			<?//=$Reset ;?>
	  </td>
	  </tr>
 <!-- where the old indicator was for reseller count -->
 <? if($User_ID) {  // when customer is active ?>
	  <tr><td colspan="2"><hr /><h3>Credit User's Account with Normal Records</h3></td></tr>
      <tr><td colspan="2"> &nbsp;<?
		echo $CreditMessage;
		 $Balance = checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID);
		 //echo "<br />User Credits = $Balance";
		?> </td></tr>

	  <tr>
	   <td><label for="Records" class="optional">Records to Credit:</label></td>
	   <td>
	   &nbsp;&nbsp;<input type="text" name="RecordsCredit" id="RecordsCredit" maxlength="20" size="8" value=""/> X
		  <select name="selMultiplier" id="selMultiplier" >
	     <option value="0">Select a Multiplier</option>
	     <option value="1">As Is</option>
	     <option value="1000" selected = "selected">Thousand</option>
	     <option value="1000000">Million</option>
	    </select>
	   </td>
	  </tr>

	  <tr>
	   <td><label for="Notes" class="optional">Notes:</label></td>
	   <td><input type="text" name="Notes" id="Notes" maxlength="512" size="50" value=""/></td>
	  </tr>

	  <tr>
	    <td><label class="required">Debit or Remove Credits:</label></td>
	    <td><input type="checkbox" name="chkDebit" id="chkDebit" value="1" onclick="if(this.checked == true) document.frmCompData.cmdPayment.value = 'Remove Credits'; else document.frmCompData.cmdPayment.value = 'Add Credits';" /></td>
	  </tr>

	  <tr>
	    <td><label class="required"><input type="hidden" name="User_ID" id="User_ID" value="<?=$User_ID ;?>" />Transfer Credits</label></td>
	    <td><input type="submit" name="cmdPayment" id="cmdPayment" onclick="subButton='Pay';" accesskey="p" title="or alt-p" value="Add Credits" /></td>
	  </tr>


  <tr><td colspan="2"><hr /><h3>User Account Stats</h3></td></tr>
	<tr><td colspan="2">
	   <?=getUserTransactions($Reseller_UN, $Reseller_ID, $User_ID); ?>
	</td></tr>
<?
  $RecordsCredit = intval(checkUserPOSCredits($Reseller_UN, $Reseller_ID, $User_ID));
  //echo $RecordsCredit;
  $ActualRecordsDebit = intval($RecordsCredit - $Balance);
  $Downloaded = intval(checkUserDownloadedCredits($Reseller_UN, $Reseller_ID, $User_ID));
  if($Downloaded == "")
   $Downloaded = 0;
?>
	  <tr>
	    <td><label>Records Purchased:</label></td>
	    <td><input type="text" name="txtRecordsCredit" id="txtRecordsCredit" maxlength="" size="20" value="<?=number_format($RecordsCredit); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	    <td><label>Records Used for Downloads:</label><br />Other records may have been taken back by reseller</td>
	    <td><input type="text" name="txtActualRecordsDebit" id="txtActualRecordsDebit" maxlength="" size="20" value="<?=number_format(intval($Downloaded)); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	    <td><label>Records Available:</label><br />Or Current Balance</td>
	    <td><input type="text" name="txtRecordsAvailable" id="txtRecordsAvailable" maxlength="" size="20" value="<?=(checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID)); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	    <td><label>Total Paid:</label></td>
	    <td><input type="text" name="txtTotalPaid" id="txtTotalPaid" maxlength="" size="20" value="$<?=number_format($TotalPaid,2); ?>" readonly="readonly"/><br />
			<? //echo "$RecordsAvailable = $RecordsCredit - $RecordsDebit $$TotalPaid";?>
	  </td>
	  </tr>

	  <tr><td colspan="2"><hr /><h3>Credit User's Account with New Movers Records</h3></td></tr>
      <tr><td colspan="2"><?
		echo $CreditMessage;
		 $Balance = checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID, "New_Home_Moves");
		 //echo "<br />User Credits = $Balance";
		?> </td></tr>

	  <tr>
	    <td><label for="NMRecords" class="optional">Records to Credit:</label></td>
	    <td><input type="text" name="NMRecordsCredit" id="NMRecordsCredit" maxlength="20" size="8" value=""/> X
		  <select name="selNMMultiplier" id="selNMMultiplier" >
	     <option value="1">Select a Multiplier</option>
	     <option value="1">As Is</option>
	     <option value="1000" selected = "selected">Thousand</option>
	     <option value="1000000">Million</option>
	    </select>
	  </td>
	  </tr>

	  <tr>
	    <td><label for="NMNotes" class="optional">Notes:</label></td>
	    <td><input type="text" name="NMNotes" id="NMNotes" maxlength="512" size="50" value=""/></td>
	  </tr>

	  <tr>
	    <td><label class="required" for="chkNMDebit">Debit or Remove Credits:</label></td>
	    <td><input type="checkbox" name="chkNMDebit" id="chkNMDebit" value="1" onclick="if(this.checked == true) document.frmCompData.cmdNMPayment.value = 'Remove New Mover Credits'; else document.frmCompData.cmdNMPayment.value = 'Add New Mover Credits';" /></td>
	  </tr>

	  <tr>
	    <td><label class="required"><input type="hidden" name="User_ID" id="User_ID" value="<?=$User_ID ;?>" />Transfer Credits</label></td>
	    <td><input type="submit" name="cmdNMPayment" id="cmdNMPayment" onclick="subButton='Pay';" accesskey="p" title="or alt-p" value="Add New Mover Credits" /></td>
	  </tr>
	  <tr>
	  <td><label>Download &amp; Query History:</label></td>
	  <td>
       <a href="customer_download.php?User_ID=<?=$User_ID;?>&Name=<?="$CompFName $CompLName";?>" target="_blank">Click Here</a>
	  </td>
	  </tr>
    <tr><td colspan="2"><hr /><h3>New Movers Account Stats</h3></td></tr>
	<tr><td colspan="2">
	   <?=getUserTransactions($Reseller_UN, $Reseller_ID, $User_ID, "New_Home_Moves"); ?>
	</td></tr>
<?
  $NMRecordsCredit = intval(checkUserPOSCredits($Reseller_UN, $Reseller_ID, $User_ID, "New_Home_Moves"));
  //echo $RecordsCredit;
  $NMActualRecordsDebit = intval($RecordsCredit - $Balance);
  $NMDownloaded = intval(checkUserDownloadedCredits($Reseller_UN, $Reseller_ID, $User_ID, "New_Home_Moves"));
  if($NMDownloaded == "")
   $NMDownloaded = 0;
?>
	  <tr>
	    <td><label>Records Purchased:</label></td>
	    <td><input type="text" name="txtNMRecordsCredit" id="txtNMRecordsCredit" maxlength="" size="20" value="<?=number_format($NMRecordsCredit); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	   <td><label>Records Used for Downloads:</label><br />Other records may have been taken back by reseller</td>
	   <td><input type="text" name="txtNMActualRecordsDebit" id="txtNMActualRecordsDebit" maxlength="" size="20" value="<?=number_format(intval($NMDownloaded)); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	    <td><label>Records Available:</label><br />Or Current Balance</td>
	    <td><input type="text" name="txtNMRecordsAvailable" id="txtNMRecordsAvailable" maxlength="" size="20" value="<?=(checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID, "New_Home_Moves")); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	    <td><label>Total Paid:</label></td>
	    <td><input type="text" name="txtTotalPaid" id="txtTotalPaid" maxlength="" size="20" value="$<?=number_format($TotalPaid,2); ?>" readonly="readonly"/><br />
			<? //echo "$RecordsAvailable = $RecordsCredit - $RecordsDebit $$TotalPaid";?>
	    </td>
	  </tr>


	  <tr><td colspan="2"><hr /><h3>Credit User's Account with White List Records</h3></td></tr>
      <tr><td colspan="2"><?
		echo $CreditMessage;
		 $Balance = checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID, "WhiteList");
		 //echo "<br />User Credits = $Balance";
		?> </td></tr>

	  <tr>
	    <td><label for="WLRecords" class="optional">Records to Credit:</label></td>
	    <td><input type="text" name="WLRecordsCredit" id="WLRecordsCredit" maxlength="20" size="8" value=""/> X
		  <select name="selWLMultiplier" id="selWLMultiplier" >
	     <option value="1">Select a Multiplier</option>
	     <option value="1">As Is</option>
	     <option value="1000" selected = "selected">Thousand</option>
	     <option value="1000000">Million</option>
	    </select>
	  </td>
	  </tr>

	  <tr>
	    <td><label for="WLNotes" class="optional">Notes:</label></td>
	    <td><input type="text" name="WLNotes" id="WLNotes" maxlength="512" size="50" value=""/></td>
	  </tr>

	  <tr>
	    <td><label class="required" for="chkWLDebit">Debit or Remove Credits:</label></td>
	    <td><input type="checkbox" name="chkWLDebit" id="chkWLDebit" value="1" onclick="if(this.checked == true) document.frmCompData.cmdWLPayment.value = 'Remove White List Credits'; else document.frmCompData.cmdWLPayment.value = 'Add White List  Credits';" /></td>
	  </tr>

	  <tr>
	    <td><label class="required"><input type="hidden" name="User_ID" id="User_ID" value="<?=$User_ID ;?>" />Transfer Credits</label></td>
	    <td><input type="submit" name="cmdWLPayment" id="cmdWLPayment" onclick="subButton='Pay';" accesskey="p" title="or alt-p" value="Add White List Credits" /></td>
	  </tr>
	  <tr>
	  <td><label>Download &amp; Query History:</label></td>
	  <td>
       <a href="customer_download.php?User_ID=<?=$User_ID;?>&Name=<?="$CompFName $CompLName";?>" target="_blank">Click Here</a>
	  </td>
	  </tr>
    <tr><td colspan="2"><hr /><h3>White List Account Stats</h3></td></tr>
	<tr><td colspan="2">
	   <?=getUserTransactions($Reseller_UN, $Reseller_ID, $User_ID, "WhiteList"); ?>
	</td></tr>
<?
  $WLRecordsCredit = intval(checkUserPOSCredits($Reseller_UN, $Reseller_ID, $User_ID, "WhiteList"));
  //echo $RecordsCredit;
  $WLActualRecordsDebit = intval($RecordsCredit - $Balance);
  $WLDownloaded = intval(checkUserDownloadedCredits($Reseller_UN, $Reseller_ID, $User_ID, "WhiteList"));
  if($WLDownloaded == "")
   $WLDownloaded = 0;
?>
	  <tr>
	    <td><label>Records Purchased:</label></td>
	    <td><input type="text" name="txtWLRecordsCredit" id="txtWLRecordsCredit" maxlength="" size="20" value="<?=number_format($WLRecordsCredit); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	   <td><label>Records Used for Downloads:</label><br />Other records may have been taken back by reseller</td>
	   <td><input type="text" name="txtWLActualRecordsDebit" id="txtWLActualRecordsDebit" maxlength="" size="20" value="<?=number_format(intval($WLDownloaded)); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	    <td><label>Records Available:</label><br />Or Current Balance</td>
	    <td><input type="text" name="txtWLRecordsAvailable" id="txtWLRecordsAvailable" maxlength="" size="20" value="<?=(checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID, "WhiteList")); ?>" readonly="readonly" /></td>
	  </tr>

	  <tr>
	    <td><label>Total Paid:</label></td>
	    <td><input type="text" name="txtTotalPaid" id="txtTotalPaid" maxlength="" size="20" value="$<?=number_format($TotalPaid,2); ?>" readonly="readonly"/><br />
			<? //echo "$RecordsAvailable = $RecordsCredit - $RecordsDebit $$TotalPaid";?>
	    </td>
	  </tr>
 </form>

	  <tr>
	  <td>
		<form method="post" ><!-- a new clear out button  -->
	    <label class="required">Clear Form Data for New Entry</label></td>
	    <td><input type="submit" name="cmdClear" id="cmdClear" accesskey="z" title="clear out old identity or alt-z" value="Clear Form" /></form></td>
	  </tr>


	  <tr><form method="post" onsubmit="return CheckForm(subButton);">
	    <td><input type="hidden" name="User_ID" id="User_ID" value="<?=$User_ID ;?>" />
	   <label class="required" for="cmdDel">Delete Customer</label>
	  </td>
	  <td><input type="submit" name="cmdDel" id="cmdDel" onclick="subButton='Del';" accesskey="x" title="deletes customer, or alt-x" value="Delete Customer" /></td>
	</form>  </tr>
   <? } // shows if $User_ID valid ?>
  </table>
	</div>
  </form>
 </td><!-- end rh column -->
</tr>
 </table>

  <? include("manager_links.php");?>
  <a href="/customer_profile.php">Public Customer Data Entry (this is where they have to go and login to get their identity cookies set)</a>
 </body>
</html>