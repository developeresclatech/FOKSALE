<?php
 extract($_POST);
 include("./includes/cURL_other_functions.php");
 include("./includes/siteData.php");
 include("./includes/dbConnecti.php");
?>
<html>
  <head>
   <title>Saved Queries For <?=$CompName; ?></title>
	  <script type="text/javascript">
<!--
   function checkDownload()
	 {
		   xx = document.getElementById('custNumOfRecords').value;
			 yy = document.getElementById('txtStep').value;
			 NumOfRecords = document.getElementById('NumOfRecords').value;
			 xx = parseInt(xx);
	     document.getElementById('custNumOfRecords').value = xx;
			 // checks customer adjusted number of records
			 if(xx < 1 || xx > NumOfRecords || isNaN(xx))
		   {
				 alert('The number of records requested is not correct, it is too high, too low or is not a number');
         document.getElementById('custNumOfRecords').select();
 				 return false;
       }
			 if(yy != '')
		   {
			  yy = parseInt(yy);
			  document.getElementById('txtStep').value = yy;
				// checks the record offset value
					 if(yy < 1 || isNaN(yy) )
					 {
						 alert('The record offset value is not correct, it is too high or low or is not a number');
						 document.getElementById('txtStep').select();
						 return false;
					 }
					 else if( (xx + yy) > NumOfRecords)
					 {
						 alert('The sum of the record offset value and records requested value '+ (xx + yy) + ' is greater than the total records available '+ NumOfRecords + ', make one or the other lower.');
						 document.getElementById('txtStep').select();
						 return false;
					 }
			 }
			 else
				 yy = "1";
       return  confirm('Do You Want to Download These '+ xx + ' Records Starting from Record '+ yy  +'? If OK, then your account here will be charged for all the records that you requested.');
	 }
	 function EnableSubmit()
	 {
    document.getElementById('subGetOutFile').disabled = false;
	 }
//-->
</script>
	 <style type="text/css">
	 	fieldset
		{
			border: 2px blue solid;
			width: 400px;
			padding: 10px;
    }
		input[type=text], input[type=password]
		{
			background-color: #FFFFCC;
		}
    #tblQuery td, #tblQuery th, td, th
		{
			color: #111111;
    }
	 </style>
	 <link rel="stylesheet" href="manager.css" type="text/css" />
 </head>

<body style="margin-left: auto; margin-right: auto;">
  <? include("includes/header.php");
 	  if($User_ID){
  ?>

 	 <div align="center" style="" id="divMain">
 	  <table width="1000" id="tblContents">
	 <tr>
<!-- 	  <td width="50">&nbsp;</td> -->
	  <td width="100%" align="center" valign="top">
 <!-- CONTENT AREA, INSERT GUTS HERE -->
 <?  include("includes/recordCount.php"); ?>
<form method="post" action=""  name="frm1" id="frm1" style="background-color: #EEEEEE; color: #111111;">
		<?php
		 		$submiturl = "$cURL_URL/api/customer_queries_api.php";
        $OUT_ARRAY = array("CompID" => $Reseller_ID, "User_ID" => $User_ID, "Username" =>$Reseller_UN );
        $data = GetDatacURL($submiturl, $OUT_ARRAY);
        echo $data;
			  if($Balance >0) {
     ?>
 	        Specify a name for your data export file(letters, numbers, or '_'s only): (opt) <input type="text" name="export_name" size="20"/><br />
					Change this to a lower value if you don't want all the records in the search: (opt) <input onBlur="document.getElementById('divStep').style.display='block'; document.frmGetOutfile.txtStep.focus();" onChange="document.getElementById('divStep').style.display='block'; document.frmGetOutfile.txtStep.focus();" type="text" name="custNumOfRecords" id="custNumOfRecords"  size="12" value="<?=$NumOfRecords;?>" /><br />
					<div align="center" id="divStep" style="display:none; padding: 2px 20px;">
					 if selecting less than the whole record count, start from this record: (opt) <input type="text" name="txtStep" style=";" id="txtStep" maxlength=" " size="12" value="<?=$txtStep ;?>" /><br />
           Otherwise you will get the records sorted A to Z by email address from the top of the list.<br />
					 Example you want only 10K records of a 101K count, but starting from the 20,000th record since you already downloaded the first two sets of 10K., you'd enter 10000 in the first box then 20000 in the one above.
					</div>
				 <input type="submit" value="Download Results" id="subGetOutFile" name="subGetOutFile" disabled="disabled" accesskey="g" title="Get the Outfile, or alt-g" /><br />
         <small>(First, Select one of the Queries Above)</small>
				<?
				  if(isset($subGetOutFile))
				  {
					  echo "<br /><a href='retrieve_data_files.php' style=''>Go Here to Download Your File(s)</a><br /><b>It may take a while depending on traffic and size</b>";
					  echo "<div style='background-color:#6aa727; padding:20px; margin:20px; color:white;'>";
						$submiturl = "$cURL_URL/remote_api_file_interface.php";
						$_POST["CompID"] = $Reseller_ID;
						$_POST["User_ID"] = $User_ID;
						$_POST["Username"] = $Reseller_UN;
						$data = GetDatacURL($submiturl, $_POST);
						
						echo "$data <h3 style='color:white;'>DONE</h3>";
						echo "</div>";
				  }
      }// END DISPLAY ONLY IF THEY HAVE A BALANCE
	?>
<!-- 				 <input type="hidden" name="NumOfRecords" id="NumOfRecords" value="<?=$NumOfRecords;?>" />
				 <input type="hidden" name="State_Abbrev" id="State_Abbrev" value="<?=$StFilePrefix;?>" />
				 <input type="hidden" name="query_outfile" id="query_outfile" value="<?=$query_outfile;?>" />
				 <input type="hidden" name="query_description" id="query_description" value="<?=$display;?>" />
         <input type="hidden" name="CustRequery" id="CustRequery" value="100" />
        <input type="hidden" name="Pull_Type" id="Pull_Type" value="<?=$Type; ?>" />
        	Specify a name for your data export file(letters, numbers, or '_'s only): (opt) <input type="text" name="export_name" size="20"/><br />
					Change this to a lower value if you don't want all the records in the search: (opt) <input onchange="document.getElementById('divStep').style.display='block'; document.frmGetOutfile.txtStep.focus();" type="text" name="custNumOfRecords" id="custNumOfRecords"  size="12" value="<?=$NumOfRecords;?>" /><br />
					<div align="left" id="divStep" style="display:none; width:;">
					 if selecting less than the whole record count, start from this record: (opt) <input type="text" name="txtStep" style=";" id="txtStep" maxlength=" " size="12" value="<?=$txtStep ;?>" /><br />
           Otherwise you will get the records sorted A to Z by email address from the top of the list.<br />
					 Example you want only 10K records of a 101K count, but starting from the 20,000th record since you already downloaded the first two sets of 10K., you'd enter 10000 in the first box then 20000 in the one above.
					</div>
				 <input type="submit" value="Download Results" id="subDownload" name="subDownload" disabled="disabled" accesskey="g" title="Get the Outfile, or alt-g" /><br />
         <small>(First, Select one of the Queries Above)</small>
			  <noscript>
			  	 Enable JavaScript
			  </noscript> -->
	    </form>
<!-- end Content area -->
	  </td>
	 </tr>
	 <? include('includes/footer.php') ;?>
	</table>
 	 </div>
  <?
	   } // end if user id
	   else
		 {
			 echo "\n<div style=\"background-color: white;\">\n<br />&nbsp;&nbsp;<h3>Your must be logged in to use this page</h3>";
			 include('includes/login.php');
			 echo "\n</div>\n";
	   include('includes/footer.php');
		 }
  ?>
 </body>
</html>