<?
  function categoryBox($NCat_ID, $dbhi, $d=-9)
  {
	  if($d > -1)
	   $return = "<select name='Type[$d]' id='Type_$d'>\n";
	  else 
	   $return = "<select name='Type' id='Type'>\n";
		$return .= "<option value=''>Select an Existing Category</option>\n";
		 $queryCat = "SELECT * FROM tblCategories ORDER BY Cat_ID ASC ; " ;
		 $resultsCat = mysqli_query($dbhi, $queryCat);
		 if($resultsCat)
		 {
			 while($dataCat = mysqli_fetch_assoc($resultsCat))
			 {
					 extract($dataCat);
					 $return .=  "<option value='$Cat_ID' ";
					 if($Cat_ID == $NCat_ID)
							 $return .=  'selected = "selected"'; 
					 $return .=  ">$Cat_Name ($Cat_Type)</option>\n";
			 }
		 }
		$return .= "</select>\n";
		return $return;
  }
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  include("../includes/siteData.php");
  include("../includes/dbConnecti.php");
  include("PHP_authenticate.php");
  $CompName = $User_ID = $Username = ""; //blanks out cookie data
  include("../includes/cURL_other_functions.php");
 // include("../includes/PHP_authenticate.php");
  extract($_POST);
  $SS = true;
  $CompMessage = "Hello Manager";
  $fontColor = "#306";
//////////////// CATEGORY SECTION ///////////////////////////////////////////////////////
 if(isset($subCatChanges))
 {
   $Description = mysqli_real_escape_string($dbhi,trim($Description));
   $Cat_Name = mysqli_real_escape_string($dbhi,trim($Cat_Name));
   if($ORDERBY > 0)
	   $OB = ", ORDERBY = $ORDERBY ";
   else
	   $OB = ", ORDERBY =  255 ";
	 $SET = " SET Cat_Name = '$Cat_Name', Cat_Type = '$Cat_Type', Description='$Description', Cat_Active ='$Cat_Active' $OB";
	 if(!$NCat_ID)
   {
		 $CatQuery = "INSERT INTO tblCategories $SET ;  ";
		 $resultsQ = mysqli_query($dbhi,$CatQuery);
		 if($Cat_ID = mysqli_insert_id($dbhi))
			 $CatMessage = "Category Added";
		 else
			 $CatMessage = $CatQuery.mysqli_error($dbhi);
	 }
	 else
   {
		 $CatQuery = "UPDATE tblCategories $SET WHERE Cat_ID = $NCat_ID ;";
		 if($resultsQ = mysqli_query($dbhi,$CatQuery))
		 {
		  if(mysqli_affected_rows($dbhi) > 0)
			{
			  $CatMessage = "Category Updated";
			 }
		  else
			  $CatMessage = "Did You Change Any Data";
		 }
		 else
			 $CatMessage = $CatQuery.mysqli_error($dbhi);
	 }
 }
// print_r($_POST);
//////////////////// ITEM SECTION /////////////////////////////////////////////////
	if($cmdUpdate) // ENTER A Price
	{
	 $CompMessage = "";
   for($x = 0; $x < count($Price) ; $x++)// MAIN FOR LOOP
	 {
	  //$Price[$x]= trim($Price[$x]);
	  $Records[$x] = intval(trim($Records[$x]));
	  $Price[$x] =  floatval(trim($Price[$x]));
	  $Licenses[$x] = intval(trim($Licenses[$x]));
	  $subscription[$x] = intval(trim($subscription[$x]));
	  $Item_Days[$x] = intval(trim($Item_Days[$x]));
	  $Intervals[$x] = intval(trim($Intervals[$x]));

    $Description[$x] = mysqli_real_escape_string($dbhi,trim($Description[$x]));
     $Type[$x] = intval($Type[$x]);
    if($Licenses[$x] == "")
			 $Licenses[$x] = 0;
    if(($Price[$x] > .01) && $Type[$x] > 0)
    {
     $SET = "SET `Item_Price` = $Price[$x] , `Item_Records` = '$Records[$x]', `Item_Licenses` = '$Licenses[$x]', `Active` = $Active[$x] , `Cat_ID` = $Type[$x] , `Item_Description` = '$Description[$x]' , `hosted_button_id` = '$hosted_button_id[$x]' , `subscription`= '$subscription[$x]' , Item_Days = '$Item_Days[$x]', Intervals = '$Intervals[$x]' ";
     if($Item_ID[$x] && !$Delete[$x])
		 {
 		  $queryUP = "UPDATE `tblItems` $SET  WHERE `Item_ID` = $Item_ID[$x] ; ";
		  echo "$queryUP<br>";
	    $resultsUP = mysqli_query($dbhi,$queryUP);
		  if($resultsUP && mysqli_affected_rows($dbhi))
		  {
			//$CompMessage .= "Price and Records Changed<br />";//<br />$queryUP";
			$UPDATE++;
	    }
		  elseif(mysqli_errno($dbhi))
			 $CompMessage .= "ERROR<br />". mysqli_error($dbhi). $queryUP.'<br>';
     }
     elseif($Item_ID[$x] && $Delete[$x] == "1")
		 {
 		  $queryDel = "DELETE FROM `tblItems` WHERE `Item_ID` = $Item_ID[$x] LIMIT 1; ";
	    $resultsDel = mysqli_query($dbhi,$queryDel);
		  if($resultsDel)
		  {
			$CompMessage = "Record #$Item_ID[$x] Deleted<br />";
			$DELETE++;
	    }
		  elseif(mysqli_errno($dbhi) && mysqli_affected_rows($dbhi))
			 echo mysqli_error($dbhi). $queryDel;
	    else
		  $CompMessage = "Check your values for Price and Records";
	   }
		// break;
	  } //END Checker if for prices
	  else
		  echo " SET `Item_Price` = '$Price[$x]' , `Item_Records` = '$Records[$x]', `Item_Licenses` = '$Licenses[$x]', `Active` = '$Active[$x]' , `Cat_ID` = $Type[$x] , `Item_Description` = '$Description[$x]' , `hosted_button_id` = '$hosted_button_id[$x]' , `subscription`= '$subscription[$x]', 	Intervals = '$Intervals[$x] <br /> ";
	 }// END FOR
  if($UPDATE)
	{
    $CompMessage .= "$UPDATE Records Changed $BR";//<br />$queryUP";
	  $BR = "<BR>";
	}
  if($DELETE)
    $CompMessage .= "<br />$DELETE Records DELETED<br />";//<br />$queryUP";
   $Records = $Price = $Licenses = $Description = null; //killl arrays to avoid putting crap in the boxes
  }//end if($cmdChange)
	if($cmdEnter) // ENTER A Price
	{
		 if($txtType !="")
            $Type = mysqli_real_escape_string($dbhi,trim($txtType));
		 else
           $Type = mysqli_real_escape_string($dbhi,trim($Type));
		 $Price = floatval(abs($Price));
		 $Records = intval(abs($Records));
		 $Active = intval(abs($Active));
		 $Licenses = intval(abs($Licenses));
		 $subscription = intval(abs($subscription));
	     $Item_Days = intval(trim($Item_Days));
	     $Intervals = intval(trim($Intervals));
         $Description = mysqli_real_escape_string($dbhi,trim($DescriptionN));
		 if($Price && $Description !="" && $Type > 0)
		 {
           if($subscription && $Intervals < 2)
			  $Intervals = 12;
           if($subscription && !$Item_Days)
			   $Item_Days = 30;
           if(!$Intervals)
			  $Intervals = 1;
           $SET = "SET `Item_Price` = '$Price' , `Item_Records` = '$Records', `Item_Licenses` = '$Licenses', `Active` = '$Active' , `Cat_ID` = $Type , `Item_Description` = '$Description' , subscription='$subscription' , Item_Days = '$Item_Days' , 	Intervals = '$Intervals' ";
		   $queryI = "INSERT INTO `tblItems` $SET  ; ";
	       $resultsI = mysqli_query($dbhi,$queryI);
		 //echo "$queryI<br />";
		 if($resultsI)
		 {
			$CompMessage = "Record Entered";
      $Price = $Records = $Licenses = $Description = $Type = "";
	   } 
		 elseif(mysqli_errno($dbhi))
			 $CompMessage = mysqli_error($dbhi). $queryI;
	   else
		  $CompMessage = "<span style='color:red;'>Check your values for Price and Records</span>". $queryI;
		 }
		 else
		  $CompMessage = "<span style='color:red;'>REJECTED: You need a price, description and/or ItemType | $Price | $Type | $Description</span>";
	 }
	?><!DOCTYPE html>
<html>
 <head>
 <title>Purchase Page Price, Package &amp; Category Manager</title>
 <meta http-equiv="content-type" content="text/html; charset=windows-1251" />
 <link rel="stylesheet" href="manager.css" type="text/css" />
 <script type="text/javascript">
  <!--
   //////////////////////////////// BOX JUMPER FUNCTION ////////////////////////////////////////////
  /* USE inside input element  onkeyup="NextBox(this.id);"  id="<?=$phIndex++; ?>_phone" */
	  function NextBox(boxID, event)
	  {
    KC = event.keyCode;
		if(KC > 47)
		{
			Box = document.getElementsByTagName('input');
			BoxL = Box.length;
			llen = document.getElementById(boxID).value.length;
			maxL = document.getElementById(boxID).maxLength;
			 if(llen >= maxL)
			 {
				for (x=0; x<BoxL; x++ )
				{
					if(boxID == Box[x].id )
					{
						Box[++x].focus();
						break;
					}
				}
			 }
		 }
    }

	  function CheckForm(b)// var b is the button clicked, in this case the delete but leaves room for more
	  {
     if(b == 'Del' )
			 return confirm('Do you want to delete this customer?');
		 else
			 return true;
	 }
  //-->
 </script>
   <style>
	  .divider
	  {
		   color:blue;
			 height:3px;
		}
		.row_header
		{
			font: 800 13pt Tahoma;
		}
	</style>
 </head>

 <body>
  <? include("manager_links.php");?>
 <a name="items"></a><h3>Message: <?=$CompMessage;?></h3>	 
<h1>Purchase Page Price, Package &amp; Category Manager</h1>
 <table width="100%" id="PricesDBS">
 <tr valign="top"><td colspan="2" ><hr /><a href="/purchase_records_software.php" target="_blank">See Purchase Page on Site</a> | <a href="<?=SELF; ?>">Reload This Page</a> | <a href="<?=SELF; ?>#categories">Category Section</a> | <a href="<?=SELF; ?>#newitems">Add New Items</a><hr />
 <h2>You Must Have Some Categories Entered, See the Bottom, Before you can Enter Any Items or Packages<br />
 All items have to have a Category Attached to Them</h2></td></tr>
  <tr valign="top">
  <td width="100%">
  <form method="post" id="frmItemUpdate" name="frmItemUpdate" action="<?=SELF; ?>#items">
	 <input type="hidden" name="Other" id="Other" value="1" />
	 <input type="submit" name="cmdUpdate" id="cmdUpdate" value="Update Existing Items" accesskey="u"  title="Update existing Items" />
	 <h3>Don't Add the Prices in the Description Fields. They will be added in automatically from the Price Field</h3>
	 <table id="existing_records" width="100%">
	  <caption><h3>Edit Existing Items and Prices<br />Required <span class="req">*</span></h3></caption>
		<!-- <tr class='row_header' align='center'><td>No.</td><td>Records</td><td>Price<span class='req'>*</span></td><td>Licenses</td><td>Type<span class='req'>*</span></td><td>PayPal Button ID</td><td>Active<span class='req'>*</span></td><td>Delete</td></tr> -->
<?
   $d = 0;
   $query = "SELECT * FROM `tblItems` LEFT OUTER JOIN `tblCategories` USING (`Cat_ID`) ORDER BY `Cat_ID`, `Item_Price`, `Item_Records` ASC ; " ;
   //$query = "SELECT * FROM `tblItems`  WHERE `Cat_ID` = 0 ORDER BY `Cat_ID`, `Item_Price`, `Item_Records` ASC ; " ;
   $results = mysqli_query($dbhi,$query);
	 if($results)
	 {
		 while($data = mysqli_fetch_assoc($results))
     {
			 extract($data);
			 $List = (int) $d + 1;
			 if($Cat_ID != $OldCat_ID)
			 {
				 if($Cat_Type =="")
           $Cat_Type = "Unlabeled You Must Assign These to a Category for Further Use";
         echo "<tr><td colspan='7' align='center'><h2>Category = $Cat_Name ($Cat_Type)";
				 if(!$Cat_Active) 
					 echo " <u>Disabled</u>";
				 echo "</h2><hr class='divider'/></td></tr>\n";
				 echo "<tr class='row_header' align='center'><td>No.</td><td>Records</td><td>Price<span class='req'>*</span></td><td>Licenses</td><td>Category<span class='req'>*</span></td><td>Active<span class='req'>*</span></td></tr>\n";//<td><!-- Delete -->&nbsp;</td>
         $OldCat_ID = $Cat_ID;
			 }
			 echo "<tr><td>$Item_ID</td><td><input type=\"hidden\" name=\"Item_ID[$d]\"  value=\"$Item_ID\" /><input type=\"text\" name=\"Records[$d]\" id=\"Records_$d\"  size=\"9\" value=\"$Item_Records\"  /></td>\n";
			 echo "<td>$<input type=\"text\" name=\"Price[$d]\" id=\"Price_$d\"  size=\"5\" value=\"$Item_Price\" /></td>\n";
 			 echo "<td><input type=\"text\" name=\"Licenses[$d]\" id=\"Licenses_$d\"  size=\"1\" value=\"$Item_Licenses\"  /></td>\n";
 			 echo "<td>";
			 echo categoryBox($Cat_ID, $dbhi, $d);
			 ?>
       
		  </td>
			<?
			 if($Active == 1)
			 {
				 $chkActiveYes = " checked=\"checked\" ";
			   $chkActiveNo = "";
			 }
 			 else
       {
			   $chkActiveNo = " checked=\"checked\" ";
         $chkActiveYes = "";
       }
			 if($subscription == 1)
				 $chkSub = " checked=\"checked\" ";
	     else
				 $chkSub = "";				 

		  echo "<td><label for=\"Active_CPSU_Yes_$d\">Yes:</label> <input type=\"radio\" name=\"Active[$d]\" id=\"Active_CPSU_Yes_$d\"  value=\"1\" $chkActiveYes /><br /><label for=\"Active_CPSU_NO_$d\">No:</label> <input type=\"radio\" name=\"Active[$d]\" id=\"Active_CPSU_NO_$d\"  value=\"0\" $chkActiveNo /></td>";
      //echo "<td><!-- <label for=\"Delete_CPS_$d\">Delete:</label> <input type=\"checkbox\" name=\"Delete[$d]\" id=\"Delete_CPS_$d\"  value=\"1\" /> -->&nbsp;</td>" ;
		  echo "</tr>\n";
			echo "<tr><td><label for=\"Subscription_CPS_$d\">Subscription:<input type=\"checkbox\" name=\"subscription[$d]\" id=\"Subscription_CPS_$d\"  value=\"1\" $chkSub /></td><td><label>Subscription Days: </label><input type='text' name=\"Item_Days[$d]\" maxlength='3' size='1' value='$Item_Days' /></td><th>Intervals: <input type='text' name='Intervals[$d]' maxlength='3' size='1' value='$Intervals'/></th><td class='row_header'>Description:<span class=\"req\">*</span></td><td colspan='2'><input type=\"text\" name=\"Description[$d]\" id=\"Description_$d\"  size=\"85\" value=\"$Item_Description\"  /></td></tr>\n";
	    echo "<tr><td colspan='6' height='7'><hr class='divider'/></td></tr>\n";
			$d++;
			// figures out the min price for a free record
			if($Licenses == 1 && !$Done)
			{
				$MinPrice = $Price;
        $Done = 1;
			}
		 }
	 }
	   else
	    echo  $query . mysqli_error($dbhi);
 //  $Active = $Records = $Price = $Licenses = $Description = $Type = "";
?> 
 </table><br /><hr />
   <input type="submit" name="cmdUpdate" id="cmdUpdate" value="Update Existing Items" accesskey="u"  title="Update existing Items" /></form><hr /><br />
  </td><!-- end lh column -->
 </tr><tr>
  <td width="100%" style="padding: 0 0 0 15px;">
  <form method="post"  action="<?=SELF; ?>#newitems" onsubmit="" id="frmACEEnter"><a name="newitems"></a>
	 <table id="new_records" width="100%">
	  <caption><h3>Add New Items</h3>Required <span class="req">*</span></caption>
		<tr class="row_header" align="center"><td>Records</td><td>Price <span class="req">*</span></td><td>Licenses</td><td>Category <span class="req">*</span></td><td>&nbsp;</td><td>Active <span class="req">*</span></td></tr>
			 <tr><td><input type="text" name="Records" id="Records"  size="8" value="<?=$Records; ?>" /></td>
			 <td>$<input type="text" name="Price" id="Price"  size="5"  value="<?=$Price; ?>"  /></td>
 			 <td><input type="text" name="Licenses" id="Licenses"  size="1"  value="<?=$Licenses; ?>"  /></td>
 			 <td align="center">
			 <?=categoryBox("",$dbhi); ?>
		   </td>
		   <td><!-- <input type="text" name="hosted_button_id" style=";" id="hosted_button_id" maxlength="" size="12" /> -->&nbsp;</td><td><label for="Active_CPS_Yes">Yes:</label> <input type="radio" name="Active" id="Active_CPS_Yes"  value="1" checked="checked" /> | <label for="Active_CPS_No">No:</label> <input type="radio" name="Active" id="Active_CPS_No"  value="0"  />  </td></tr>
			<tr><th>Is Subscription:<input type="checkbox" name="subscription" value="1"/></th><th>Subscription Days: <input type='text' name='Item_Days' maxlength='3' size='1' value="<?=$Item_Days ;?>"/></th><th>Intervals: <input type='text' name='Intervals' maxlength='3' size='1' value="1"/></th><th>Description:<span class="req">*</span></th><td colspan='2'><input type="text" name="DescriptionN" id="Description_$d"  size="70" value="<?=$DescriptionN; ?>"  /><hr /></td></tr>

	 </table><br /><hr />
   <input type="submit" name="cmdEnter" id="cmdEnter" value="Enter New Items" accesskey="e"  title="" /> </form><hr />
	  <h3>Message: <?=$CompMessage;?></h3>
  </td><!-- end rh column -->
 </tr>
 <? $Cat_ID= $Cat_Name = $Cat_Type = $Description = $ORDERBY = $Cat_Active = ""; ?>
 <tr valign="top">
  <td colspan="2" style="padding-left:20px;">
   Note: Active is a way to park a price-record level. If marked Active = No, it will be stored but not displayed anywhere<br />
	 Delete however, will permanently delete the price-record level.
	</td>
  </tr>
 </table>
<hr />
<? 
 if(isset($subCategory))
 {
	 $query = "SELECT * FROM tblCategories WHERE Cat_ID = $selCat_ID ; " ;
	 $results = mysqli_query($dbhi,$query);
	 if($results)
	 {
			$RRR = mysqli_fetch_assoc($results);
	     extract($RRR);
			 $CatMessage = "Category Data Retrieved";
	 }
	 else
		 echo $query.mysqli_error($dbhi);
 }
 elseif($NCat_ID > 0)
 {
	 $query = "SELECT * FROM tblCategories WHERE Cat_ID = $NCat_ID ; " ;
   // echo "Cat_ID = $NCat_ID<BR>$query<br />";
	 $results = mysqli_query($dbhi,$query);
	 if($results)
	 {
			$RRR = mysqli_fetch_assoc($results);
	     extract($RRR);
	 }
	 else
		 echo $query.mysqli_error($dbhi);
 }
?>
<h2>Manage/Add Product Categories</h2><a name="categories"></a>
  <h3>Category Message: <?=$CatMessage; ?></h3>
	 <a href="<?=SELF; ?>#items">Back to Top</a>
   <table width="100%" cellpadding="4" cellspacing="4"> 
	 <tr valign="top">
    <td width="320">
	   <h3>Select a Category if You Want to Change It</h3><br /><br />
    <form method="post" action="<?=SELF; ?>#categories" onsubmit="return " name="frmCategory1" id="frmCategory1">
    	  <select name="selCat_ID" id="selCat_ID" ondblclick="subCategory.click();" style="width:380px;" size="10">
		   <option value="">SELECT CATEGORY</option>
				 <? 
					 $query = "SELECT * FROM tblCategories ORDER BY ORDERBY, Cat_Name ASC ; " ;
					 $results = mysqli_query($dbhi,$query);
					 if($results)
					 {
						 while($dataCI = mysqli_fetch_assoc($results))
						 {

								 echo "<option value='$dataCI[Cat_ID]' ";
								 echo ">$dataCI[Cat_Name] ($dataCI[Cat_Type]) #$dataCI[ORDERBY]";
								 if($dataCI['Cat_Active'] == 0)
									   echo ' | NOT ACTIVE'; 
								 echo "</option>\n";
						 }
					 }
			   ?>
			  </select><br /><br />
			  <input type="submit" name="subCategory" id="subCategory" style=";" value="Select Category" accesskey=""  title="or doubleclick entry" />
    </form>
	</td>
  <td>
<form method="post" action="<?=SELF; ?>#categories" onsubmit="return " name="frmCategory2" id="frmCategory2">
   <h3>Change Category Data<br />Or Add New One</h3>
    <table width="100%" cellpadding="4" cellspacing="4">
	  <tr <? if(!$Cat_ID)  echo 'style="visibility: hidden;"'; ?>>
	   <td align="right" valign="top">
       <input type="hidden" name="NCat_ID" id="NCat_ID" value="<?=$Cat_ID ;?>" />
 			<label class="required">ID Number:</label>
	  </td>
	  <td>
	  	  <b>#<?=$Cat_ID; ?></b>
	  </td>
	  </tr>

	  </tr>

	  <tr>
	  <td align="right">
 			 <label for="Cat_Name" class="required">Category Name:</label>:<br />
 			 	<span class="cue">(6 to 32 Letters numbers)</span>
	  </td>
	  <td>
 			 <input type="text" name="Cat_Name" id="Cat_Name" maxlength="" size="40" value="<?=$Cat_Name; ?>" />
	  </td>
	  </tr>

	  <tr>
	  <td align="right">
	   <label for="Cat_Type" class="required">Category Code:</label>:<br />
 			 	<span class="cue">(5 Letters Max)</span>
	  </td>
	  <td>
	   <input type="text" name="Cat_Type" id="Cat_Type" maxlength="5" size="3" value="<?=$Cat_Type; ?>"/>
	   <input type="hidden" name="OLDCat_Type" id="OLDCat_Type" value="<?=$Cat_Type; ?>"/>
	  </td>
	  </tr>
	  <tr>
	  <td align="right">
	   <label for="ORDER" class="required">Category Order:</label>:<br />
 			 	<span class="cue">(255 is Default, Change it to a number less than like 1 for order this category will appear)</span>
	  </td>
	  <td>
	   <input type="text" name="ORDERBY" id="ORDERBY" maxlength="3" size="2" value="<? if($ORDERBY) echo $ORDERBY; else echo 255;; ?>"/>
	  </td>
	  </tr>
 	  <tr>
	  <td align="right">
	   <label for="Description" class="required">Description:</label>:<br />
 			 	<span class="cue">(512 characters maximum)</span>
	  </td>
	  <td>
		  <textarea name="Description" id="Description" rows="6" cols="51"><?=$Description;?></textarea>
	  </td>
	  </tr>  

	<?
			 if($Cat_Active == 1 || !$Cat_ID)
			 {
				 $chkCatActiveYes = " checked=\"checked\" ";
			   $chkCatActiveNo = "";
			 }
 			 else
       {
			   $chkCatActiveNo = " checked=\"checked\" ";
         $chkCatActiveYes = "";
       }
 		  echo "<tr><td><label for=\"Cat_ActiveY\" class=\"required\">Active:</label><br />No means the category won't display on purchase page</td>";    
		  echo "<td><label for=\"Cat_ActiveY\">Yes:</label> <input type=\"radio\" name=\"Cat_Active\" id=\"Cat_ActiveY\"  value=\"1\" $chkCatActiveYes /> |  
			<label for=\"Cat_ActiveN\">No:</label> <input type=\"radio\" name=\"Cat_Active\" id=\"Cat_ActiveN\"  value=\"0\" $chkCatActiveNo /></td>";
      echo "</td></tr>\n"

   ?>
	  <tr>
	  <td align="right">
	   <label class="required">Save Changes</label>
	  </td>
	  <td>
	    <input type="submit" name="subCatChanges" id="subCatChanges" accesskey="e" title="or alt-e" value="<? if($Cat_ID) echo "Save Category Edit"; else echo "Create New Category"; ?>" />
	  </td>
	  </tr>
   </table>
  </form>
  </td>
 </tr>
 </table>
 <form action="<?=SELF; ?>#categories" method="post"> 
    <div align="center" style=";">
     <input type="submit" name="clear" id="clear" style=";" value="CLEAR CATEGORIES" accesskey=""  title="" />
    </div>
 </form>
 <hr />
 	<a href="/purchase_records_software.php" target="_blank">See Purchase Page</a>
  <? include("manager_links.php");?>
 </body>
</html>