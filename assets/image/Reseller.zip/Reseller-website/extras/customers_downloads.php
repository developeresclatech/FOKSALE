<?php
 extract($_POST);
 include("../includes/cURL_other_functions.php");
 include("../includes/siteData.php");
 include("../includes/dbConnecti.php");
  $User_ID = $_GET['User_ID'];
  $Name = $_GET['Name'];
?>
<html>
  <head>
   <title>Queries For <?=$Name; ?></title>
   <link rel="stylesheet" href="manager.css" type="text/css" />
	 <style type="text/css">
	 	fieldset
		{
			border: 2px blue solid;
			width: 400px;
			padding: 10px;
    }
		input[type=text], input[type=password]
		{
			background-color: #FFC;
		}
    #tblQuery td, #tblQuery th, td, th
		{
			color: #111;
    }
	 </style>
 </head>
<body>
 	 <div align="center" id="divMain">
	  <h2>Queries &amp; Downloads For <?=$Name; ?></h2>
 	  <table width="100%" id="tblContents">
	 <tr>
<!-- 	  <td width="50">&nbsp;</td> -->
	  <td width="100%" align="center" valign="top">
 <!-- CONTENT AREA, INSERT GUTS HERE -->
 <?   // include("../includes/recordCount.php"); 
		 		$submiturl = "$cURL_URL/api/customer_queries_api.php";
        $OUT_ARRAY = array("CompID" => $Reseller_ID, "User_ID" => $User_ID, "Username" =>$Reseller_UN );
        $data = GetDatacURL($submiturl, $OUT_ARRAY);
        echo $data;
 	    
	?>

	  </td>
	 </tr>
	</table>
 	 </div>

 </body>
</html>