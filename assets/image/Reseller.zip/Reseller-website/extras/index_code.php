<?
	function checkUserLicenses($User_ID, $CompID) //available credits
	{  
      $arrData= ARRAY( "CheckUserLicenses"=>"1", "User_ID"=>"$User_ID", "CompID" => "$CompID") ;
      $table = GetDatacURL("$cURL_URL/api/reseller_software_licenses_interface.php", $arrData);
		  return $table;
	}
	
	function AssignLicenses($User_ID, $CompID) //available credits
	{  
      $arrData= ARRAY( "AssignLicenses"=>"1", "User_ID"=>"$User_ID", "CompID" => "$CompID") ;
      $table = GetDatacURL("$cURL_URL/api/reseller_software_licenses_interface.php", $arrData);
		  return $table;
	}
	
	function setLicense($User_ID, $CompID, $KeyID) //available credits
	{  
      $arrData= ARRAY( "setLicense"=>"1", "User_ID"=>"$User_ID", "CompID" => "$CompID", "KeyID" => "$KeyID") ;
      $table = GetDatacURL("$cURL_URL/api/reseller_software_licenses_interface.php", $arrData);
		  return $table;
	}
	function CheckAllLicenses($CompID) //available credits
	{  
      $arrData= ARRAY( "CheckAllLicenses"=>"1", "CompID" => "$CompID") ;
      $table = GetDatacURL("$cURL_URL/api/reseller_software_licenses_interface.php", $arrData);
		  return $table;
	}
  include("../includes/siteData.php");
  $RID = $Reseller_ID;
  include("../includes/dbConnecti.php");
  include("../includes/cURL_other_functions.php");
 include("../includes/PHP_authenticate.php");
  $CompName = $User_ID = $Username = ""; //blanks out cookie data

///////////// START FILE DOWNLOAD FUNCTION ///////////////////////////////////////
function DownloadFile($fileName)
{

 if(file_exists($file))
 {
	//$finfo = finfo_open(FILEINFO_MIME);
  header('Content-Description: File Transfer');
  header('Content-Type: application/octet-stream'); //.finfo_file($finfo, $file)header('Content-Type: text/plain'); basename
  header('Content-Disposition: attachment; filename='.($file));
  header('Content-Transfer-Encoding: binary'); //header('Content-Transfer-Encoding: ascii'); //
  header('Expires: 0');
  header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
  header('Pragma: public');
  header('Content-Length: ' . filesize($file));
  $download_done = readfile($file);
	if($download_done > 0)
	{
	  $dlMessage = "File " . $file . " Downloaded";
	  //unlink($file);
	  exit;
	}
 }
 else
 {
		return "File not found, $file";
 }
}
///////////// END FILE DOWNLOAD FUNCTION ///////////////////////////////////////
//mkdir("emailLists");  `CompFName`, `CompLName`,
///////////// BEGIN MAILING LIST FUNCTION //////////////////////////////////////////
  function makeEmailList($cond)
  {
	  if(!file_exists($_SERVER['DOCUMENT_ROOT']."/emailLists"))
     mkdir($_SERVER['DOCUMENT_ROOT']."/emailLists");
   $cond = stripslashes($cond);   // ORDER BY `CompEmail`
 	 $query = "SELECT `CompEmail` FROM tblResellerCustomers WHERE `CompEmail` != '' $cond ORDER BY `User_ID`  ";
	 $results = mysqli_query($dbhi,$query);
	// echo $query;
	 if($results && mysqli_num_rows($results))
	 {  //emailLists/
	  if($cond)
		 $fileName = $_SERVER['DOCUMENT_ROOT']."/emailLists/DBEMUpdatesEmails_".date('mdY').".txt";
	  else
		 $fileName = $_SERVER['DOCUMENT_ROOT']."/emailLists/CustomerEmails_".date('mdY').".txt";

		 $fh= fopen($fileName, "w");       //"customerEmails".time().".csv"
     if($fh)
		 {
		 while($data = mysqli_fetch_assoc($results))
	   {
			 extract($data);
       $str .= "$CompEmail;\r\n";
	   }
		 fputs($fh, $str);
		 fclose($fh);
     return DownloadFile($fileName);
		 }
		 else//file open problems
		 {
			 echo "Can't open the email file, $fileName for writing";
       return 0;
		 }
	  }
	 elseif(mysqli_error($dbhi))// db problems
   {
     echo "$query<br /> ". mysqli_error($dbhi) .', '. mysqli_errno($dbhi);
		 return 0;
   }
	 else
   {
     echo "<h2>No Emails In This Set</h2>";
		 return 0;
   }
  }
  ///////////// END MAILING LIST FUNCTION //////////////////////////////////////////
  foreach($_POST AS $K => $V)
  {
	   $V = stripslashes($V);
     $V = str_replace(chr(39), "",$V);
	   $CLEAN[$K] = mysqli_real_escape_string($dbhi,$V);
		 //echo $K.' ='.$V." &nbsp;&nbsp;";
  }
  extract($CLEAN);
 	  $CLEAN['Reseller_ID'] = $Reseller_ID;
	  $CLEAN["CompID"] = $Reseller_ID;
	  $CLEAN["Reseller_UN"] = $Reseller_UN;


  ///////////// MAILING LIST HANDLER /////////////////////////////////////////////////////
  if(isset($subMakeEmailList))
  {
    makeEmailList($chkUpdates);
  }
  echo $welcomeMessage;

  $SS = true;
  $CompMessage = "Hello Manager";
  $fontColor = "#330066";
  /// BEGIN HANDLER

	if(isset($subActivate))
	{
	 //echo "YES<BR>";
	  if($subActivate == "Activate")
		  $ActStatus = "N";
   elseif($subActivate == "Deactivate")
		  $ActStatus = "Y";
   $queryAct = "UPDATE `tblResellerCustomers` SET `Stopped` = '$ActStatus' WHERE User_ID = $User_ID LIMIT 1; ";
   $resultsAct = mysqli_query($dbhi,$queryAct);
    if(mysqli_affected_rows($dbhi)>0)
	  {
	   $CompMessage = "The Account is ".$subActivate."d.";//$CompName Data Entered!";
	   $fontColor = "green";
	  }
		else
			echo $queryAct .mysqli_error($dbhi);
	}


  elseif(isset($cmdDel))
	{
 		 $queryDel = "DELETE FROM `tblResellerCustomers` WHERE `User_ID` = '$User_ID' ;";
	   $resultsDel = mysqli_query($dbhi,$queryDel);
		 $User_ID = 0;
		 unset($User_ID);
		 $CompMessage = " Account Deleted";
	}
  	elseif (isset($cmdCompData))
	{
		if($CompExc !="")
		  $CompPhone = $CompExc . $CompBody;
		if($CompName == "")//2/7/2007
    {
      $CompName = $CompFName . " " . $CompLName;
    }
  if($XCompEmail == $CompEmail && strlen($CompEmail) > 6)
  {
   $SET = " SET `CompName` = '$CompName', `CompAddress1` = '$CompAddress1', `CompCity` = '$CompCity', `CompSt` = '$states', `CompCountry` = '$CompCountry', `CompZip` = '$CompZip', `CompPlus4` = '$CompPlus4', `CompAreaCode` = '$CompAreaCode', `CompPhone` = '$CompPhone', `CompExt` = '$CompExt', `CompEmail` = '$CompEmail', CompURL = '$CompURL', CompFName = '$CompFName', CompLName = '$CompLName' , `Stopped` = '$Stopped' , `RefererType` = '$RefererType', `RefererSource` = '$RefererSource' ,`Reseller_ID` = $Reseller_ID ";
   if(!$User_ID)// INSERT NEW CUSTOMER
	 {
   if($CompCountry != "" AND strlen($Username) > 5 AND strlen($YYCPassword) > 5 AND $CompName != "" AND $CompPhone != "" AND $CompEmail != "" )
	 {
        $queryI = "INSERT INTO tblResellerCustomers $SET ";
	 	    $submiturl = "$cURL_URL/api/remote_interface_insert_new.php";
        $queryI .= " , `Username` = '$Username', `CPassword` = PASSWORD('$YYCPassword') " ; //need to add username for use on this page
        $data = GetDatacURL($submiturl, $CLEAN);
		   if(is_numeric($data))
		   {
          $User_ID = $data;
				  $InsertGood = 1;
				  $queryI .=", `User_ID` = $User_ID";
			 }
			 else
			  {
				 echo $data;
				 $CompMessage = "Username has been already taken, use another one";
			  }
   if($InsertGood)
	 {
	  $resultsI = mysqli_query($dbhi,$queryI);
		if(mysqli_affected_rows($dbhi) > 0)
		 {
			 $User_ID = mysqli_insert_id($dbhi);
			 $update = 100; //flag var for successful updates and inserts
		   $CompMessage = "$CompName 's Profile Has Been Successfully Created";
     }
    else//username taken, so no User_ID returned, insert failed, User_ID is primary key, table logic
		 { //
			$CompMessage = mysqli_error($dbhi)."<br />$query<br />"."Username is taken,<br />Please choose another one!";
			$fontColor = "red";
	   }
	  }// END if($InsertGood)
	  }
		else
  		{ //
		 $CompMessage = "There Is Missing Information In the Profile, Please Try Again.";
		 $fontColor = "red";
	  }
    }//insert new user when User_ID is null

///////////////////////////////////  UPDATE QUERY

	 else //update query UPDATE OLD CUSTOMER
	 {

	  $queryUp = "UPDATE tblResellerCustomers SET  CompName = '$CompName', CompAddress1 = '$CompAddress1', CompCity = '$CompCity', CompSt = '$states', CompCountry = '$CompCountry', ";  //CPassword=PASSWORD('$CPassword'),
	  $queryUp .= "CompZip = '$CompZip', CompPlus4 = '$CompPlus4', CompAreaCode = '$CompAreaCode', CompPhone = '$CompPhone', CompExt = '$CompExt', CompEmail = '$CompEmail', CompURL = '$CompURL', CompFName = '$CompFName', CompLName = '$CompLName' , `Stopped` = '$Stopped' , `RefererType` = '$RefererType', `RefererSource` = '$RefererSource' , `DataNeeded` = '$DataNeeded' , `CompProvince` = '$CompProvince' , `CPS` = $optCPS WHERE User_ID = $User_ID;";
    $queryUp = "UPDATE tblResellerCustomers $SET WHERE `User_ID` = $User_ID ";
		$submiturl = "$cURL_URL/api/remote_interface_update_new.php";
       $data = GetDatacURL($submiturl, $CLEAN);
		   if(is_numeric($data))
		   {
				  $UpdateGood = 1;
			 }
			 else
			  {
				 echo $data;
				 echo "Remote failed";
				 $CompMessage = "Remote Update Failed, Update aborted";
			  }
   if($UpdateGood)
	 {
    $resultsUp = mysqli_query($dbhi,$queryUp);
		 $update = 100;  //flag var for successful updates and inserts
		//error messages for chock edit
    if(mysqli_affected_rows($dbhi)>0)
	  {
	   $CompMessage = "The Profile Has Been Updated";//$CompName Data Entered!";
	   $fontColor = "green";
	  }
    elseif(mysqli_errno($dbhi))
		{
      $CompMessage = "Company Data Entry Failed, ". mysqli_error($dbhi).", " . mysqli_errno($dbhi) . " : <br />". $queryI;
      $fontColor = "red";
	  }
		else
		{
		 $CompMessage = "Our System Did Not Notice A Change In Information.";
		 $fontColor = "orange";
	  }
	  }// end if remote worked
	 }//END else //update query
   }// end check passwords
   else //passwords don't match or are not long enough
   { //
		 $CompMessage = "The Passwords don't match or are invalid, Please Try Again.";
		 $fontColor = "red";
	 }

	}// END if (isset($_POST['cmdCompData'])) /// DATA ENTRY/EDIT HANDLERS
	if($subChangePW) //JUST GET DATA IF good User_ID
	{
		if(strlen($YYCPassword) > 5 && strlen($YYCPassword) < 17)
		{
 		 $queryS = "UPDATE tblResellerCustomers SET CPassword = PASSWORD('$YYCPassword') WHERE User_ID=$User_ID ;";
	   $resultsS = mysqli_query($dbhi,$queryS);
		 if($resultsS)
		 {
         $CompMessage = "Password Updated";
	   }
		 else
			 $CompMessage = mysqli_error($dbhi). $queryS;
		}
		else
         $CompMessage = "Password Length Wrong it's ".strlen($YYCPassword)." when it should be &gt; 5 and &lt; 17 characters long";
  }
?>