<?
 // page for management to see downloads by a chosen user
  include("../includes/siteData.php");
  include("../includes/dbConnecti.php");
  include("../PHP_authenticate.php");
  extract($_POST);
$CreateTable = "CREATE TABLE `tblDownloadFiles` (
 `Filename` varchar(256) NOT NULL,
 `CreationDate` int(11) NOT NULL COMMENT 'UNIX date from PHP',
 `Size` int(11) NOT NULL,
 `DateEntered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `tblUser_ID` int(11) NOT NULL COMMENT 'User ID of File Owner',
 `Display` char(1) NOT NULL DEFAULT '1' COMMENT 'controls whether the file should be shown to user',
 UNIQUE KEY `Filename` (`Filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <title>Download Data File Monitor</title>
 <meta http-equiv="content-type" content="text/html; charset=windows-1251">
 <link rel="stylesheet" href="manager.css" type="text/css" />
 <style type="text/css">
 	
 </style>

 </head>

 <body>
  <? include("manager_links.php");?>
   <h1>Download Data File Monitor</h1>
<?
  		      $dirR = "../pulls";
					//echo "SEARCH DIR ".$dirR.' | '.$ID.'<br />';
					$d = dir($dirR);
					$x = array();
					while (false !== ($r = $d->read()))
					{
						//if(stristr($r, ".csv.tar.bz"))
						if(substr($r, -12) == ".csv.tar.bz2")
						{
							$x[$r] = true;
						}
					}

         if(count($x))
				  {
					  foreach($x AS $K=>$V)
					  {
						    $J = "../pulls/".$K;
							  $RR = explode("_", $K);
							  $UID = $RR[0];
                $queryInsert = "INSERT INTO `tblDownloadFiles` SET `Filename` = '$K', `Size` = ".filesize($J)." , `CreationDate` = ".filemtime($J).", `tblUser_ID` = $UID ; ";
                $results = mysqli_query($dbhi,$queryInsert);
							 // echo $queryInsert .mysqli_error($dbhi)."<BR>";
					  }
				  }

				   if(isset($subDelete) && intval($txtDays) > 0)
				   {
						 $RRRR = time() - (86400 * intval($txtDays));
						 $queryHide1 = "UPDATE `tblDownloadFiles` SET `Display` = '0' WHERE  `CreationDate` < $RRRR   ;  ";
             $results = mysqli_query($dbhi,$queryHide1);
						 echo "QUERY = $queryHide1<br />";
						 if(mysqli_affected_rows($dbhi) > 0)
							  $status =mysqli_affected_rows($dbhi). " Files Deleted Older Than $txtDays Days";
						  /* else 	
							  $status = $queryHide1 .mysqli_error($dbhi);  */
					 }

				   if(isset($_GET['Delete']))
				   {
						 $del = $_GET['Delete'];
             $queryHide = "UPDATE `tblDownloadFiles` SET `Display` = '0' WHERE `Filename` = '$del'  LIMIT 1   ;  ";
             $results = mysqli_query($dbhi,$queryHide);
						 if(mysqli_affected_rows($dbhi) > 0)
							  $status = "File Deleted";
						  /* else 	
							  $status = $queryHide .mysqli_error($dbhi); */
					 }
           $querySelect = "SELECT * FROM `tblDownloadFiles` WHERE `Display` = '1' ORDER BY tblUser_ID, `CreationDate` ASC ";
           $resultsSelect = mysqli_query($dbhi,$querySelect);
					 if(mysqli_num_rows($resultsSelect))
				   {
					  echo "<h3>Site Address Files</h3>\n<hr />\n";
					  echo "<table width='100%'>\n";
					  echo "<caption>$status</caption>\n";
					  echo "<tr><td>&nbsp;</td><td>User ID</td><td>User Name</td><td>Creation Date</td><td>File Size (KB)</td><td>Download Link</td><td>Delete the File</td></tr>\n";  //
					  while($data = mysqli_fetch_assoc($resultsSelect))
					  {
						 extract($data);
						 if(file_exists("../pulls/".$Filename))
						 {
							 $queryName = "SELECT `CompName` FROM `tblResellerCustomers` WHERE `User_ID` = $tblUser_ID  ;" ;
							 $resultsName = mysqli_query($dbhi,$queryName);
							 $dataName = mysqli_fetch_assoc($resultsName);
							 extract($dataName);
							  $LL = number_format($Size/1000, 1);
							 echo "<tr class='outfilelinks'><td>".++$yy.")&nbsp;</td><td>$tblUser_ID</td><td>$CompName</td><td>".date ("m/d/y H:i", $CreationDate)."</td><td align='right'>$LL&nbsp;&nbsp;</td><td>";
							 echo "<a href='../pulls/$Filename'>$Filename</a></td><td><a href='$_SERVER[PHP_SELF]?Delete=$Filename'>Delete $yy</td></tr>\n"; //
						 }
            }
					  echo "</table>\n";
   				 echo "<hr />\n" ;
				  }
				  else
   					 echo "<h3>There are no Address Files in the /pulls directory</h3>\n" ;
  ?>
   <form method="post" action="<?=$_SERVER['PHP_SELF'] ; ?>" onsubmit="" name="frmDelete" id="frmDelete">
       <fieldset style="width:300px;">
        <legend>Delete Files Older Than a Certain Date </legend>
          Delete Files Older Than <input type="text" name="txtDays" id="txtDays" maxlength="10" size="4" value="40" /> Days<br />
				  <input type="submit" name="subDelete" id="subDelete" value="Delete Files" accesskey="x"  title="Delete Files Older Than the Days Entered Above" />
       </fieldset>
   </form>
<?
	 mysqli_free_result($resultsSelect);
   mysqli_close($dbhi);
   include("manager_links.php");
 ?>
 </body>
</html>