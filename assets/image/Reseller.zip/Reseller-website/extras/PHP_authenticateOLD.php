<?
 $_SESSION['LoggedIn'] = 1;
 if($_SESSION['LoggedIn'] == 1)
 {
	  $welcomeMessage = "<h3>Hello $CompName, welcome to the Customer Management Suite</h3>" ;
	  $_SESSION['LoggedIn'] = 1;
 }
 elseif($_SERVER['PHP_AUTH_USER'] != PHP_AUTH_USER || $_SERVER['PHP_AUTH_PW'] != PHP_AUTH_PW)
 {
		 $q = "SELECT User_ID, concat(CompFName, ' ',CompLName) AS NAME FROM tblResellerCustomers WHERE Username= '".$Username."' AND User_ID = $User_ID AND Admin > 0 ; ";
		 $r = mysqli_query($dbhi, $q);
		 if($r)
		  @$d = mysqli_fetch_row($r);
		 if($d[0])
		 {
		  $welcomeMessage = "<h3>Hello $d[1], welcome to the Customer Management Suite</h3>" ;
		  $_SESSION['LoggedIn'] = 1;
		 }
		else
		{
		 header('WWW-Authenticate: Basic realm="Website Management Section"');
		 header('HTTP/1.0 401 Unauthorized');
		 echo "You need to login with proper username and password to gain access to this page. ".PHP_AUTH_USER . " | ".PHP_AUTH_PW ."<BR>";
         print_r($_SERVER);
		 exit;
		}
 }
 else
 {
     $welcomeMessage = "<h3>Hello $SiteContact, welcome to the Customer Management Suite</h3>" ;
	 $_SESSION['LoggedIn'] = 1;
 }
 ?>