<?
 // page for management to see downloads by a chosen user
  include("../includes/siteData.php");
  include($_SERVER['DOCUMENT_ROOT']."/includes/dbConnecti.php");
  extract($_POST);
  $User_ID = $_GET['User_ID'];
  $Name = $_GET['CompName'];

 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <title>Customer Search History for #<?=$User_ID.', '.$Name ;?>: Private</title>
 <meta http-equiv="content-type" content="text/html; charset=windows-1251">
 <link rel="stylesheet" href="manager.css" type="text/css" />
 <style type="text/css">
 	  body
	  {
		  padding-left:30px;
		  font-family: arial, tahoma, helvetica;
		  font-size:10pt;
	  }
 </style>

 </head>
 
 <body style="max-width:1000px; margin-left: auto; margin-right: auto; ">
<!-- imageready slices (0005_red.psd - slices: 03, 04, 05) -->

   <h2>Customer Search History</h2>
<?
 
   $query = "SELECT `tblCustomerDebits`.RecordsDownloaded AS `RD`, Debit_ID, Timestamp, rows, QueryID, QueryDesc, QueryTime AS T FROM `tblCountQueries` LEFT OUTER JOIN `tblCustomerDebits` ON `tblCustomerDebits`.`Search_ID` = `tblCountQueries`.`QueryID` WHERE `tblCountQueries`.`User_ID` = $User_ID ORDER BY Timestamp DESC ;  ";
	
	 $query= "SELECT `tblCountQueries`.`Timestamp` AS TSTAMP, `tblCustomerDebits`.`RecordsDownloaded` AS `RD`,`tblCustomerDebits`.`Search_ID` AS `RAN`, `tblCustomerDebits`.`RecordsDownloaded` ,  `tblCountQueries`.`IPAddress`, `tblCountQueries`.`QueryTime` AS T, `QueryDesc`, `tblCountQueries`.`rows`, `tblCountQueries`.`User_ID`, `tblCountQueries`.`affiliate_id`, `tblCountQueries`.`QueryID`, DATE_FORMAT(`tblCountQueries`.`Timestamp`, '%m/%d/%y %H:%i' ) AS `TS` FROM `tblCountQueries`  LEFT OUTER JOIN `tblCustomerDebits` ON `tblCustomerDebits`.`Search_ID` = `tblCountQueries`.`QueryID` WHERE `tblCountQueries`.`User_ID` = $User_ID ORDER BY `tblCountQueries`.`Timestamp` DESC;";
   
	 $results = mysqli_query($dbhi,$query);
	 if($results)
	 {
    echo "<h2>Customer $Name #$User_ID Downloads</h2><hr />";
		echo '<table><tr><th width="100">When</th><th>Time<br />(secs)</th><th>Download<br />Count</th><th>Search<br />Count</th><th width="800">Description</th></tr>';
		echo "<caption><b>".mysqli_num_rows($results)." Searches</b></caption>";
		while($dataX = mysqli_fetch_assoc($results))
		 {	
			extract($dataX);
			echo "<tr valign=\"top\"";
			if($RD > 0)
				echo " style='background-color: #FFCC66;' ";
			echo "><td>$TSTAMP</td><td align='right'>$T</td><td align='right'>$RD</td><td align='right'>$rows&nbsp;&nbsp;</td><td><a href=\"SQL_Readout.php?QueryID=$QueryID\" target=\"_blank\">$QueryDesc SQL</a></td></tr>\n";
			echo "<tr><td colspan=\"5\"><hr /></td></tr>\n";
		 }
    echo "</table>";
	 }
	 else
	  echo $query.mysqli_error($dbhi).'<br />';   

	 mysqli_free_result($results);
   mysqli_close($dbhi); 
   //  phpinfo();			
 ?>	
 </body>
</html>