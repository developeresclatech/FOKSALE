<?
 // page for management to see downloads by a chosen user
  include("../includes/siteData.php");
  include("../includes/dbConnecti.php");
  include("PHP_authenticate.php");
  include("../includes/cURL_other_functions.php");
  extract($_POST);
   /* $User_ID = $_GET['User_ID'];
  $Name = $_GET['CompName']; */

 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <title>All Software Licenses</title>
 <meta http-equiv="content-type" content="text/html; charset=windows-1251">
 <link rel="stylesheet" href="manager.css" type="text/css" />
 <style type="text/css">
 	
 </style>

 </head>

 <body style="margin-left:auto; margin-right:auto;">
  <div align="center" style=";">
   <? include("manager_links.php");?>

   <h2>All Software Licenses</h2>
 <?
   echo CheckAllLicenses($Reseller_ID); //available credits
	 echo"<br /><hr /><br />";
   include("manager_links.php");
 ?>
  </div>
 </body>
</html>