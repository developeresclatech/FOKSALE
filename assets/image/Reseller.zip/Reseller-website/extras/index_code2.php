<?
  ///////////////////////////////////
  if(count($_POST ))
  {
		  foreach($_POST AS $K => $V)
		  {
				 $V = stripslashes($V);
				 $V = str_replace(chr(39), "",$V);
				 $CLEAN[$K] = mysqli_real_escape_string($dbhi,$V);
				 //echo $K.' ='.$V." &nbsp;&nbsp;";
		  }
		  extract($CLEAN);
  }
 	  $CLEAN['Reseller_ID'] = $Reseller_ID;
	  $CLEAN["CompID"] = $Reseller_ID;
	  $CLEAN["Reseller_UN"] = $Reseller_UN;


  ///////////// MAILING LIST HANDLER /////////////////////////////////////////////////////
  if(isset($subMakeEmailList))
  {
    makeEmailList($dbhi, $chkUpdates);
  }
  if(isset($subMakeCustomerList))
  {
    makeCustomerList($dbhi);
  }
 // echo $welcomeMessage;

  $SS = true;
  $CompMessage = $welcomeMessage;//"Hello Manager";
  $fontColor = "#306";
  /// BEGIN HANDLER

	if(isset($subActivate))
	{
	 //echo "YES<BR>";
	  if($subActivate == "Activate")
		  $ActStatus = "N";
   elseif($subActivate == "Deactivate")
		  $ActStatus = "Y";
   $queryAct = "UPDATE `tblResellerCustomers` SET `Stopped` = '$ActStatus' WHERE User_ID = $User_ID LIMIT 1; ";
   $resultsAct = mysqli_query($dbhi,$queryAct);
    if(mysqli_affected_rows($dbhi)>0)
	  {
	   $CompMessage = "The Account is ".$subActivate."d.";//$CompName Data Entered!";
	   $fontColor = "green";
	  }
		else
			echo $queryAct .mysqli_error($dbhi);
	}
  elseif(isset($cmdDel))
	{
		 $DelBalance = -1* (checkUserCredits($Reseller_UN, $Reseller_ID, $User_ID)); // recredits old credits back to reseller, 12/28/2012
		 AddUserCredits($Reseller_UN, $Reseller_ID, $User_ID, $DelBalance , $Notes);
		 //AddUserCredits($Reseller_UN, $Reseller_ID, $User_ID, $DelBalance , $Notes);
		 if(deleteUser($Reseller_UN, $Reseller_ID, $User_ID))
      $CompMessage = "User Deleted from DBE Server";
 		 $queryDel = "DELETE FROM `tblResellerCustomers` WHERE `User_ID` = '$User_ID' ;";
	   $resultsDel = mysqli_query($dbhi,$queryDel);
		 if(mysqli_affected_rows($dbhi))
      $CompMessage .= " User Deleted from Local DB";
		 $User_ID = 0;
		 unset($User_ID);
		 $CompMessage .= " Account Deleted";
	}
  	elseif (isset($cmdCompData))
	{
    if(is_numeric($CompExc) && is_numeric($CompBody))
      $CompPhone = $CompExc . $CompBody;
		$CompAreaCode = intval($CompAreaCode);
		if($CompName == "")//2/7/2007
    {
      $CompName = $CompFName . " " . $CompLName;
    }
  if($XCompEmail == $CompEmail && strlen($CompEmail) > 6)
  {
   $SET = " SET `CompName` = '$CompName', `CompAddress1` = '$CompAddress1', `CompCity` = '$CompCity', `CompSt` = '$states', `CompCountry` = '$CompCountry', `CompZip` = '$CompZip', `CompPlus4` = '$CompPlus4', `CompAreaCode` = '$CompAreaCode', `CompPhone` = '$CompPhone', `CompExt` = '$CompExt', `CompEmail` = '$CompEmail', CompURL = '$CompURL', CompFName = '$CompFName', CompLName = '$CompLName' , `Stopped` = '$Stopped' , `RefererType` = '$RefererType', `RefererSource` = '$RefererSource' ,`Reseller_ID` = $Reseller_ID ";
   if(!$User_ID)// INSERT NEW CUSTOMER
	 {
   if($CompCountry != "" AND strlen($Username) > 5 AND strlen($YYCPassword) > 5 AND $CompName != "" AND $CompEmail != "" )
	 {
        $queryI = "INSERT INTO tblResellerCustomers $SET ";
	 	    $submiturl = "$cURL_URL/api/remote_interface_insert_new.php";
        $queryI .= " , `Username` = '$Username', `CPassword` = PASSWORD('$YYCPassword') " ; //need to add username for use on this page
        $data = GetDatacURL($submiturl, $CLEAN);
		   if(is_numeric($data))
		   {
          $User_ID = $data;
				  $InsertGood = 1;
				  $queryI .=", `User_ID` = $User_ID";
			 }
			 else
			  {
				 echo $data;
				 $CompMessage = "Username has been already taken, use another one";
			  }
   if($InsertGood)
	 {
	  $resultsI = mysqli_query($dbhi,$queryI);
		if(mysqli_affected_rows($dbhi) > 0)
		 {
			 $User_ID = mysqli_insert_id($dbhi);
			 $update = 100; //flag var for successful updates and inserts
		   $CompMessage = "$CompName 's Profile Has Been Successfully Created";
     }
    else//username taken, so no User_ID returned, insert failed, User_ID is primary key, table logic
		 { //
			$CompMessage = mysqli_error($dbhi)."<br />$query<br />"."Username is taken,<br />Please choose another one!";
			$fontColor = "red";
	   }
	  }// END if($InsertGood)
	  }
		else
  		{ //
		 $CompMessage = "There Is Missing Information In the Profile, Please Try Again.";
		 $fontColor = "red";
	  }
    }//insert new user when User_ID is null

///////////////////////////////////  UPDATE QUERY
	 else //update query UPDATE OLD CUSTOMER
	 {
	  $queryUp = "UPDATE tblResellerCustomers SET  CompName = '$CompName', CompAddress1 = '$CompAddress1', CompCity = '$CompCity', CompSt = '$states', CompCountry = '$CompCountry', ";  //CPassword=PASSWORD('$CPassword'),
	  $queryUp .= "CompZip = '$CompZip', CompPlus4 = '$CompPlus4', CompAreaCode = '$CompAreaCode', CompPhone = '$CompPhone', CompExt = '$CompExt', CompEmail = '$CompEmail', CompURL = '$CompURL', CompFName = '$CompFName', CompLName = '$CompLName' , `Stopped` = '$Stopped' , `RefererType` = '$RefererType', `RefererSource` = '$RefererSource' , `DataNeeded` = '$DataNeeded' , `CompProvince` = '$CompProvince' , `CPS` = $optCPS WHERE User_ID = $User_ID;";
    $queryUp = "UPDATE tblResellerCustomers $SET WHERE `User_ID` = $User_ID ";
		$submiturl = "$cURL_URL/api/remote_interface_update_new.php";
       $data = GetDatacURL($submiturl, $CLEAN);
		   if(is_numeric($data))
		   {
				  $UpdateGood = 1;
			 }
			 else
			  {
				 echo $data;
				 echo "Remote failed";
				 $CompMessage = "Remote Update Failed, Update aborted";
			  }
   if($UpdateGood)
	 {
    $resultsUp = mysqli_query($dbhi,$queryUp);
		 $update = 100;  //flag var for successful updates and inserts
		//error messages for chock edit
    if(mysqli_affected_rows($dbhi)>0)
	  {
	   $CompMessage = "The Profile Has Been Updated";//$CompName Data Entered!";
	   $fontColor = "green";
	  }
    elseif(mysqli_errno($dbhi))
		{
      $CompMessage = "Company Data Entry Failed, ". mysqli_error($dbhi).", " . mysqli_errno($dbhi) . " : <br />". $queryI;
      $fontColor = "red";
	  }
		else
		{
		 $CompMessage = "Our System Did Not Notice A Change In Information.";
		 $fontColor = "orange";
	  }
	  }// end if remote worked
	 }//END else //update query
	 }// end check passwords
   else //passwords don't match or are not long enough
  	 { //
		 $CompMessage = "The Passwords don't match or are invalid, Please Try Again.";
		 $fontColor = "red";
	 }

	}// END if (isset($_POST['cmdCompData'])) /// DATA ENTRY/EDIT HANDLERS
	if($subChangePW)
	{
		if(strlen($YYCPassword) > 5 && strlen($YYCPassword) < 17)
		{
 		 $queryS = "UPDATE tblResellerCustomers SET CPassword = PASSWORD('$YYCPassword') WHERE User_ID=$User_ID ;";
	   $resultsS = mysqli_query($dbhi,$queryS);
		 if($resultsS)
		 {
         $CompMessage = "Password Updated";
	   }
		 else
			 $CompMessage = mysqli_error($dbhi). $queryS;
		}
		else
         $CompMessage = "Password Length Wrong it's ".strlen($YYCPassword)." when it should be &gt; 5 and &lt; 17 characters long";
  }
	if($subMakeAdmin)
	{
		if($Admin == 1)
		{
			$Target = 0;
			$NOW = "NOT";
		}
		else
		{
			$Target = 1;
			$NOW = "NOW";
		}
 		 $queryS = "UPDATE tblResellerCustomers SET Admin = $Target WHERE User_ID=$User_ID ;";
	   $resultsS = mysqli_query($dbhi,$queryS);
		 if($resultsS)
		 {
         $CompMessage = "User Is $NOW an Admin";
	   }
		 else
			 $CompMessage = mysqli_error($dbhi). $queryS;
	}
//////////////////////////////////////
     if(isset($cmdPayment))
	 {
		  $Records1000 = abs(floatval($RecordsCredit))*$selMultiplier;
		  if($chkDebit)
        $Records1000 *=-1;
		if($User_ID && abs($Records1000))
		{
			$Notes .= " | From Account Management";
			$CreditMessage =  AddUserCredits($Reseller_UN, $Reseller_ID, $User_ID, $Records1000, $Notes);
			$CompMessage = $CreditMessage;
			$bodyCredits = "$CompFName $CompLName, \r\n".number_format(abs($Records1000),0)." credits were just ";
		    if($chkDebit)
			{
              $bodyCredits .= "subtracted from";
              $CompMessage .= " credits subtracted from user account.";
			}
			else{
             $bodyCredits .= "added to";
             $CompMessage .= " credits added to user account.";
		   }
                $bodyCredits .= " your account at the $SiteName website with username of '$Username' and a company name of '$CompName'\r\n";
				if($Notes != "")
					$bodyCredits .= "Explanation: $Notes\r\n";
				$bodyCredits .= "Thanks\r\n\t---$SiteName Management";
				$headerCredits = "From: $SiteEmailFull\r\nReply-To:$SiteEmailFull";
				mail($CompEmail, "Account Change at $SiteName", $bodyCredits , $headerCredits);
			 }
			 else
				 $CompMessage = "You Must Enter a Valid Number of Records";
		 }
		//////////////////////////////////////////////////////
	  elseif(isset($cmdNMPayment))
	  {
		  $Records1000 = abs(floatval($NMRecordsCredit))*$selNMMultiplier;
		  if($chkNMDebit)
        $Records1000 *=-1;
		  if($User_ID && abs($Records1000))
		  {
			$Notes .= " | From Account Management";
			$CreditMessage =  AddUserCredits($Reseller_UN, $Reseller_ID, $User_ID, $Records1000, $NMNotes, "New_Home_Moves");
			$CompMessage = $CreditMessage;
			$bodyCredits = "$CompFName $CompLName, \r\n".number_format(abs($Records1000),0)." new mover credits were just ";
		    if($chkNMDebit)
			{
              $bodyCredits .= "subtracted from";
             $CompMessage .= " credits subtracted from user account.";
			}
			else
			{
              $bodyCredits .= "added to";
              $CompMessage .= " credits added to user account.";
			}
            $bodyCredits .= " your account at the $SiteName website with username of '$Username' and a company name of '$CompName'\r\n";
				if($Notes != "")
					$bodyCredits .= "Explanation: $Notes\r\n";
				$bodyCredits .= "Thanks\r\n\t---$SiteName Management";
				$headerCredits = "From: $SiteEmailFull\r\nReply-To:$SiteEmailFull";
				mail($CompEmail, "Account Change at $SiteName", $bodyCredits , $headerCredits);
			 }
			 else
				 $CompMessage = "You Must Enter a Valid Number of Records";
		 }
		//////////////////////////////////////////////////////
	  elseif(isset($cmdWLPayment))
	   {
		  $Records1000 = abs(floatval($WLRecordsCredit))*$selWLMultiplier;
		  if($chkWLDebit)
        $Records1000 *=-1;
		  if($User_ID && abs($Records1000))
		  {
			$Notes .= " | From Account Management";
			$CreditMessage =  AddUserCredits($Reseller_UN, $Reseller_ID, $User_ID, $Records1000, $WLNotes, "WhiteList");
			$CompMessage = $CreditMessage;
			$bodyCredits = "$CompFName $CompLName, \r\n".number_format(abs($Records1000),0)." new White List were just ";
		    if($chkWLDebit)
			{
              $bodyCredits .= "subtracted from";
             $CompMessage .= " credits subtracted from user account.";
			}
			else
			{
              $bodyCredits .= "added to";
              $CompMessage .= " credits added to user account.";
			}
            $bodyCredits .= " your account at the $SiteName website with username of '$Username' and your company name of '$CompName'\r\n";
				if($Notes != "")
					$bodyCredits .= "Explanation: $Notes\r\n";
				$bodyCredits .= "Thanks\r\n\t---$SiteName Management";
				$headerCredits = "From: $SiteEmailFull\r\nReply-To:$SiteEmailFull";
				mail($CompEmail, "Account Change at $SiteName", $bodyCredits , $headerCredits);
			 }
			 else
				 $CompMessage = "You Must Enter a Valid Number of Records";
		 }
//////////////////////////////////////
 	    $submiturl = "$cURL_URL/api/reseller_remote_create_users.php";
	    $RecordBalance = checkResellerCredits($Reseller_UN, $RID);
		  //echo "<h2>RecordBalance = $RecordBalance</h2>";
		  if(intval($RecordBalance))
		   $formatRB = number_format($RecordBalance,0);
//////////////////////////////////////////
	    $NMRecordBalance = checkResellerCredits($Reseller_UN, $RID, "New_Home_Moves");
		  //echo "<h2>RecordBalance = $RecordBalance</h2>";
		  if(intval($NMRecordBalance))
		   $formatNMRB = number_format($NMRecordBalance,0);
//////////////////////////////////////////
	    $WLRecordBalance = checkResellerCredits($Reseller_UN, $RID, "WhiteList");
		  //echo "<h2>RecordBalance = $RecordBalance</h2>";
		  if(intval($WLRecordBalance))
		   $formatWLRB = number_format($WLRecordBalance,0);
?>