<?php
 extract($_POST);
 include("../includes/cURL_other_functions.php");
 include("../includes/siteData.php");
 include("../includes/dbConnecti.php");
 include("PHP_authenticate.php");
?>
<html>
  <head>
   <title>Consumer and Business Search Queries on this Site</title>
   
 <style type="text/css">
	  #keys td
	  {
		  text-align: center;
    }
   #mainlist option
	 {
	  font-size: 9pt;
		background-color: #FED;
	 } 
	 *, td
	 {
		 max-width:1200px;
		 font-family:arial, tahoma;
		 color: #303;
	 }
	 body
	 {
		  background-color: #FF9;
		  padding:15px;
	 }
	 h3
	 {
	  font-size: 15pt;
		font-weight: bold;
	 } 
	 legend
	 {
	  font-size: 13pt;
		font-weight: bold;
	 } 
	 a, label
	 {
	  font-size: 12pt;
		font-weight: bold;
	 } 
	  input[type=text], input[type=password], textarea, select
		{

			margin:1px;
			margin-right:2px;
			margin-top:2px;
			color: #000;
			border:2px solid #7f7f7f;
			background-color: #F2F2F2;
		}
 </style>
 <link rel="stylesheet" href="manager.css" type="text/css" />
 </head>
<body>
  <? //include("../includes/header.php"); ?> 
  
  <? include("manager_links.php");?>
  <h1>All Queries from this Site</h1>
 	 <table width="100%" id="tblContents">
	 <caption></caption>
	 <tr>
	  <td width="80%" align="center" valign="top">
 <!-- CONTENT AREA, INSERT GUTS HERE -->
    <form method="post" name="frm1" id="frm1" style="background-color: #FFE; color: #111;">
		<?php
				$submiturl = "$cURL_URL/api/cURLSearchQueryMonitor.php";
				{
					 $_POST["Reseller_ID"] = $Reseller_ID;
					 $data = GetDatacURL($submiturl, $_POST);
					 echo $data;
				}
		?>
	 </form>
<!-- end Content area -->
	 </td>
	 </tr>
	</table>
 </body>
</html>