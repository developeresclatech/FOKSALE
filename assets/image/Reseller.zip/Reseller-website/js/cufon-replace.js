Cufon.replace('#header .row-1 .fright ul li', { fontFamily: 'Delicious', textShadow:'1px 1px #071317', color: '-linear-gradient(#fff, #999999)' });
Cufon.replace('#header .row-1 .fright ul li span', { fontFamily: 'Delicious Heavy', textShadow:'1px 1px #071317', color: '-linear-gradient(#fff, #999999)' });
Cufon.replace('#header .row-2 .fleft ul li', { fontFamily: 'Delicious', hover:true });
Cufon.replace('h2, h3', { fontFamily: 'Delicious Heavy' });