<?
function GetItemOE($dbhi, $Quantity)
{
	 $query = "SELECT * FROM `tblItems` WHERE `Item_Licenses` >= $Quantity AND `Active` > 0  AND `Item_Type` = 'OE'  ORDER BY `Item_Licenses` ASC LIMIT 1  ;  " ;
     $results = mysqli_query($dbhi,$query);
	 if($results)
	 {
		 //echo $query. mysqli_error($dbhi);
		// echo "NOR = ". mysql_num_rows();
		 $data = mysqli_fetch_assoc($results);
		 return $data;
	 }
     else
		 echo $query. mysqli_error($dbhi);
}
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    function GetDatacURL(&$arrData)
	{
		 $submiturl =  "https://www.paypal.com/cgi-bin/webscr";
		if(is_array($arrData))
           //$postdata = jdf_build_query( $arrData);//for fucking godaddy bs
	       $postdata = http_build_query( $arrData); //for fucking PHP 5
		$ch = curl_init(); /// initialize a cURL session
		curl_setopt ($ch, CURLOPT_URL,$submiturl);  //live server
		curl_setopt ($ch, CURLOPT_HEADER, 0);
		curl_setopt ($ch, CURLOPT_POST, 1);
		curl_setopt ($ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);

		//Un comment the next line to write the response to the rates and services request to a file.
		//curl_setopt ($ch, CURLOPT_FILE, $fp);

		//Check to see if this code is on a windows machine or a unix
		$filename = "c:\\windows\\system32\\ca-bundle.crt";
		if (file_exists($filename))
		{
			curl_setopt ($ch, CURLOPT_CAINFO, "c:\windows\system32\ca-bundle.crt");
			curl_setopt ($ch, CURLOPT_CAPATH, "c:\windows\system32\ca-bundle.crt");
			//curl_setopt ($ch, CURL_CA_BUNDLE, "c:\windows\system32\ca-bundle.crt");
		}
		$data = curl_exec ($ch);
		if (curl_errno($ch))
		{
			  return curl_error($ch);
		}
		else
			return $data;
  	  curl_close ($ch);
	}//
////////////////////////////////////////  END function GetDatacURL($submiturl)  //////////////////////////////////////////////////////
		include("./includes/siteData.php");
        include("./includes/dbConnect.php");
		session_start();
		extract($_POST);
/*
  CREATE TABLE tblSales (
  SalesID bigint(20) unsigned NOT NULL auto_increment,
  Order_No varchar(128) NOT NULL COMMENT 'The order id forwarded to cc handler, unique',
  Price decimal(12,2) unsigned NOT NULL COMMENT 'Price ',
  ReferenceNo int(11) NOT NULL,
  Description varchar(128) NOT NULL,
  User_ID bigint(20) unsigned NOT NULL COMMENT 'who bought it',
  Completed tinyint(4) NOT NULL COMMENT 'was it paid',
  Error varchar(64) default NULL COMMENT 'Why payment was rejected',
  SalesDate timestamp NOT NULL default CURRENT_TIMESTAMP,
  IPAddress varchar(64) NOT NULL,
  Item_ID bigint(20) unsigned NOT NULL,
  authcode varchar(32) NOT NULL,
  response_reason varchar(64) NOT NULL,
  txn_id varchar(64) NOT NULL,
  CCPayment decimal(12,2) unsigned default NULL COMMENT 'actual payment',
  PRIMARY KEY  (SalesID)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COMMENT='new sales table for software'
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////
function GetItem($Item_ID)
{
	 $query = "SELECT * FROM `tblItems` WHERE `Item_ID` = $Item_ID  ;  " ;
     $results = mysqli_query($dbhi,$query);
	 if($results)
	 {
		 $data = mysqli_fetch_assoc($results);
		 return $data;
	 }
	 else
		 echo $query. mysqli_error($dbhi);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
function GetPayPalID($Item_ID)
{
	 $query = "SELECT `hosted_button_id` AS HBID  FROM `tblItems` WHERE `Item_ID` = $Item_ID  ;  " ;
     $results = mysqli_query($dbhi,$query);
	 if($results)
	 {
		 $data = mysqli_fetch_assoc($results);
		 extract($data);
		 if($HBID != "")
		    return $HBID;
		 else
			 return 0;
	 }
	 else
		 echo $query. mysqli_error($dbhi);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(isset($SubCompleteOrder)   && $User_ID)//processing loop
	{
		if(ctype_digit($CCNumber) && ctype_digit($CCMonth) && ctype_digit($CCYear) && ctype_digit($User_ID) )
		{
         include("includes/graypay.php");
		 extract(GetItem($_SESSION['Item_ID']));
         $Invoice = $User_ID."_".date('YmdHis');
         $gw = new gwapi;
         $gw->setLogin($CC_UN, $CC_PW); // LIVE LOGIN
         //$gw->setLogin("demo", "password"); // TEST LOGIN
		 $gw->setBilling($CCFName,$CCLName,$CompName,$CCAddress1, $CompAddress2,  $CCCity,  $states, $CCZip, $CCCountry, $CompAreaCode.$CompPhone, "", $CompEmail,         $CompURL);
		 $gw->setOrder($Invoice, $Item_Description, $_SERVER['REMOTE_ADDR']);
		 $r = $gw->doSale($Item_Price,  $CCNumber, $CCMonth.$CCYear, $CCCcv);
        extract  ($gw->responses);
        if($response == 1)
		{
			$Completed = 1;
			$SalesMessage = "Sale Successful: Authorization Code = $authcode";
		}
		else
		{
			$Completed = 0;
			$SalesMessage = "Sale Failed: $responsetext";
		}

  	    $queryI = "INSERT INTO `tblSales`  SET  `Order_No` = '$Invoice', `IPAddress`= '".$_SERVER['REMOTE_ADDR']."',  `Price` = '$Item_Price',  `User_ID` = '$User_ID' , `Item_ID` = '$Item_ID' ,  `Description` = '$Item_Description' , Completed = '$Completed' , ReferenceNo = '$transactionid' , Error = '$responsetext' , authcode = '$authcode ' ;  ";
	    $resultsI = mysqli_query($dbhi,$queryI);
		if($resultsI)
		{
			$SalesID = mysqli_insert_id($dbhi);
		}
		else
		 {
			//echo $queryI.mysqli_error($dbhi);
			  $SalesMessage .= "<br />Good Sale but local DB error";
		}  //Town News <townnews@optonline.net>
		     /*  echo      */ $gw->sendReceipt($Completed, $responsetext, $MainEmail);  //,  jakefree@verizon.net
	  }// end if(ctype_digit($CCNumber) && ctype_digit($CCMonth) && ctype_digit($CCYear) && ctype_digit($User_ID) )
	  else
		  $SalesMessage = "You have Bad CC Information, check your numbers and  expiration date";

	 }
 ?><!DOCTYPE html>
<html>
  <head>
    <title><?=$SiteName; ?>: Purchase Data and Licenses</title>
    <?  include("includes/metas.php"); ?>
    <style>
	  p{}
		label
		{
			padding-left: 15px;
			padding-bottom: 5px;
			font-size: 11pt;
		}
		#ulOE li ,  .ulOE
		{
			font-size: 11pt;
		}
		.my_li, li
		{
		  padding-left:30px;
		  margin-bottom:6px;
          list-style-type: none;
		}
		#tdItems strong
		{
			font-size: 14pt;
		}
		.productName
		{
			font-size: 13pt;
		}
		.description
		{
			font-size: 11pt;
		}
		.notes
		{
			font-size: 9pt;
			font-style: italic;
		}
		.PP
		{
			color: #928E87;
			font-size: 11pt;
		}
	</style>
	    <script type="text/javascript">
  <!--
    //////////////////////////////// BOX JUMPER FUNCTION ////////////////////////////////////////////
    /*  USE inside input element    onkeyup="NextBox(this.id);"   id="phone"  */
	   function NextBox(boxID, event)
	   {
        if(event.keyCode > 47)
		{
        Box = document.getElementsByTagName('input');
	    BoxL = Box.length;
		llen = document.getElementById(boxID).value.length;
		maxL = document.getElementById(boxID).maxLength;
		if(llen >= maxL)
		 {
            for (x=0; x<BoxL; x++ )
            {
				if(boxID == Box[x].id )
				{
                    Box[++x].focus();
					break;
				}
            }
          }
		}
       }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      function enable()
	  {
         w = document.frmPayment;
        w.subSelectItem.disabled = false;
          /*  w.subSelectItem2.disabled = false;
        w.subSelectItem3.disabled = false;
        w.subSelectItem4.disabled = false;
        w.subSelectItem5.disabled = false;
        w.subSelectItem6.disabled = false;
        w.subSelectItem7.disabled = false;
        w.subSelectItem8.disabled = false;
        //w.subSelectItem9.disabled = false;
        w.subSelectItem10.disabled = false;  */
	  }
   //-->
  </script>
  </head>
<body>
   <?  include("includes/header.php"); ?>
     <div id="content">
    <div class="row1">
      <div class="main">
 <form method="post" action="<?=$_SERVER['PHP_SELF'] ; ?>#start"  onsubmit="//return " name="frmPayment" id="frmPayment">
 <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents" >
  <tr>
    <td align="center" valign="top" class="p2">
	<table width="100%" border="0" cellspacing="0" cellpadding="5" style="color:white;">
      <tr>
        <td align="center" valign="top">
		  <table width="97%" border="0" cellspacing="0" cellpadding="5" style="margin:10px;">
            <tr>
              <td align="left" valign="top">
  <h3>Purchase Plans for our   Software and Data Packages</h3>
<p class="productName">( We accept PayPal payments only )</p>
 250 Million US Opt-in Email records; 100% Bounced Data Replacement<br /><br />
 <fieldset>
  <legend><h4>TECH SUPPORT & TRAINING:</h4></legend>
 Let our techies help you set up your software and give you one on one personal training; only $25 per hour*.  ( *subject to change without notice). <br />
 We will schedule the appointment between you and our Technical Support Staff after we deliver your software license
 </fieldset><br />
<p class="productName">All One Time License Fees Include Updates</p>
<br /><br /><hr /><br />
  <div align="center" id="divWarning">
                    <?
					    if(!$User_ID)
					   {
						   echo "<h3>You must be logged into make a purchase</h3>";
						   include("includes/loginNew.php");
						   echo "<hr /><br />\n";
					   }
					 ?>
                  </div>
			  </td>
            </tr>
            <tr>
              <td align="left"  id="tdItems">
	          <?
					 $queryCL = "SELECT  *  FROM tblCategories   WHERE Cat_Active !=0  ORDER BY ORDERBY, Cat_Name ASC; " ;
					 $resultsCL = mysqli_query($dbhi,$queryCL);
					 if($resultsCL)
					 {
						 while($dataCI = mysqli_fetch_assoc($resultsCL))
						 {
							 extract($dataCI);
							  $d = 0;
							  $query = "SELECT * FROM `tblItems` WHERE `Active` = 1 AND  Cat_ID = '$Cat_Type'  AND  ! subscription  ORDER BY `Item_Price`, `Item_Records` ASC  ; " ;
							 $results = mysqli_query($dbhi,$query);
							 if($results && mysqli_num_rows($results))
							 {
								 echo "<p class='productName'>$Cat_Name ($Cat_Type)</p><a name='$Cat_Type'></a>
								   <p class='description'>".stripslashes($Description)."</p><br />
								  <p class='PP'>Purchase Plans:</p>
								<ul>\n";
								 while($data = mysqli_fetch_assoc($results))
								 {
									 extract($data);             //
									 echo "<li><label for=\"Data_".$Item_ID."\"><input type=\"radio\" name=\"Items\" id=\"Data_".$Item_ID."\" value=\"$Item_ID\"";
									 echo "   onclick='enable();' />".stripslashes($Item_Description)." $Item_Price";
									 echo "</label></li>\n";
								  }// end while
							//echo "<li><input type=\"radio\" name=\"UMamount\" id=\"1\" value=\".5\"  checked='checked' />  50 Cents for 1 Record TEST ONLY </li>\n";
							   echo "\n</ul>\n<br /><hr /><br />"; //end of data only section
							 }
							 elseif(mysqli_errno($dbhi))
							   echo "$query  ". mysqli_error($dbhi);
						 }
					 }
					elseif(mysqli_errno($dbhi))
					   echo "$queryCL  ". mysqli_error($dbhi);
/////////////////////////////////////////////////////////////////////////////////////////////////////////

	  $d = 0;
      $query = "SELECT * FROM `tblItems` WHERE `Active` = 1 AND  subscription = 1  ORDER BY `Item_Price`, `Item_Records` ASC  ; " ;
     $results = mysqli_query($dbhi,$query);
	 if($results && mysqli_num_rows($results))
	 {
		 echo '<p class="productName">Monthly Subscriptions Plans</p>
		   <p class="description">Get monthly allotments of records through a subscription plan with Pay Pal</p><br />
          <p class="PP">Purchase Plans:</p>
		<ul> ';
		 while($data = mysqli_fetch_assoc($results))
         {
			  extract($data);
               echo "<li><label for=\"AllPack_".$Item_ID."\"><input type=\"radio\" name=\"Items\" id=\"AllPack_".$Item_ID."\" value=\"$Item_ID\"";
			   echo "   onclick='enable();' />$Item_Description";
			echo "</label></li>\n<li>&nbsp;</li>";
		  }// end while

	   echo "\n</ul>\n"; //end of data only section
	 }
	 elseif(mysqli_errno($dbhi))
	   echo "$query  ". mysqli_error($dbhi);
?><br /><hr /><br />
                  <div align="center" id="divButtons">
                    <?
					    if($User_ID)
					      echo '<p style="width:168px; border: 2px solid #369; padding: 10px;"  title="Purchase selected package or alt p, You must select a package first!"><input type="submit" name="subSelectItem" id="subSelectItem"  style="font-size:14pt; font-weight:bold; color:#30F; margin:2px;" value="Purchase Item"  accesskey="P"  disabled="disabled"  /></p>';
                       else
					   {
						   echo "<h3>You must be logged into make a purchase</h3>";
						  // include("includes/login.php");
					   }
					 ?>
                  </div><hr /><br />
				  <p class="productName">All One Time License Fees Include Updates</p>
             </td>
            </tr>
            <tr>
            	<td align="left" valign="top">
                	<span class="style23"><span class="style26"><strong>Use of Stolen Card Security Warning:</strong></span></span>
                     <p class="content">When purchasing the Internet Protocol (IP) address of your computer will be seen and if the IP address is not one
                     that matches the postal mailing location provided on the credit card being used, no license or software download
                     will be issued. Additionally all orders need a phone number in the geographic area that corresponds to the mailing
                     address being used on the credit card as security will contact you to verify that you are placing the order.
                     Users of stolen credit cards should also understand that the software unlock codes can be remotely disabled by us.
                     Additionally if there is an attempt to purchase with a stolen credit card the IP address of the computer used will
                     be turned over to authorities.</p>
                </td>
            </tr>
          </table>
         </td>
      </tr>
    </table></td>
  </tr>
  </table>
 </form>
 <?
 if($User_ID)
 {
 	 if(isset($subSelectItem)) // 1st click
	 {
		$_SESSION['Item_ID'] = "";
        if(ctype_digit($Items))
		{
         if($Items)
		    extract(GetItem($Items));
		// echo "<h1>$hosted_button_id</h1>";
        if($Item_Price > 0)
		 {
		   $_SESSION['Item_ID'] = $Items;
		   $GoAhead = 1;
           $querySales = "INSERT INTO `tblSales` SET `Price` = $Item_Price, User_ID = $User_ID, `Item_ID` = $Item_ID, `IPAddress` = '$_SERVER[REMOTE_ADDR]' , `Description` = '$Item_Description'  ;         ";
		   $resutlsSales = mysqli_query($dbhi,$querySales);
		   if(!$resutlsSales)
			   echo $querySales.mysqli_error($dbhi);
		   else
			{
			    $SalesID = mysqli_insert_id($dbhi);
			    $_SESSION['SalesID'] =	$SalesID;
				//echo "<h1>id = $SalesID | ".$_SESSION['SalesID']."</h1>";
			}
		  }
		}
	 }
 	 elseif(isset($subOutlookEnhanced)) // 1st click
	 {
        $selQuantity = (intval($selQuantity));
		$_SESSION['Item_ID'] = "";
        if($selQuantity > 0)
		{
		    extract(GetItemOE($selQuantity));
		  //  print_r(GetItemOE($selQuantity));
         if($Item_Price > 0)
		 {
		   $GoAhead = 1;
		   $Price = $Item_Price*$selQuantity;
           $querySales = "INSERT INTO `tblSales` SET `Price` = $Price, `Quantity` = $selQuantity,  User_ID = $User_ID, `Item_ID` = $Item_ID, `IPAddress` = '$_SERVER[REMOTE_ADDR]' , `Description` = '$Item_Description'  ;         ";
		   $resutlsSales = mysqli_query($dbhi,$querySales);
		   $Item_Description = "$selQuantity Outlook Enhanced Licenses at \$$Item_Price a piece";
		   if(!$resutlsSales)
			   echo $querySales.mysqli_error($dbhi);
		   else
			{
			    $SalesID = mysqli_insert_id($dbhi);
			    $_SESSION['SalesID'] =	$SalesID;
				//echo "<h1>id = $SalesID | ".$_SESSION['SalesID']."</h1>";
				$Item_Price = $Price;
			}
		  }
		}
	 } //elseif(isset($subOutlookEnhanced)) // 1st click
 }// if userid
 ?>
 <div style="" id="divPayPal">
	 <form action="https://www.paypal.com/cgi-bin/webscr" method="post"  id="frmPayPal"  name="frmPayPal">
		 <input type="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" id="subPayPal" alt="PayPal - The safer, easier way to pay online!"  style="display:none;"/>
		 <input type="hidden" name="business" value="<?=$PayPalEmail ;?>" /><!--  seller_1315543827_biz@verizon.net  -->
		 <input type="hidden" name="return" value="http://<?=$_SERVER['SERVER_NAME'];?>/order_status.php?SalesID=<?=$SalesID  ;?>" />
	     <input type="hidden" name="cancel_return" value="http://<?=$_SERVER['SERVER_NAME'];?>/order_status.php" />
         <input type="hidden" name="cbt" value="Return to <?=$SiteName; ?>" />
	     <input type="hidden" name="invoice" value="Order_<?=$SalesID ;?>" />
	     <input type="hidden" name="item_name" value="<?=$Item_Description;?>" />
	     <input type="hidden" name="item_number" value="<?=$Item_ID;?>" />
      <? if($subscription) { ?>
		 <input type="hidden" name="cmd"  value="_xclick-subscriptions" />
		 <input type="hidden" name="rm" value="2" />
	     <input type="hidden" name="a3" value="<?=$Item_Price ;?>" />
         <? if(!$Item_Days) $Item_Days = 30;?>
	     <input type="hidden" name="p3" value="<?=$Item_Days;?>" />
	     <input type="hidden" name="t3" value="D" />
	     <input type="hidden" name="src" value="1" />
	     <input type="hidden" name="sra" value="1" />
	     <input type="hidden" name="srt" value="26" />
	     <input type="hidden" name="no_note" value="0" />
       <? } else {  //recurring payments for weekly subscription ?>
		 <input type="hidden" name="cmd"  value="_xclick" />
	     <input type="hidden" name="amount"  value="<?=$Item_Price ;?>" />
       <? } ?>
	</form>
	<?     if($GoAhead) { ?>
	  <script type="text/javascript">
	  <!--
		  answer = confirm('Do you want to go ahead to PayPal with this sale, <?=$Item_Description;?>, for a total of $<?=$Item_Price ;?>?');
		   if(answer)
			  document.frmPayPal.subPayPal.click();
	  //-->
	  </script>
	  <? } ?>

     </div>
    </div>
  </div>
</div>
<?  include("includes/footer.php"); ?>
 </body>
</html>