<?
include("./includes/siteData.php");
include("./includes/dbConnect.php");
$SiteName= 'Get Trusted Advice'; 
?><!DOCTYPE html>
<html lang="en">

<head>
    <title><?= $SiteName; ?>; Consumer and Business Email Lists: Listen to Our Free Webinar</title>
    <? include("includes/metas.php"); ?>
    <style type="text/css" title="">
        #tblContents td,
        .contentinner {
            color: #222222;
        }

        h3 {
            font-size: 16pt;
            font-weight: 700;
        }

        li {
            font-size: 11pt;
            font-weight: 700;
        }
    </style>
</head>

<body>
    <? include("includes/newhome_header.php"); include("includes/links.php");?>

     <section class="newcheckbusiness" class="text-center">

      <div id="divContent"  align="center"  id="tblContents" >
        <div class="row">
            <div class="col-md-12 text-center">
                <h1>Live Q&A Webinar; 2 PM  Eastern Time every Wednesday</h1>

               
            </div>
        </div>
      </div>


		


       <div class="row">
            <div class="col-md-12 text-center">
                <h1>Software Webinar Covers:</h1>
                
            </div>
        </div>

        	<div class="row">
			  <div class="col-md-12 text-center">
				  <p>Video Access Here:<br />
				      Audio Access: Dial-in Number: <br />
				      OR Skype:<br />
				      When prompted for room number, enter:
				      <b>670911</b> then the "<b>#</b> " key.
				  </p>
				</div>
			</div>
        <div class="row d-flex flex-sm-column-reverse flex-md-row justify-content-center flex-xs-column-reverse w-100">
            <div
                class="col-md-6 col-lg-8 col-xl-7 offset-lg-0 d-lg-flex justify-content-lg-center align-items-lg-center">
                <ul class="list-group">
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">Blast Email Marketing Machine</p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">Contact Page Marketing Machine</p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">Search Engine Extractor</p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">Yellow Pages Lead Finder</p>
                        </div>
                    </li>
                    <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">Classifieds Collector</p>
                        </div>
                    </li>

                       <li class="list-group-item d-xl-flex"><span class="material-symbols-outlined"></span>
                        <div class="d-inline-flex"><svg xmlns="http://www.w3.org/2000/svg" viewBox="-32 0 512 512"
                                width="1em" height="1em" fill="currentColor" style="font-size: 26px;">
                                <path
                                    d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z">
                                </path>
                            </svg>
                            <p class="mx-2 list-text">Realtor Marketing Machine</p>
                        </div>
                    </li>
                </ul>

            </div>
            <div class="col-md-6 col-lg-4 d-sm-flex justify-content-sm-center"><img src="images/redhead.jpg"
                    width="320px"></div>
        </div>
      </div>

      <div class="container d-flex flex-column justify-content-center align-items-center">
       <div class="wide" id="searchContent">

           <p style="font-size: 32px; font-weight: bold !important;">Opt-In Emailing For as Low as $20 per Million Sent</p>

            <p>
                Webinar will demonstrate how our industry acclaimed, user
                friendly Blast Email Marketing Machine software controls the
                sending of opt-in emails from the IP address and domain of an
                unlimited number of white-listed web hosting email servers for
                as low as $20 per million.
            </p>

            <p>
                This unique "decentralized" email sending system provides the
                highest delivery rates and is scalable into the tens of millions
                per month without ever needing an IT person to manage an email
                server.
            </p>

            <p>
                The Wednesday 2 PM Eastern, 11 AM Pacific, Q&A webinar is an
                absolute must attend to learn about the lead industry.
            </p>

            <p>
                Learn how unique software bypasses your ISP and controls the
                opt-in emailing from white listed USA based email servers
            </p>
        </div>
     </div>

    </section>


    <? include("includes/newFooter.php"); ?>
</body>

</html>