<?
	    ////////////////////// OPEN DB  ////////////////////////////////////
      include_once("./includes/siteData.php");
      include_once("./includes/dbConnect.php");
     extract($_POST);
?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <title><?=$SiteName; ?>: Your Data Files</title>
   <? include("includes/metas.php"); ?> 
   <meta http-equiv="refresh" content="1500" />

  <style>
		h5
		{
             text-align: center;
			 font-style:italic;
			 font-size: 14pt;
			 color:#FF0011;
		}
		#tblOutfiles *
		{
			font-size: 10pt;
			font-weight: 600;
		}
     #tblOutfiles a:hover
	 {
		 color: red; 
		 text-decoration: underline;
		 font-style:italic;
	 }
   </style>
  </head>

<body>
<!--   <div  id="divAll" style="margin-left: auto; margin-right: auto; width:1000px; background-color: #282828;">  -->
<? include("includes/header.php"); ?>

<div align="center" style="height:100px;"><h1>Your Download Files</h1></div>
<table border="0" align="center" cellpadding="0" cellspacing="0" id="tblContents">
	  <tr>
	   <td width="100">&nbsp;</td>
	   <td width="900" align="center" valign="top">
		<div class="wide" style="padding:0px;">
		  	<? 
               extract($_POST);
			   if(!$User_ID)
			   {
			       echo "<form method=\"post\" action='$_SERVER[PHP_SELF]' >\n";
			       include("includes/login.php");
			       echo "</form>\n";
			   }
               else 
			   {
					$dirR = "pulls";
					//echo "SEARCH DIR ".$dirR.' | '.$ID.'<br />';
					$d = dir($dirR);
					$x = array();
					while (false !== ($r = $d->read()))
					{
						if(stripos($r, $User_ID."_") === 0)
						{
							$x[$r] = true;
						}
					}
					//ksort($x);
                  if(count($x))
				   { 
					  echo "<h3>Your Address Files</h3>\n<hr />\n";
					  echo "<table id='tblOutfiles'>\n<tr><th>Created On</th><th>File Size</th><th>Download Link</th></tr>\n";;
                      foreach($x AS $K=>$V)
					   {
						  $RR =  filemtime("./pulls/".$K);
                          $TimeStamp  = date( 'm/d/y H:i',$RR);
						  $FSRaw = filesize("./pulls/".$K);
						  if($FSRaw >= 10000000)
						     $FS = number_format($FSRaw/1048576,2). " Mb" ;
						  elseif($FSRaw < 10000000 && $FSRaw >= 1000)
						     $FS = number_format($FSRaw/1024,1). " Kb" ;
						  else
						     $FS = $FSRaw. " Bytes" ;

						  $files[] = "<tr><td>$TimeStamp&nbsp;&nbsp;</td><td align='right'>$FS&nbsp;</td><td>&nbsp;&nbsp;<a href='/pulls/$K'>$K</a></td></tr>\n";
					  }
					  ksort( $files);
					  foreach($files AS $K=>$V)
						   echo $V;
     				 echo "</table>\n<hr /><h3>There is a one million record limit on file size, so for downloads larger than 1,000,000 records, you will have to wait for all of the data files  to show up</h3>\n" ;
				   }
				   else
     					  echo "<h3>There are no  Address Files ready now, if you just started one, it may take a while to show up, sometimes over an hour or more for really big downloads</h3>\n" ;
			   }// END IF USER_ID
	   ?>
			 <div align="left" style=";" id="divInstructions">
					  Your emailer program can unpack/unzip  these compressed files or you can go to this site and get this simple free proven program to unpack the files: <a href="http://www.7-zip.org/" target="_blank">Compressed File Unzipper</a>. Newer Window's OSs use this one: "Download 	.msi 	64-bit x64 1MB". <br /><br />
					When you have installed the 7zip program and downloaded the data file from us. open up Windows Explorer and find the data file you just downloaded from this site. It will have a filename like mydatafromohio.csv.tar.bz.. Now highlight the data file and right click on it, then select "Extract Here" It will create another file called mydatafromohio.csv.tar . Now  highlight the new file and right click on it, then select "Extract Here" <b>AGAIN</b>. It will create a new file mydatafromohio.csv. Now you will have the basic CSV  text file that you can open with Excel, Notepad, or any other editor or word processing program.
			</div>
        </div><!-- end search area -->    
	 </td>
     <td width="100">&nbsp; </td>
	</tr>
  </table>
	<? include("includes/footer.php"); ?>
 </body>
</html>