-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 24, 2024 at 12:57 AM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `whitelis_mackopt`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblCategories`
--

CREATE TABLE `tblCategories` (
  `Cat_ID` bigint(20) NOT NULL,
  `DBE_Code` varchar(16) DEFAULT NULL COMMENT 'Al''s like CPS',
  `My_Code` varchar(16) DEFAULT NULL COMMENT 'my code like EE',
  `Cat_Name` varchar(256) NOT NULL COMMENT 'Category Name',
  `Description` text NOT NULL,
  `Cat_Active` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `Cat_Type` varchar(12) NOT NULL,
  `ORDERBY` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='sales categories';

-- --------------------------------------------------------

--
-- Table structure for table `tblDownloadFiles`
--

CREATE TABLE `tblDownloadFiles` (
  `Filename` varchar(256) NOT NULL,
  `CreationDate` int(11) NOT NULL COMMENT 'UNIX date from PHP',
  `Size` int(11) NOT NULL,
  `DateEntered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tblUser_ID` int(11) NOT NULL COMMENT 'User ID of File Owner',
  `Display` char(1) NOT NULL DEFAULT '1' COMMENT 'controls whether the file should be shown to user'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblItems`
--

CREATE TABLE `tblItems` (
  `Item_ID` bigint(20) NOT NULL,
  `DateEntered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Item_Price` decimal(12,2) UNSIGNED NOT NULL,
  `Item_Records` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'how many records',
  `Item_Licenses` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'number of licenses',
  `Active` tinyint(3) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'display this?',
  `Item_Description` text NOT NULL,
  `hosted_button_id` varchar(64) DEFAULT NULL COMMENT 'PayPal form field for button',
  `Cat_ID` int(10) UNSIGNED NOT NULL,
  `subscription` char(1) DEFAULT '0',
  `Item_Days` tinyint(3) UNSIGNED DEFAULT NULL,
  `Intervals` tinyint(3) UNSIGNED DEFAULT '1' COMMENT 'how many payment intervals'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='table for all  products';


-- --------------------------------------------------------

--
-- Table structure for table `tblPayPalData`
--

CREATE TABLE `tblPayPalData` (
  `PP_ID` int(11) NOT NULL,
  `payment_type` varchar(64) NOT NULL,
  `PaymentStatus` varchar(20) DEFAULT NULL,
  `PaymentAmount` decimal(12,2) DEFAULT NULL,
  `PPFee` decimal(7,2) NOT NULL,
  `PaymentCurrency` varchar(20) DEFAULT NULL,
  `PayerEmail` varchar(560) DEFAULT NULL,
  `payer_id` varchar(50) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(60) NOT NULL,
  `invoice` varchar(64) NOT NULL,
  `TransactionID` varchar(30) DEFAULT NULL,
  `Camp_ID` varchar(30) DEFAULT NULL,
  `Camp_Name` varchar(60) DEFAULT NULL,
  `IPAddress` varchar(20) DEFAULT NULL,
  `PPTrans_Date` varchar(64) NOT NULL COMMENT 'PP time of transaction',
  `DateEntered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblQDs`
--

CREATE TABLE `tblQDs` (
  `QD_ID` bigint(20) UNSIGNED NOT NULL,
  `Completed` tinyint(4) NOT NULL,
  `QDFName` varchar(64) NOT NULL,
  `QDLName` varchar(64) NOT NULL,
  `QDEmail` varchar(128) NOT NULL,
  `export_name` varchar(32) NOT NULL,
  `QDPrice` float(15,2) UNSIGNED NOT NULL,
  `NumOfRecords` bigint(20) UNSIGNED NOT NULL,
  `custNumOfRecords` bigint(20) UNSIGNED NOT NULL,
  `QueryID` bigint(20) UNSIGNED NOT NULL,
  `query_description` text NOT NULL,
  `Pull_Type` varchar(64) NOT NULL,
  `DateEntered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblResellerCustomers`
--

CREATE TABLE `tblResellerCustomers` (
  `Username` varchar(32) NOT NULL DEFAULT '',
  `CPassword` varchar(128) DEFAULT NULL,
  `User_ID` int(11) NOT NULL,
  `Reseller_ID` bigint(20) NOT NULL COMMENT 'fk of reseller',
  `DateEntered` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'when id was created',
  `CompName` varchar(60) NOT NULL DEFAULT '',
  `CompAddress1` varchar(60) NOT NULL DEFAULT '',
  `CompCity` varchar(60) NOT NULL DEFAULT '',
  `CompSt` char(2) NOT NULL DEFAULT '',
  `CompZip` varchar(16) NOT NULL DEFAULT '',
  `CompPlus4` varchar(4) DEFAULT NULL,
  `CompCountry` char(2) NOT NULL DEFAULT 'US',
  `CompAreaCode` char(3) NOT NULL DEFAULT '',
  `CompPhone` varchar(16) NOT NULL DEFAULT '',
  `CompExt` varchar(6) DEFAULT NULL,
  `CompURL` varchar(60) DEFAULT NULL,
  `CompEmail` varchar(50) NOT NULL,
  `CompFName` varchar(30) NOT NULL,
  `CompLName` varchar(30) NOT NULL,
  `Stopped` char(1) DEFAULT 'N',
  `RefererSource` varchar(32) DEFAULT NULL,
  `RefererType` varchar(32) DEFAULT NULL,
  `DataNeeded` varchar(1024) DEFAULT NULL,
  `CompProvince` varchar(48) DEFAULT NULL,
  `IPAddress` varchar(24) DEFAULT NULL,
  `Admin` tinyint(3) UNSIGNED DEFAULT NULL,
  `ResetCode` varchar(32) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblResellersUsersCredits`
--

CREATE TABLE `tblResellersUsersCredits` (
  `Credit_ID` bigint(20) NOT NULL,
  `Credits` bigint(20) NOT NULL COMMENT 'credits & debits',
  `User_ID` bigint(20) NOT NULL,
  `DateEntered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Table structure for table `tblSales`
--

CREATE TABLE `tblSales` (
  `SalesID` bigint(20) UNSIGNED NOT NULL,
  `Order_No` varchar(128) NOT NULL COMMENT 'The order id forwarded to cc handler, unique',
  `SalesDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Price` decimal(12,2) UNSIGNED NOT NULL COMMENT 'Price ',
  `ReferenceNo` int(11) DEFAULT NULL,
  `payment_status` smallint(6) DEFAULT NULL,
  `Description` varchar(512) NOT NULL,
  `User_ID` bigint(20) UNSIGNED NOT NULL COMMENT 'who bought it',
  `Completed` tinyint(4) DEFAULT NULL COMMENT 'was it paid',
  `Error` varchar(64) DEFAULT NULL COMMENT 'Why payment was rejected',
  `IPAddress` varchar(64) NOT NULL,
  `Item_ID` bigint(20) UNSIGNED NOT NULL,
  `authcode` varchar(32) DEFAULT NULL,
  `response_reason` varchar(64) DEFAULT NULL,
  `txn_id` varchar(64) DEFAULT NULL,
  `CCPayment` decimal(12,2) UNSIGNED DEFAULT NULL COMMENT 'actual payment'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblVehicleYearMakeModelAll`
--

CREATE TABLE `tblVehicleYearMakeModelAll` (
  `Year` char(4) NOT NULL,
  `Make` varchar(256) NOT NULL,
  `Model` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='make model and year for vehicle table';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblCategories`
--
ALTER TABLE `tblCategories`
  ADD PRIMARY KEY (`Cat_ID`),
  ADD UNIQUE KEY `Cat_Type` (`Cat_Type`);

--
-- Indexes for table `tblDownloadFiles`
--
ALTER TABLE `tblDownloadFiles`
  ADD UNIQUE KEY `Filename` (`Filename`);

--
-- Indexes for table `tblItems`
--
ALTER TABLE `tblItems`
  ADD PRIMARY KEY (`Item_ID`);

--
-- Indexes for table `tblPayPalData`
--
ALTER TABLE `tblPayPalData`
  ADD PRIMARY KEY (`PP_ID`);

--
-- Indexes for table `tblQDs`
--
ALTER TABLE `tblQDs`
  ADD PRIMARY KEY (`QD_ID`);

--
-- Indexes for table `tblResellerCustomers`
--
ALTER TABLE `tblResellerCustomers`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `tblResellersUsersCredits`
--
ALTER TABLE `tblResellersUsersCredits`
  ADD PRIMARY KEY (`Credit_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `tblSales`
--
ALTER TABLE `tblSales`
  ADD PRIMARY KEY (`SalesID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblCategories`
--
ALTER TABLE `tblCategories`
  MODIFY `Cat_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblItems`
--
ALTER TABLE `tblItems`
  MODIFY `Item_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tblPayPalData`
--
ALTER TABLE `tblPayPalData`
  MODIFY `PP_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tblQDs`
--
ALTER TABLE `tblQDs`
  MODIFY `QD_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tblResellerCustomers`
--
ALTER TABLE `tblResellerCustomers`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131608;

--
-- AUTO_INCREMENT for table `tblSales`
--
ALTER TABLE `tblSales`
  MODIFY `SalesID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
